<?php
// includes/header.php - 完整版（仅修改学校/培训机构侧边栏菜单）
$currentUser = getCurrentUser();
$isLoggedIn = $currentUser !== null;
$currentRoute = $_GET['route'] ?? 'dashboard';

// 获取站点设置
$siteName = getSetting('site_name') ?: SITE_NAME;
$logo = getSetting('logo');

// 检查是否登录页面（使用简化布局）
$isAuthPage = in_array($currentRoute, ['login', 'register', 'forgot', 'reset', 'verify', 'logout']);

// 注意：getRoleLabel() 已经在 functions.php 中定义了
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5, user-scalable=yes" />
    <meta name="theme-color" content="#2f6fed" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <?php if ($isLoggedIn): ?>
    <meta name="user-id" content="<?= $currentUser['id'] ?? 0 ?>">
    <meta name="user-role" content="<?= $currentUser['role'] ?? '' ?>">
    <?php endif; ?>
    <title><?= h($siteName) ?> · 中小学数学教练</title>
    <link rel="stylesheet" href="css/styles.css" />
    <link rel="stylesheet" href="css/admin.css" />
    <style>
        /* 移动端点击优化 */
        * {
            -webkit-tap-highlight-color: transparent;
        }
        input, select, textarea, button {
            font-size: 16px !important; /* 防止iOS缩放 */
        }
        @media (max-width: 480px) {
            .hide-mobile { display: none !important; }
        }
        @media (min-width: 481px) and (max-width: 768px) {
            .hide-tablet { display: none !important; }
        }
        @media (min-width: 769px) {
            .hide-desktop { display: none !important; }
        }
        <?php if ($isAuthPage): ?>
        body { 
            background: #f5f7fa; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            min-height: 100vh; 
            margin: 0; 
            padding: 16px;
        }
        .auth-container { 
            max-width: 440px; 
            width: 100%; 
            margin: 0 auto; 
        }
        .auth-container .card { 
            padding: 20px; 
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,.08);
        }
        @media (min-width: 480px) {
            .auth-container .card { padding: 24px; }
        }
        @media (min-width: 769px) {
            .auth-container .card { padding: 30px; }
        }
        .auth-container .brand { 
            text-align: center; 
            margin-bottom: 20px; 
        }
        .auth-container .brand .logo { 
            font-size: 36px; 
            display: block; 
        }
        @media (min-width: 480px) {
            .auth-container .brand .logo { font-size: 42px; }
        }
        .auth-container .brand h1 { 
            font-size: 20px; 
            margin: 6px 0 2px; 
            color: #2f6fed; 
        }
        @media (min-width: 480px) {
            .auth-container .brand h1 { font-size: 24px; margin: 8px 0 4px; }
        }
        .auth-container .brand p { 
            color: #6b7280; 
            font-size: 13px; 
        }
        @media (min-width: 480px) {
            .auth-container .brand p { font-size: 14px; }
        }
        .auth-container .brand img {
            max-height: 50px;
            border-radius: 8px;
        }
        @media (min-width: 480px) {
            .auth-container .brand img { max-height: 60px; }
        }
        .role-fields { display: none; }
        .role-fields.active { display: block; }
        <?php endif; ?>
        /* ============================================================ */
    /* 主题变体 */
    /* ============================================================ */
    .theme-green {
        --header-bg: linear-gradient(90deg, #15803d, #22c55e);
        --sidebar-active: #16a34a;
    }
    .theme-green .stat-number { color: #16a34a; }
    .theme-green .btn { background: #16a34a; }
    .theme-green .btn:hover { background: #15803d; }
    .theme-green .nav-item.active { background: #16a34a; }
    .theme-green .topbar { background: linear-gradient(90deg, #15803d, #22c55e); }
    .theme-green .grade-tag { color: #16a34a; }
    .theme-green .grade-sep { border-left-color: #16a34a; }
    .theme-green .stage-banner { background: linear-gradient(90deg, #15803d, #22c55e); }
    .theme-green .stage-banner.sm { background: #e7f6ee; }
    .theme-green .stage-banner.sm .stage-name { color: #16a34a; }
    .theme-green .chart-bar { background: #16a34a; }

    .theme-purple {
        --header-bg: linear-gradient(90deg, #5b21b6, #8b5cf6);
        --sidebar-active: #7c3aed;
    }
    .theme-purple .stat-number { color: #7c3aed; }
    .theme-purple .btn { background: #7c3aed; }
    .theme-purple .btn:hover { background: #6d28d9; }
    .theme-purple .nav-item.active { background: #7c3aed; }
    .theme-purple .topbar { background: linear-gradient(90deg, #5b21b6, #8b5cf6); }
    .theme-purple .grade-tag { color: #7c3aed; }
    .theme-purple .grade-sep { border-left-color: #7c3aed; }
    .theme-purple .stage-banner { background: linear-gradient(90deg, #5b21b6, #8b5cf6); }
    .theme-purple .stage-banner.sm { background: #ede9fe; }
    .theme-purple .stage-banner.sm .stage-name { color: #7c3aed; }
    .theme-purple .chart-bar { background: #7c3aed; }

    .theme-orange {
        --header-bg: linear-gradient(90deg, #b45309, #f59e0b);
        --sidebar-active: #d97706;
    }
    .theme-orange .stat-number { color: #d97706; }
    .theme-orange .btn { background: #d97706; }
    .theme-orange .btn:hover { background: #b45309; }
    .theme-orange .nav-item.active { background: #d97706; }
    .theme-orange .topbar { background: linear-gradient(90deg, #b45309, #f59e0b); }
    .theme-orange .grade-tag { color: #d97706; }
    .theme-orange .grade-sep { border-left-color: #d97706; }
    .theme-orange .stage-banner { background: linear-gradient(90deg, #b45309, #f59e0b); }
    .theme-orange .stage-banner.sm { background: #fef3c7; }
    .theme-orange .stage-banner.sm .stage-name { color: #d97706; }
    .theme-orange .chart-bar { background: #d97706; }
</style>
</head>
<body>
<?php if ($isAuthPage): ?>
    <!-- 登录/注册专用布局 -->
    <div class="auth-container">
        <div class="brand">
            <?php if ($logo): ?>
            <img src="<?= h($logo) ?>" alt="logo">
            <?php else: ?>
            <span class="logo">∑</span>
            <?php endif; ?>
            <h1><?= h($siteName) ?></h1>
            <p>中小学数学技巧教练</p>
        </div>
        <?php 
        $authPageFile = 'pages/' . $currentRoute . '.php';
        if (file_exists($authPageFile)) {
            include $authPageFile;
        }
        ?>
    </div>
<?php else: ?>
<!-- 侧边栏 -->
<aside class="sidebar" id="sidebar" role="navigation" aria-label="主导航">
    <div class="sidebar-header">
        <?php if ($logo): ?>
        <img src="<?= h($logo) ?>" alt="logo">
        <?php else: ?>
        <span class="logo">∑</span>
        <?php endif; ?>
        <span class="brand-text"><?= h($siteName) ?></span>
        <!-- 桌面端折叠按钮 -->
        <button class="sidebar-toggle hide-mobile" id="sidebarToggle" aria-label="折叠侧边栏">◀</button>
        </div>
        <nav class="sidebar-nav">
            <a href="?route=dashboard" class="nav-item <?= $currentRoute === 'dashboard' ? 'active' : '' ?>">
                <span class="icon">📊</span>
                <span class="label">控制台</span>
            </a>
            <a href="?route=ai_chat" class="nav-item <?= $route === 'ai_chat' ? 'active' : '' ?>">
    <span class="icon">🤖</span>
    <span class="label">智慧学习</span>
</a>
            <?php if ($isLoggedIn && $currentUser['role'] === 'admin'): ?>
            <a href="?route=users" class="nav-item <?= $currentRoute === 'users' ? 'active' : '' ?>">
                <span class="icon">👥</span>
                <span class="label">用户管理</span>
            </a>
            <a href="?route=settings" class="nav-item <?= $currentRoute === 'settings' ? 'active' : '' ?>">
                <span class="icon">⚙️</span>
                <span class="label">网站设置</span>
            </a>
            <a href="?route=ai_models" class="nav-item <?= $route === 'ai_models' ? 'active' : '' ?>">
    <span class="icon">⚙️</span>
    <span class="label">模型设置</span>
</a>
            <a href="?route=email" class="nav-item <?= $currentRoute === 'email' ? 'active' : '' ?>">
                <span class="icon">📧</span>
                <span class="label">邮箱设置</span>
            </a>
            <?php endif; ?>
            
            <?php if ($isLoggedIn && $currentUser['role'] === 'student'): ?>
            <!-- 学生菜单 -->
            <a href="?route=learning" class="nav-item <?= $currentRoute === 'learning' ? 'active' : '' ?>">
                <span class="icon">📚</span>
                <span class="label">学习路径</span>
            </a>
            <a href="?route=review" class="nav-item <?= $currentRoute === 'review' ? 'active' : '' ?>">
                <span class="icon">🔍</span>
                <span class="label">薄弱点复习</span>
                <span class="badge" id="weakBadge">0</span>
            </a>
            <a href="?route=progress" class="nav-item <?= $currentRoute === 'progress' ? 'active' : '' ?>">
                <span class="icon">📈</span>
                <span class="label">我的进度</span>
            </a>
            <?php endif; ?>
            
            <?php if ($isLoggedIn && $currentUser['role'] === 'parent'): ?>
            <!-- 家长菜单 -->
            <?php
            $childrenIds = !empty($currentUser['children']) ? explode(',', $currentUser['children']) : [];
            $firstChildId = !empty($childrenIds) ? $childrenIds[0] : 0;
            ?>
            <a href="?route=learning<?= $firstChildId ? '&child_id=' . $firstChildId : '' ?>" class="nav-item <?= $currentRoute === 'learning' ? 'active' : '' ?>">
                <span class="icon">📚</span>
                <span class="label">孩子学习路径</span>
            </a>
            <a href="?route=review<?= $firstChildId ? '&child_id=' . $firstChildId : '' ?>" class="nav-item <?= $currentRoute === 'review' ? 'active' : '' ?>">
                <span class="icon">🔍</span>
                <span class="label">孩子薄弱点</span>
            </a>
            <a href="?route=progress<?= $firstChildId ? '&child_id=' . $firstChildId : '' ?>" class="nav-item <?= $currentRoute === 'progress' ? 'active' : '' ?>">
                <span class="icon">📈</span>
                <span class="label">孩子进度</span>
            </a>
            <?php endif; ?>
            
            <?php if ($isLoggedIn && ($currentUser['role'] === 'school' || $currentUser['role'] === 'training')): ?>
            <!-- ============================================================ -->
            <!-- 【修改点】学校/培训机构菜单 - 改为调用 showStudentSelector() -->
            <!-- ============================================================ -->
            <a href="javascript:void(0)" class="nav-item <?= $currentRoute === 'learning' ? 'active' : '' ?>" onclick="showStudentSelector('learning')">
                <span class="icon">📚</span>
                <span class="label">学生学习路径</span>
            </a>
            <a href="javascript:void(0)" class="nav-item <?= $currentRoute === 'review' ? 'active' : '' ?>" onclick="showStudentSelector('review')">
                <span class="icon">🔍</span>
                <span class="label">学生薄弱点</span>
            </a>
            <a href="javascript:void(0)" class="nav-item <?= $currentRoute === 'progress' ? 'active' : '' ?>" onclick="showStudentSelector('progress')">
                <span class="icon">📈</span>
                <span class="label">学生进度</span>
            </a>
            <?php endif; ?>
            
            <a href="?route=profile" class="nav-item <?= $currentRoute === 'profile' ? 'active' : '' ?>">
                <span class="icon">👤</span>
                <span class="label">个人信息</span>
            </a>
            <a href="?route=help" class="nav-item <?= $currentRoute === 'help' ? 'active' : '' ?>">
                <span class="icon">❓</span>
                <span class="label">帮助</span>
            </a>
        </nav>
<div class="sidebar-footer">
    <div class="user-info">
        <span class="avatar"><?= $isLoggedIn ? ($currentUser['gender'] === '女' ? '👩' : '👤') : '👤' ?></span>
        <div>
            <div class="username"><?= $isLoggedIn ? h($currentUser['name'] ?? $currentUser['username']) : '未登录' ?></div>
            <div class="role-text"><?= $isLoggedIn ? getRoleLabel($currentUser['role']) : '' ?></div>
        </div>
    </div>
    <div class="collapse-hint hide-mobile">💡 点击顶部 ◀ 折叠侧边栏</div>
    <?php if ($isLoggedIn): ?>
    <button class="btn-logout" onclick="window.location.href='?route=logout'">退出</button>
    <?php else: ?>
    <a href="?route=login" class="btn-logout" style="text-align:center;text-decoration:none;display:block;">登录</a>
    <?php endif; ?>
</div>
    </aside>

    <main class="main-content" role="main">
        <header class="topbar">
            <div class="topbar-left">
                <button class="menu-btn hide-desktop" id="menuBtn" aria-label="打开菜单">☰</button>
                <div class="brand">
                    <?php if ($logo): ?>
                    <img src="<?= h($logo) ?>" alt="logo">
                    <?php else: ?>
                    <span class="logo">∑</span>
                    <?php endif; ?>
                    <div>
                        <div class="brand-title"><?= h($siteName) ?></div>
                        <div class="brand-sub">中小学数学技巧教练</div>
                    </div>
                </div>
            </div>
            <div class="topbar-right">
                <?php if ($isLoggedIn): ?>
                <span class="role-badge"><?= getRoleLabel($currentUser['role']) ?></span>
                <?php endif; ?>
                <div class="theme-selector">
                    <label>主题</label>
                    <select id="themeSelect">
                        <option value="default">默认蓝</option>
                        <option value="green">清新绿</option>
                        <option value="purple">典雅紫</option>
                        <option value="orange">暖阳橙</option>
                        <option value="auto">🌓 自动（跟随系统）</option>
                    </select>
                </div>
            </div>
        </header>
        <div id="view" class="view">
<?php endif; ?>