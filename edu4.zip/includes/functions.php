<?php
// includes/functions.php - 所有辅助函数

/**
 * 获取用户IP
 */
function getUserIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    }
}

/**
 * 根据IP获取用户大致位置和天气
 * 使用免费API: wttr.in
 */
function getUserWeather() {
    $ip = getUserIP();
    
    // 如果是本地IP，使用默认位置（北京）
    if ($ip === '127.0.0.1' || $ip === '::1' || strpos($ip, '192.168.') === 0 || strpos($ip, '10.') === 0) {
        $location = 'Beijing';
    } else {
        // 使用 ip-api.com 获取位置（免费，无需API key）
        $locationData = @file_get_contents("http://ip-api.com/json/{$ip}?fields=status,message,country,city,lat,lon");
        if ($locationData) {
            $data = json_decode($locationData, true);
            if ($data && isset($data['status']) && $data['status'] === 'success') {
                $location = $data['city'] . ',' . $data['country'];
            } else {
                $location = 'Beijing';
            }
        } else {
            $location = 'Beijing';
        }
    }
    
    // 使用 wttr.in 获取天气（免费，无需API key）
    $weatherData = @file_get_contents("https://wttr.in/{$location}?format=%C|%t|%w|%h");
    if ($weatherData) {
        $parts = explode('|', $weatherData);
        return [
            'location' => $location,
            'condition' => trim($parts[0] ?? '未知'),
            'temp' => trim($parts[1] ?? '--'),
            'wind' => trim($parts[2] ?? '--'),
            'humidity' => trim($parts[3] ?? '--'),
            'icon' => getWeatherIcon($parts[0] ?? '')
        ];
    }
    
    return [
        'location' => $location,
        'condition' => '获取天气失败',
        'temp' => '--',
        'wind' => '--',
        'humidity' => '--',
        'icon' => '🌤'
    ];
}

/**
 * 根据天气状况返回对应图标
 */
function getWeatherIcon($condition) {
    $condition = strtolower($condition);
    if (strpos($condition, 'sun') !== false || strpos($condition, 'clear') !== false) return '☀️';
    if (strpos($condition, 'cloud') !== false) {
        if (strpos($condition, 'partly') !== false) return '⛅';
        return '☁️';
    }
    if (strpos($condition, 'rain') !== false || strpos($condition, 'drizzle') !== false) return '🌧';
    if (strpos($condition, 'thunder') !== false || strpos($condition, 'storm') !== false) return '⛈';
    if (strpos($condition, 'snow') !== false) return '❄️';
    if (strpos($condition, 'fog') !== false || strpos($condition, 'mist') !== false) return '🌫';
    return '🌤';
}

/**
 * 获取12个时段配置
 */
function getTimeSlots() {
    return [
        ['start' => 0, 'end' => 2, 'name' => '深夜', 'emoji' => '🌙', 'bgClass' => 'bg-night', 'label' => '🌙 深夜 · 万籁俱寂'],
        ['start' => 2, 'end' => 5, 'name' => '凌晨', 'emoji' => '🌃', 'bgClass' => 'bg-night', 'label' => '🌃 凌晨 · 星光点点'],
        ['start' => 5, 'end' => 7, 'name' => '黎明', 'emoji' => '🌅', 'bgClass' => 'bg-dawn', 'label' => '🌅 黎明 · 东方既白'],
        ['start' => 7, 'end' => 9, 'name' => '早晨', 'emoji' => '🌤', 'bgClass' => 'bg-morning', 'label' => '🌤 早晨 · 清新晨光'],
        ['start' => 9, 'end' => 11, 'name' => '上午', 'emoji' => '☀️', 'bgClass' => 'bg-day', 'label' => '☀️ 上午 · 阳光明媚'],
        ['start' => 11, 'end' => 13, 'name' => '中午', 'emoji' => '🌞', 'bgClass' => 'bg-noon', 'label' => '🌞 中午 · 烈日当空'],
        ['start' => 13, 'end' => 15, 'name' => '午后', 'emoji' => '☀️', 'bgClass' => 'bg-afternoon', 'label' => '☀️ 午后 · 暖阳和煦'],
        ['start' => 15, 'end' => 17, 'name' => '下午', 'emoji' => '🌤', 'bgClass' => 'bg-day', 'label' => '🌤 下午 · 斜阳微醺'],
        ['start' => 17, 'end' => 19, 'name' => '黄昏', 'emoji' => '🌇', 'bgClass' => 'bg-sunset', 'label' => '🌇 黄昏 · 落日熔金'],
        ['start' => 19, 'end' => 21, 'name' => '傍晚', 'emoji' => '🌆', 'bgClass' => 'bg-dusk', 'label' => '🌆 傍晚 · 华灯初上'],
        ['start' => 21, 'end' => 23, 'name' => '夜晚', 'emoji' => '🌙', 'bgClass' => 'bg-night', 'label' => '🌙 夜晚 · 月明星稀'],
        ['start' => 23, 'end' => 24, 'name' => '深夜', 'emoji' => '🌙', 'bgClass' => 'bg-night', 'label' => '🌙 深夜 · 夜深人静']
    ];
}

/**
 * 获取当前时段
 */
function getCurrentTimeSlot() {
    $slots = getTimeSlots();
    $hour = (int)date('H');
    $minute = (int)date('i');
    $totalMinutes = $hour * 60 + $minute;
    
    foreach ($slots as $slot) {
        $startMin = $slot['start'] * 60;
        $endMin = $slot['end'] * 60;
        
        if ($slot['end'] < $slot['start']) {
            if ($totalMinutes >= $startMin || $totalMinutes < $endMin) {
                return $slot;
            }
        } else {
            if ($totalMinutes >= $startMin && $totalMinutes < $endMin) {
                return $slot;
            }
        }
    }
    return $slots[0];
}

/**
 * 获取农历日期
 */
function getLunarDate() {
    // 农历每月天数（2000-2100年）
    $lunarMonths = [
        0 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        1 => [0,30,29,30,29,30,29,29,30,29,30,29,30],
        2 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        3 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        4 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        5 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        6 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        7 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        8 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        9 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        10 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        11 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        12 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        13 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        14 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        15 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        16 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        17 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        18 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        19 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        20 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        21 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        22 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        23 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        24 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        25 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        26 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        27 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        28 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        29 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        30 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        31 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        32 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        33 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        34 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        35 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        36 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        37 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        38 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        39 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        40 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        41 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        42 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        43 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        44 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        45 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        46 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        47 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        48 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        49 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        50 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        51 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        52 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        53 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        54 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        55 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        56 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        57 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        58 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        59 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        60 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        61 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        62 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        63 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        64 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        65 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        66 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        67 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        68 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        69 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        70 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        71 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        72 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        73 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        74 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        75 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        76 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        77 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        78 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        79 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        80 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        81 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        82 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        83 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        84 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        85 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        86 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        87 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        88 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        89 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        90 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        91 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        92 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        93 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        94 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        95 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        96 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        97 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        98 => [0,29,30,29,30,29,30,29,30,29,30,29,30],
        99 => [0,30,29,30,29,30,29,30,29,30,29,30,29],
        100 => [0,29,30,29,30,29,30,29,30,29,30,29,30]
    ];
    
    // 农历闰月信息（2000-2100年）
    $lunarLeap = [
        2000 => 4, 2001 => 4, 2002 => 5, 2003 => 4, 2004 => 3,
        2005 => 6, 2006 => 7, 2007 => 5, 2008 => 5, 2009 => 5,
        2010 => 5, 2011 => 4, 2012 => 5, 2013 => 4, 2014 => 9,
        2015 => 6, 2016 => 6, 2017 => 6, 2018 => 6, 2019 => 4,
        2020 => 4, 2021 => 4, 2022 => 5, 2023 => 4, 2024 => 3,
        2025 => 6, 2026 => 7, 2027 => 5, 2028 => 5, 2029 => 5,
        2030 => 5, 2031 => 4, 2032 => 5, 2033 => 4, 2034 => 9,
        2035 => 6, 2036 => 6, 2037 => 6, 2038 => 6, 2039 => 4,
        2040 => 4, 2041 => 4, 2042 => 5, 2043 => 4, 2044 => 3,
        2045 => 6, 2046 => 7, 2047 => 5, 2048 => 5, 2049 => 5,
        2050 => 5, 2051 => 4, 2052 => 5, 2053 => 4, 2054 => 9,
        2055 => 6, 2056 => 6, 2057 => 6, 2058 => 6, 2059 => 4,
        2060 => 4, 2061 => 4, 2062 => 5, 2063 => 4, 2064 => 3,
        2065 => 6, 2066 => 7, 2067 => 5, 2068 => 5, 2069 => 5,
        2070 => 5, 2071 => 4, 2072 => 5, 2073 => 4, 2074 => 9,
        2075 => 6, 2076 => 6, 2077 => 6, 2078 => 6, 2079 => 4,
        2080 => 4, 2081 => 4, 2082 => 5, 2083 => 4, 2084 => 3,
        2085 => 6, 2086 => 7, 2087 => 5, 2088 => 5, 2089 => 5,
        2090 => 5, 2091 => 4, 2092 => 5, 2093 => 4, 2094 => 9,
        2095 => 6, 2096 => 6, 2097 => 6, 2098 => 6, 2099 => 4,
        2100 => 4
    ];
    
    // 2000年1月1日 = 农历己卯年十一月廿五
    $baseDate = mktime(0, 0, 0, 1, 1, 2000);
    $currentDate = mktime(0, 0, 0, (int)date('m'), (int)date('d'), (int)date('Y'));
    $diffDays = floor(($currentDate - $baseDate) / 86400);
    
    $year = 2000;
    $month = 11;
    $day = 25;
    $remaining = $diffDays;
    
    while ($remaining > 0) {
        $yearIndex = $year - 2000;
        if ($yearIndex < 0 || $yearIndex >= count($lunarMonths)) break;
        
        $monthDays = $lunarMonths[$yearIndex][$month] ?? 29;
        if ($remaining >= $monthDays) {
            $remaining -= $monthDays;
            $month++;
            if ($month > 12) {
                $month = 1;
                $year++;
                if (isset($lunarLeap[$year]) && $month == $lunarLeap[$year]) {
                    $leapDays = $lunarMonths[$yearIndex][13] ?? 29;
                    if ($remaining >= $leapDays) {
                        $remaining -= $leapDays;
                        $month++;
                    }
                }
            }
        } else {
            $day = $remaining + 1;
            $remaining = 0;
        }
    }
    
    $lunarYear = $year;
    $lunarMonth = $month;
    $lunarDay = $day;
    
    // 月相计算
    $moonPhase = getMoonPhase($lunarDay);
    
    return [
        'year' => $lunarYear,
        'month' => $lunarMonth,
        'day' => $lunarDay,
        'phase' => $moonPhase['name'],
        'phase_emoji' => $moonPhase['emoji'],
        'phase_icon' => $moonPhase['icon'],
        'phase_desc' => $moonPhase['description'],
        'phase_detail' => $moonPhase['detail']
    ];
}

/**
 * 根据农历日期计算月相
 */
function getMoonPhase($lunarDay) {
    // 月相映射：农历1-30日对应不同月相
    if ($lunarDay <= 2) {
        return ['name' => '新月', 'emoji' => '🌑', 'icon' => 'new_moon', 'description' => '朔月', 'detail' => '月球位于地球和太阳之间，不可见'];
    } elseif ($lunarDay <= 7) {
        return ['name' => '蛾眉月', 'emoji' => '🌒', 'icon' => 'waxing_crescent', 'description' => '月初的弯月', 'detail' => '月牙初现，如蛾眉'];
    } elseif ($lunarDay <= 9) {
        return ['name' => '上弦月', 'emoji' => '🌓', 'icon' => 'first_quarter', 'description' => '上弦月', 'detail' => '月相半圆，亮面朝西'];
    } elseif ($lunarDay <= 14) {
        return ['name' => '盈凸月', 'emoji' => '🌔', 'icon' => 'waxing_gibbous', 'description' => '盈凸月', 'detail' => '超过半圆，趋向满月'];
    } elseif ($lunarDay <= 16) {
        return ['name' => '满月', 'emoji' => '🌕', 'icon' => 'full_moon', 'description' => '望月', 'detail' => '地球位于月球和太阳之间，月面全亮'];
    } elseif ($lunarDay <= 21) {
        return ['name' => '亏凸月', 'emoji' => '🌖', 'icon' => 'waning_gibbous', 'description' => '亏凸月', 'detail' => '开始亏损，趋向半月'];
    } elseif ($lunarDay <= 23) {
        return ['name' => '下弦月', 'emoji' => '🌗', 'icon' => 'last_quarter', 'description' => '下弦月', 'detail' => '月相半圆，亮面朝东'];
    } else {
        return ['name' => '残月', 'emoji' => '🌘', 'icon' => 'waning_crescent', 'description' => '月末的弯月', 'detail' => '月牙渐细'];
    }
}

/**
 * 获取月相SVG图标
 */
function getMoonPhaseSVG($phase) {
    $icons = [
        'new_moon' => '<circle cx="50" cy="50" r="40" fill="#2d3748" stroke="#718096" stroke-width="2"/>',
        'waxing_crescent' => '<circle cx="50" cy="50" r="40" fill="#2d3748" stroke="#718096" stroke-width="2"/><path d="M50 10 A40 40 0 0 1 50 90 A30 30 0 0 0 50 10" fill="#f6e05e"/>',
        'first_quarter' => '<circle cx="50" cy="50" r="40" fill="#2d3748" stroke="#718096" stroke-width="2"/><path d="M50 10 A40 40 0 0 1 50 90 A40 40 0 0 0 50 10" fill="#f6e05e"/>',
        'waxing_gibbous' => '<circle cx="50" cy="50" r="40" fill="#2d3748" stroke="#718096" stroke-width="2"/><path d="M50 10 A40 40 0 0 1 50 90 A35 40 0 0 0 50 10" fill="#f6e05e"/>',
        'full_moon' => '<circle cx="50" cy="50" r="40" fill="#f6e05e" stroke="#d69e2e" stroke-width="2"/><circle cx="35" cy="35" r="8" fill="#ecc94b" opacity="0.3"/><circle cx="65" cy="60" r="6" fill="#ecc94b" opacity="0.2"/>',
        'waning_gibbous' => '<circle cx="50" cy="50" r="40" fill="#2d3748" stroke="#718096" stroke-width="2"/><path d="M50 10 A40 40 0 0 0 50 90 A35 40 0 0 1 50 10" fill="#f6e05e"/>',
        'last_quarter' => '<circle cx="50" cy="50" r="40" fill="#2d3748" stroke="#718096" stroke-width="2"/><path d="M50 10 A40 40 0 0 0 50 90 A40 40 0 0 1 50 10" fill="#f6e05e"/>',
        'waning_crescent' => '<circle cx="50" cy="50" r="40" fill="#2d3748" stroke="#718096" stroke-width="2"/><path d="M50 10 A40 40 0 0 0 50 90 A30 30 0 0 1 50 10" fill="#f6e05e"/>'
    ];
    
    return $icons[$phase] ?? $icons['new_moon'];
}
// 安全输出
function h($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

// 获取站点设置
function getSetting($key, $default = null) {
    static $settings = null;
    if ($settings === null) {
        try {
            $pdo = getDB();
            $stmt = $pdo->query("SELECT * FROM site_settings");
            $settings = [];
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $settings[$row['key_name']] = $row['value'];
            }
        } catch (Exception $e) {
            $settings = [];
            error_log("站点设置加载失败: " . $e->getMessage());
        }
    }
    return $settings[$key] ?? $default;
}

// 获取统计信息
function getStats() {
    $pdo = getDB();
    $stats = [];
    
    $stats['total_users'] = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $stats['active_users'] = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 'active'")->fetchColumn();
    
    $roles = ['admin', 'parent', 'student', 'school', 'training'];
    foreach ($roles as $role) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = ?");
        $stmt->execute([$role]);
        $stats['role_' . $role] = $stmt->fetchColumn();
    }
    
    $stats['total_learns'] = $pdo->query("SELECT COUNT(*) FROM learning_records")->fetchColumn();
    $stats['today_learns'] = $pdo->query("SELECT COUNT(*) FROM learning_records WHERE DATE(created_at) = CURDATE()")->fetchColumn();
    $stats['total_weak'] = $pdo->query("SELECT COUNT(*) FROM weak_points WHERE cleared = FALSE")->fetchColumn();
    
    return $stats;
}

// 获取学习趋势（近7天）
function getLearningTrend() {
    $pdo = getDB();
    $data = [];
    for ($i = 6; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-$i days"));
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM learning_records WHERE DATE(created_at) = ?");
        $stmt->execute([$date]);
        $data[] = ['date' => $date, 'count' => (int)$stmt->fetchColumn()];
    }
    return $data;
}

// 获取用户角色中文名
function getRoleLabel($role) {
    $map = [
        'admin' => '管理员',
        'parent' => '家长',
        'student' => '学生',
        'school' => '学校',
        'training' => '培训机构'
    ];
    return $map[$role] ?? $role;
}

// 获取状态徽章
function getStatusBadge($status) {
    $map = [
        'active' => '<span class="status-badge active">正常</span>',
        'inactive' => '<span class="status-badge inactive">已停用</span>',
        'pending' => '<span class="status-badge pending">待审核</span>'
    ];
    return $map[$status] ?? $status;
}

// 生成纯数字验证码
function generateCode($length = 6) {
    return str_pad((string)rand(0, pow(10, $length) - 1), $length, '0', STR_PAD_LEFT);
}

// ============================================================
// 【修复】初始化 PHPMailer 实例 - 统一读取站点配置
// ============================================================
function getMailerInstance() {
    // 引入 Composer 自动加载文件
    $vendorPath = __DIR__ . '/../vendor/autoload.php';
    if (!file_exists($vendorPath)) {
        error_log('vendor/autoload.php 不存在，请执行 composer update');
        throw new Exception("vendor 目录不存在，请先执行 composer update 安装依赖");
    }
    require_once $vendorPath;

    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    
    // 从站点设置读取 SMTP 配置
    $mail->isSMTP();
    $mail->Host = getSetting('smtp_host', 'smtp.qq.com');
    $mail->SMTPAuth = true;
    $mail->Username = getSetting('smtp_username', '');
    $mail->Password = getSetting('smtp_password', '');
    $mail->Port = (int)getSetting('smtp_port', 587);
    $mail->CharSet = 'UTF-8';
    $mail->SMTPDebug = 0; // 生产环境设为0，调试时可改为2
    
    // 加密方式
    $secure = getSetting('smtp_secure', 'tls');
    if ($secure === 'ssl') {
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
    } elseif ($secure === 'tls') {
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
    }
    
    // 【关键修复】发件人邮箱：优先使用 smtp_from，兼容 mail_from
    $fromEmail = getSetting('smtp_from', '');
    if (empty($fromEmail)) {
        $fromEmail = getSetting('mail_from', '');
    }
    if (empty($fromEmail)) {
        $fromEmail = $mail->Username;
    }
    
    $fromName = getSetting('site_name', '教育平台');
    $mail->setFrom($fromEmail, $fromName);
    
    return $mail;
}

// ============================================================
// 【修复】发送验证邮件 - 修复变量作用域问题
// ============================================================
function sendVerificationEmail($email, $code = null, $type = 'register') {
    // 1. 如果 $code 为空，自动生成
    if (empty($code)) {
        $code = generateCode();
        error_log('警告: sendVerificationEmail 调用时未传入验证码，已自动生成: ' . $code);
    }
    
    // 2. 邮箱格式校验
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        error_log('邮件发送失败: 无效的邮箱地址 -> ' . $email);
        return false;
    }
    
    $pdo = getDB();
    
    // 根据类型设置邮件主题
    $subjectMap = [
        'register' => '注册验证码',
        'reset' => '密码重置',
        'test' => '邮箱测试',
        'notice' => '系统通知'
    ];
    $subject = $subjectMap[$type] ?? '验证码';
    
    // 邮件内容
    $content = "您的验证码是：{$code}，有效期10分钟。\n\n";
    $content .= "发送时间: " . date('Y-m-d H:i:s');
    
    // ============================================================
    // 【关键】插入邮件日志（先记录，再发送）
    // ============================================================
    try {
        $typeShort = substr($type, 0, 20);
        $stmt = $pdo->prepare("INSERT INTO email_logs (to_email, subject, content, type) VALUES (?, ?, ?, ?)");
        $stmt->execute([$email, $subject, $content, $typeShort]);
    } catch (PDOException $e) {
        error_log('邮件日志插入失败: ' . $e->getMessage());
    }
    
    // 清理旧验证码
    $pdo->prepare("DELETE FROM verification_codes WHERE email = ? AND type = ?")->execute([$email, $type]);
    
    // 插入新验证码记录
    $stmt = $pdo->prepare("INSERT INTO verification_codes (email, code, type, expires_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 10 MINUTE))");
    $stmt->execute([$email, $code, $type]);
    
    // ============================================================
    // 【关键】实际发送邮件
    // ============================================================
    $mail = null;
    try {
        $mail = getMailerInstance();
        $mail->addAddress($email);
        $mail->Subject = $subject;
        $mail->Body = $content;
        $mail->AltBody = strip_tags($content);
        
        $result = $mail->send();
        if ($result) {
            error_log("邮件发送成功: $email, 类型: $type");
            return true;
        } else {
            error_log('邮件发送失败 (SMTP Error): ' . ($mail->ErrorInfo ?? '未知错误'));
            return false;
        }
    } catch (Exception $e) {
        $errorMsg = $mail ? ($mail->ErrorInfo ?: $e->getMessage()) : $e->getMessage();
        error_log('邮件发送异常: ' . $errorMsg);
        return false;
    }
}

// 验证验证码
function verifyCode($email, $inputCode, $type = 'register') {
    if (empty($email) || empty($inputCode)) {
        return false;
    }
    
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT * FROM verification_codes WHERE email = ? AND code = ? AND type = ? AND used = FALSE AND expires_at > NOW() ORDER BY id DESC LIMIT 1");
    $stmt->execute([$email, $inputCode, $type]);
    $record = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($record) {
        $pdo->prepare("UPDATE verification_codes SET used = TRUE WHERE id = ?")->execute([$record['id']]);
        return true;
    }
    return false;
}

// 记录学习行为
function logLearning($userId, $techniqueId, $action, $score = 0, $duration = 0) {
    if (empty($userId) || empty($techniqueId)) {
        error_log('学习记录写入失败: 用户ID或知识点ID为空');
        return false;
    }
    
    $pdo = getDB();
    $stmt = $pdo->prepare("INSERT INTO learning_records (user_id, technique_id, action, score, duration) VALUES (?, ?, ?, ?, ?)");
    return $stmt->execute([$userId, $techniqueId, $action, $score, $duration]);
}