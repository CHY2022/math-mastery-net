<?php
// 底部脚本
$icpNumber = getSetting('icp_number') ?: ICP_NUMBER;
$isAuthPage = in_array($_GET['route'] ?? '', ['login', 'register', 'forgot', 'reset', 'verify', 'logout']);
?>
<?php if (!$isAuthPage): ?>
        </div>
        <footer class="footpad">
            <div style="text-align:center;padding:16px 0;font-size:12px;color:#6b7280;border-top:1px solid #e5e7eb;margin-top:20px;">
                <?= h(SITE_NAME) ?> &copy; <?= date('Y') ?> 
                <?php if ($icpNumber): ?>
                · <a href="https://beian.miit.gov.cn/" target="_blank" style="color:#6b7280;text-decoration:none;"><?= h($icpNumber) ?></a>
                <?php endif; ?>
            </div>
        </footer>
    </main>

    <div id="toast" class="toast"></div>
    <div id="modal" class="modal" style="display:none;">
        <div class="modal-content">
            <button class="modal-close" id="modalClose">&times;</button>
            <div id="modalBody"></div>
        </div>
    </div>

    <!-- 原有核心JS文件 -->
    <script src="js/data.js"></script>
    <script src="js/animations.js"></script>
    <script src="js/figures.js"></script>
    <script src="js/qgen.js"></script>
    <script src="js/qgen_junior.js"></script>
    <script src="js/qgen_high.js"></script>
    <script src="js/related-projects.js"></script>
    <script src="js/app.js"></script>
    <script src="js/auth.js"></script>
    <script src="js/admin.js"></script>
    <script src="js/app_main.js"></script>
    
    <script>
document.addEventListener('DOMContentLoaded', function() {
    // 初始化认证
    if (typeof Auth !== 'undefined') Auth.init();
    
    // ✅ 【修改】AppMain 会自动初始化，不需要手动调用 init
    // 如果 AppMain 已经存在，调用 route 方法更新导航
    if (typeof AppMain !== 'undefined' && typeof AppMain.route === 'function') {
        AppMain.route();
    }
    
    // 修复侧边栏高亮
    var currentRoute = '<?= $_GET['route'] ?? 'dashboard' ?>';
    document.querySelectorAll('.nav-item').forEach(function(item) {
        var href = item.getAttribute('href');
        if (href && href.indexOf('route=' + currentRoute) > -1) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });
});
</script>
</body>
</html>
<?php endif; ?>