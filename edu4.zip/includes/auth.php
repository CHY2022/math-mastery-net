<?php
// 认证函数

// 检查用户是否已登录
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// 获取当前用户（含缓存）
function getCurrentUser() {
    static $currentUser = null;
    if ($currentUser !== null) {
        return $currentUser;
    }
    if (!isLoggedIn()) {
        return null;
    }
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND status = 'active'");
    $stmt->execute([$_SESSION['user_id']]);
    $currentUser = $stmt->fetch(PDO::FETCH_ASSOC);
    return $currentUser;
}

// 检查是否特定角色
function isRole($role) {
    $user = getCurrentUser();
    return $user && $user['role'] === $role;
}

// 检查是否有权限（admin拥有所有权限）
function hasPermission($permission) {
    $user = getCurrentUser();
    if (!$user) return false;
    if ($user['role'] === 'admin') return true;
    return $user['role'] === $permission;
}

// 获取用户完整信息（含额外字段）
function getUserFull($userId) {
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// 获取用户的学习统计
function getUserStats($userId) {
    $pdo = getDB();
    $stats = [];
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM learning_records WHERE user_id = ? AND action = 'learn'");
    $stmt->execute([$userId]);
    $stats['learn_count'] = (int)$stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM learning_records WHERE user_id = ? AND action = 'practice'");
    $stmt->execute([$userId]);
    $stats['practice_count'] = (int)$stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM learning_records WHERE user_id = ? AND action = 'gate' AND score >= 80");
    $stmt->execute([$userId]);
    $stats['passed_gates'] = (int)$stmt->fetchColumn();
    
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM weak_points WHERE user_id = ? AND cleared = FALSE");
    $stmt->execute([$userId]);
    $stats['weak_count'] = (int)$stmt->fetchColumn();
    
    return $stats;
}

// 获取绑定的学生（家长或学校）
function getBoundStudents($userId) {
    $pdo = getDB();
    $user = getUserFull($userId);
    if (!$user) return [];
    
    $studentIds = [];
    if ($user['role'] === 'parent' && !empty($user['children'])) {
        $studentIds = explode(',', $user['children']);
    } elseif ($user['role'] === 'school' || $user['role'] === 'training') {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE school_id = ? OR training_id = ?");
        $stmt->execute([$userId, $userId]);
        $studentIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    if (empty($studentIds)) return [];
    
    $placeholders = implode(',', array_fill(0, count($studentIds), '?'));
    $stmt = $pdo->prepare("SELECT id, username, name, grade, school, training FROM users WHERE id IN ($placeholders) AND role = 'student'");
    $stmt->execute($studentIds);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}