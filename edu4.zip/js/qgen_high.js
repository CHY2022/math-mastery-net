   /* ============================================================
 * 融会贯通 · 高中数学方法参数化出题引擎（超强版）
 * 覆盖：集合、函数、指数对数、三角函数、数列、向量、
 *       立体几何、导数、圆锥曲线、参数方程、概率统计、复数
 * 每个技巧每次生成 8 道题，题库组合 400+ 种
 * ============================================================ */
(function () {
    'use strict';

    var K = { ink: "#334155", sub: "#64748b", line: "#cbd5e1", pri: "#2f6fed", ok: "#16a34a", warn: "#d97706", red: "#dc2626", soft: "#eef3ff", blue: "#2563eb" };

    function S(w, h, inner) { return '<svg viewBox="0 0 ' + w + ' ' + h + '" width="100%" style="max-width:' + w + 'px;height:auto;display:block" xmlns="http://www.w3.org/2000/svg">' + inner + '</svg>'; }

    function rnd(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
    function pick(a) { return a[rnd(0, a.length - 1)]; }
    function shuffle(a) {
        a = a.slice();
        for (var i = a.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * (i + 1));
            var t = a[i];
            a[i] = a[j];
            a[j] = t;
        }
        return a;
    }

    function opts(ans, make1, make2, make3) {
        var arr = [String(ans), String(make1()), String(make2()), String(make3())];
        var unique = [];
        for (var i = 0; i < arr.length; i++) {
            if (unique.indexOf(arr[i]) === -1) {
                unique.push(arr[i]);
            }
        }
        while (unique.length < 4) {
            unique.push(String(ans + unique.length));
        }
        var shuffled = shuffle(unique);
        return { opts: shuffled, ans: shuffled.indexOf(String(ans)) };
    }

    function Q(q, optsObj, level, explain, point, fig) {
        return Object.assign({ q: q, level: level || "基础", explain: explain, point: point || "" }, optsObj, { fig: fig || null });
    }

    /* ============================================================
     * 1. 集合与逻辑（十年级）- 400+ 种组合
     * ============================================================ */
    function qSet(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var a = rnd(2, 8);
                var b = rnd(2, 8);
                var inter = Math.min(a, b);
                o = opts(inter + '个', function() { return (a + b) + '个'; }, function() { return Math.abs(a - b) + '个'; }, function() { return '0个'; });
                q = '集合 A 有 ' + a + ' 个元素，集合 B 有 ' + b + ' 个元素，若 A⊆B，则 A∩B 有？';
                exp = 'A⊆B 时 A∩B = A，有 ' + a + ' 个元素。';
            } else if (type === 1) {
                var n_elem = rnd(2, 6);
                var ansCount = Math.pow(2, n_elem);
                o = opts(ansCount + '个', function() { return ansCount + n_elem + '个'; }, function() { return (ansCount - 1) + '个'; }, function() { return n_elem + '个'; });
                q = '集合有 ' + n_elem + ' 个元素，它的子集共有？';
                exp = 'n 个元素的集合有 2ⁿ 个子集，2^' + n_elem + ' = ' + ansCount + ' 个。';
            } else if (type === 2) {
                var conditions = [
                    { cond: '"x > 2" 是 "x > 1" 的什么条件？', ans: '充分不必要', exp: 'x > 2 能推出 x > 1（充分），但 x > 1 不能推出 x > 2（不必要），故为充分不必要条件。' },
                    { cond: '"x > 1" 是 "x > 2" 的什么条件？', ans: '必要不充分', exp: 'x > 1 不能推出 x > 2（不充分），但 x > 2 能推出 x > 1（必要），故为必要不充分条件。' },
                    { cond: '"x = 1" 是 "x² = 1" 的什么条件？', ans: '充分不必要', exp: 'x=1 能推出 x²=1（充分），但 x²=1 推出 x=±1 不能推出 x=1（不必要）。' },
                    { cond: '"x² = 1" 是 "x = 1" 的什么条件？', ans: '必要不充分', exp: 'x²=1 不能推出 x=1（不充分），但 x=1 能推出 x²=1（必要）。' },
                    { cond: '"x > 0" 是 "x > 1" 的什么条件？', ans: '必要不充分', exp: 'x>0 不能推出 x>1（不充分），但 x>1 能推出 x>0（必要）。' },
                    { cond: '"x > 1" 是 "x > 0" 的什么条件？', ans: '充分不必要', exp: 'x>1 能推出 x>0（充分），但 x>0 不能推出 x>1（不必要）。' },
                    { cond: '"x² = 0" 是 "x = 0" 的什么条件？', ans: '充要', exp: 'x²=0 ⇔ x=0，互为充要条件。' },
                    { cond: '"x > 0" 是 "x² > 0" 的什么条件？', ans: '充分不必要', exp: 'x>0 能推出 x²>0（充分），但 x²>0 推出 x≠0 不能推出 x>0（不必要）。' }
                ];
                var idx = i % conditions.length;
                var c = conditions[idx];
                var wrongs = ['充分不必要', '必要不充分', '充要', '既不充分也不必要'].filter(function(w) { return w !== c.ans; });
                o = opts(c.ans, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = c.cond;
                exp = c.exp;
            } else if (type === 3) {
                var props = [
                    { q: '命题 "∃x∈R, x² < 0" 的否定是？', ans: '∀x∈R, x² ≥ 0', exp: '存在命题的否定是全称命题：∀x∈R, x² ≥ 0。' },
                    { q: '命题 "∀x∈R, x² > 0" 的否定是？', ans: '∃x∈R, x² ≤ 0', exp: '全称命题的否定是存在命题：∃x∈R, x² ≤ 0。' },
                    { q: '命题 "∃x∈R, x² = 0" 的否定是？', ans: '∀x∈R, x² ≠ 0', exp: '存在命题的否定是全称命题：∀x∈R, x² ≠ 0。' },
                    { q: '命题 "∀x∈R, x² ≥ 0" 的否定是？', ans: '∃x∈R, x² < 0', exp: '全称命题的否定是存在命题：∃x∈R, x² < 0。' }
                ];
                var idx = i % props.length;
                var p = props[idx];
                var wrongs = ['∀x∈R, x² < 0', '∃x∈R, x² ≥ 0', '∀x∈R, x² ≤ 0', '∃x∈R, x² > 0'].filter(function(w) { return w !== p.ans; });
                o = opts(p.ans, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = p.q;
                exp = p.exp;
            } else if (type === 4) {
                var a = rnd(1, 6);
                var b = rnd(1, 6);
                var union = a + b - Math.min(a, b);
                o = opts(union + '个', function() { return (a + b) + '个'; }, function() { return (a + b + 1) + '个'; }, function() { return Math.abs(a - b) + '个'; });
                q = '|A|=' + a + ', |B|=' + b + ', |A∩B|=' + Math.min(a, b) + '，|A∪B|=？';
                exp = '|A∪B| = |A| + |B| − |A∩B| = ' + a + ' + ' + b + ' − ' + Math.min(a, b) + ' = ' + union + '。';
            } else if (type === 5) {
                var a = rnd(1, 4);
                var b = rnd(1, 4);
                var c = rnd(1, 4);
                var union = a + b + c - 1 - 1 - 1 + 1;
                o = opts(union + '个', function() { return (a + b + c) + '个'; }, function() { return (a + b + c - 1) + '个'; }, function() { return (a + b + c - 2) + '个'; });
                q = '|A|=' + a + ', |B|=' + b + ', |C|=' + c + '，两两交集各1个，三者交集1个，|A∪B∪C|=？';
                exp = '|A∪B∪C| = ' + a + '+' + b + '+' + c + '−1−1−1+1 = ' + union + '。';
            } else if (type === 6) {
                var a = rnd(1, 4);
                var b = rnd(1, 4);
                var wrongs = [a + '≤x≤' + (a + b + 1), (a - 1) + '≤x≤' + (a + b), a + '<x<' + (a + b)];
                o = opts(a + '≤x≤' + (a + b), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '集合 A={x|' + a + '≤x≤' + (a + b) + '}，用区间表示为？';
                exp = '区间表示为 [' + a + ', ' + (a + b) + ']。';
            } else {
                var a = rnd(1, 5);
                var wrongs = ['{x|x≠' + (a + 1) + '}', '{x|x≠' + (a - 1) + '}', '{x|x>' + a + '}'];
                o = opts('{x|x≠' + a + '}', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 y = 1/(x−' + a + ') 的定义域用集合表示为？';
                exp = 'x − ' + a + ' ≠ 0，x ≠ ' + a + '，定义域为 {x|x≠' + a + '}。';
            }
            results.push(Q(q, o, '基础', exp, '集合与逻辑'));
        }
        return results;
    }

    /* ============================================================
     * 2. 函数概念与性质（十年级）- 400+ 种组合
     * ============================================================ */
    function qFuncConcept(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 10;
            var q, ans, o, exp;
            if (type === 0) {
                var a = rnd(1, 10);
                var wrongs = ['x ≠ ' + (a + 1), 'x ≠ ' + (a - 1), 'x ≥ ' + a];
                o = opts('x ≠ ' + a, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = 1/(x − ' + a + ') 的定义域是？';
                exp = '分母不为 0，x − ' + a + ' ≠ 0，即 x ≠ ' + a + '。';
            } else if (type === 1) {
                var a = rnd(1, 8);
                var wrongs = ['x ≥ ' + (a + 1), 'x > ' + a, 'x ≤ ' + a];
                o = opts('x ≥ ' + a, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = √(x − ' + a + ') 的定义域是？';
                exp = '根号下 ≥ 0，x − ' + a + ' ≥ 0，x ≥ ' + a + '。';
            } else if (type === 2) {
                var a = rnd(1, 8);
                var wrongs = ['y ≥ ' + (a + 1), 'y ≤ ' + a, 'y > ' + a];
                o = opts('y ≥ ' + a, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = x² + ' + a + ' 的值域是？';
                exp = 'x² ≥ 0，故 f(x) ≥ ' + a + '，值域为 y ≥ ' + a + '。';
            } else if (type === 3) {
                var a = rnd(1, 6);
                var wrongs = ['偶函数', '既是奇函数又是偶函数', '非奇非偶'];
                o = opts('奇函数', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = ' + a + 'x³ 是？';
                exp = 'f(−x) = ' + a + '(−x)³ = −' + a + 'x³ = −f(x)，为奇函数。';
            } else if (type === 4) {
                var a = rnd(1, 6);
                var wrongs = ['奇函数', '既是奇函数又是偶函数', '非奇非偶'];
                o = opts('偶函数', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = ' + a + 'x² 是？';
                exp = 'f(−x) = ' + a + '(−x)² = ' + a + 'x² = f(x)，为偶函数。';
            } else if (type === 5) {
                var a = rnd(1, 5);
                var wrongs = ['在 R 上递减', '先增后减', '先减后增'];
                o = opts('在 R 上递增', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = ' + a + 'x + 1 (a>0) 的单调性是？';
                exp = '一次函数斜率 a > 0，在 R 上单调递增。';
            } else if (type === 6) {
                var a = rnd(-5, -1);
                var wrongs = ['在 R 上递增', '先增后减', '先减后增'];
                o = opts('在 R 上递减', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = ' + a + 'x + 1 (a<0) 的单调性是？';
                exp = '一次函数斜率 a < 0，在 R 上单调递减。';
            } else if (type === 7) {
                var a = rnd(1, 5);
                var b = rnd(1, 5);
                var c = rnd(1, 5);
                var wrongs = ['f(a)·f(b) > 0', 'f(a) = f(b)', 'f(a) + f(b) = 0'];
                o = opts('f(a)·f(b) < 0', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数在 [a,b] 上有零点的充分条件是？';
                exp = '零点存在定理：若 f(a)·f(b) < 0，则在 (a,b) 内至少有一个零点。';
            } else if (type === 8) {
                var a = rnd(1, 5);
                var b = rnd(1, 5);
                var wrongs = ['f(a) = f(b)', 'f(a) > f(b)', 'f(a) < f(b)'];
                o = opts('f(a)·f(b) < 0', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = x² + ' + a + 'x + ' + b + ' 在区间 [0,1] 上有零点的条件是？';
                exp = 'f(0)·f(1) < 0 时，在 (0,1) 内至少有一个零点。';
            } else {
                var a = rnd(1, 5);
                var wrongs = ['f(x) = f(−x)', 'f(x) = −f(−x)', 'f(x) = 0'];
                o = opts('f(−x) = −f(x)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) 为奇函数的充要条件是？';
                exp = '奇函数满足 f(−x) = −f(x)，定义域关于原点对称。';
            }
            results.push(Q(q, o, '基础', exp, '函数概念与性质'));
        }
        return results;
    }

    /* ============================================================
     * 3. 指数与对数（十年级）- 400+ 种组合
     * ============================================================ */
    function qExpLog(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 10;
            var q, ans, o, exp;
            if (type === 0) {
                var a = rnd(2, 5);
                var m = rnd(1, 5);
                var ansVal = a * m;
                var wrongs = ['a^' + (ansVal + 1), 'a^' + (ansVal - 1), a * m + ''];
                o = opts('a^' + ansVal, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'a^' + m + ' · a^' + m + ' = ？';
                exp = '同底数幂相乘，指数相加：a^' + m + ' · a^' + m + ' = a^' + (m + m) + ' = a^' + ansVal + '。';
            } else if (type === 1) {
                var base = rnd(2, 6);
                var ans = rnd(2, 8);
                var val = Math.pow(base, ans);
                var wrongs = [ans + 1, ans - 1, base];
                o = opts(ans, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'log_' + base + '(' + val + ') = ？';
                exp = '由对数定义：' + base + '^' + ans + ' = ' + val + '，故 log_' + base + '(' + val + ') = ' + ans + '。';
            } else if (type === 2) {
                var base = rnd(2, 6);
                var ans = rnd(2, 7);
                var val = Math.pow(base, ans);
                var wrongs = [ans + 1, ans - 1, val];
                o = opts(ans, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '解方程 log_' + base + '(x) = ' + ans + '，x = ？';
                exp = 'x = ' + base + '^' + ans + ' = ' + val + '。';
            } else if (type === 3) {
                var base = rnd(2, 5);
                var ans = rnd(1, 6);
                var val = Math.pow(base, ans);
                var wrongs = [ans + 1, ans - 1, val];
                o = opts(ans, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '解方程 ' + base + '^x = ' + val + '，x = ？';
                exp = 'x = log_' + base + '(' + val + ') = ' + ans + '。';
            } else if (type === 4) {
                var a = rnd(2, 5);
                var b = rnd(2, 5);
                var wrongs = ['log_' + a + '(' + (b * b) + ')', '2log_' + a + '(' + b + ')', 'log_' + a + '(' + b + ')'];
                o = opts('2log_' + a + '(' + b + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'log_' + a + '(' + b + ')' + ' + log_' + a + '(' + b + ')' + ' = ？';
                exp = 'log_' + a + '(' + b + ')' + ' + log_' + a + '(' + b + ')' + ' = 2log_' + a + '(' + b + ')。';
            } else if (type === 5) {
                var a = rnd(2, 5);
                var b = rnd(2, 5);
                var ansVal = a * b;
                var wrongs = ['log_' + a + '(' + (ansVal + 1) + ')', 'log_' + a + '(' + b + ')', '1+log_' + a + '(' + b + ')'];
                o = opts('log_' + a + '(' + ansVal + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'log_' + a + '(' + a + ')' + ' + log_' + a + '(' + b + ')' + ' = ？';
                exp = 'log_' + a + '(' + a + ')' + ' + log_' + a + '(' + b + ')' + ' = 1 + log_' + a + '(' + b + ')' + ' = log_' + a + '(' + ansVal + ')。';
            } else if (type === 6) {
                var a = rnd(2, 6);
                var b = rnd(2, 6);
                var c = rnd(2, 6);
                var ansVal = b * c;
                var wrongs = ['log_' + a + '(' + (b + c) + ')', 'log_' + a + '(' + b + ')' + '−log_' + a + '(' + c + ')', 'log_' + a + '(' + ansVal + ')'];
                o = opts('log_' + a + '(' + b + ')' + '+log_' + a + '(' + c + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'log_' + a + '(' + b + ')' + ' + log_' + a + '(' + c + ')' + ' = ？';
                exp = 'log_' + a + '(' + b + ')' + ' + log_' + a + '(' + c + ')' + ' = log_' + a + '(' + (b * c) + ')。';
            } else if (type === 7) {
                var a = rnd(2, 6);
                var b = rnd(2, 6);
                var ansVal = a / b;
                var wrongs = ['log_' + a + '(' + b + ')', 'log_' + a + '(' + (a * b) + ')', '0'];
                o = opts('log_' + a + '(' + b + ')' + '−log_' + a + '(' + b + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'log_' + a + '(' + b + ')' + ' − log_' + a + '(' + b + ')' + ' = ？';
                exp = 'log_' + a + '(' + b + ')' + ' − log_' + a + '(' + b + ')' + ' = 0。';
            } else if (type === 8) {
                var a = rnd(2, 5);
                var b = rnd(2, 5);
                var ansVal = Math.pow(a, b);
                var wrongs = ['log_' + a + '(' + b + ')', 'b·log_' + a + '(' + a + ')', 'log_' + a + '(' + (a * b) + ')'];
                o = opts('log_' + a + '(' + ansVal + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'log_' + a + '(' + ansVal + ')' + ' = ？';
                exp = 'log_' + a + '(' + a + '^' + b + ')' + ' = ' + b + '。';
            } else {
                var a = rnd(2, 5);
                var b = rnd(2, 5);
                var ansVal = Math.log(b) / Math.log(a);
                var wrongs = [ansVal + 1, ansVal - 1, a + b];
                o = opts(ansVal.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'log_' + a + '(' + b + ')' + ' 约等于？';
                exp = 'log_' + a + '(' + b + ')' + ' = ln' + b + '/ln' + a + ' ≈ ' + ansVal.toFixed(2) + '。';
            }
            results.push(Q(q, o, '基础', exp, '指数与对数'));
        }
        return results;
    }

    /* ============================================================
     * 4. 三角函数（十一年级）- 400+ 种组合
     * ============================================================ */
    function qTrig(n) {
        var results = [];
        var angles = [0, 30, 45, 60, 90, 120, 135, 150, 180, 210, 225, 240, 270, 300, 315, 330, 360];
        var sinVals = {};
        var cosVals = {};
        var tanVals = {};
        for (var i = 0; i < angles.length; i++) {
            var rad = angles[i] * Math.PI / 180;
            sinVals[angles[i]] = Math.sin(rad).toFixed(4);
            cosVals[angles[i]] = Math.cos(rad).toFixed(4);
            tanVals[angles[i]] = Math.tan(rad).toFixed(4);
        }
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var angle = pick(angles);
                var val = sinVals[angle];
                var optVals = shuffle([val, sinVals[angle + 30] || '0.5000', sinVals[angle - 30] || '0.7071', '0.0000']);
                o = { opts: optVals, ans: optVals.indexOf(val) };
                q = 'sin ' + angle + '° = ？';
                exp = 'sin ' + angle + '° = ' + val + '。';
            } else if (type === 1) {
                var angle = pick(angles);
                var val = cosVals[angle];
                var optVals = shuffle([val, cosVals[angle + 30] || '0.5000', cosVals[angle - 30] || '0.7071', '0.0000']);
                o = { opts: optVals, ans: optVals.indexOf(val) };
                q = 'cos ' + angle + '° = ？';
                exp = 'cos ' + angle + '° = ' + val + '。';
            } else if (type === 2) {
                var angle = pick(angles.filter(function(a) { return a % 90 !== 0; }));
                var val = tanVals[angle];
                var optVals = shuffle([val, tanVals[angle + 30] || '1.0000', tanVals[angle - 30] || '0.5774', '0.0000']);
                o = { opts: optVals, ans: optVals.indexOf(val) };
                q = 'tan ' + angle + '° = ？';
                exp = 'tan ' + angle + '° = ' + val + '。';
            } else if (type === 3) {
                var wrongs = ['sin²α − cos²α = 1', 'sinα + cosα = 1', 'tanα = sinα/cosα'];
                o = opts('sin²α + cos²α = 1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '下列等式恒成立的是？';
                exp = '基本的三角恒等式：sin²α + cos²α = 1。';
            } else if (type === 4) {
                var angles2 = [30, 45, 60, 90, 120, 135, 150, 180];
                var angle = pick(angles2);
                var val = sinVals[180 - angle] || sinVals[angle];
                var wrongs = [(-val).toFixed(4), '0.0000', '1.0000'];
                o = opts(val, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'sin(180° − ' + angle + '°) = ？';
                exp = '诱导公式：sin(180° − ' + angle + '°) = sin' + angle + '° = ' + val + '。';
            } else if (type === 5) {
                var angles2 = [30, 45, 60, 90, 120, 135, 150, 180];
                var angle = pick(angles2);
                var val = cosVals[180 - angle] || cosVals[angle];
                var wrongs = [val.toFixed(4), '0.0000', '1.0000'];
                o = opts((-val).toFixed(4), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'cos(180° − ' + angle + '°) = ？';
                exp = '诱导公式：cos(180° − ' + angle + '°) = −cos' + angle + '° = ' + (-val).toFixed(4) + '。';
            } else if (type === 6) {
                var angle = pick(angles.filter(function(a) { return a >= 0 && a <= 90; }));
                var val = sinVals[90 - angle] || sinVals[angle];
                var wrongs = [cosVals[angle], '0.0000', '1.0000'];
                o = opts(val, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'sin(' + angle + '°) = cos(90° − ' + angle + '°)，对吗？';
                exp = 'sin' + angle + '° = cos' + (90 - angle) + '° = ' + val + '。';
            } else {
                var angles3 = [30, 45, 60];
                var angle = pick(angles3);
                var val = sinVals[angle];
                var wrongs = ['1/2', '√3/2', '√2/2'];
                o = opts(val, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'sin ' + angle + '° = ？';
                exp = 'sin ' + angle + '° = ' + val + '（特殊角值）。';
            }
            results.push(Q(q, o, '基础', exp, '三角函数'));
        }
        return results;
    }

    /* ============================================================
     * 5. 三角恒等变换（十一年级）- 400+ 种组合
     * ============================================================ */
    function qTrigId(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var wrongs = ['sinαcosβ − cosαsinβ', 'cosαcosβ − sinαsinβ', 'cosαcosβ + sinαsinβ'];
                o = opts('sinαcosβ + cosαsinβ', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'sin(α + β) 的展开式是？';
                exp = '和角公式：sin(α + β) = sinαcosβ + cosαsinβ。';
            } else if (type === 1) {
                var wrongs = ['sin²α − cos²α', '2cos²α − 1', '1 − 2sin²α'];
                o = opts('2sinαcosα', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'sin2α 的公式是？';
                exp = '二倍角公式：sin2α = 2sinαcosα。';
            } else if (type === 2) {
                var wrongs = ['±√((1+cosα)/2)', '1−cosα', '1+cosα'];
                o = opts('±√((1−cosα)/2)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'sin(α/2) 的半角公式是？';
                exp = '半角公式：sin(α/2) = ±√((1−cosα)/2)。';
            } else if (type === 3) {
                var wrongs = ['(1/2)[cos(α+β)+cos(α−β)]', '(1/2)[sin(α+β)−sin(α−β)]', '(1/2)[cos(α+β)−cos(α−β)]'];
                o = opts('(1/2)[sin(α+β)+sin(α−β)]', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'sinαcosβ 的积化和差公式是？';
                exp = '积化和差：sinαcosβ = (1/2)[sin(α+β)+sin(α−β)]。';
            } else if (type === 4) {
                var wrongs = ['cos²α − sin²α', '2sin²α − 1', '1 + 2sin²α'];
                o = opts('cos²α − sin²α', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'cos2α 的等价形式之一是？';
                exp = 'cos2α = cos²α − sin²α = 2cos²α − 1 = 1 − 2sin²α。';
            } else if (type === 5) {
                var a = rnd(2, 5);
                var b = rnd(2, 5);
                var phi = Math.atan2(b, a);
                var wrongs = ['√' + (a * a + b * b) + '·cos(x+φ)', '√' + (a * a + b * b) + '·sin(x−φ)', a + '·sinx + ' + b + '·cosx'];
                o = opts('√(' + (a * a + b * b) + ')·sin(x+φ)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = a + '·sinx + ' + b + '·cosx 可化为？';
                exp = '辅助角公式：' + a + '·sinx + ' + b + '·cosx = √(' + (a * a + b * b) + ')·sin(x+φ)，tanφ=' + b + '/' + a + '。';
            } else if (type === 6) {
                var angle = pick([30, 45, 60]);
                var val = Math.sin(2 * angle * Math.PI / 180).toFixed(4);
                var wrongs = [(2 * Math.sin(angle * Math.PI / 180) * Math.cos(angle * Math.PI / 180)).toFixed(4), '0.0000', '1.0000'];
                o = opts(val, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'sin2×' + angle + '° = ？';
                exp = 'sin' + (2 * angle) + '° = ' + val + '。';
            } else {
                var angle = pick([30, 45, 60]);
                var val = Math.cos(2 * angle * Math.PI / 180).toFixed(4);
                var wrongs = [(Math.cos(angle * Math.PI / 180) * Math.cos(angle * Math.PI / 180) - Math.sin(angle * Math.PI / 180) * Math.sin(angle * Math.PI / 180)).toFixed(4), '0.0000', '1.0000'];
                o = opts(val, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'cos2×' + angle + '° = ？';
                exp = 'cos' + (2 * angle) + '° = ' + val + '。';
            }
            results.push(Q(q, o, '基础', exp, '三角恒等变换'));
        }
        return results;
    }

    /* ============================================================
     * 6. 数列（十一年级）- 400+ 种组合
     * ============================================================ */
    function qSequence(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var a1 = rnd(1, 8);
                var d = rnd(1, 5);
                var idx = rnd(3, 8);
                var an = a1 + (idx - 1) * d;
                var wrongs = [an + d, an - d, a1 + idx * d];
                o = opts(an, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '等差数列首项 ' + a1 + '，公差 ' + d + '，第 ' + idx + ' 项 a_' + idx + ' = ？';
                exp = 'a_n = a₁ + (n−1)d = ' + a1 + ' + (' + idx + '−1)×' + d + ' = ' + an + '。';
            } else if (type === 1) {
                var a1 = rnd(1, 6);
                var d = rnd(1, 4);
                var idx = rnd(3, 7);
                var sn = idx * a1 + idx * (idx - 1) * d / 2;
                var wrongs = [sn + idx, sn - idx, a1 * idx];
                o = opts(sn, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '等差数列首项 ' + a1 + '，公差 ' + d + '，前 ' + idx + ' 项和 S_' + idx + ' = ？';
                exp = 'S_n = na₁ + n(n−1)d/2 = ' + idx + '×' + a1 + ' + ' + idx + '×' + (idx - 1) + '×' + d + '/2 = ' + sn + '。';
            } else if (type === 2) {
                var a1 = rnd(1, 4);
                var q_val = rnd(2, 4);
                var idx = rnd(3, 6);
                var an = a1 * Math.pow(q_val, idx - 1);
                var wrongs = [an * q_val, an / q_val, a1 * idx];
                o = opts(an, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '等比数列首项 ' + a1 + '，公比 ' + q_val + '，第 ' + idx + ' 项 a_' + idx + ' = ？';
                exp = 'a_n = a₁ × q^(n−1) = ' + a1 + ' × ' + q_val + '^' + (idx - 1) + ' = ' + an + '。';
            } else if (type === 3) {
                var a1 = rnd(1, 4);
                var q_val = rnd(2, 4);
                var idx = rnd(2, 5);
                var sn = a1 * (Math.pow(q_val, idx) - 1) / (q_val - 1);
                var wrongs = [sn + a1, sn - a1, a1 * idx];
                o = opts(sn, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '等比数列首项 ' + a1 + '，公比 ' + q_val + '，前 ' + idx + ' 项和 S_' + idx + ' = ？';
                exp = 'S_n = a₁(q^n − 1)/(q − 1) = ' + a1 + '×(' + q_val + '^' + idx + ' − 1)/(' + q_val + ' − 1) = ' + sn + '。';
            } else if (type === 4) {
                var d = rnd(2, 5);
                var a1 = rnd(1, 5);
                var idx = rnd(3, 7);
                var an = a1 + (idx - 1) * d;
                var wrongs = [an + 1, an - 1, a1 + idx * d];
                o = opts(an, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '已知等差数列 a_1=' + a1 + ', a_' + idx + '=' + an + '，公差 d = ？';
                exp = 'd = (a_' + idx + ' − a_1)/(' + idx + ' − 1) = (' + an + ' − ' + a1 + ')/' + (idx - 1) + ' = ' + d + '。';
            } else if (type === 5) {
                var a1 = rnd(1, 5);
                var q_val = rnd(2, 4);
                var idx = rnd(3, 6);
                var an = a1 * Math.pow(q_val, idx - 1);
                var wrongs = [an * q_val, an / q_val, a1 * idx];
                o = opts(q_val, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '等比数列 a_1=' + a1 + ', a_' + idx + '=' + an + '，公比 q = ？';
                exp = 'q = (a_' + idx + '/a_1)^(1/(' + idx + '-1)) = (' + an + '/' + a1 + ')^(1/' + (idx - 1) + ') = ' + q_val + '。';
            } else if (type === 6) {
                var a1 = rnd(1, 5);
                var d = rnd(1, 4);
                var idx = rnd(3, 7);
                var sn = idx * a1 + idx * (idx - 1) * d / 2;
                var wrongs = [sn + 1, sn - 1, idx * a1 + idx * (idx - 1) * d];
                o = opts(sn, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '等差数列前 ' + idx + ' 项和 S_' + idx + ' = ' + sn + '，a_1=' + a1 + '，公差 d = ？';
                exp = 'd = 2(S_n − na₁)/(n(n−1)) = 2(' + sn + ' − ' + idx + '×' + a1 + ')/(' + idx + '×' + (idx - 1) + ') = ' + d + '。';
            } else {
                var a1 = rnd(1, 4);
                var q_val = rnd(2, 4);
                var idx = rnd(2, 5);
                var sn = a1 * (Math.pow(q_val, idx) - 1) / (q_val - 1);
                var wrongs = [sn + 1, sn - 1, a1 * (Math.pow(q_val, idx + 1) - 1) / (q_val - 1)];
                o = opts(sn, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '等比数列前 ' + idx + ' 项和 S_' + idx + ' = ' + sn + '，a_1=' + a1 + '，公比 q = ？';
                exp = 'q = (S_n/a_1 + 1)^(1/n) = ' + q_val + '。';
            }
            results.push(Q(q, o, '基础', exp, '数列'));
        }
        return results;
    }

    /* ============================================================
     * 7. 数列求和技巧（十一年级）- 400+ 种组合
     * ============================================================ */
    function qSeqSum(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var idx = rnd(3, 8);
                var ans_val = idx / (idx + 1);
                var wrongs = [(idx + 1) / (idx + 2), (idx - 1) / idx, 1 / (idx + 1)];
                o = opts(ans_val, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '求和：1/(1×2) + 1/(2×3) + ... + 1/(' + idx + '×(' + idx + '+1)) = ？';
                exp = '裂项：1/(k(k+1)) = 1/k − 1/(k+1)，相消后得 ' + idx + '/' + (idx + 1) + '。';
            } else if (type === 1) {
                var idx = rnd(3, 6);
                var ans_val = Math.pow(2, idx) - 1;
                var wrongs = [ans_val + 1, ans_val - 1, Math.pow(2, idx + 1)];
                o = opts(ans_val, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '求和：1 + 2 + 4 + ... + 2^' + (idx - 1) + ' = ？';
                exp = '等比数列求和：S = (2^' + idx + ' − 1)/(2 − 1) = ' + ans_val + '。';
            } else if (type === 2) {
                var idx = rnd(2, 6);
                var an = 2 * idx + 1;
                var wrongs = [an + 2, an - 2, 2 * idx];
                o = opts(an, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '数列 a_n = 2n + 1，第 ' + idx + ' 项 a_' + idx + ' = ？';
                exp = 'a_' + idx + ' = 2×' + idx + ' + 1 = ' + an + '。';
            } else if (type === 3) {
                var idx = rnd(2, 6);
                var ans_val = idx * (idx + 1) / 2;
                var wrongs = [ans_val + 1, ans_val - 1, idx * idx];
                o = opts(ans_val, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '求和：1 + 2 − 3 + 4 − 5 + ... + ' + (2 * idx) + ' = ？';
                exp = '分组：(1+2)+(−3+4)+(−5+6)+... = ' + idx + ' 组，每组 1，和为 ' + ans_val + '。';
            } else if (type === 4) {
                var idx = rnd(3, 7);
                var ans_val = idx * (idx + 1) / 2;
                var wrongs = [ans_val + 1, ans_val - 1, idx * (idx + 1)];
                o = opts(ans_val, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '求和：1 + 2 + 3 + ... + ' + idx + ' = ？';
                exp = '高斯求和：' + idx + '(' + idx + '+1)/2 = ' + ans_val + '。';
            } else if (type === 5) {
                var idx = rnd(3, 6);
                var ans_val = Math.pow(2, idx) - 1;
                var wrongs = [ans_val + 1, ans_val - 1, Math.pow(2, idx)];
                o = opts(ans_val, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '求和：1 + 2 + 4 + 8 + ... + 2^' + (idx - 1) + ' = ？';
                exp = '等比数列求和：S = (2^' + idx + ' − 1)/(2 − 1) = ' + ans_val + '。';
            } else if (type === 6) {
                var idx = rnd(3, 7);
                var ans_val = idx * (idx + 1) * (2 * idx + 1) / 6;
                var wrongs = [ans_val + 1, ans_val - 1, idx * (idx + 1) / 2];
                o = opts(ans_val, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '求和：1² + 2² + 3² + ... + ' + idx + '² = ？';
                exp = '平方和公式：' + idx + '(' + idx + '+1)(2' + idx + '+1)/6 = ' + ans_val + '。';
            } else {
                var idx = rnd(3, 7);
                var ans_val = idx * idx * (idx + 1) * (idx + 1) / 4;
                var wrongs = [ans_val + 1, ans_val - 1, idx * (idx + 1) * (2 * idx + 1) / 6];
                o = opts(ans_val, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '求和：1³ + 2³ + 3³ + ... + ' + idx + '³ = ？';
                exp = '立方和公式：[' + idx + '(' + idx + '+1)/2]² = ' + ans_val + '。';
            }
            results.push(Q(q, o, '进阶', exp, '数列求和技巧'));
        }
        return results;
    }

    /* ============================================================
     * 8. 平面向量（十一年级）- 400+ 种组合
     * ============================================================ */
    function qVector(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var ax = rnd(1, 8);
                var ay = rnd(1, 8);
                var bx = rnd(1, 8);
                var by = rnd(1, 8);
                var sx = ax + bx;
                var sy = ay + by;
                var wrongs = ['(' + (sx + 1) + ',' + sy + ')', '(' + ax + ',' + by + ')', '(' + bx + ',' + ay + ')'];
                o = opts('(' + sx + ',' + sy + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '向量 a=(' + ax + ',' + ay + '), b=(' + bx + ',' + by + ')，a+b=？';
                exp = '向量加法：(a₁+b₁, a₂+b₂) = (' + ax + '+' + bx + ', ' + ay + '+' + by + ') = (' + sx + ',' + sy + ')。';
            } else if (type === 1) {
                var ax = rnd(2, 8);
                var ay = rnd(2, 8);
                var bx = rnd(1, ax - 1);
                var by = rnd(1, ay - 1);
                var dx = ax - bx;
                var dy = ay - by;
                var wrongs = ['(' + (dx + 1) + ',' + dy + ')', '(' + (ax + bx) + ',' + (ay + by) + ')', '(' + (bx - ax) + ',' + (by - ay) + ')'];
                o = opts('(' + dx + ',' + dy + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '向量 a=(' + ax + ',' + ay + '), b=(' + bx + ',' + by + ')，a−b=？';
                exp = '向量减法：(a₁−b₁, a₂−b₂) = (' + ax + '−' + bx + ', ' + ay + '−' + by + ') = (' + dx + ',' + dy + ')。';
            } else if (type === 2) {
                var ax = rnd(1, 6);
                var ay = rnd(1, 6);
                var bx = rnd(1, 6);
                var by = rnd(1, 6);
                var dot = ax * bx + ay * by;
                var wrongs = [dot + 1, dot - 1, ax * bx];
                o = opts(dot, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '向量 a=(' + ax + ',' + ay + '), b=(' + bx + ',' + by + ')，a·b=？';
                exp = '数量积：a·b = a₁b₁ + a₂b₂ = ' + ax + '×' + bx + ' + ' + ay + '×' + by + ' = ' + dot + '。';
            } else if (type === 3) {
                var k = rnd(2, 5);
                var ax = rnd(1, 4);
                var ay = ax * k;
                var bx = rnd(1, 4);
                var by = bx * k;
                var wrongs = ['不共线', '垂直', '无法判断'];
                o = opts('共线', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '向量 a=(' + ax + ',' + ay + '), b=(' + bx + ',' + by + ')，它们的关系是？';
                exp = 'a = ' + k + ' × b，两向量共线。';
            } else if (type === 4) {
                var ax = rnd(1, 5);
                var ay = rnd(1, 5);
                var mod = Math.sqrt(ax * ax + ay * ay);
                var wrongs = [mod + 1, mod - 1, ax + ay];
                o = opts(mod.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '向量 a=(' + ax + ',' + ay + ') 的模 |a| = ？';
                exp = '|a| = √(' + ax + '² + ' + ay + '²) = √' + (ax * ax + ay * ay) + ' = ' + mod.toFixed(2) + '。';
            } else if (type === 5) {
                var ax = rnd(1, 5);
                var ay = rnd(1, 5);
                var bx = rnd(1, 5);
                var by = rnd(1, 5);
                var dot = ax * bx + ay * by;
                var wrongs = ['共线', '平行', '无法判断'];
                o = opts('垂直', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '向量 a=(' + ax + ',' + ay + '), b=(' + bx + ',' + by + ')，a·b=' + dot + '，它们的关系是？';
                exp = 'a·b = ' + dot + ' ' + (dot === 0 ? '= 0，两向量垂直。' : '≠ 0，两向量不垂直。');
            } else if (type === 6) {
                var ax = rnd(1, 5);
                var ay = rnd(1, 5);
                var k = rnd(2, 5);
                var wrongs = ['(' + (ax * k + 1) + ',' + (ay * k) + ')', '(' + (ax + k) + ',' + (ay + k) + ')', '(' + (ax * k) + ',' + (ay * k + 1) + ')'];
                o = opts('(' + (ax * k) + ',' + (ay * k) + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '向量 a=(' + ax + ',' + ay + ')，' + k + 'a = ？';
                exp = k + 'a = (' + k + '×' + ax + ', ' + k + '×' + ay + ') = (' + (ax * k) + ',' + (ay * k) + ')。';
            } else {
                var ax = rnd(1, 5);
                var ay = rnd(1, 5);
                var wrongs = ['(' + (-ax) + ',' + ay + ')', '(' + ax + ',' + (-ay) + ')', '(' + (-ax) + ',' + (-ay) + ')'];
                o = opts('(' + (-ax) + ',' + (-ay) + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '向量 a=(' + ax + ',' + ay + ')，−a = ？';
                exp = '−a = (' + (-ax) + ',' + (-ay) + ')。';
            }
            results.push(Q(q, o, '基础', exp, '平面向量'));
        }
        return results;
    }
   
    /* ============================================================
     * 9. 立体几何（十一年级）- 400+ 种组合
     * ============================================================ */
    function qSolid(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var wrongs = ['4个', '8个', '12个'];
                o = opts('3个', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '正方体从每个顶点出发的棱有？';
                exp = '正方体每个顶点连接 3 条棱。';
            } else if (type === 1) {
                var wrongs = ['正视图、俯视图、剖视图', '正视图、侧视图、剖视图', '主视图、左视图、右视图'];
                o = opts('正视图、侧视图、俯视图', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '三视图包括？';
                exp = '三视图：正视图（主视图）、侧视图（左视图）、俯视图。';
            } else if (type === 2) {
                var wrongs = ['线与面内所有直线平行', '线与面内一直线垂直', '线在面内'];
                o = opts('线在面外且与面内一直线平行', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '直线与平面平行的判定条件是？';
                exp = '线面平行判定：若平面外一直线与平面内一直线平行，则线面平行。';
            } else if (type === 3) {
                var wrongs = ['两平面交线垂直', '两平面平行', '两平面相交'];
                o = opts('一平面过另一平面的垂线', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '两平面垂直的判定条件是？';
                exp = '面面垂直判定：若一平面过另一平面的垂线，则两平面垂直。';
            } else if (type === 4) {
                var a = rnd(2, 8);
                var wrongs = [a * a * a + 1, a * a * a - 1, a * a * 6];
                o = opts(a * a * a, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '正方体棱长为 ' + a + '，体积是？';
                exp = '体积 = ' + a + '³ = ' + (a * a * a) + '。';
            } else if (type === 5) {
                var a = rnd(2, 8);
                var wrongs = [a * a * 6 + 1, a * a * 6 - 1, a * a * 4];
                o = opts(a * a * 6, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '正方体棱长为 ' + a + '，表面积是？';
                exp = '表面积 = 6×' + a + '² = ' + (a * a * 6) + '。';
            } else if (type === 6) {
                var a = rnd(2, 8);
                var b = rnd(2, 8);
                var c = rnd(2, 8);
                var wrongs = [a * b * c + 1, a * b * c - 1, a * b + b * c + c * a];
                o = opts(a * b * c, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '长方体长=' + a + '，宽=' + b + '，高=' + c + '，体积是？';
                exp = '体积 = ' + a + '×' + b + '×' + c + ' = ' + (a * b * c) + '。';
            } else {
                var a = rnd(2, 8);
                var b = rnd(2, 8);
                var c = rnd(2, 8);
                var wrongs = [2 * (a * b + b * c + c * a) + 1, 2 * (a * b + b * c + c * a) - 1, a * b + b * c + c * a];
                o = opts(2 * (a * b + b * c + c * a), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '长方体长=' + a + '，宽=' + b + '，高=' + c + '，表面积是？';
                exp = '表面积 = 2(' + a + '×' + b + ' + ' + b + '×' + c + ' + ' + c + '×' + a + ') = ' + (2 * (a * b + b * c + c * a)) + '。';
            }
            results.push(Q(q, o, '基础', exp, '立体几何'));
        }
        return results;
    }

    /* ============================================================
     * 10. 空间向量建系（十一年级）- 400+ 种组合
     * ============================================================ */
    function qSolidAxis(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var x = rnd(1, 8);
                var y = rnd(1, 8);
                var z = rnd(1, 8);
                var wrongs = ['(' + x + ',' + z + ',' + y + ')', '(' + y + ',' + x + ',' + z + ')', '(-' + x + ',-' + y + ',-' + z + ')'];
                o = opts('(' + x + ',' + y + ',' + z + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '空间点 P 的坐标为 (' + x + ', ' + y + ', ' + z + ')，其坐标表示是？';
                exp = '空间直角坐标系中，点 P 的坐标为 (x, y, z)。';
            } else if (type === 1) {
                var ax = rnd(1, 8);
                var ay = rnd(1, 8);
                var az = rnd(1, 8);
                var bx = rnd(1, ax - 1);
                var by = rnd(1, ay - 1);
                var bz = rnd(1, az - 1);
                var dx = ax - bx;
                var dy = ay - by;
                var dz = az - bz;
                var wrongs = ['(' + (dx + 1) + ',' + dy + ',' + dz + ')', '(' + (ax + bx) + ',' + (ay + by) + ',' + (az + bz) + ')', '(' + (bx - ax) + ',' + (by - ay) + ',' + (bz - az) + ')'];
                o = opts('(' + dx + ',' + dy + ',' + dz + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '向量 a=(' + ax + ',' + ay + ',' + az + '), b=(' + bx + ',' + by + ',' + bz + ')，a−b=？';
                exp = '向量减法：(a₁−b₁, a₂−b₂, a₃−b₃) = (' + dx + ',' + dy + ',' + dz + ')。';
            } else if (type === 2) {
                var wrongs = ['(1,0,0)', '(0,1,0)', '(1,1,1)'];
                o = opts('(0,0,1)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '平面 xOy 的法向量是？';
                exp = 'xOy 平面的法向量垂直于该平面，可取 (0, 0, 1)。';
            } else if (type === 3) {
                var ax = rnd(1, 6);
                var ay = rnd(1, 6);
                var az = rnd(1, 6);
                var bx = rnd(1, 6);
                var by = rnd(1, 6);
                var bz = rnd(1, 6);
                var dot = ax * bx + ay * by + az * bz;
                var wrongs = [dot + 1, dot - 1, ax * bx + ay * by];
                o = opts(dot, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '向量 a=(' + ax + ',' + ay + ',' + az + '), b=(' + bx + ',' + by + ',' + bz + ')，a·b=？';
                exp = '数量积：a·b = ' + ax + '×' + bx + ' + ' + ay + '×' + by + ' + ' + az + '×' + bz + ' = ' + dot + '。';
            } else if (type === 4) {
                var ax = rnd(1, 5);
                var ay = rnd(1, 5);
                var az = rnd(1, 5);
                var mod = Math.sqrt(ax * ax + ay * ay + az * az);
                var wrongs = [mod + 1, mod - 1, ax + ay + az];
                o = opts(mod.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '向量 a=(' + ax + ',' + ay + ',' + az + ') 的模 |a| = ？';
                exp = '|a| = √(' + ax + '² + ' + ay + '² + ' + az + '²) = √' + (ax * ax + ay * ay + az * az) + ' = ' + mod.toFixed(2) + '。';
            } else {
                var ax = rnd(1, 6);
                var ay = rnd(1, 6);
                var az = rnd(1, 6);
                var wrongs = ['(' + (-ax) + ',' + ay + ',' + az + ')', '(' + ax + ',' + (-ay) + ',' + az + ')', '(' + ax + ',' + ay + ',' + (-az) + ')'];
                o = opts('(' + (-ax) + ',' + (-ay) + ',' + (-az) + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '向量 a=(' + ax + ',' + ay + ',' + az + ')，−a = ？';
                exp = '−a = (' + (-ax) + ',' + (-ay) + ',' + (-az) + ')。';
            }
            results.push(Q(q, o, '基础', exp, '空间向量建系'));
        }
        return results;
    }

    /* ============================================================
     * 11. 空间角与距离（十一年级）- 400+ 种组合
     * ============================================================ */
    function qSolidAngle(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var wrongs = ['钝角', '平角', '无法确定'];
                o = opts('锐角或直角', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '异面直线所成角的范围是？';
                exp = '异面直线所成角范围：(0°, 90°]，即锐角或直角。';
            } else if (type === 1) {
                var wrongs = ['线与面内任意直线的夹角', '两平面的夹角', '线与法向量的夹角'];
                o = opts('线与面内投影的夹角', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '直线与平面所成角是指？';
                exp = '线面角是直线与其在平面内投影的夹角，范围 [0°, 90°]。';
            } else if (type === 2) {
                var wrongs = ['两平面内任意两条直线的夹角', '两平面法向量的夹角', '两平面内平行线的夹角'];
                o = opts('两平面交线的垂面与两平面的交线所成的角', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '二面角的平面角是指？';
                exp = '二面角的平面角是由交线上一点，在两平面内分别作交线的垂线所成的角。';
            } else if (type === 3) {
                var a = rnd(2, 6);
                var b = rnd(2, 6);
                var c = rnd(2, 6);
                var wrongs = [a + b + c + 1, a + b + c - 1, a * b * c];
                o = opts(Math.sqrt(a * a + b * b + c * c).toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '点 P(' + a + ',' + b + ',' + c + ') 到原点 O 的距离是？';
                exp = '|OP| = √(' + a + '² + ' + b + '² + ' + c + '²) = √' + (a * a + b * b + c * c) + ' = ' + Math.sqrt(a * a + b * b + c * c).toFixed(2) + '。';
            } else if (type === 4) {
                var a = rnd(2, 6);
                var b = rnd(2, 6);
                var c = rnd(2, 6);
                var d = rnd(1, 5);
                var wrongs = [d + 1, d - 1, d * d];
                o = opts(d, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '平面 ' + a + 'x + ' + b + 'y + ' + c + 'z = ' + d + ' 的法向量是？';
                exp = '法向量可取 (' + a + ', ' + b + ', ' + c + ')。';
            } else {
                var a = rnd(2, 6);
                var b = rnd(2, 6);
                var c = rnd(2, 6);
                var wrongs = [a + b + c + 1, a * b * c, Math.abs(a - b) + Math.abs(b - c)];
                o = opts(Math.sqrt(a * a + b * b + c * c).toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '向量 a=(' + a + ',' + b + ',' + c + ') 的模 |a| = ？';
                exp = '|a| = √(' + a + '² + ' + b + '² + ' + c + '²) = ' + Math.sqrt(a * a + b * b + c * c).toFixed(2) + '。';
            }
            results.push(Q(q, o, '基础', exp, '空间角与距离'));
        }
        return results;
    }

    /* ============================================================
     * 12. 导数与单调性（十二年级）- 400+ 种组合
     * ============================================================ */
    function qDerivative(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var n_val = rnd(2, 8);
                var coeff = rnd(1, 5);
                var ansCoeff = coeff * n_val;
                var wrongs = [coeff + 'x^' + n_val, ansCoeff + 'x^' + (n_val + 1), n_val + 'x^' + (n_val - 1)];
                o = opts(ansCoeff + 'x^' + (n_val - 1), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'f(x) = ' + coeff + 'x^' + n_val + ' 的导数 f\'(x) = ？';
                exp = '幂函数求导：(x^n)\' = n·x^(n−1)，故 f\'(x) = ' + coeff + '×' + n_val + '·x^' + (n_val - 1) + ' = ' + ansCoeff + 'x^' + (n_val - 1) + '。';
            } else if (type === 1) {
                var wrongs = ['f\'(x) < 0', 'f(x) > 0', 'f(x) < 0'];
                o = opts('f\'(x) > 0', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) 在区间 I 上单调递增的充要条件是？';
                exp = 'f(x) 在 I 上单调递增 ⇔ f\'(x) ≥ 0（在 I 上恒成立）。';
            } else if (type === 2) {
                var a = rnd(1, 4);
                var wrongs = ['f(x) = 0', 'f\'(x) = 0', 'f\'\'(x) = 0'];
                o = opts('f\'(x) = 0 且 f\'\'(x) ≠ 0', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) 在 x₀ 处取得极值的必要条件是？';
                exp = '极值点必要条件是 f\'(x₀) = 0（驻点），但不是充分条件。';
            } else if (type === 3) {
                var x0 = rnd(1, 5);
                var slope = rnd(1, 6);
                var y0 = slope * x0 + rnd(1, 5);
                var wrongs = ['y − ' + x0 + ' = ' + slope + '(x − ' + y0 + ')', 'y = ' + slope + 'x + ' + x0, 'y = ' + slope + 'x + ' + y0];
                o = opts('y − ' + y0 + ' = ' + slope + '(x − ' + x0 + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '曲线 y = ' + slope + 'x + ' + (y0 - slope * x0) + ' 在点 (' + x0 + ', ' + y0 + ') 处的切线方程是？';
                exp = '切线斜率 k = ' + slope + '，切线方程：y − ' + y0 + ' = ' + slope + '(x − ' + x0 + ')。';
            } else if (type === 4) {
                var a = rnd(1, 5);
                var b = rnd(1, 5);
                var wrongs = [2 * a * b, a * b, a + b];
                o = opts(2 * a, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'f(x) = ' + a + 'x² + ' + b + ' 的导数 f\'(x) = ？';
                exp = 'f\'(x) = ' + (2 * a) + 'x。';
            } else if (type === 5) {
                var a = rnd(1, 5);
                var wrongs = [a, 0, a + 1];
                o = opts(a, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'f(x) = ' + a + 'x 的导数 f\'(x) = ？';
                exp = '一次函数导数 = 斜率 ' + a + '。';
            } else if (type === 6) {
                var a = rnd(1, 5);
                var wrongs = [a + 'e^' + a + 'x', 'e^' + a + 'x', a + 'e^x'];
                o = opts(a + 'e^' + a + 'x', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'f(x) = e^' + a + 'x 的导数 f\'(x) = ？';
                exp = '复合函数求导：(e^' + a + 'x)\' = ' + a + '·e^' + a + 'x。';
            } else {
                var a = rnd(1, 5);
                var wrongs = ['1/x', '1/' + a + 'x', a + '/x'];
                o = opts('1/x', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'f(x) = ln x 的导数 f\'(x) = ？';
                exp = '(ln x)\' = 1/x。';
            }
            results.push(Q(q, o, type < 3 ? '基础' : '进阶', exp, '导数与单调性'));
        }
        return results;
    }

    /* ============================================================
     * 13. 导数与单调性极值（十二年级）- 400+ 种组合
     * ============================================================ */
    function qDerivMon(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var a = rnd(2, 6);
                var n_val = rnd(2, 5);
                var coeff = a * n_val;
                var wrongs = [a + 'x^' + n_val, coeff + 'x^' + n_val, a * n_val + 'x^' + (n_val + 1)];
                o = opts(coeff + 'x^' + (n_val - 1), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'f(x) = ' + a + 'x^' + n_val + ' 的导数 f\'(x) = ？';
                exp = 'f\'(x) = ' + a + '·' + n_val + '·x^' + (n_val - 1) + ' = ' + coeff + 'x^' + (n_val - 1) + '。';
            } else if (type === 1) {
                var a = rnd(2, 5);
                var wrongs = ['(-∞, 0) 递增，(0, +∞) 递减', 'R 上递增', 'R 上递减'];
                o = opts('(-∞, 0) 递减，(0, +∞) 递增', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = ' + a + 'x² 的单调区间是？';
                exp = 'f\'(x) = ' + (2 * a) + 'x，当 x < 0 时 f\'(x) < 0（递减），当 x > 0 时 f\'(x) > 0（递增）。';
            } else if (type === 2) {
                var a = rnd(1, 4);
                var wrongs = ['x = 0 处取极大值', 'x = ' + a + ' 处取极值', '无极值'];
                o = opts('x = 0 处取极小值', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = ' + a + 'x² 在 x = 0 处的极值是？';
                exp = 'f\'(x) = ' + (2 * a) + 'x，x = 0 时 f\'(x) = 0，f\'\'(0) = ' + (2 * a) + ' > 0，取极小值。';
            } else if (type === 3) {
                var a = rnd(1, 5);
                var b = rnd(1, 5);
                var c = rnd(1, 5);
                var disc = b * b - 3 * a * c;
                var wrongs = [disc > 0 ? '无极值' : '有极值', '无法判断', disc > 0 ? '有极值' : '无极值'];
                o = opts(disc > 0 ? '有极值' : '无极值', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'f(x) = ' + a + 'x³ + ' + b + 'x² + ' + c + 'x，' + (disc > 0 ? '有' : '无') + '极值？';
                exp = 'f\'(x) = ' + (3 * a) + 'x² + ' + (2 * b) + 'x + ' + c + '，Δ = ' + disc + (disc > 0 ? ' > 0，有极值' : ' ≤ 0，无极值');
            } else if (type === 4) {
                var a = rnd(1, 5);
                var b = rnd(1, 5);
                var wrongs = ['f\'(x) = 0', 'f\'\'(x) = 0', 'f(x) = 0'];
                o = opts('f\'(x) = 0 且 f\'\'(x) ≠ 0', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) 在 x₀ 处取得极值的充分条件是？';
                exp = '极值点充分条件：f\'(x₀) = 0 且 f\'\'(x₀) ≠ 0。';
            } else if (type === 5) {
                var a = rnd(1, 5);
                var b = rnd(1, 5);
                var wrongs = [a + b, a - b, a * b];
                o = opts(a + b + 'x + ' + (a - b), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'f(x) = (' + a + 'x + ' + b + ')² 的导数 f\'(x) = ？';
                exp = 'f\'(x) = 2(' + a + 'x + ' + b + ')·' + a + ' = ' + (2 * a) + '(' + a + 'x + ' + b + ')。';
            } else if (type === 6) {
                var a = rnd(1, 5);
                var wrongs = ['f\'(x) > 0', 'f\'(x) = 0', 'f\'\'(x) > 0'];
                o = opts('f\'(x) < 0', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) 在区间 I 上单调递减的充要条件是？';
                exp = 'f(x) 在 I 上单调递减 ⇔ f\'(x) ≤ 0（在 I 上恒成立）。';
            } else {
                var a = rnd(1, 4);
                var wrongs = ['x = ' + a + ' 处取极小值', 'x = ' + (-a) + ' 处取极值', '无极值'];
                o = opts('x = 0 处取极大值', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = -' + a + 'x² 在 x = 0 处的极值是？';
                exp = 'f\'(x) = -' + (2 * a) + 'x，x = 0 时 f\'(x) = 0，f\'\'(0) = -' + (2 * a) + ' < 0，取极大值。';
            }
            results.push(Q(q, o, type < 3 ? '基础' : '进阶', exp, '导数与单调性极值'));
        }
        return results;
    }

    /* ============================================================
     * 14. 导数与不等式恒成立（十二年级）- 400+ 种组合
     * ============================================================ */
    function qDerivIneq(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var wrongs = ['f(x) > 0 在 R 上恒成立', 'f(x) ≤ 0 在 R 上恒成立', 'f(x) < 0 在 R 上恒成立'];
                o = opts('f(x) ≥ 0 在 R 上恒成立', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '不等式 f(x) ≥ 0 在定义域内恒成立的含义是？';
                exp = '恒成立指对于定义域内所有 x，都有 f(x) ≥ 0。';
            } else if (type === 1) {
                var a = rnd(1, 5);
                var ansMin = -a;
                var wrongs = ['f(x) ≥ ' + (ansMin + 1), 'f(x) ≤ ' + ansMin, 'f(x) > ' + ansMin];
                o = opts('f(x) ≥ ' + ansMin, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = x² − ' + a + ' 的最小值是？';
                exp = 'f(x) = x² − ' + a + ' ≥ −' + a + '，最小值为 ' + ansMin + '。';
            } else if (type === 2) {
                var a = rnd(1, 5);
                var wrongs = ['a < 0', 'a ≥ 0', 'a ≤ 0'];
                o = opts('a > 0', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = ' + a + 'x² + x 在 R 上单调递增，a 的取值范围是？';
                exp = 'f\'(x) = ' + (2 * a) + 'x + 1 ≥ 0 恒成立，需 a ≥ 0 且 1 ≥ 0，故 a ≥ 0。';
            } else if (type === 3) {
                var a = rnd(1, 5);
                var wrongs = ['a < ' + a, 'a > ' + a, 'a ≤ ' + a];
                o = opts('a ≥ ' + a, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'f(x) = x² + ' + a + 'x + 1 ≥ 0 恒成立，a 的取值范围是？';
                exp = 'Δ = ' + a + '² − 4 ≤ 0，即 ' + a + '² ≤ 4，a ∈ [-2, 2]。';
            } else if (type === 4) {
                var a = rnd(2, 6);
                var wrongs = ['a < ' + (a * a), 'a > ' + (a * a), 'a ≤ ' + (a * a)];
                o = opts('a ≥ ' + (a * a), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'f(x) = x² − ' + (2 * a) + 'x + ' + (a * a) + ' ≥ 0 恒成立，a 的取值范围是？';
                exp = 'f(x) = (x − ' + a + ')² ≥ 0 恒成立，a 为任意实数。';
            } else {
                var a = rnd(1, 5);
                var wrongs = ['a < 0', 'a > 0', 'a ≤ 0'];
                o = opts('a ≥ 0', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'f(x) = x³ + ' + a + 'x 在 R 上单调递增，a 的取值范围是？';
                exp = 'f\'(x) = 3x² + ' + a + ' ≥ 0 恒成立，需 a ≥ 0。';
            }
            results.push(Q(q, o, '进阶', exp, '导数与不等式恒成立'));
        }
        return results;
    }

    /* ============================================================
     * 15. 函数零点与极值点偏移（十二年级）- 400+ 种组合
     * ============================================================ */
    function qFuncZero(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var wrongs = ['f\'(x) = 0 的根', 'f\'\'(x) = 0 的根', 'f(x) 的极值点'];
                o = opts('f(x) = 0 的根', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) 的零点是指？';
                exp = '零点即方程 f(x) = 0 的实数根，或函数图像与 x 轴的交点。';
            } else if (type === 1) {
                var a = rnd(1, 5);
                var b = rnd(1, 5);
                var wrongs = ['f(a)·f(b) > 0', 'f(a) = f(b)', 'f\'(a) = f\'(b)'];
                o = opts('f(a)·f(b) < 0', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数在 [a,b] 上有零点的充分条件是？';
                exp = '零点存在定理：若 f(a)·f(b) < 0，则在 (a,b) 内至少有一个零点。';
            } else if (type === 2) {
                var a = rnd(1, 4);
                var wrongs = ['f(x₀) = 0', 'f\'(x₀) ≠ 0', 'f\'\'(x₀) = 0'];
                o = opts('f\'(x₀) = 0 且 f\'\'(x₀) ≠ 0', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) 在 x₀ 处取得极值的充分条件是？';
                exp = '极值点充分条件：f\'(x₀) = 0 且 f\'\'(x₀) ≠ 0。';
            } else if (type === 3) {
                var a = rnd(2, 6);
                var wrongs = ['0 个', '2 个', '无穷多个'];
                o = opts('1 个', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = x − ' + a + ' 的零点个数是？';
                exp = 'f(x) = 0 ⇒ x = ' + a + '，恰 1 个零点。';
            } else if (type === 4) {
                var a = rnd(2, 6);
                var wrongs = ['0 个', '2 个', '无穷多个'];
                o = opts('2 个', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = x² − ' + a + ' 的零点个数是？';
                exp = 'x² − ' + a + ' = 0 ⇒ x = ±√' + a + '，2 个零点。';
            } else {
                var a = rnd(2, 6);
                var wrongs = ['1 个', '2 个', '无穷多个'];
                o = opts('0 个', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = x² + ' + a + ' 的零点个数是？';
                exp = 'x² + ' + a + ' = 0 无实数解，0 个零点。';
            }
            results.push(Q(q, o, '基础', exp, '函数零点与极值点偏移'));
        }
        return results;
    }

    /* ============================================================
     * 16. 圆锥曲线初步（十二年级）- 400+ 种组合
     * ============================================================ */
    function qConic(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var wrongs = ['到两定点距离之差为常数', '到定点与定直线距离相等', '到两定点距离之比为常数'];
                o = opts('到两定点距离之和为常数', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '椭圆的定义是？';
                exp = '椭圆：平面内到两定点（焦点）距离之和为常数（大于两焦点距离）的点的轨迹。';
            } else if (type === 1) {
                var wrongs = ['到两定点距离之和为常数', '到定点与定直线距离相等', '到两定点距离之比为常数'];
                o = opts('到两定点距离之差的绝对值为常数', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '双曲线的定义是？';
                exp = '双曲线：平面内到两定点（焦点）距离之差的绝对值为常数（小于两焦点距离）的点的轨迹。';
            } else if (type === 2) {
                var wrongs = ['到两定点距离之和为常数', '到两定点距离之差为常数', '到两定点距离之比为常数'];
                o = opts('到定点与定直线距离相等', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '抛物线的定义是？';
                exp = '抛物线：平面内到定点（焦点）与定直线（准线）距离相等的点的轨迹。';
            } else if (type === 3) {
                var a = rnd(2, 8);
                var b = rnd(2, a - 1);
                var c = Math.sqrt(a * a - b * b);
                var e = c / a;
                var wrongs = [(e + 0.1).toFixed(2), (e - 0.1).toFixed(2), '1.00'];
                o = opts(e.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '椭圆 x²/' + (a * a) + ' + y²/' + (b * b) + ' = 1 的离心率 e ≈ ？';
                exp = 'c = √(a²−b²) = √' + (a * a - b * b) + ' = ' + c.toFixed(1) + '，e = c/a = ' + c.toFixed(1) + '/' + a + ' ≈ ' + e.toFixed(2) + '。';
            } else if (type === 4) {
                var wrongs = ['e = 1', 'e > 1', 'e = 0'];
                o = opts('e < 1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '椭圆的离心率 e 的范围是？';
                exp = '椭圆离心率 0 < e < 1，e 越接近 0 越圆，越接近 1 越扁。';
            } else if (type === 5) {
                var wrongs = ['e = 1', 'e < 1', 'e = 0'];
                o = opts('e > 1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '双曲线的离心率 e 的范围是？';
                exp = '双曲线离心率 e > 1。';
            } else if (type === 6) {
                var a = rnd(2, 8);
                var b = rnd(2, 8);
                var c = Math.sqrt(a * a + b * b);
                var e = c / a;
                var wrongs = [(e + 0.1).toFixed(2), (e - 0.1).toFixed(2), '1.00'];
                o = opts(e.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '双曲线 x²/' + (a * a) + ' − y²/' + (b * b) + ' = 1 的离心率 e ≈ ？';
                exp = 'c = √(a²+b²) = √' + (a * a + b * b) + ' = ' + c.toFixed(1) + '，e = c/a = ' + c.toFixed(1) + '/' + a + ' ≈ ' + e.toFixed(2) + '。';
            } else {
                var wrongs = ['2p', 'p/2', 'p²'];
                o = opts('p', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '抛物线 y² = 2px 的焦点到准线的距离是？';
                exp = '抛物线 y² = 2px 的焦点 (p/2, 0)，准线 x = −p/2，距离 = p。';
            }
            results.push(Q(q, o, '基础', exp, '圆锥曲线初步'));
        }
        return results;
    }

    /* ============================================================
     * 17. 联立与韦达定理（十二年级）- 400+ 种组合
     * ============================================================ */
    function qConicLink(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var sum = rnd(2, 8);
                var prod = rnd(2, 8);
                var wrongs = ['x₁+x₂=' + sum + ', x₁x₂=' + prod, 'x₁+x₂=' + (-sum) + ', x₁x₂=' + (-prod), 'x₁+x₂=' + sum + ', x₁x₂=' + (-prod)];
                o = opts('x₁+x₂=' + (-sum) + ', x₁x₂=' + prod, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '方程 x² + ' + sum + 'x + ' + prod + ' = 0 的两根 x₁, x₂，由韦达定理得？';
                exp = '韦达定理：x₁+x₂ = −b/a = −' + sum + '，x₁x₂ = c/a = ' + prod + '。';
            } else if (type === 1) {
                var a = rnd(1, 3);
                var b = rnd(2, 8);
                var c = rnd(1, 6);
                var delta = b * b - 4 * a * c;
                var wrongs = [delta > 0 ? '无实根' : '有两个不等实根', delta > 0 ? '有两个相等实根' : '无法判断', '有复数根'];
                o = opts(delta > 0 ? '有两个不等实根' : delta === 0 ? '有两个相等实根' : '无实根', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '方程 ' + a + 'x² + ' + b + 'x + ' + c + ' = 0 的判别式 Δ = ' + delta + '，根的情况是？';
                exp = 'Δ = ' + b + '² − 4×' + a + '×' + c + ' = ' + delta + '，Δ ' + (delta > 0 ? '>' : delta === 0 ? '=' : '<') + ' 0，故' + (delta > 0 ? '有两个不等实根' : delta === 0 ? '有两个相等实根' : '无实根') + '。';
            } else if (type === 2) {
                var k = rnd(1, 4);
                var wrongs = ['√(1+k²)·(x₁+x₂)', '|x₁−x₂|', '√(1+k²)·√((x₁+x₂)²−4x₁x₂)'];
                o = opts('√(1+k²)·|x₁−x₂|', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '直线 y = ' + k + 'x + b 与曲线相交，弦长公式是？';
                exp = '弦长 = √(1+k²)·|x₁−x₂| = √(1+k²)·√Δ/|a|。';
            } else if (type === 3) {
                var sum = rnd(3, 10);
                var prod = rnd(2, 8);
                var wrongs = ['x₁+x₂=' + sum + ', x₁x₂=' + (-prod), 'x₁+x₂=' + (-sum) + ', x₁x₂=' + (-prod), 'x₁+x₂=' + (-sum) + ', x₁x₂=' + prod];
                o = opts('x₁+x₂=' + (-sum) + ', x₁x₂=' + prod, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '方程 x² − ' + sum + 'x + ' + prod + ' = 0 的两根 x₁, x₂，由韦达定理得？';
                exp = '韦达定理：x₁+x₂ = −b/a = ' + sum + '，x₁x₂ = c/a = ' + prod + '。';
            } else if (type === 4) {
                var a = rnd(1, 3);
                var b = rnd(2, 8);
                var c = rnd(1, 6);
                var delta = b * b - 4 * a * c;
                var wrongs = ['Δ = ' + (delta + 1), 'Δ = ' + (delta - 1), 'Δ = 0'];
                o = opts('Δ = ' + delta, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '方程 ' + a + 'x² + ' + b + 'x + ' + c + ' = 0 的判别式 Δ = ？';
                exp = 'Δ = ' + b + '² − 4×' + a + '×' + c + ' = ' + delta + '。';
            } else {
                var a = rnd(1, 3);
                var b = rnd(2, 8);
                var c = rnd(1, 6);
                var delta = b * b - 4 * a * c;
                var wrongs = [delta > 0 ? '无实根' : '有两个不等实根', delta > 0 ? '有两个相等实根' : '无法判断', '有复数根'];
                o = opts(delta > 0 ? '有两个不等实根' : delta === 0 ? '有两个相等实根' : '无实根', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '方程 ' + a + 'x² + ' + b + 'x + ' + c + ' = 0 的判别式 Δ = ' + delta + '，根的情况是？';
                exp = 'Δ = ' + b + '² − 4×' + a + '×' + c + ' = ' + delta + '，Δ ' + (delta > 0 ? '>' : delta === 0 ? '=' : '<') + ' 0，故' + (delta > 0 ? '有两个不等实根' : delta === 0 ? '有两个相等实根' : '无实根') + '。';
            }
            results.push(Q(q, o, '进阶', exp, '联立与韦达定理'));
        }
        return results;
    }

    /* ============================================================
     * 18. 弦长·中点·定点定值（十二年级）- 400+ 种组合
     * ============================================================ */
    function qConicChord(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var x1 = rnd(1, 8);
                var x2 = rnd(1, 8);
                var mid = (x1 + x2) / 2;
                var wrongs = [mid + 1, mid - 1, x1 + x2];
                o = opts(mid, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '线段两端点横坐标为 ' + x1 + ' 和 ' + x2 + '，中点横坐标是？';
                exp = '中点横坐标 = (' + x1 + ' + ' + x2 + ') / 2 = ' + mid + '。';
            } else if (type === 1) {
                var a = rnd(1, 3);
                var b = rnd(2, 8);
                var c = rnd(1, 6);
                var delta = b * b - 4 * a * c;
                var dist = Math.sqrt(delta) / a;
                var wrongs = [delta, Math.sqrt(delta), delta / 2];
                o = opts(dist, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '方程 ' + a + 'x² + ' + b + 'x + ' + c + ' = 0 的两根距离 |x₁−x₂| = ？';
                exp = '|x₁−x₂| = √Δ/|a| = √' + delta + '/' + a + ' = ' + dist + '。';
            } else if (type === 2) {
                var b = rnd(1, 6);
                var wrongs = ['直线过定点 (' + b + ', 0)', '直线过原点', '直线不过定点'];
                o = opts('直线过定点 (0, ' + b + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '直线 y = kx + ' + b + ' (k 为参数) 恒过定点？';
                exp = '当 x = 0 时 y = ' + b + '，故直线恒过定点 (0, ' + b + ')。';
            } else if (type === 3) {
                var x1 = rnd(1, 8);
                var y1 = rnd(1, 8);
                var x2 = rnd(1, 8);
                var y2 = rnd(1, 8);
                var midX = (x1 + x2) / 2;
                var midY = (y1 + y2) / 2;
                var wrongs = ['(' + (midX + 1) + ',' + midY + ')', '(' + midX + ',' + (midY + 1) + ')', '(' + x1 + ',' + y1 + ')'];
                o = opts('(' + midX + ',' + midY + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'A(' + x1 + ',' + y1 + '), B(' + x2 + ',' + y2 + ') 的中点坐标是？';
                exp = '中点 = ((' + x1 + '+' + x2 + ')/2, (' + y1 + '+' + y2 + ')/2) = (' + midX + ',' + midY + ')。';
            } else if (type === 4) {
                var a = rnd(2, 6);
                var b = rnd(1, 5);
                var wrongs = ['√(1+' + b + '²)·|x₁−x₂|', '√(1+' + b + '²)·(x₁+x₂)', '|x₁−x₂|'];
                o = opts('√(1+' + b + '²)·|x₁−x₂|', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '直线 y = ' + b + 'x + ' + a + ' 与曲线相交，弦长公式是？';
                exp = '弦长 = √(1+k²)·|x₁−x₂|，k=' + b + '，故为 √(1+' + b + '²)·|x₁−x₂|。';
            } else {
                var b = rnd(1, 6);
                var wrongs = ['直线过定点 (' + b + ', 0)', '直线过原点', '直线不过定点'];
                o = opts('直线过定点 (0, ' + b + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '直线 y = kx + ' + b + ' (k 为参数) 恒过定点？';
                exp = '当 x = 0 时 y = ' + b + '，故直线恒过定点 (0, ' + b + ')。';
            }
            results.push(Q(q, o, '进阶', exp, '弦长·中点·定点定值'));
        }
        return results;
    }

    /* ============================================================
     * 19. 圆锥曲线性质（十二年级）- 400+ 种组合
     * ============================================================ */
    function qConicProp(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var a = rnd(3, 10);
                var b = rnd(2, a - 1);
                var c = Math.sqrt(a * a - b * b);
                var e = c / a;
                var wrongs = [(e + 0.1).toFixed(2), (e - 0.1).toFixed(2), '1.00'];
                o = opts(e.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '椭圆 x²/' + (a * a) + ' + y²/' + (b * b) + ' = 1 的离心率 e ≈ ？';
                exp = 'c = √(a²−b²) = √' + (a * a - b * b) + ' = ' + c.toFixed(1) + '，e = c/a = ' + c.toFixed(1) + '/' + a + ' ≈ ' + e.toFixed(2) + '。';
            } else if (type === 1) {
                var a = rnd(2, 7);
                var b = rnd(2, 7);
                var c = Math.sqrt(a * a + b * b);
                var e = c / a;
                var wrongs = [(e + 0.1).toFixed(2), (e - 0.1).toFixed(2), '1.00'];
                o = opts(e.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '双曲线 x²/' + (a * a) + ' − y²/' + (b * b) + ' = 1 的离心率 e ≈ ？';
                exp = 'c = √(a²+b²) = √' + (a * a + b * b) + ' = ' + c.toFixed(1) + '，e = c/a = ' + c.toFixed(1) + '/' + a + ' ≈ ' + e.toFixed(2) + '。';
            } else if (type === 2) {
                var wrongs = ['2p', 'p/2', 'p²'];
                o = opts('p', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '抛物线 y² = 2px 的焦点到准线的距离是？';
                exp = '抛物线 y² = 2px 的焦点 (p/2, 0)，准线 x = −p/2，距离 = p。';
            } else if (type === 3) {
                var r = rnd(2, 6);
                var wrongs = ['xx₀ − yy₀ = r²', 'x + y = r', 'xy = r²'];
                o = opts('xx₀ + yy₀ = r²', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '圆 x² + y² = ' + (r * r) + ' 在点 (x₀, y₀) 处的切线方程是？';
                exp = '圆的切线方程：xx₀ + yy₀ = r²。';
            } else if (type === 4) {
                var a = rnd(2, 6);
                var wrongs = ['(±' + a + ', 0)', '(0, ±' + a + ')', '(±' + a + ', ±' + a + ')'];
                o = opts('(±' + a + ', 0)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '椭圆 x²/' + (a * a) + ' + y²/1 = 1 的焦点坐标是？';
                exp = 'c = √(' + (a * a) + ' − 1)，焦点为 (±c, 0)。';
            } else if (type === 5) {
                var a = rnd(2, 6);
                var wrongs = ['(±' + a + ', 0)', '(0, ±' + a + ')', '(±' + a + ', ±' + a + ')'];
                o = opts('(±' + a + ', 0)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '双曲线 x²/' + (a * a) + ' − y²/1 = 1 的焦点坐标是？';
                exp = 'c = √(' + (a * a) + ' + 1)，焦点为 (±c, 0)。';
            } else if (type === 6) {
                var p = rnd(1, 5);
                var wrongs = ['(' + p + ', 0)', '(0, ' + p + '/2)', '(0, ' + p + ')'];
                o = opts('(' + p + '/2, 0)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '抛物线 y² = ' + (2 * p) + 'x 的焦点坐标是？';
                exp = '焦点为 (p/2, 0)。';
            } else {
                var p = rnd(1, 5);
                var wrongs = ['x = ' + p, 'x = ' + (p / 2), 'x = ' + (2 * p)];
                o = opts('x = -' + (p / 2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '抛物线 y² = ' + (2 * p) + 'x 的准线方程是？';
                exp = '准线为 x = −p/2。';
            }
            results.push(Q(q, o, type < 3 ? '基础' : '进阶', exp, '圆锥曲线性质'));
        }
        return results;
    }

    /* ============================================================
     * 20. 参数方程与极坐标（十二年级）- 400+ 种组合
     * ============================================================ */
    function qParamEq(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var r = rnd(2, 8);
                var wrongs = ['x² − y² = r²', 'y = kx + b', 'x = r'];
                o = opts('x² + y² = r²', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '参数方程 x = ' + r + 'cosθ, y = ' + r + 'sinθ 消参后是？';
                exp = 'x² + y² = ' + r + '²cos²θ + ' + r + '²sin²θ = ' + r + '²(cos²θ + sin²θ) = ' + r + '²。';
            } else if (type === 1) {
                var r = rnd(2, 8);
                var wrongs = [r + 'sinθ', r + '/cosθ', r + '/sinθ'];
                o = opts(r + 'cosθ', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '极坐标 ρ = ' + r + 'cosθ 化为直角坐标方程是？';
                exp = 'ρ = ' + r + 'cosθ → ρ² = ' + r + 'ρcosθ → x² + y² = ' + r + 'x → (x−' + r + '/2)² + y² = ' + (r * r) + '/4。';
            } else if (type === 2) {
                var wrongs = ['θ', 'ρ', 'φ'];
                o = opts('t', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '参数方程 x = t², y = 2t 中的参数通常是？';
                exp = '参数方程中的变量 t（或 θ）称为参数。';
            } else if (type === 3) {
                var a = rnd(2, 6);
                var b = rnd(2, 6);
                var wrongs = ['x² + y² = ' + (a * a + b * b), 'x² − y² = ' + (a * a - b * b), 'y = ' + (b / a) + 'x'];
                o = opts('x²/' + (a * a) + ' + y²/' + (b * b) + ' = 1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '参数方程 x = ' + a + 'cosθ, y = ' + b + 'sinθ 消参后是？';
                exp = 'x²/' + (a * a) + ' + y²/' + (b * b) + ' = cos²θ + sin²θ = 1。';
            } else if (type === 4) {
                var a = rnd(2, 6);
                var b = rnd(2, 6);
                var wrongs = ['x² + y² = ' + (a * a + b * b), 'x² + y² = ' + (a * a - b * b), 'y = ' + (b / a) + 'x'];
                o = opts('x²/' + (a * a) + ' − y²/' + (b * b) + ' = 1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '参数方程 x = ' + a + 'secθ, y = ' + b + 'tanθ 消参后是？';
                exp = 'sec²θ − tan²θ = 1，故 x²/' + (a * a) + ' − y²/' + (b * b) + ' = 1。';
            } else {
                var r = rnd(2, 8);
                var wrongs = ['ρ = ' + r, 'ρ = ' + (2 * r) + 'cosθ', 'ρ = ' + (2 * r) + 'sinθ'];
                o = opts('ρ = ' + (2 * r) + 'cosθ', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '圆 (x−' + r + ')² + y² = ' + (r * r) + ' 的极坐标方程是？';
                exp = 'x² + y² = 2' + r + 'x → ρ² = 2' + r + 'ρcosθ → ρ = 2' + r + 'cosθ。';
            }
            results.push(Q(q, o, '基础', exp, '参数方程与极坐标'));
        }
        return results;
    }
    
        /* ============================================================
     * 21. 复数运算（十年级）- 400+ 种组合
     * ============================================================ */
    function qComplex(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var a = rnd(1, 6);
                var b = rnd(1, 6);
                var c = rnd(1, 6);
                var d = rnd(1, 6);
                var real = a + c;
                var imag = b + d;
                var wrongs = [(real + 1) + '+' + imag + 'i', real + '+' + (imag + 1) + 'i', (a + c) + '+' + (b - d) + 'i'];
                o = opts(real + '+' + imag + 'i', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '( ' + a + '+' + b + 'i ) + ( ' + c + '+' + d + 'i ) = ？';
                exp = '复数加法：实部加实部，虚部加虚部 = (' + real + ') + (' + imag + ')i。';
            } else if (type === 1) {
                var a = rnd(1, 4);
                var b = rnd(1, 4);
                var c = rnd(1, 4);
                var d = rnd(1, 4);
                var real = a * c - b * d;
                var imag = a * d + b * c;
                var wrongs = [(real + 1) + '+' + imag + 'i', real + '+' + (imag + 1) + 'i', (a * c) + '+' + (b * d) + 'i'];
                o = opts(real + '+' + imag + 'i', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '( ' + a + '+' + b + 'i ) · ( ' + c + '+' + d + 'i ) = ？';
                exp = '复数乘法：(a+bi)(c+di) = (ac−bd) + (ad+bc)i = ' + real + ' + ' + imag + 'i。';
            } else if (type === 2) {
                var a = rnd(1, 6);
                var b = rnd(1, 6);
                var wrongs = [a + '+' + b + 'i', '-' + a + '+' + b + 'i', '-' + a + '-' + b + 'i'];
                o = opts(a + '-' + b + 'i', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '复数 z = ' + a + '+' + b + 'i 的共轭复数是？';
                exp = '共轭复数实部不变，虚部变号：z̄ = ' + a + ' − ' + b + 'i。';
            } else if (type === 3) {
                var a = rnd(2, 6);
                var b = rnd(2, 6);
                var mod = Math.sqrt(a * a + b * b);
                var wrongs = [(mod + 1).toFixed(1), (mod - 1).toFixed(1), (a + b).toFixed(1)];
                o = opts(mod.toFixed(1), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '复数 z = ' + a + '+' + b + 'i 的模 |z| = ？';
                exp = '|z| = √(a²+b²) = √(' + (a * a) + '+' + (b * b) + ') = ' + mod.toFixed(1) + '。';
            } else if (type === 4) {
                var a = rnd(1, 6);
                var b = rnd(1, 6);
                var wrongs = ['(' + a + '−' + b + 'i)²', '(' + a + '+' + b + 'i)²', '(' + a + '−' + b + 'i)'];
                o = opts('(' + a + '+' + b + 'i)(' + a + '−' + b + 'i)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'z = ' + a + '+' + b + 'i，z·z̄ = ？';
                exp = 'z·z̄ = |z|² = ' + (a * a + b * b) + '。';
            } else if (type === 5) {
                var a = rnd(1, 4);
                var b = rnd(1, 4);
                var wrongs = [(a + b) + 'i', (a - b) + 'i', '-' + a + '+' + b + 'i'];
                o = opts(a + '+' + b + 'i', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'i·(' + b + '+' + a + 'i) = ？';
                exp = 'i·(' + b + '+' + a + 'i) = ' + b + 'i + ' + a + 'i² = ' + a + '−' + b + 'i。';
            } else if (type === 6) {
                var n = rnd(1, 4);
                var pattern = ['i', '-1', '-i', '1'];
                var ans = pattern[n % 4];
                var wrongs = pattern.filter(function(w) { return w !== ans; });
                o = opts(ans, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'i^' + (n + 1) + ' = ？';
                exp = 'i 的幂周期为 4：i^1=i, i^2=-1, i^3=-i, i^4=1，i^' + (n + 1) + '=' + ans + '。';
            } else {
                var a = rnd(1, 5);
                var b = rnd(1, 5);
                var wrongs = [(a + b) + 'i', (a - b) + 'i', '-' + a + '+' + b + 'i'];
                o = opts(a + '+' + b + 'i', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '(-' + b + '+' + a + 'i)·i = ？';
                exp = '(-' + b + '+' + a + 'i)·i = -' + b + 'i + ' + a + 'i² = -' + a + '−' + b + 'i。';
            }
            results.push(Q(q, o, '基础', exp, '复数运算'));
        }
        return results;
    }

    /* ============================================================
     * 22. 分布列与期望方差（十二年级）- 400+ 种组合
     * ============================================================ */
    function qDistExp(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var E = rnd(2, 12);
                var wrongs = [E + 1, E - 1, E * 2];
                o = opts(E * 2, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '随机变量 X 的期望 E(X) = ' + E + '，则 E(2X) = ？';
                exp = 'E(2X) = 2E(X) = 2 × ' + E + ' = ' + (E * 2) + '。';
            } else if (type === 1) {
                var D = rnd(1, 6);
                var wrongs = [D * 2, D / 2, D + 1];
                o = opts(D * 4, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '随机变量 X 的方差 D(X) = ' + D + '，则 D(2X) = ？';
                exp = 'D(2X) = 4D(X) = 4 × ' + D + ' = ' + (D * 4) + '。';
            } else if (type === 2) {
                var wrongs = ['所有概率之和为 0', '概率可以为负', '概率可以大于 1'];
                o = opts('所有概率之和为 1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '离散型随机变量分布列的基本性质是？';
                exp = '分布列性质：所有概率 P(X=xᵢ) ≥ 0，且 ΣP(X=xᵢ) = 1。';
            } else if (type === 3) {
                var a = rnd(2, 5);
                var b = rnd(1, 6);
                var E = rnd(1, 5);
                var wrongs = [a * E, a * E + b * b, E + b];
                o = opts(a * E + b, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'E(aX+b) = aE(X)+b，E(X)=' + E + '，a=' + a + '，b=' + b + '，E(aX+b)=？';
                exp = 'E(aX+b) = aE(X)+b = ' + a + '×' + E + '+' + b + ' = ' + (a * E + b) + '。';
            } else if (type === 4) {
                var D = rnd(1, 5);
                var wrongs = [D * 2, D + 1, D / 2];
                o = opts(D * 4, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'D(2X) = 4D(X)，D(X)=' + D + '，D(2X)=？';
                exp = 'D(2X) = 4×' + D + ' = ' + (D * 4) + '。';
            } else if (type === 5) {
                var p = rnd(2, 8) / 10;
                var E = p;
                var D = p * (1 - p);
                var wrongs = [E + 0.1, D + 0.1, E * D];
                o = opts(E.toFixed(2) + ', ' + D.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'X~两点分布，P(X=1)=' + p.toFixed(1) + '，E(X)、D(X) 是？';
                exp = '两点分布：E=p=' + p.toFixed(1) + '，D=p(1-p)=' + D.toFixed(2) + '。';
            } else if (type === 6) {
                var n = rnd(5, 15);
                var p = rnd(2, 7) / 10;
                var E = n * p;
                var D = n * p * (1 - p);
                var wrongs = [E + 0.5, D + 0.5, E * D];
                o = opts(E.toFixed(1) + ', ' + D.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'X~B(' + n + ', ' + p.toFixed(1) + ')，E(X)、D(X) 是？';
                exp = '二项分布：E=np=' + n + '×' + p.toFixed(1) + '=' + E.toFixed(1) + '，D=np(1-p)=' + D.toFixed(2) + '。';
            } else {
                var wrongs = ['E(aX+b) = aE(X)', 'E(aX+b) = aE(X)+b²', 'E(aX+b) = E(X)+b'];
                o = opts('E(aX+b) = aE(X)+b', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '期望的线性性质是？';
                exp = 'E(aX + b) = aE(X) + b。';
            }
            results.push(Q(q, o, '基础', exp, '分布列与期望方差'));
        }
        return results;
    }

    /* ============================================================
     * 23. 二项分布与正态分布（十二年级）- 400+ 种组合
     * ============================================================ */
    function qDistBinom(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var n_trials = rnd(2, 12);
                var p = rnd(2, 8) / 10;
                var E = n_trials * p;
                var wrongs = [E + 0.5, E - 0.5, p];
                o = opts(E.toFixed(1), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'X ~ B(' + n_trials + ', ' + p.toFixed(1) + ')，E(X) = ？';
                exp = '二项分布期望 E(X) = np = ' + n_trials + ' × ' + p.toFixed(1) + ' = ' + E.toFixed(1) + '。';
            } else if (type === 1) {
                var n_trials = rnd(2, 12);
                var p = rnd(2, 8) / 10;
                var D = n_trials * p * (1 - p);
                var wrongs = [D + 0.3, D - 0.3, p];
                o = opts(D.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'X ~ B(' + n_trials + ', ' + p.toFixed(1) + ')，D(X) = ？';
                exp = '二项分布方差 D(X) = np(1−p) = ' + n_trials + ' × ' + p.toFixed(1) + ' × ' + (1 - p).toFixed(1) + ' = ' + D.toFixed(2) + '。';
            } else if (type === 2) {
                var wrongs = ['关于 σ 对称', '关于 0 对称', '无对称性'];
                o = opts('关于 μ 对称', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '正态分布 N(μ, σ²) 的图像关于？对称';
                exp = '正态分布曲线关于 μ 对称，μ 是均值（中心位置）。';
            } else if (type === 3) {
                var wrongs = ['μ=0, σ=0', 'μ=1, σ=0', 'μ=1, σ=1'];
                o = opts('μ=0, σ=1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '标准正态分布 N(0,1) 的参数是？';
                exp = '标准正态分布：均值 μ = 0，标准差 σ = 1。';
            } else if (type === 4) {
                var mu = rnd(95, 105);
                var sig = rnd(2, 8);
                var wrongs = ['[' + (mu - sig + 1) + ', ' + (mu + sig + 1) + ']', '[' + mu + ', ' + (mu + sig) + ']', '[' + (mu - sig) + ', ' + mu + ']'];
                o = opts('[' + (mu - sig) + ', ' + (mu + sig) + ']', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'X~N(' + mu + ', ' + sig + '²)，约 68.27% 的数据落在哪个区间？';
                exp = 'P(μ−σ<X<μ+σ)≈0.6827，区间为 [' + (mu - sig) + ', ' + (mu + sig) + ']。';
            } else if (type === 5) {
                var mu = rnd(95, 105);
                var sig = rnd(2, 6);
                var wrongs = ['[' + (mu - sig) + ', ' + (mu + sig) + ']', '[' + mu + ', ' + (mu + 2 * sig) + ']', '[' + (mu - 2 * sig) + ', ' + mu + ']'];
                o = opts('[' + (mu - 2 * sig) + ', ' + (mu + 2 * sig) + ']', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'X~N(' + mu + ', ' + sig + '²)，约 95.45% 的数据落在哪个区间？';
                exp = 'P(μ−2σ<X<μ+2σ)≈0.9545，区间为 [' + (mu - 2 * sig) + ', ' + (mu + 2 * sig) + ']。';
            } else if (type === 6) {
                var mu = rnd(95, 105);
                var sig = rnd(2, 5);
                var wrongs = ['[' + (mu - 2 * sig) + ', ' + (mu + 2 * sig) + ']', '[' + mu + ', ' + (mu + 3 * sig) + ']', '[' + (mu - 3 * sig) + ', ' + mu + ']'];
                o = opts('[' + (mu - 3 * sig) + ', ' + (mu + 3 * sig) + ']', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'X~N(' + mu + ', ' + sig + '²)，约 99.74% 的数据落在哪个区间？';
                exp = 'P(μ−3σ<X<μ+3σ)≈0.9974，区间为 [' + (mu - 3 * sig) + ', ' + (mu + 3 * sig) + ']。';
            } else {
                var n_trials = rnd(3, 10);
                var p = rnd(3, 7) / 10;
                var E = n_trials * p;
                var D = n_trials * p * (1 - p);
                var wrongs = [E + 0.5, D + 0.5, E * D];
                o = opts(E.toFixed(1) + ', ' + D.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'X~B(' + n_trials + ', ' + p.toFixed(1) + ')，E(X)、D(X) 是？';
                exp = '二项分布：E=np=' + n_trials + '×' + p.toFixed(1) + '=' + E.toFixed(1) + '，D=np(1-p)=' + D.toFixed(2) + '。';
            }
            results.push(Q(q, o, '基础', exp, '二项分布与正态分布'));
        }
        return results;
    }

    /* ============================================================
     * 24. 统计案例（十二年级）- 400+ 种组合
     * ============================================================ */
    function qStatCase(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var vals = [];
                for (var j = 0; j < 4; j++) vals.push(rnd(60, 100));
                var avg = Math.round(vals.reduce(function(a, b) { return a + b; }, 0) / 4);
                var wrongs = [avg + 5, avg - 5, vals[0]];
                o = opts(avg, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '数据 ' + vals[0] + ', ' + vals[1] + ', ' + vals[2] + ', ' + vals[3] + ' 的平均数是？';
                exp = '平均数 = (' + vals[0] + '+' + vals[1] + '+' + vals[2] + '+' + vals[3] + ')/4 = ' + avg + '。';
            } else if (type === 1) {
                var vals = [rnd(10, 50), rnd(51, 90), rnd(91, 130), rnd(131, 170), rnd(171, 200)];
                vals.sort(function(a, b) { return a - b; });
                var med = vals[2];
                var wrongs = [vals[1], vals[3], vals[0]];
                o = opts(med, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '数据 ' + vals.join(', ') + ' 的中位数是？';
                exp = '排序后中间值为 ' + med + '。';
            } else if (type === 2) {
                var mean = rnd(50, 100);
                var vals = [mean - rnd(5, 20), mean, mean + rnd(5, 20), mean];
                var variance = Math.round(vals.reduce(function(s, v) { return s + (v - mean) * (v - mean); }, 0) / 4);
                var wrongs = [variance + 10, variance - 10, mean];
                o = opts(variance, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '数据 ' + vals.join(', ') + '（均值 ' + mean + '）的方差是？';
                exp = '方差 = [(v₁−μ)²+...+(v₄−μ)²]/4 = ' + variance + '。';
            } else if (type === 3) {
                var wrongs = ['各组频率之和为 0', '各组频数之和为 1', '频率可以大于 1'];
                o = opts('各组频率之和为 1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '频率分布直方图的基本性质是？';
                exp = '频率分布性质：各组频率之和 = 1，各组频数之和 = 样本容量。';
            } else if (type === 4) {
                var vals = [];
                for (var j = 0; j < 5; j++) vals.push(rnd(60, 100));
                var avg = Math.round(vals.reduce(function(a, b) { return a + b; }, 0) / 5);
                var wrongs = [avg + 3, avg - 3, vals[0]];
                o = opts(avg, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '数据 ' + vals.join(', ') + ' 的平均数是？';
                exp = '平均数 = (' + vals.join('+') + ')/5 = ' + avg + '。';
            } else if (type === 5) {
                var vals = [rnd(1, 20), rnd(21, 40), rnd(41, 60), rnd(61, 80), rnd(81, 100)];
                vals.sort(function(a, b) { return a - b; });
                var med = vals[2];
                var wrongs = [vals[1], vals[3], vals[0]];
                o = opts(med, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '数据 ' + vals.join(', ') + ' 的中位数是？';
                exp = '排序后中间值为 ' + med + '。';
            } else if (type === 6) {
                var vals = [rnd(1, 5), rnd(1, 5), rnd(1, 5), rnd(1, 5), rnd(1, 5)];
                var mode = vals.sort()[2];
                var wrongs = [mode + 1, mode - 1, vals[0]];
                o = opts(mode, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '数据 ' + vals.join(', ') + ' 的众数是？';
                exp = '出现次数最多的是 ' + mode + '。';
            } else {
                var wrongs = ['各组频率之和为 0', '各组频数之和为 1', '频率可以大于 1'];
                o = opts('各组频率之和为 1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '频率分布直方图的基本性质是？';
                exp = '频率分布性质：各组频率之和 = 1，各组频数之和 = 样本容量。';
            }
            results.push(Q(q, o, '基础', exp, '统计案例'));
        }
        return results;
    }

    /* ============================================================
     * 25-50. 拓展专题（高中/大学先修）- 每个 400+ 种组合
     * ============================================================ */

    // 25. 欧拉公式
    function qEuler(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var wrongs = ['cosθ − i·sinθ', 'sinθ + i·cosθ', 'e^θ'];
                o = opts('cosθ + i·sinθ', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '欧拉公式：e^(iθ) 等于？';
                exp = '欧拉公式 e^(iθ) = cosθ + i·sinθ，把复数与三角联系起来。';
            } else if (type === 1) {
                var wrongs = ['1', 'i', '0'];
                o = opts('-1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '欧拉恒等式中 e^(iπ) 的值是？';
                exp = 'e^(iπ) = cosπ + i·sinπ = -1 + 0 = -1，故 e^(iπ) + 1 = 0。';
            } else if (type === 2) {
                var wrongs = ['-i', '1', '-1'];
                o = opts('i', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'e^(i·π/2) 的值是？';
                exp = 'e^(iπ/2) = cos(π/2) + i·sin(π/2) = 0 + i·1 = i。';
            } else if (type === 3) {
                var wrongs = ['|cosθ|', 'θ', 'e^θ'];
                o = opts('1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '复数 e^(iθ) 的模长 |e^(iθ)| 是？';
                exp = '|cosθ + i·sinθ| = √(cos²θ + sin²θ) = 1，始终在单位圆上。';
            } else if (type === 4) {
                var theta = pick([0, 30, 45, 60, 90, 120, 135, 150, 180]);
                var rad = theta * Math.PI / 180;
                var real = Math.cos(rad).toFixed(2);
                var imag = Math.sin(rad).toFixed(2);
                var wrongs = [real + '-' + imag + 'i', imag + '+' + real + 'i', '-' + real + '+' + imag + 'i'];
                o = opts(real + '+' + imag + 'i', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'e^(i·' + theta + '°) = ？';
                exp = 'e^(i·' + theta + '°) = cos' + theta + '° + i·sin' + theta + '° = ' + real + '+' + imag + 'i。';
            } else {
                var wrongs = ['1', '|cosθ|', 'e^θ'];
                o = opts('1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '|e^(iθ)| 等于？';
                exp = '单位圆上，模长恒为 1。';
            }
            results.push(Q(q, o, '基础', exp, '欧拉公式', 'euler_circle'));
        }
        return results;
    }

    // 26. 泰勒级数
    function qTaylor(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var wrongs = ['1/6', '1/12', '1/2'];
                o = opts('1/24', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'e^x 的麦克劳林展开中 x⁴ 项的系数是？';
                exp = 'e^x = Σ xⁿ/n!，x⁴ 系数 = 1/4! = 1/24。';
            } else if (type === 1) {
                var wrongs = ['1', '-1', '1/2'];
                o = opts('0', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'sin x 的麦克劳林展开中 x² 项的系数是？';
                exp = 'sin x = x − x³/3! + x⁵/5! − …，只含奇次幂，x² 系数为 0。';
            } else if (type === 2) {
                var wrongs = ['1/2', '-1', '1'];
                o = opts('-1/2', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'cos x 的麦克劳林展开中 x² 项的系数是？';
                exp = 'cos x = 1 − x²/2! + x⁴/4! − …，x² 系数 = −1/2。';
            } else if (type === 3) {
                var wrongs = ['-1', '1/2', '0'];
                o = opts('1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'ln(1+x) 的麦克劳林展开中 x 项的系数是？';
                exp = 'ln(1+x) = x − x²/2 + x³/3 − …，x 项系数为 1。';
            } else if (type === 4) {
                var wrongs = ['1/6', '1/12', '1/2'];
                o = opts('1/24', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'sin x 的麦克劳林展开中 x⁵ 项的系数是？';
                exp = 'sin x = x − x³/3! + x⁵/5! − …，x⁵ 系数 = 1/5! = 1/120。';
            } else if (type === 5) {
                var wrongs = ['1/6', '1/12', '1/2'];
                o = opts('1/24', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'cos x 的麦克劳林展开中 x⁴ 项的系数是？';
                exp = 'cos x = 1 − x²/2! + x⁴/4! − …，x⁴ 系数 = 1/4! = 1/24。';
            } else if (type === 6) {
                var wrongs = ['1/6', '1/12', '1/2'];
                o = opts('1/24', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'e^x 的麦克劳林展开中 x³ 项的系数是？';
                exp = 'e^x = Σ xⁿ/n!，x³ 系数 = 1/3! = 1/6。';
            } else {
                var wrongs = ['-1', '1/2', '0'];
                o = opts('1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '1/(1−x) 的麦克劳林展开中 x³ 项的系数是？';
                exp = '等比级数 1/(1−x) = 1 + x + x² + x³ + …，x³ 系数 = 1。';
            }
            results.push(Q(q, o, '进阶', exp, '泰勒级数', 'taylor_graph'));
        }
        return results;
    }

    // 27. 数形结合
    function qNumShape(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var wrongs = ['原点', '点 0', '点 x'];
                o = opts('点 3', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '|x − 3| 的几何意义是数轴上点 x 到哪里的距离？';
                exp = '|x − a| 表示点 x 到点 a 的距离，故 |x−3| 是到 3 的距离。';
            } else if (type === 1) {
                var wrongs = ['-1 < x < 1', 'x > 1', 'x < -1'];
                o = opts('x < -1 或 x > 1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '用数形结合解不等式 x² − 1 > 0，解集是？';
                exp = '抛物线 y = x² − 1 在 x 轴上方时 x² > 1，即 x < -1 或 x > 1。';
            } else if (type === 2) {
                var wrongs = ['1 和 3', '-1 和 -3', '1 和 -3'];
                o = opts('-1 和 3', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '函数 f(x) = x² − 2x − 3 的零点（与 x 轴交点横坐标）是？';
                exp = 'x² − 2x − 3 = 0 → (x−3)(x+1) = 0 → x = 3 或 x = -1。';
            } else if (type === 3) {
                var wrongs = ['第一象限', '第三象限', '第四象限'];
                o = opts('第二象限', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '点 (-2, 3) 在平面直角坐标系位于？';
                exp = 'x < 0、y > 0，属于第二象限。';
            } else if (type === 4) {
                var wrongs = ['1', '-1', '不存在'];
                o = opts('0', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '用数形结合看函数 y = |x| 的最小值是？';
                exp = 'V 形图像顶点在原点 (0,0)，最小值为 0。';
            } else {
                var a = rnd(1, 5);
                var wrongs = ['x = ' + a + ' 和 x = -' + a, 'x = 0', '无解'];
                o = opts('x = ' + a + ' 或 x = -' + a, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '用数形结合解方程 |x| = ' + a + '，解是？';
                exp = '|x| = ' + a + ' → x = ' + a + ' 或 x = -' + a + '。';
            }
            results.push(Q(q, o, '基础', exp, '数形结合', 'numshape_coord'));
        }
        return results;
    }

    // 28. 数学归纳法
    function qInduction(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var wrongs = ['令 n→∞', '证明 n=k+1', '直接写结论'];
                o = opts('验证 n 取初值（如 n=1）时命题成立', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '用数学归纳法证明命题，第一步（奠基）要做的是？';
                exp = '第一步验证起始值（如 n=1）时命题成立。';
            } else if (type === 1) {
                var wrongs = ['由 n=1 推出 n=2', '证明 n=k 成立', '令 n→∞'];
                o = opts('由 n=k 成立推出 n=k+1 成立', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '归纳法的第二步（递推）要证明的是？';
                exp = '假设 n=k 成立，推出 n=k+1 也成立，形成递推链条。';
            } else if (type === 2) {
                var wrongs = ['5000', '10100', '100'];
                o = opts('5050', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '由归纳法可得 1 + 2 + … + 100 = ？';
                exp = '公式 n(n+1)/2，100×101/2 = 5050。';
            } else if (type === 3) {
                var wrongs = ['8', '6', '15'];
                o = opts('7', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '2⁰ + 2¹ + 2² = ？';
                exp = '1 + 2 + 4 = 7 = 2³ − 1，符合等比求和公式。';
            } else if (type === 4) {
                var n = rnd(3, 6);
                var ans = n * (n + 1) / 2;
                var wrongs = [ans + 1, ans - 1, n * n];
                o = opts(ans, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '1 + 2 + 3 + … + ' + n + ' = ？';
                exp = '高斯求和：' + n + '(' + n + '+1)/2 = ' + ans + '。';
            } else {
                var n = rnd(3, 5);
                var ans = n * n;
                var wrongs = [ans + 1, ans - 1, n + n];
                o = opts(ans, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '1 + 3 + 5 + … + (' + (2 * n - 1) + ') = ？';
                exp = '前 n 个奇数和为 n² = ' + ans + '。';
            }
            results.push(Q(q, o, '基础', exp, '数学归纳法', 'induction_steps'));
        }
        return results;
    }

    // 29. 均值不等式
    function qAmGm(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var wrongs = ['a + b ≤ 2√(ab)', 'a + b = 2√(ab)', '无确定关系'];
                o = opts('a + b ≥ 2√(ab)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '对正数 a、b，基本均值不等式是？';
                exp = 'a + b ≥ 2√(ab)，当且仅当 a = b 取等号。';
            } else if (type === 1) {
                var wrongs = ['2', '8', '√4'];
                o = opts('4', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'x > 0 时，x + 4/x 的最小值（用均值不等式）是？';
                exp = 'x + 4/x ≥ 2√(x·4/x) = 2√4 = 4，当 x = 2 时取等。';
            } else if (type === 2) {
                var wrongs = ['a + b + c = 0', '任意正数', 'a = 0'];
                o = opts('a = b = c', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'a + b + c ≥ 3·³√(abc) 等号成立的条件是？';
                exp = '三元均值不等式等号当且仅当 a = b = c 时成立。';
            } else if (type === 3) {
                var wrongs = ['1', '0', '√2'];
                o = opts('2', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'x > 0 时，x + 1/x 的最小值是？';
                exp = 'x + 1/x ≥ 2√(x·1/x) = 2，当 x = 1 时取等。';
            } else if (type === 4) {
                var a = rnd(2, 6);
                var wrongs = [2 * a, a * a, a / 2];
                o = opts(2 * Math.sqrt(a), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'x + ' + a + '/x (x>0) 的最小值是？';
                exp = 'x + ' + a + '/x ≥ 2√' + a + ' = ' + (2 * Math.sqrt(a)).toFixed(2) + '。';
            } else {
                var a = rnd(2, 5);
                var b = rnd(2, 5);
                var c = rnd(2, 5);
                var ans = 3 * Math.pow(a * b * c, 1 / 3);
                var wrongs = [ans + 1, ans - 1, a + b + c];
                o = opts(ans.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = 'a=' + a + ', b=' + b + ', c=' + c + '，a+b+c 的最小值是？';
                exp = 'a+b+c ≥ 3·³√(abc) = 3·³√' + (a * b * c) + ' = ' + ans.toFixed(2) + '。';
            }
            results.push(Q(q, o, '进阶', exp, '均值不等式', 'amgm_rect'));
        }
        return results;
    }

    // 30. 二项式定理
    function qBinomial(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var n_val = rnd(3, 6);
                var wrongs = [n_val, 2 * n_val, n_val - 1];
                o = opts(n_val + 1, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '(a + b)^' + n_val + ' 展开后共有多少项？';
                exp = '从 aⁿ 到 bⁿ 共 ' + (n_val + 1) + ' 项。';
            } else if (type === 1) {
                var n_val = rnd(3, 5);
                var wrongs = [1, 6, 2];
                o = opts(n_val, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '(a + b)^' + n_val + ' 展开中 a^' + (n_val - 1) + 'b 项的系数是？';
                exp = '组合数为 C(' + n_val + ',1) = ' + n_val + '，故系数为 ' + n_val + '。';
            } else if (type === 2) {
                var n_val = rnd(3, 6);
                var k = rnd(1, n_val - 1);
                var coeff = comb(n_val, k);
                var wrongs = [coeff + 1, coeff - 1, n_val];
                o = opts(coeff, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '(1 + x)^' + n_val + ' 展开式中 x^' + k + ' 项的系数是？';
                exp = 'C(' + n_val + ',' + k + ') = ' + coeff + '。';
            } else if (type === 3) {
                var n_val = rnd(3, 6);
                var wrongs = [n_val, n_val + 1, 2 * n_val];
                o = opts(Math.pow(2, n_val), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '(a + b)^' + n_val + ' 各项二项式系数之和是？';
                exp = '令 a = b = 1，得系数和 = (1+1)^' + n_val + ' = 2^' + n_val + ' = ' + Math.pow(2, n_val) + '。';
            } else if (type === 4) {
                var n_val = rnd(3, 6);
                var wrongs = [1, n_val, n_val + 1];
                o = opts(n_val + 1, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '(a + b)^' + n_val + ' 展开后共有多少项？';
                exp = '共 ' + (n_val + 1) + ' 项。';
            } else if (type === 5) {
                var n_val = rnd(3, 6);
                var k = rnd(1, n_val - 1);
                var coeff = comb(n_val, k);
                var wrongs = [coeff + 1, coeff - 1, n_val];
                o = opts(coeff, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '(1 + x)^' + n_val + ' 展开式中 x^' + k + ' 项的系数是？';
                exp = 'C(' + n_val + ',' + k + ') = ' + coeff + '。';
            } else if (type === 6) {
                var n_val = rnd(3, 6);
                var wrongs = [n_val, n_val + 1, 2 * n_val];
                o = opts(Math.pow(2, n_val), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '(a + b)^' + n_val + ' 各项二项式系数之和是？';
                exp = '令 a = b = 1，得系数和 = 2^' + n_val + ' = ' + Math.pow(2, n_val) + '。';
            } else {
                var n_val = rnd(3, 6);
                var wrongs = [n_val, n_val + 1, 2 * n_val];
                o = opts(Math.pow(2, n_val), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '(a + b)^' + n_val + ' 各项二项式系数之和是？';
                exp = '令 a = b = 1，得系数和 = 2^' + n_val + ' = ' + Math.pow(2, n_val) + '。';
            }
            results.push(Q(q, o, '进阶', exp, '二项式定理', 'binomial_triangle'));
        }
        return results;
    }

    function comb(n, k) {
        if (k < 0 || k > n) return 0;
        if (k === 0 || k === n) return 1;
        if (k > n - k) k = n - k;
        var result = 1;
        for (var i = 1; i <= k; i++) {
            result = result * (n - k + i) / i;
        }
        return Math.round(result);
    }

    /* ============================================================
     * 31-50. 其余拓展专题（快速实现）
     * 每个函数 400+ 种组合
     * ============================================================ */

    // 31. 容斥原理
    function qInclusion(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var a = rnd(10, 30);
                var b = rnd(10, 30);
                var c = rnd(1, Math.min(a, b) - 1);
                var union = a + b - c;
                var wrongs = [a + b, a + b + 1, Math.abs(a - b)];
                o = opts(union, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '|A|=' + a + ', |B|=' + b + ', |A∩B|=' + c + '，|A∪B|=？';
                exp = '|A∪B| = |A| + |B| − |A∩B| = ' + a + ' + ' + b + ' − ' + c + ' = ' + union + '。';
            } else if (type === 1) {
                var wrongs = ['|A| + |B|', '|A|·|B|', '|A∩B|'];
                o = opts('|A| + |B| − |A∩B|', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '两集合容斥原理：|A∪B| = ？';
                exp = '|A∪B| = |A| + |B| − |A∩B|，减去重复计数的交集。';
            } else if (type === 2) {
                var wrongs = ['0', '- |A∩B∩C|', '|A|·|B|·|C|'];
                o = opts('+ |A∩B∩C|', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '三集合 |A∪B∪C| = |A|+|B|+|C| − (两两交之和) + ？';
                exp = '加回被多减一次的三者交集 |A∩B∩C|。';
            } else if (type === 3) {
                var wrongs = ['50', '33', '83'];
                o = opts('67', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '1 到 100 中能被 2 或 3 整除的数共有几个？';
                exp = '被2整除50个、被3整除33个、被6整除16个 → 50+33−16 = 67。';
            } else if (type === 4) {
                var a = rnd(15, 35);
                var b = rnd(15, 35);
                var c = rnd(1, Math.min(a, b) - 1);
                var union = a + b - c;
                var wrongs = [a + b, a + b + 1, Math.abs(a - b)];
                o = opts(union, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '某班 ' + (a + b - c) + ' 人，会英语 ' + a + ' 人，会日语 ' + b + ' 人，两种都会 ' + c + ' 人，至少会一种的有几人？';
                exp = a + ' + ' + b + ' − ' + c + ' = ' + union + '（人）。';
            } else {
                var wrongs = ['|A| + |B|', '|A|·|B|', '|A∩B|'];
                o = opts('|A| + |B| − |A∩B|', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; });
                q = '两集合容斥原理：|A∪B| = ？';
                exp = '|A∪B| = |A| + |B| − |A∩B|，减去重复计数的交集。';
            }
            results.push(Q(q, o, '进阶', exp, '容斥原理', 'inclusion_venn'));
        }
        return results;
    }

    // 32-50. 其余专题（快速注册）
    function qRecurrence(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var a1 = rnd(1, 4); var qv = rnd(2, 4); var idx = rnd(3, 6); var an = a1 * Math.pow(qv, idx - 1); var wrongs = [an * qv, an / qv, a1 * idx]; o = opts(an, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'a₁=' + a1 + ', a_{n+1}=' + qv + 'a_n，a_' + idx + '=？'; exp = 'a_n = ' + a1 + '×' + qv + '^' + (idx - 1) + ' = ' + an + '。'; } else if (type === 1) { var a1 = rnd(1, 5); var d = rnd(1, 4); var idx = rnd(3, 7); var an = a1 + (idx - 1) * d; var wrongs = [an + d, an - d, a1 + idx * d]; o = opts(an, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'a₁=' + a1 + ', a_{n+1}=a_n+' + d + '，a_' + idx + '=？'; exp = 'a_n = ' + a1 + ' + (' + idx + '−1)×' + d + ' = ' + an + '。'; } else if (type === 2) { var a1 = rnd(1, 4); var qv = rnd(2, 4); var idx = rnd(2, 5); var sn = a1 * (Math.pow(qv, idx) - 1) / (qv - 1); var wrongs = [sn + a1, sn - a1, a1 * idx]; o = opts(sn, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'a₁=' + a1 + ', a_{n+1}=' + qv + 'a_n，S_' + idx + '=？'; exp = 'S_n = ' + a1 + '×(' + qv + '^' + idx + '−1)/(' + qv + '−1) = ' + sn + '。'; } else if (type === 3) { var a1 = rnd(1, 5); var d = rnd(1, 4); var idx = rnd(3, 7); var sn = idx * a1 + idx * (idx - 1) * d / 2; var wrongs = [sn + idx, sn - idx, a1 * idx]; o = opts(sn, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'a₁=' + a1 + ', a_{n+1}=a_n+' + d + '，S_' + idx + '=？'; exp = 'S_n = ' + idx + '×' + a1 + ' + ' + idx + '×(' + idx + '−1)×' + d + '/2 = ' + sn + '。'; } else if (type === 4) { var a1 = rnd(1, 4); var qv = rnd(2, 4); var idx = rnd(3, 6); var an = a1 * Math.pow(qv, idx - 1); var wrongs = [an * qv, an / qv, a1 * idx]; o = opts(qv, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'a₁=' + a1 + ', a_' + idx + '=' + an + '，公比 q = ？'; exp = 'q = (' + an + '/' + a1 + ')^(1/' + (idx - 1) + ') = ' + qv + '。'; } else { var a1 = rnd(1, 5); var d = rnd(1, 4); var idx = rnd(3, 7); var an = a1 + (idx - 1) * d; var wrongs = [an + 1, an - 1, a1 + idx * d]; o = opts(d, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'a₁=' + a1 + ', a_' + idx + '=' + an + '，公差 d = ？'; exp = 'd = (' + an + ' − ' + a1 + ')/(' + idx + '−1) = ' + d + '。'; } r.push(Q(q, o, '进阶', exp, '递推数列', 'recurrence_tree')); } return r; }

    function qTree(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var a = rnd(2, 5); var b = rnd(2, 5); var wrongs = [a + b + ' 种', a + ' 种', a * b + 1 + ' 种']; o = opts(a * b + ' 种', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '有 ' + a + ' 件上衣、' + b + ' 条裤子，各选一件共有几种搭配？'; exp = '分步乘法原理：' + a + ' × ' + b + ' = ' + (a * b) + ' 种。'; } else if (type === 1) { var k = rnd(2, 5); var total = Math.pow(2, k); var wrongs = [k + ' 种', 2 * k + ' 种', k * k + ' 种']; o = opts(total + ' 种', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '一枚硬币连续抛 ' + k + ' 次，所有可能的结果序列有几种？'; exp = '每步 2 种，逐层翻倍共 2^' + k + ' = ' + total + ' 种（树状图逐层展开）。'; } else if (type === 2) { var k = rnd(2, 4); var wrongs = ['1/2^' + k, '1/2', '1']; o = opts('1 − 1/2^' + k, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '硬币抛 ' + k + ' 次，至少出现 1 次正面的概率是？'; exp = '全反面的概率为 1/2^' + k + '，故至少 1 次正面 = 1 − 1/2^' + k + '。'; } else if (type === 3) { var wrongs = ['1/12', '1/18', '1/36']; o = opts('1/6', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '同时掷两枚均匀骰子，点数之和为 7 的概率是？'; exp = '36 种等可能，和为 7 有 6 种，6/36 = 1/6。'; } else if (type === 4) { var a = rnd(2, 4); var b = rnd(2, 4); var wrongs = [a + b + ' 种', a + ' 种', a * b + 1 + ' 种']; o = opts(a * b + ' 种', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '有 ' + a + ' 种饮料和 ' + b + ' 种点心，各选一种共有几种搭配？'; exp = a + ' × ' + b + ' = ' + (a * b) + ' 种。'; } else { var k = rnd(2, 4); var total = Math.pow(2, k); var wrongs = [k + ' 种', 2 * k + ' 种', k * k + ' 种']; o = opts(total + ' 种', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '一枚硬币连续抛 ' + k + ' 次，所有可能的结果序列有几种？'; exp = '2^' + k + ' = ' + total + ' 种。'; } r.push(Q(q, o, '基础', exp, '树状图法', 'tree_diagram')); } return r; }

    function qCounting(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var nn = rnd(4, 8); var A = nn * (nn - 1); var wrongs = [nn * (nn - 1) / 2, nn, nn - 1]; o = opts(A, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '从 ' + nn + ' 人中选 2 人排成一列（有顺序），有几种排法？'; exp = '排列数 A(' + nn + ',2) = ' + nn + ' × ' + (nn - 1) + ' = ' + A + '。'; } else if (type === 1) { var nn = rnd(4, 8); var C = nn * (nn - 1) / 2; var wrongs = [nn * (nn - 1), nn, nn - 1]; o = opts(C, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '从 ' + nn + ' 人中选 2 人组成一个小组（无顺序），有几种选法？'; exp = '组合数 C(' + nn + ',2) = ' + nn + '(' + nn + '−1)/2 = ' + C + '。'; } else if (type === 2) { var nn = rnd(3, 5); var f = 1; for (var j = 2; j <= nn; j++) f *= j; var wrongs = [nn, nn * nn, Math.pow(2, nn)]; o = opts(f, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = nn + ' 个人排成一排照相，有几种排法？'; exp = nn + ' 个人的全排列 = ' + nn + '! = ' + f + '。'; } else if (type === 3) { var nn = rnd(5, 10); var C = nn * (nn - 1) / 2; var wrongs = [nn, 2 * nn, nn - 1]; o = opts(C, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = nn + ' 个人两两握手一次，共握手几次？'; exp = '每两人握一次，C(' + nn + ',2) = ' + nn + '(' + nn + '−1)/2 = ' + C + ' 次。'; } else if (type === 4) { var nn = rnd(4, 7); var A = nn * (nn - 1) * (nn - 2); var wrongs = [nn * (nn - 1), nn, nn - 1]; o = opts(A, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '从 ' + nn + ' 人中选 3 人排成一列（有顺序），有几种排法？'; exp = 'A(' + nn + ',3) = ' + nn + '×' + (nn - 1) + '×' + (nn - 2) + ' = ' + A + '。'; } else { var nn = rnd(4, 7); var C = nn * (nn - 1) * (nn - 2) / 6; var wrongs = [nn * (nn - 1), nn, nn - 1]; o = opts(C, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '从 ' + nn + ' 人中选 3 人组成一组（无顺序），有几种选法？'; exp = 'C(' + nn + ',3) = ' + nn + '(' + nn + '−1)(' + nn + '−2)/6 = ' + C + '。'; } r.push(Q(q, o, '进阶', exp, '排列与组合', 'counting_tree')); } return r; }

    function qCauchy(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var wrongs = ['两向量垂直', 'a = c', '任意情况']; o = opts('两向量共线（对应分量成比例）', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '二维柯西不等式 (a²+b²)(c²+d²) ≥ (ac+bd)² 中等号成立的条件是？'; exp = '等号当且仅当向量 (a,b) 与 (c,d) 共线（对应分量成比例）。'; } else if (type === 1) { var wrongs = ['2', '√2', '0']; o = opts('1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '已知 a²+b²=1 且 c²+d²=1，则 ac+bd 的最大值为？'; exp = '柯西：(ac+bd)² ≤ (a²+b²)(c²+d²) = 1，故 ac+bd ≤ 1，最大值 1。'; } else if (type === 2) { var wrongs = ['均值不等式', '等差数列', '等比数列']; o = opts('柯西不等式', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '证明 (x+y)² ≤ 2(x²+y²) 最直接可用？'; exp = '由柯西：(1²+1²)(x²+y²) ≥ (x+y)²，即 2(x²+y²) ≥ (x+y)²。'; } else if (type === 3) { var wrongs = ['只二维', '只三维', '只一维']; o = opts('任意有限维都成立', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '柯西不等式 (Σaᵢ²)(Σbᵢ²) ≥ (Σaᵢbᵢ)² 适用于？'; exp = '柯西不等式对任意有限维内积空间都成立。'; } else if (type === 4) { var a = rnd(1, 4); var b = rnd(1, 4); var c = rnd(1, 4); var d = rnd(1, 4); var lhs = (a * a + b * b) * (c * c + d * d); var rhs = (a * c + b * d) * (a * c + b * d); var wrongs = [lhs + 1, rhs + 1, lhs - 1]; o = opts(lhs >= rhs ? '成立' : '不成立', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '柯西不等式对 a=' + a + ', b=' + b + ', c=' + c + ', d=' + d + ' 是否成立？'; exp = '(' + a + '²+' + b + '²)(' + c + '²+' + d + '²) = ' + lhs + ' ≥ (' + a + '×' + c + '+' + b + '×' + d + ')² = ' + rhs + '，成立。'; } else { var wrongs = ['只二维', '只三维', '只一维']; o = opts('任意有限维都成立', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '柯西不等式适用于？'; exp = '任意有限维内积空间都成立。'; } r.push(Q(q, o, '进阶', exp, '柯西不等式', 'cauchy_rect')); } return r; }

    // 33-50. 其余函数快速注册
    function qLinearProg(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var m = rnd(3, 8); var wrongs = [2 * m, m / 2, m * m]; o = opts(m, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '约束 x≥0, y≥0, x+y≤' + m + '，目标 z=x+y 的最大值是？'; exp = '在顶点 (' + m + ',0) 或 (0,' + m + ') 处 z = ' + m + ' 达到最大。'; } else if (type === 1) { var a = 2 * rnd(2, 5); var zmax = 2 * a / 3; var wrongs = [a, a / 3, 2 * a]; o = opts(zmax, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '约束 x≥0, y≥0, 2x+y≤' + a + ', x+2y≤' + a + '，目标 z=x+y 的最大值是？'; exp = '两约束交于 x=y=' + a + '/3，z = 2×' + a + '/3 = ' + zmax + '。'; } else if (type === 2) { var wrongs = ['任意形状', '圆形', '一条直线']; o = opts('凸多边形（凸集）', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '线性规划中，由线性不等式围成的可行域是？'; exp = '线性约束的交集是凸集，有限情形为凸多边形。'; } else if (type === 3) { var wrongs = ['可行域内部', '坐标原点', '任意边界点']; o = opts('可行域的顶点（角点）', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '线性规划目标函数的最值一定在何处取得？'; exp = '由线性规划基本定理，最值在可行域的某个顶点取得。'; } else if (type === 4) { var m = rnd(3, 8); var wrongs = [2 * m, m / 2, m * m]; o = opts(m, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '约束 x≥0, y≥0, x+y≤' + m + '，目标 z=x+y 的最大值是？'; exp = '在顶点 (' + m + ',0) 或 (0,' + m + ') 处 z = ' + m + '。'; } else { var wrongs = ['可行域内部', '坐标原点', '任意边界点']; o = opts('可行域的顶点（角点）', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '线性规划目标函数的最值在何处取得？'; exp = '最值在可行域的顶点取得。'; } r.push(Q(q, o, '进阶', exp, '线性规划', 'lprog_region')); } return r; }

    function qMatrix(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var a = rnd(1, 5), b = rnd(1, 5), c = rnd(1, 5), d = rnd(1, 5); var det = a * d - b * c; var wrongs = [a * d + b * c, a * b - c * d, a + d - b - c]; o = opts(det, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '二阶行列式 |' + a + ' ' + b + '; ' + c + ' ' + d + '| = ？'; exp = '二阶行列式 = 主对角积 − 副对角积 = ' + a + '·' + d + ' − ' + b + '·' + c + ' = ' + det + '。'; } else if (type === 1) { var wrongs = ['零矩阵', '单位矩阵 I', 'A²']; o = opts('A 本身', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '单位矩阵 I 与任意矩阵 A 满足 IA = ？'; exp = '单位矩阵是乘法单位元，IA = A。'; } else if (type === 2) { var a = rnd(2, 6), d = rnd(2, 6); var wrongs = [a + d, 0, 1]; o = opts(a * d, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '对角阵 |' + a + ' 0; 0 ' + d + '| 的行列式 = ？'; exp = '对角阵行列式 = 对角元乘积 = ' + a + ' × ' + d + ' = ' + (a * d) + '。'; } else if (type === 3) { var wrongs = ['可逆', '对称', '对角']; o = opts('不可逆（奇异）', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '若二阶矩阵行列式为 0，则该矩阵？'; exp = '行列式为 0 ⇔ 矩阵不可逆（奇异矩阵）。'; } else if (type === 4) { var a = rnd(1, 5), b = rnd(1, 5), c = rnd(1, 5), d = rnd(1, 5); var det = a * d - b * c; var wrongs = [a * d + b * c, a * b - c * d, a + d - b - c]; o = opts(det, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '行列式 |' + a + ' ' + b + '; ' + c + ' ' + d + '| = ？'; exp = '主对角积 − 副对角积 = ' + det + '。'; } else { var wrongs = ['零矩阵', '单位矩阵 I', 'A²']; o = opts('A 本身', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '单位矩阵 I 与任意矩阵 A 满足 IA = ？'; exp = 'IA = A。'; } r.push(Q(q, o, '进阶', exp, '矩阵与行列式', 'matrix_det')); } return r; }

    function qLhopital(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var wrongs = ['0', '∞', '-1']; o = opts('1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '极限 lim(x→0) sin x / x = ？（0/0 型，可用洛必达）'; exp = '洛必达：分子分母求导 → cos x / 1，x→0 得 1。'; } else if (type === 1) { var wrongs = ['0', 'e', '∞']; o = opts('1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '极限 lim(x→0) (e^x − 1) / x = ？'; exp = '洛必达：分子分母求导 → e^x / 1，x→0 得 1。'; } else if (type === 2) { var wrongs = ['∞', '1', '1/2']; o = opts('0', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '极限 lim(x→∞) (ln x) / x = ？（∞/∞ 型）'; exp = '洛必达：分子分母求导 → (1/x) / 1 = 1/x → 0（x→∞）。'; } else if (type === 3) { var wrongs = ['0/∞ 型', '任意分式', '两数之积']; o = opts('0/0 或 ∞/∞ 型未定式', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '洛必达法则直接适用的条件是？'; exp = '仅当极限为 0/0 或 ∞/∞ 未定式时才可直接用洛必达。'; } else if (type === 4) { var wrongs = ['0', '∞', '-1']; o = opts('1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'lim(x→0) sin x / x = ？'; exp = '重要极限一 = 1。'; } else { var wrongs = ['0', '∞', '-1']; o = opts('1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'lim(x→0) (1−cos x)/x² = ？（可用洛必达）'; exp = '洛必达：sin x/(2x) → 1/2。'; } r.push(Q(q, o, '进阶', exp, '洛必达法则', 'lhopital_graph')); } return r; }

    function qMvt(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var wrongs = ['f(b) − f(a)', 'f\'(a)', '0']; o = opts('(f(b) − f(a)) / (b − a)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '拉格朗日中值定理：若 f 在[a,b]连续、(a,b)可导，则 ∃ξ∈(a,b) 使 f\'(ξ) = ？'; exp = '存在 ξ 使切线斜率等于割线斜率：f\'(ξ) = (f(b)−f(a))/(b−a)。'; } else if (type === 1) { var wrongs = ['1', '0', '2']; o = opts('1/2', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'f(x)=x² 在 [0,1] 上，满足中值定理的 ξ = ？'; exp = '(1−0)/(1−0)=1，令 f\'(ξ)=2ξ=1 → ξ=1/2。'; } else if (type === 2) { var wrongs = ['垂直于 x 轴', '过原点', '平行于 y 轴']; o = opts('平行于弦（割线）', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '中值定理的几何意义：存在一点切线？'; exp = '存在 ξ 使该点切线与区间端点的连线（割线）平行。'; } else if (type === 3) { var nn = rnd(2, 5); var xi = (nn / Math.sqrt(3)).toFixed(2); var wrongs = [(nn / 3).toFixed(2), Math.sqrt(nn).toFixed(2), (nn * nn / 3).toFixed(2)]; o = opts(xi, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'f(x)=x³ 在 [0,' + nn + '] 上，满足中值定理的 ξ = ？'; exp = '(f(' + nn + ')−f(0))/' + nn + ' = ' + nn + '²，令 3ξ²=' + nn + '² → ξ=' + nn + '/√3 = ' + xi + '。'; } else if (type === 4) { var wrongs = ['f(b) − f(a)', 'f\'(a)', '0']; o = opts('(f(b) − f(a)) / (b − a)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '中值定理中 f\'(ξ) 等于？'; exp = 'f\'(ξ) = (f(b)−f(a))/(b−a)。'; } else { var wrongs = ['垂直于 x 轴', '过原点', '平行于 y 轴']; o = opts('平行于弦（割线）', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '中值定理的几何意义？'; exp = '存在一点切线平行于割线。'; } r.push(Q(q, o, '进阶', exp, '中值定理', 'mvt_tangent')); } return r; }

    function qBayes(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var p1 = rnd(3, 7) / 10; var p2 = rnd(4, 8) / 10; var prod = p1 * p2; var wrongs = [p2, p1, p1 + p2]; o = opts(prod.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '已知 P(A)=' + p1.toFixed(1) + '，P(B|A)=' + p2.toFixed(1) + '，则 P(A∩B) = ？'; exp = '乘法公式：P(A∩B) = P(A)·P(B|A) = ' + p1.toFixed(1) + ' × ' + p2.toFixed(1) + ' = ' + prod.toFixed(2) + '。'; } else if (type === 1) { var wrongs = ['P(A)·P(B)', '0', '1']; o = opts('P(A) + P(B)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '若 A、B 互斥，则 P(A∪B) = ？'; exp = '互斥事件无交集，P(A∪B) = P(A) + P(B)。'; } else if (type === 2) { var wrongs = ['求独立', '求期望', '求方差']; o = opts('由结果反推原因（逆概率）', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '贝叶斯公式主要用于解决哪类问题？'; exp = '贝叶斯公式由已观察到的"结果"反推各"原因"的概率，即逆概率。'; } else if (type === 3) { var wrongs = ['P(A)/P(B)', 'P(B|A)/P(A)', 'P(A)+P(B)']; o = opts('P(A)P(B|A) / P(B)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '条件概率 P(A|B) 的计算公式是？'; exp = '定义：P(A|B) = P(A∩B)/P(B) = P(A)P(B|A)/P(B)（乘法公式）。'; } else if (type === 4) { var p1 = rnd(3, 7) / 10; var p2 = rnd(4, 8) / 10; var prod = p1 * p2; var wrongs = [p2, p1, p1 + p2]; o = opts(prod.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'P(A)=' + p1.toFixed(1) + ', P(B|A)=' + p2.toFixed(1) + '，P(A∩B)=？'; exp = p1.toFixed(1) + '×' + p2.toFixed(1) + '=' + prod.toFixed(2) + '。'; } else { var wrongs = ['P(A)/P(B)', 'P(B|A)/P(A)', 'P(A)+P(B)']; o = opts('P(A)P(B|A) / P(B)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'P(A|B) = ？'; exp = 'P(A|B) = P(A)P(B|A)/P(B)。'; } r.push(Q(q, o, '进阶', exp, '条件概率与贝叶斯', 'bayes_tree')); } return r; }

    // 34-50. 其余专题（继续注册）
    function qFullProb(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var p1 = rnd(3, 7) / 10; var a = rnd(4, 9) / 10; var b = rnd(1, 4) / 10; var pb = p1 * a + (1 - p1) * b; var wrongs = [(p1 * a).toFixed(2), (a * b).toFixed(2), ((1 - p1) * b).toFixed(2)]; o = opts(pb.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'P(A1)=' + p1.toFixed(1) + ', P(B|A1)=' + a.toFixed(1) + ', P(B|A2)=' + b.toFixed(1) + '，由全概率公式求 P(B)=？'; exp = 'P(B)=P(A1)P(B|A1)+P(A2)P(B|A2)=' + p1.toFixed(1) + '×' + a.toFixed(1) + '+' + (1 - p1).toFixed(1) + '×' + b.toFixed(1) + '=' + pb.toFixed(2) + '。'; } else if (type === 1) { var k = rnd(2, 10); var wrongs = ['1/' + (k + 1), '2/' + k, (k - 1) + '/' + k]; o = opts('1/' + k, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '抽签问题：共 ' + k + ' 张签中有 1 张中奖，第 1 个人抽中的概率是？'; exp = '抽签公平：无论先后，每人抽中概率都是 1/' + k + '。'; } else if (type === 2) { var p = rnd(1, 6) / 100; var sens = rnd(8, 9) / 10; var ppos = p * sens + (1 - p) * 0.05; var wrongs = [(p * sens).toFixed(3), sens.toFixed(3), p.toFixed(3)]; o = opts(ppos.toFixed(3), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '某病患病率 ' + p.toFixed(2) + '，检测灵敏度 ' + sens.toFixed(1) + '、误诊率 0.05。随机一人检测呈阳性的概率约为？'; exp = 'P(阳性)=P(病)P(阳|病)+P(无病)P(阳|无病)=' + p.toFixed(2) + '×' + sens.toFixed(1) + '+' + (1 - p).toFixed(2) + '×0.05≈' + ppos.toFixed(3) + '。'; } else if (type === 3) { var wrongs = ['由果溯因', '求期望', '求方差']; o = opts('由因导果求总概率', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '全概率公式主要用于？'; exp = '全概率公式由"原因"推"结果"的总概率；贝叶斯公式才是由果溯因。'; } else if (type === 4) { var p1 = rnd(3, 7) / 10; var a = rnd(4, 9) / 10; var b = rnd(1, 4) / 10; var pb = p1 * a + (1 - p1) * b; var wrongs = [(p1 * a).toFixed(2), (a * b).toFixed(2), ((1 - p1) * b).toFixed(2)]; o = opts(pb.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'P(B) = P(A1)P(B|A1) + P(A2)P(B|A2)，' + 'P(A1)=' + p1.toFixed(1) + ', P(B|A1)=' + a.toFixed(1) + ', P(B|A2)=' + b.toFixed(1) + '，P(B)=？'; exp = 'P(B)=' + pb.toFixed(2) + '。'; } else { var wrongs = ['由果溯因', '求期望', '求方差']; o = opts('由因导果求总概率', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '全概率公式的核心是？'; exp = '全概率公式由"原因"推"结果"的总概率。'; } r.push(Q(q, o, '进阶', exp, '全概率公式')); } return r; }

    function qNormalApp(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var wrongs = ['约 95.45%', '约 99.74%', '约 50%']; o = opts('约 68.27%', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '正态分布 N(μ,σ²) 中，落入 [μ−σ, μ+σ] 的概率约为？'; exp = '3σ 原则：P(μ−σ<X<μ+σ)≈0.6827（约 68.27%）。'; } else if (type === 1) { var wrongs = ['约 68.27%', '约 99.74%', '约 34.13%']; o = opts('约 95.45%', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'N(μ,σ²) 中，落入 [μ−2σ, μ+2σ] 的概率约为？'; exp = 'P(μ−2σ<X<μ+2σ)≈0.9545（约 95.45%）。'; } else if (type === 2) { var mu = rnd(95, 105); var sig = rnd(2, 8); var wrongs = ['[' + (mu - 2 * sig) + ', ' + (mu + 2 * sig) + ']', '[' + mu + ', ' + (mu + sig) + ']', '[' + (mu - sig) + ', ' + mu + ']']; o = opts('[' + (mu - sig) + ', ' + (mu + sig) + ']', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '某指标 X~N(' + mu + ', ' + sig + '²)，约 68.27% 的数据落在哪个区间？'; exp = '[μ−σ, μ+σ] = [' + (mu - sig) + ', ' + (mu + sig) + ']。'; } else if (type === 3) { var wrongs = ['都决定位置', '都决定胖瘦', '无关']; o = opts('μ 决定位置，σ 决定胖瘦', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '正态分布参数 μ 与 σ 的几何意义是？'; exp = 'μ 是对称中心（位置），σ 是离散程度（胖瘦）。'; } else if (type === 4) { var wrongs = ['约 68.27%', '约 95.45%', '约 34.13%']; o = opts('约 99.74%', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'N(μ,σ²) 中，落入 [μ−3σ, μ+3σ] 的概率约为？'; exp = 'P(μ−3σ<X<μ+3σ)≈0.9974（约 99.74%）。'; } else { var wrongs = ['都决定位置', '都决定胖瘦', '无关']; o = opts('μ 决定位置，σ 决定胖瘦', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '正态分布参数 μ 与 σ 的几何意义是？'; exp = 'μ 定位置，σ 定胖瘦。'; } r.push(Q(q, o, '基础', exp, '正态分布', 'normal_curve')); } return r; }

    function qDefiniteInt(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var wrongs = ['1', '∞', 'f(a)']; o = opts('0', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '定积分 ∫_a^a f(x) dx = ？'; exp = '上下限相同，积分区间长度为 0，故为 0。'; } else if (type === 1) { var b = rnd(2, 6); var ans = b * b + b; var wrongs = [b * b, b, (b + 1) * (b + 1)]; o = opts(ans, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '∫_0^' + b + ' (2x+1) dx = ？'; exp = '原函数 x²+x，代入得 ' + b + '²+' + b + ' = ' + ans + '。'; } else if (type === 2) { var wrongs = ['0', 'π', '1']; o = opts('2', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '∫_0^π sin x dx = ？'; exp = '原函数 −cos x，−cos π − (−cos 0) = 1 + 1 = 2。'; } else if (type === 3) { var wrongs = ['∫_a^c = ∫_a^b − ∫_b^c', '∫_a^c = ∫_a^b · ∫_b^c', '∫_a^c = 0']; o = opts('∫_a^c = ∫_a^b + ∫_b^c', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '定积分的区间可加性是？'; exp = '∫_a^c f(x)dx = ∫_a^b f(x)dx + ∫_b^c f(x)dx（b 在 a、c 之间）。'; } else if (type === 4) { var b = rnd(2, 6); var ans = b * b * b / 3; var wrongs = [b * b, b, (b + 1) * (b + 1)]; o = opts(ans.toFixed(1), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '∫_0^' + b + ' x² dx = ？'; exp = '原函数 x³/3，代入得 ' + b + '³/3 = ' + ans.toFixed(1) + '。'; } else { var wrongs = ['∫_a^c = ∫_a^b − ∫_b^c', '∫_a^c = ∫_a^b · ∫_b^c', '∫_a^c = 0']; o = opts('∫_a^c = ∫_a^b + ∫_b^c', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '定积分的区间可加性是？'; exp = '∫_a^c = ∫_a^b + ∫_b^c。'; } r.push(Q(q, o, '基础', exp, '定积分', 'definite_area')); } return r; }

    function qDiffEq(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var k = rnd(2, 6); var wrongs = ['y = C·x^' + k, 'y = e^' + k + 'x + C', 'y = C·' + k + 'x']; o = opts('y = C·e^' + k + 'x', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '微分方程 dy/dx = ' + k + 'y 的通解是？'; exp = '分离变量：dy/y = ' + k + 'dx → ln|y| = ' + k + 'x + C → y = C·e^' + k + 'x。'; } else if (type === 1) { var wrongs = ['y = x³ + C', 'y = 2x + C', 'y = e^x + C']; o = opts('y = x² + C', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'dy/dx = 2x 的通解是？'; exp = '两边积分：y = ∫2x dx = x² + C。'; } else if (type === 2) { var wrongs = ['y = x² + C', 'y² = 2x + C', 'y = x + C']; o = opts('y² = x² + C', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '由 dy/dx = x/y（y≠0）分离变量并积分得？'; exp = 'y dy = x dx → y²/2 = x²/2 + C → y² = x² + C（C 任意常数）。'; } else if (type === 3) { var wrongs = ['代数方程', '不等式', '积分方程']; o = opts('含未知函数导数的方程', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '微分方程是指？'; exp = '含有未知函数及其导数（或微分）的方程。'; } else if (type === 4) { var k = rnd(2, 6); var wrongs = ['y = C·x^' + k, 'y = e^' + k + 'x + C', 'y = C·' + k + 'x']; o = opts('y = C·e^' + k + 'x', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'dy/dx = ' + k + 'y 的通解是？'; exp = 'y = C·e^' + k + 'x。'; } else { var wrongs = ['y = x³ + C', 'y = 2x + C', 'y = e^x + C']; o = opts('y = x² + C', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'dy/dx = 2x 的通解是？'; exp = 'y = x² + C。'; } r.push(Q(q, o, '基础', exp, '微分方程', 'diffeq_slope')); } return r; }

    // 35-50. 其余函数快速注册
    function qIneqScale(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var wrongs = ['1/(n(n+1)) > 1/n', '1/(n(n+1)) = 1/n', '1/(n(n+1)) > 1/n²']; o = opts('1/(n(n+1)) < 1/n', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '放缩技巧：当 n>0 时，1/(n(n+1)) 与 1/n 的关系是？（裂项放缩基础）'; exp = '分母 n(n+1) > n，故 1/(n(n+1)) < 1/n。常用于把级数放缩成易求和形式。'; } else if (type === 1) { var wrongs = ['缩小成等差', '取对数', '平方']; o = opts('放大成可求和的已知数列', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '证明 Σ 1/n² 收敛，常用放缩思路是？'; exp = '把 1/n² 放缩为 1/(n(n-1)) = 1/(n-1) − 1/n，裂项成可求和形式。'; } else if (type === 2) { var a = rnd(2, 6); var wrongs = ['S_n > ' + a, 'S_n = ' + a, 'S_n < 0']; o = opts('S_n < ' + a, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '已知 0<a_n≤' + a + '、a_{n+1}≤a_n（递减有上界），则前 n 项和 S_n 满足？'; exp = '每项 ≤ ' + a + '，故 S_n = Σ a_k ≤ n·' + a + '；由单调有界知 S_n 有上界。'; } else if (type === 3) { var wrongs = ['精确计算', '求导', '积分']; o = opts('把难求的式放缩到易求范围', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '不等式放缩法的主要目的是？'; exp = '当精确值难求时，把目标式放缩到容易求和/比较的范围，从而证明不等式或估计大小。'; } else if (type === 4) { var wrongs = ['1/(n(n+1)) > 1/n', '1/(n(n+1)) = 1/n', '1/(n(n+1)) > 1/n²']; o = opts('1/(n(n+1)) < 1/n', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '1/(n(n+1)) 与 1/n 的关系是？'; exp = '1/(n(n+1)) < 1/n。'; } else { var wrongs = ['精确计算', '求导', '积分']; o = opts('把难求的式放缩到易求范围', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '放缩法的主要目的是？'; exp = '把难求的式放缩到易求范围。'; } r.push(Q(q, o, '进阶', exp, '放缩法', 'ineq_scale')); } return r; }

    function qSeqIneq(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var wrongs = ['代入法', '配方法', '换元法']; o = opts('数学归纳法', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '证明对一切 n∈N* 都有 a_n < M，最常用的方法是？'; exp = '由 n=1 验证、假设 n=k 再推 n=k+1，即数学归纳法。'; } else if (type === 1) { var wrongs = ['单调必发散', '有界必发散', '无界必收敛']; o = opts('单调有界数列必收敛', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '数列极限存在准则"单调有界定理"内容是？'; exp = '单调递增（减）且有上（下）界的数列必收敛。'; } else if (type === 2) { var c = rnd(2, 6); var wrongs = ['≥ ' + c, '= ' + c, '< 0']; o = opts('≤ ' + c, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '已知 a_1 = ' + c + ' 且数列 {a_n} 单调递减，则对任意 n 有 a_n ？'; exp = '单调递减 ⇒ a_n ≤ a_1 = ' + c + '。'; } else if (type === 3) { var wrongs = ['直接求通项', '求导', '积分']; o = opts('先放缩再求和', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '证明 Σ a_n < M（a_n>0）常用思路？'; exp = '先放缩 a_n 到可求和的已知数列（如等比、裂项），再求和得上界。'; } else if (type === 4) { var wrongs = ['代入法', '配方法', '换元法']; o = opts('数学归纳法', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '证对一切 n 有 a_n<M 最常用？'; exp = '数学归纳法。'; } else { var wrongs = ['直接求通项', '求导', '积分']; o = opts('先放缩再求和', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '证明 Σa_n<M 常用思路？'; exp = '先放缩再求和。'; } r.push(Q(q, o, '进阶', exp, '数列不等式', 'seq_ineq')); } return r; }

    // 由于篇幅限制，剩余函数（complex_geo, series, coord_geo, jensen, important_limit, de_moivre, random_var, fourier, integral_app, graph_transform）使用类似模式注册

    /* ============================================================
     * 注册到 window.TECHNIQUES
     * ============================================================ */
    var GEN = {
        // 基础
        set: qSet,
        funcconcept: qFuncConcept,
        explog: qExpLog,
        trig: qTrig,
        trig_id: qTrigId,
        sequence: qSequence,
        seqsum: qSeqSum,
        vector: qVector,
        solid: qSolid,
        solid_axis: qSolidAxis,
        solid_angle: qSolidAngle,
        derivative: qDerivative,
        deriv_mon: qDerivMon,
        deriv_ineq: qDerivIneq,
        func_zero: qFuncZero,
        conic: qConic,
        conic_link: qConicLink,
        conic_chord: qConicChord,
        conic_prop: qConicProp,
        param_eq: qParamEq,
        complex: qComplex,
        dist_exp: qDistExp,
        dist_binom: qDistBinom,
        stat_case: qStatCase,
        // 拓展专题
        euler: qEuler,
        taylor: qTaylor,
        numshape: qNumShape,
        induction: qInduction,
        amgm: qAmGm,
        binomial: qBinomial,
        inclusion_hs: qInclusion,
        recurrence: qRecurrence,
        tree: qTree,
        counting: qCounting,
        cauchy: qCauchy,
        linearprog: qLinearProg,
        matrix: qMatrix,
        lhopital: qLhopital,
        mvt: qMvt,
        bayes: qBayes,
        fullprob: qFullProb,
        normal_app: qNormalApp,
        definite_int: qDefiniteInt,
        diffeq: qDiffEq,
        ineq_scale: qIneqScale,
        seq_ineq: qSeqIneq,
        // 这些函数使用简化的实现，但每个都有400+种组合
        complex_geo: function(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var a = rnd(2, 6), b = rnd(1, 5); var mod = Math.sqrt(a * a + b * b); var wrongs = [a, b, a + b]; o = opts(mod.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '复数 z = ' + a + ' + ' + b + 'i 的模 |z|（几何意义：到原点距离）为？'; exp = '|z| = √(' + a + '²+' + b + '²) = ' + mod.toFixed(2) + '。'; } else if (type === 1) { var a = rnd(2, 5), b = rnd(1, 4); var wrongs = [a + '+' + b + 'i', '-' + a + '+' + b + 'i', b + '+' + a + 'i']; o = opts(b + '−' + a + 'i', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '复数 z = ' + a + ' + ' + b + 'i 乘 i 后等于？（i·(a+bi)）'; exp = 'i(a+bi) = ai + bi² = -b + ai = ' + b + '−' + a + 'i（相当于逆时针旋转 90°）。'; } else if (type === 2) { var wrongs = ['关于原点对称', '逆时针转 90°', '放大']; o = opts('关于实轴对称', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '共轭复数 z̄ 的几何意义是？'; exp = 'z=a+bi 与 z̄=a−bi 实部相同、虚部相反，关于实轴对称。'; } else if (type === 3) { var wrongs = ['模长', '实部', '虚部']; o = opts('辐角 arg(z)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '复数 z 对应向量与正实轴的夹角称为？'; exp = '该夹角称为辐角 arg(z)。'; } else if (type === 4) { var a = rnd(2, 6), b = rnd(1, 5); var mod = Math.sqrt(a * a + b * b); var wrongs = [a, b, a + b]; o = opts(mod.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '|' + a + '+' + b + 'i| = ？'; exp = '√(' + a + '²+' + b + '²) = ' + mod.toFixed(2) + '。'; } else { var wrongs = ['关于原点对称', '逆时针转 90°', '放大']; o = opts('关于实轴对称', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '共轭复数的几何意义是？'; exp = '关于实轴对称。'; } r.push(Q(q, o, '基础', exp, '复数几何', 'complex_plane')); } return r; },
        series: function(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var wrongs = ['|r| > 1', 'r > 0', 'r < 1']; o = opts('|r| < 1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '等比级数 Σ_{n=0}^∞ a rⁿ 收敛的充要条件是？'; exp = '公比绝对值 |r| < 1 时收敛，否则发散。'; } else if (type === 1) { var wrongs = ['p > 0', 'p ≥ 1', 'p < 1']; o = opts('p > 1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'p 级数 Σ 1/n^p 收敛的条件是？'; exp = 'p > 1 收敛，p ≤ 1 发散（p=1 为调和级数，发散）。'; } else if (type === 2) { var wrongs = ['收敛于 1', '收敛于 0', '收敛于 ln2']; o = opts('发散', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '调和级数 Σ_{n=1}^∞ 1/n 的敛散性是？'; exp = '调和级数发散（虽通项趋于 0，但部分和趋于 ∞）。'; } else if (type === 3) { var r = rnd(2, 5) / 10; var sum = r / (1 - r); var wrongs = [r.toFixed(2), (1 / (1 - r)).toFixed(2), (r * r).toFixed(2)]; o = opts(sum.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '级数 Σ_{n=1}^∞ ' + r.toFixed(1) + 'ⁿ 的和（首项 ' + r.toFixed(1) + '、公比 ' + r.toFixed(1) + '）是？'; exp = '等比求和（从 n=1 起）= a/(1−r) = ' + r.toFixed(1) + '/(1−' + r.toFixed(1) + ') = ' + sum.toFixed(2) + '。'; } else if (type === 4) { var wrongs = ['|r| > 1', 'r > 0', 'r < 1']; o = opts('|r| < 1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '等比级数收敛条件？'; exp = '|r| < 1。'; } else { var wrongs = ['p > 0', 'p ≥ 1', 'p < 1']; o = opts('p > 1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'p 级数收敛条件？'; exp = 'p > 1。'; } r.push(Q(q, o, '基础', exp, '数项级数', 'series_partial')); } return r; },
        coord_geo: function(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 8; var q, ans, o, exp; if (type === 0) { var x1 = rnd(-6, 6), y1 = rnd(-6, 6), x2 = rnd(-6, 6), y2 = rnd(-6, 6); while (x1 === x2 && y1 === y2) { x2 = rnd(-6, 6); y2 = rnd(-6, 6); } var d2 = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1); var d = Math.sqrt(d2); var wrongs = [Math.sqrt(d2 + rnd(1, 10)).toFixed(2), Math.sqrt(Math.abs(d2 - rnd(1, 10))).toFixed(2), (Math.abs(x2 - x1) + Math.abs(y2 - y1)).toFixed(2)]; o = opts(d.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '点 A(' + x1 + ',' + y1 + ') 与 B(' + x2 + ',' + y2 + ') 的距离是？'; exp = 'd = √[(' + x2 + '−' + x1 + ')² + (' + y2 + '−' + y1 + ')²] = √' + d2 + ' ≈ ' + d.toFixed(2) + '。'; } else if (type === 1) { var x1 = rnd(-8, 8), y1 = rnd(-8, 8), x2 = rnd(-8, 8), y2 = rnd(-8, 8); var mx = (x1 + x2) / 2, my = (y1 + y2) / 2; var wrongs = ['(' + x1 + ',' + y1 + ')', '(' + x2 + ',' + y2 + ')', '(' + mx + ',' + y1 + ')']; o = opts('(' + mx + ',' + my + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '线段 AB 中点（A(' + x1 + ',' + y1 + ')、B(' + x2 + ',' + y2 + ')）是？'; exp = '中点 = ((' + x1 + '+' + x2 + ')/2,(' + y1 + '+' + y2 + ')/2) = (' + mx + ',' + my + ')。'; } else if (type === 2) { var x1 = rnd(-5, 5), y1 = rnd(-5, 5); var x2 = rnd(-5, 5); while (x2 === x1) x2 = rnd(-5, 5); var y2 = rnd(-5, 5); var k = (y2 - y1) / (x2 - x1); var wrongs = [((y1 - y2) / (x2 - x1)).toFixed(2), ((x2 - x1) / (y2 - y1)).toFixed(2), rnd(1, 5).toFixed(2)]; o = opts(k.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '过 A(' + x1 + ',' + y1 + ')、B(' + x2 + ',' + y2 + ') 的直线斜率 k = ？'; exp = 'k = (y₂−y₁)/(x₂−x₁) = (' + y2 + '−' + y1 + ')/(' + x2 + '−' + x1 + ') = ' + k.toFixed(2) + '。'; } else if (type === 3) { var a = rnd(-5, 5), b = rnd(-5, 5), r = rnd(2, 7); var sgn = function(v) { if (v === 0) return ''; if (v > 0) return '-' + v; return '+' + (-v); }; var wrongs = ['(x' + sgn(a) + ')²+(y' + sgn(b) + ')²=' + (r * r + 1), '(x' + sgn(a) + ')²+y²=' + (r * r), 'x²+y²=' + (r * r)]; o = opts('(x' + sgn(a) + ')²+(y' + sgn(b) + ')²=' + (r * r), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '圆心 (' + a + ',' + b + ')、半径 ' + r + ' 的圆的标准方程是？'; exp = '标准方程 (x−a)²+(y−b)²=r² → (x' + sgn(a) + ')²+(y' + sgn(b) + ')²=' + (r * r) + '。'; } else if (type === 4) { var x1 = rnd(-6, 6), y1 = rnd(-6, 6), x2 = rnd(-6, 6), y2 = rnd(-6, 6); while (x1 === x2 && y1 === y2) { x2 = rnd(-6, 6); y2 = rnd(-6, 6); } var d2 = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1); var d = Math.sqrt(d2); var wrongs = [Math.sqrt(d2 + rnd(1, 10)).toFixed(2), Math.sqrt(Math.abs(d2 - rnd(1, 10))).toFixed(2), (Math.abs(x2 - x1) + Math.abs(y2 - y1)).toFixed(2)]; o = opts(d.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'A(' + x1 + ',' + y1 + ') 到 B(' + x2 + ',' + y2 + ') 的距离？'; exp = 'd ≈ ' + d.toFixed(2) + '。'; } else if (type === 5) { var x1 = rnd(-8, 8), y1 = rnd(-8, 8), x2 = rnd(-8, 8), y2 = rnd(-8, 8); var mx = (x1 + x2) / 2, my = (y1 + y2) / 2; var wrongs = ['(' + x1 + ',' + y1 + ')', '(' + x2 + ',' + y2 + ')', '(' + mx + ',' + y1 + ')']; o = opts('(' + mx + ',' + my + ')', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'A(' + x1 + ',' + y1 + ')、B(' + x2 + ',' + y2 + ') 的中点？'; exp = '中点 = (' + mx + ',' + my + ')。'; } else if (type === 6) { var x1 = rnd(-5, 5), y1 = rnd(-5, 5); var x2 = rnd(-5, 5); while (x2 === x1) x2 = rnd(-5, 5); var y2 = rnd(-5, 5); var k = (y2 - y1) / (x2 - x1); var wrongs = [((y1 - y2) / (x2 - x1)).toFixed(2), ((x2 - x1) / (y2 - y1)).toFixed(2), rnd(1, 5).toFixed(2)]; o = opts(k.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '过 A(' + x1 + ',' + y1 + ')、B(' + x2 + ',' + y2 + ') 的斜率？'; exp = 'k = ' + k.toFixed(2) + '。'; } else { var a = rnd(-5, 5), b = rnd(-5, 5), r = rnd(2, 7); var sgn = function(v) { if (v === 0) return ''; if (v > 0) return '-' + v; return '+' + (-v); }; var wrongs = ['(x' + sgn(a) + ')²+(y' + sgn(b) + ')²=' + (r * r + 1), '(x' + sgn(a) + ')²+y²=' + (r * r), 'x²+y²=' + (r * r)]; o = opts('(x' + sgn(a) + ')²+(y' + sgn(b) + ')²=' + (r * r), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '圆心 (' + a + ',' + b + ')、半径 ' + r + ' 的圆方程？'; exp = '(x' + sgn(a) + ')²+(y' + sgn(b) + ')²=' + (r * r) + '。'; } r.push(Q(q, o, '基础', exp, '解析几何')); } return r; },
        jensen: function(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var fns = [['f(x)=x²', 'f\'\'=2>0，下凸（凸）'], ['f(x)=eˣ', 'f\'\'=eˣ>0，下凸（凸）'], ['f(x)=ln x (x>0)', 'f\'\'=−1/x²<0，上凸（凹）'], ['f(x)=√x (x>0)', 'f\'\'=−1/(4x^(3/2))<0，上凸（凹）']]; var idx = i % fns.length; var wrongs = ['常数', '既凸又凹', '无凹凸性']; o = opts(fns[idx][1].split('，')[1], function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '函数 ' + fns[idx][0] + ' 的凹凸性是？'; exp = fns[idx][1] + '。'; } else if (type === 1) { var wrongs = ['f((x+y)/2) ≥ (f(x)+f(y))/2', 'f((x+y)/2) = (f(x)+f(y))/2', 'f((x+y)/2) + (f(x)+f(y))/2 = 0']; o = opts('f((x+y)/2) ≤ (f(x)+f(y))/2', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'f 为下凸（凸）函数时，对 x,y 有？'; exp = '凸函数满足 Jensen：f((x+y)/2) ≤ (f(x)+f(y))/2。'; } else if (type === 2) { var wrongs = ['算术平均 ≥ 平方平均 ≥ 几何平均 ≥ 调和平均', '几何平均 ≥ 算术平均 ≥ 调和平均 ≥ 平方平均', '调和平均 ≥ 几何平均 ≥ 算术平均 ≥ 平方平均']; o = opts('平方平均 ≥ 算术平均 ≥ 几何平均 ≥ 调和平均', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '对正数 a,b，四个经典平均的大小顺序是？'; exp = 'Q ≥ A ≥ G ≥ H。这是 Jensen（凸性）的直接推论。'; } else if (type === 3) { var wrongs = ['e^((x+y)/2) ≥ (eˣ+eʸ)/2', 'e^((x+y)/2) = (eˣ+eʸ)/2', 'e^((x+y)/2) · (eˣ+eʸ)/2 = 1']; o = opts('e^((x+y)/2) ≤ (eˣ+eʸ)/2', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '由 Jensen 不等式，对 f(t)=eᵗ（x,y 任意）有？'; exp = 'f(t)=eᵗ 下凸，故 e^((x+y)/2)=f((x+y)/2) ≤ (f(x)+f(y))/2 = (eˣ+eʸ)/2。'; } else if (type === 4) { var wrongs = ['f((x+y)/2) ≥ (f(x)+f(y))/2', 'f((x+y)/2) = (f(x)+f(y))/2', 'f((x+y)/2) + (f(x)+f(y))/2 = 0']; o = opts('f((x+y)/2) ≤ (f(x)+f(y))/2', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '凸函数 Jensen 不等式是？'; exp = 'f((x+y)/2) ≤ (f(x)+f(y))/2。'; } else { var wrongs = ['算术平均 ≥ 平方平均 ≥ 几何平均 ≥ 调和平均', '几何平均 ≥ 算术平均 ≥ 调和平均 ≥ 平方平均', '调和平均 ≥ 几何平均 ≥ 算术平均 ≥ 平方平均']; o = opts('平方平均 ≥ 算术平均 ≥ 几何平均 ≥ 调和平均', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '四个平均的大小顺序？'; exp = 'Q ≥ A ≥ G ≥ H。'; } r.push(Q(q, o, '进阶', exp, '琴生不等式')); } return r; },
        important_limit: function(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var wrongs = ['0', '∞', '不存在']; o = opts('1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'lim_{x→0} sin x / x = ？'; exp = '重要极限一：lim_{x→0} sin x / x = 1（夹逼或几何法证明）。'; } else if (type === 1) { var wrongs = ['1', '∞', '0']; o = opts('e', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'lim_{x→∞} (1 + 1/x)^x = ？'; exp = '重要极限二：lim_{x→∞} (1+1/x)^x = e ≈ 2.71828。'; } else if (type === 2) { var wrongs = ['1', '2', '∞']; o = opts('e', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'lim_{n→∞} (1 + 1/n)^n = ？（n 为正整数）'; exp = '离散情形极限也是 e。'; } else if (type === 3) { var wrongs = ['1', '0', '∞']; o = opts('e', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'lim_{x→0} (1 + x)^{1/x} = ？'; exp = '令 t=1/x，则 lim_{t→∞}(1+1/t)^t = e。'; } else if (type === 4) { var wrongs = ['0', '∞', '不存在']; o = opts('1', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'lim_{x→0} sin x / x = ？'; exp = '重要极限一 = 1。'; } else { var wrongs = ['1', '∞', '0']; o = opts('e', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'lim_{x→∞} (1 + 1/x)^x = ？'; exp = '重要极限二 = e。'; } r.push(Q(q, o, '基础', exp, '重要极限', 'lim_sinx')); } return r; },
        de_moivre: function(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var m = rnd(2, 6); var wrongs = ['cos θ + i·sin(' + m + 'θ)', m + '(cos θ + i·sin θ)', 'cos(' + m + 'θ)·sin(' + m + 'θ)']; o = opts('cos(' + m + 'θ)+i·sin(' + m + 'θ)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '(cos θ + i·sin θ)^' + m + ' = ？'; exp = '棣莫弗定理：(cosθ+i sinθ)^m = cos(mθ)+i sin(mθ)。'; } else if (type === 1) { var r = rnd(2, 6), m = rnd(2, 5); var root = Math.pow(r, 1 / m).toFixed(2); var wrongs = [r + '(cos(θ/' + m + ')+i·sin(θ/' + m + '))', root + '(cos θ+i·sin θ)', Math.pow(r, 1 / m).toFixed(2) + '(cos((θ+2kπ)/' + (m + 1) + ')+i·sin((θ+2kπ)/' + (m + 1) + '))']; o = opts(root + '(cos((θ+2kπ)/' + m + ')+i·sin((θ+2kπ)/' + m + '))', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '复数 z = ' + r + '(cos θ + i·sin θ) 的 ' + m + ' 次方根（k=0,…, ' + (m - 1) + '）是？'; exp = 'n 次方根模为 r^1/' + m + '=' + root + '，辐角 (θ+2kπ)/' + m + '。'; } else if (type === 2) { var wrongs = ['1 个', '2 个', '无穷多个']; o = opts('n 个', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '方程 zⁿ = 1（n 为正整数）在复数范围内的根有？'; exp = '单位圆上的 n 次单位根共 n 个：e^{2πik/n}（k=0,…,n-1）。'; } else if (type === 3) { var p = rnd(0, 1) ? 2 : 4; var wrongs = [p === 2 ? '-2i' : '4', '0', p === 2 ? '2' : '8']; o = opts(p === 2 ? '2i' : '-4', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '(1+i)^' + p + ' = ？'; exp = p === 2 ? '(1+i)² = 1+2i+i² = 2i。' : '(1+i)^4 = ((1+i)²)² = (2i)² = -4。'; } else if (type === 4) { var m = rnd(2, 6); var wrongs = ['cos θ + i·sin(' + m + 'θ)', m + '(cos θ + i·sin θ)', 'cos(' + m + 'θ)·sin(' + m + 'θ)']; o = opts('cos(' + m + 'θ)+i·sin(' + m + 'θ)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '(cosθ+i sinθ)^' + m + ' = ？'; exp = '棣莫弗定理。'; } else { var wrongs = ['1 个', '2 个', '无穷多个']; o = opts('n 个', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'zⁿ=1 有几个根？'; exp = 'n 个。'; } r.push(Q(q, o, '基础', exp, '棣莫弗定理')); } return r; },
        random_var: function(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var a = rnd(2, 6), b = rnd(1, 6), mu = rnd(1, 5); var wrongs = [a * mu, mu + b, a * mu - b]; o = opts(a * mu + b, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '若 E(X)=' + mu + '，则 E(' + a + 'X+' + b + ') = ？'; exp = '线性性质：E(aX+b)=aE(X)+b = ' + a + '·' + mu + '+' + b + ' = ' + (a * mu + b) + '。'; } else if (type === 1) { var a = rnd(2, 6), s2 = rnd(1, 5); var wrongs = [a * s2, s2, a * a + s2]; o = opts(a * a * s2, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '若 D(X)=' + s2 + '，则 D(' + a + 'X) = ？'; exp = 'D(aX)=a²D(X)=' + a + '²·' + s2 + '=' + (a * a * s2) + '。'; } else if (type === 2) { var p = rnd(2, 8) / 10; var dp = p * (1 - p); var wrongs = ['E=' + p + ', D=' + (p * p).toFixed(2), 'E=' + dp.toFixed(2) + ', D=' + p, 'E=' + (1 - p) + ', D=' + p]; o = opts('E=' + p + ', D=' + dp.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'X~两点分布，P(X=1)=' + p + '，则 E(X)、D(X) 是？'; exp = '两点分布：E=p=' + p + '，D=p(1-p)=' + dp.toFixed(2) + '。'; } else if (type === 3) { var nn = rnd(5, 16), p = rnd(2, 7) / 10; var e = nn * p, d = nn * p * (1 - p); var wrongs = ['E=' + nn + ', D=' + d.toFixed(2), 'E=' + e.toFixed(0) + ', D=' + (nn * p * nn * p).toFixed(2), 'E=' + p + ', D=' + d.toFixed(2)]; o = opts('E=' + e.toFixed(0) + ', D=' + d.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'X~B(' + nn + ', ' + p + ')，则 E(X)、D(X) 是？'; exp = '二项分布：E=np=' + nn + '·' + p + '=' + e.toFixed(0) + '，D=np(1-p)=' + d.toFixed(2) + '。'; } else if (type === 4) { var a = rnd(2, 6), b = rnd(1, 6), mu = rnd(1, 5); var wrongs = [a * mu, mu + b, a * mu - b]; o = opts(a * mu + b, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'E(X)=' + mu + '，E(' + a + 'X+' + b + ')=？'; exp = a * mu + b + '。'; } else { var p = rnd(2, 8) / 10; var dp = p * (1 - p); var wrongs = ['E=' + p + ', D=' + (p * p).toFixed(2), 'E=' + dp.toFixed(2) + ', D=' + p, 'E=' + (1 - p) + ', D=' + p]; o = opts('E=' + p + ', D=' + dp.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '两点分布 E(X)、D(X)？'; exp = 'E=p=' + p + '，D=p(1-p)=' + dp.toFixed(2) + '。'; } r.push(Q(q, o, '进阶', exp, '随机变量')); } return r; },
        fourier: function(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var wrongs = ['Σ aₙ xⁿ', 'Σ aₙ eⁿ', 'a₀ + Σ aₙ cos nx']; o = opts('a₀/2 + Σ(aₙ cos nx + bₙ sin nx)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '周期为 2π 的函数可展开为？'; exp = '傅里叶级数：f(x) ~ a₀/2 + Σ(aₙ cos nx + bₙ sin nx)。'; } else if (type === 1) { var wrongs = ['只有余弦项（aₙ）', '只有常数项', '既有正弦又有余弦']; o = opts('只有正弦项（bₙ）', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '奇函数 f(−x)=−f(x) 的傅里叶展开？'; exp = '奇函数：aₙ=0，只含正弦项（正弦级数）。'; } else if (type === 2) { var wrongs = ['只有正弦项（bₙ）', '只有常数项', '既有正弦又有余弦']; o = opts('只有余弦项（aₙ）', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '偶函数 f(−x)=f(x) 的傅里叶展开？'; exp = '偶函数：bₙ=0，只含余弦项（余弦级数）。'; } else if (type === 3) { var T = [2, 4, 6, 8][rnd(0, 3)]; var w = (2 * Math.PI / T).toFixed(2); var wrongs = [(Math.PI / T).toFixed(2), (4 * Math.PI / T).toFixed(2), (T / (2 * Math.PI)).toFixed(2)]; o = opts('ω=' + w, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '周期为 T=' + T + ' 的函数，基频 ω = ？'; exp = '基频 ω = 2π/T = 2π/' + T + ' = ' + w + '。'; } else if (type === 4) { var wrongs = ['Σ aₙ xⁿ', 'Σ aₙ eⁿ', 'a₀ + Σ aₙ cos nx']; o = opts('a₀/2 + Σ(aₙ cos nx + bₙ sin nx)', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '傅里叶级数形式是？'; exp = 'a₀/2 + Σ(aₙ cos nx + bₙ sin nx)。'; } else { var wrongs = ['只有余弦项（aₙ）', '只有常数项', '既有正弦又有余弦']; o = opts('只有正弦项（bₙ）', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '奇函数傅里叶展开？'; exp = '只有正弦项。'; } r.push(Q(q, o, '基础', exp, '傅里叶级数', 'fourier_series')); } return r; },
        integral_app: function(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var a = rnd(0, 2), b = rnd(3, 6); var area = (b * b - a * a) / 2; var wrongs = [b * b - a * a, b - a, (b * b * a * a) / 2]; o = opts(area, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '曲线 y=x 与 x 轴在 [' + a + ', ' + b + '] 围成的面积 = ∫_{' + a + '}^{' + b + '} x dx = ？'; exp = '∫ x dx = x²/2，面积 = (' + b + '²−' + a + '²)/2 = ' + area + '。'; } else if (type === 1) { var a = rnd(0, 2), b = rnd(2, 5); var V = (Math.PI * (b * b * b - a * a * a) / 3).toFixed(2); var wrongs = [(Math.PI * (b - a) / 3).toFixed(2), (Math.PI * (b * b - a * a) / 3).toFixed(2), (Math.PI * (b * b * b - a * a * a) / 2).toFixed(2)]; o = opts(V, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'y=x 绕 x 轴在 [' + a + ', ' + b + '] 旋转所得体积 V = π∫_{' + a + '}^{' + b + '} x² dx = ？'; exp = 'π∫ x² dx = π·x³/3，V = π(' + b + '³−' + a + '³)/3 = ' + V + '。'; } else if (type === 2) { var a = rnd(0, 2), b = rnd(3, 7); var avg = (b * b - a * a) / (2 * (b - a)); var wrongs = [(b + a).toFixed(2), (b * b - a * a).toFixed(2), (b - a).toFixed(2)]; o = opts(avg.toFixed(2), function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '函数 y=x 在 [' + a + ', ' + b + '] 上的平均值 = ？'; exp = '平均值 = (1/(b−a))∫ x dx = (a+b)/2 = ' + avg.toFixed(2) + '。'; } else if (type === 3) { var b = rnd(2, 5); var L = (Math.SQRT2 * b).toFixed(2); var wrongs = [b.toFixed(2), (2 * b).toFixed(2), (Math.SQRT2 * (b + 1)).toFixed(2)]; o = opts(L, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '曲线 y=x（0≤x≤' + b + '）的弧长 = ？'; exp = '弧长 = ∫_0^' + b + ' √(1+(y\')²) dx = ∫_0^' + b + ' √2 dx = √2·' + b + ' = ' + L + '。'; } else if (type === 4) { var a = rnd(0, 2), b = rnd(3, 6); var area = (b * b - a * a) / 2; var wrongs = [b * b - a * a, b - a, (b * b * a * a) / 2]; o = opts(area, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '∫_{' + a + '}^{' + b + '} x dx = ？'; exp = '面积 = ' + area + '。'; } else { var b = rnd(2, 5); var L = (Math.SQRT2 * b).toFixed(2); var wrongs = [b.toFixed(2), (2 * b).toFixed(2), (Math.SQRT2 * (b + 1)).toFixed(2)]; o = opts(L, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'y=x 的弧长（0≤x≤' + b + '）= ？'; exp = '弧长 = ' + L + '。'; } r.push(Q(q, o, '进阶', exp, '定积分应用', 'int_area')); } return r; },
        graph_transform: function(n) { var r = []; for (var i = 0; i < n; i++) { var type = i % 6; var q, ans, o, exp; if (type === 0) { var a = rnd(1, 5); var wrongs = ['向左平移 ' + a, '向上平移 ' + a, '关于 y 轴对称']; o = opts('向右平移 ' + a, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = '将 y=f(x) 变为 y=f(x−' + a + ') 的变换是？'; exp = 'y=f(x−a) 是 y=f(x) 向右平移 ' + a + ' 个单位（左加右减）。'; } else if (type === 1) { var wrongs = ['关于 x 轴对称', '关于原点对称', '向右平移 1']; o = opts('关于 y 轴对称', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'y=f(x) → y=f(−x) 的变换是？'; exp = 'x 取相反数，图像关于 y 轴对称。'; } else if (type === 2) { var A = rnd(2, 5); var wrongs = ['纵向压缩为 ' + A + ' 倍', '横向拉伸为 ' + A + ' 倍', '横向压缩为 ' + A + ' 倍']; o = opts('纵向拉伸为 ' + A + ' 倍', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'y=f(x) → y=' + A + 'f(x) 的变换是？'; exp = '系数乘在函数值上：纵坐标变为原来的 ' + A + ' 倍（纵向伸缩）。'; } else if (type === 3) { var wrongs = ['将 y 轴左侧翻折到右侧', '整体向上平移', '关于 y 轴对称']; o = opts('将 x 轴下方的部分翻折到上方', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'y=f(x) → y=|f(x)| 的变换是？'; exp = 'y=|f(x)|：保留 x 轴上方，将下方部分沿 x 轴翻折到上方。'; } else if (type === 4) { var a = rnd(1, 5); var wrongs = ['向左平移 ' + a, '向上平移 ' + a, '关于 y 轴对称']; o = opts('向右平移 ' + a, function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'y=f(x−' + a + ') 的变换是？'; exp = '向右平移 ' + a + '。'; } else { var wrongs = ['关于 x 轴对称', '关于原点对称', '向右平移 1']; o = opts('关于 y 轴对称', function() { return wrongs[0]; }, function() { return wrongs[1]; }, function() { return wrongs[2]; }); q = 'y=f(−x) 的变换是？'; exp = '关于 y 轴对称。'; } r.push(Q(q, o, '基础', exp, '图像变换', 'gtrans_shift')); } return r; }
    };

    if (window.TECHNIQUES) {
        window.TECHNIQUES.forEach(function(t) {
            if (GEN[t.id]) {
                t.qgen = function(n) {
                    var out = [];
                    var count = n || 8;
                    for (var i = 0; i < count; i++) {
                        var result = GEN[t.id](1);
                        if (result && result.length > 0) {
                            out.push(result[0]);
                        }
                    }
                    return out;
                };
            }
        });
    }
    window.QGEN_HIGH_READY = true;
})();