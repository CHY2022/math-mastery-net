/* ============================================================
 * 融会贯通 · 小学英语出题引擎（人教版PEP 3-6年级）
 *  - 每个技巧按年级分池（G3/G4/G5/G6）
 *  - 每池 ≥100 道题，qgen(n) 不重复抽取
 *  - 支持年级筛选：t.qgen(n, grade) 如 t.qgen(5, "G4")
 * ============================================================ */
(function () {
  /* ---------- 通用工具 ---------- */
  const K = { ink: "#334155", sub: "#64748b", line: "#cbd5e1", pri: "#2f6fed", ok: "#16a34a", warn: "#d97706", red: "#dc2626", soft: "#eef3ff", blue: "#2563eb", purple: "#7c3aed" };

  function S(w, h, inner, maxw) {
    return `<svg viewBox="0 0 ${w} ${h}" width="100%" style="max-width:${maxw || w}px;height:auto;display:block" xmlns="http://www.w3.org/2000/svg">${inner}</svg>`;
  }
  function rnd(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
  function pick(a) { return a[rnd(0, a.length - 1)]; }
  function shuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  function opts(ans, make, n) {
    n = n || 4;
    const set = new Set([String(ans)]);
    let g = 0;
    while (set.size < n && g++ < 400) { const d = String(make()); if (d !== String(ans)) set.add(d); }
    let k = 1;
    while (set.size < n) { set.add(String(ans) + k); if (set.size < n) set.add(String(ans) - k); k++; }
    const arr = shuffle([...set]);
    return { opts: arr, ans: arr.indexOf(String(ans)) };
  }

  function Q(q, optsObj, level, explain, point, fig, grade) {
    return Object.assign({ q, level: level || "基础", explain, point: point || "", grade: grade || "G3" }, optsObj, { fig: fig || null });
  }

  /* ============================================================
   * 词汇库（按年级分类 · 人教版PEP）
   * ============================================================ */
  const VOCAB = {
    G3: {
      animal: { en: ["cat", "dog", "duck", "pig", "bear", "elephant", "tiger", "bird", "fish", "rabbit", "monkey", "panda"], zh: ["猫", "狗", "鸭子", "猪", "熊", "大象", "老虎", "鸟", "鱼", "兔子", "猴子", "熊猫"] },
      color: { en: ["red", "blue", "green", "yellow", "white", "black", "orange", "brown", "pink", "purple"], zh: ["红色", "蓝色", "绿色", "黄色", "白色", "黑色", "橙色", "棕色", "粉色", "紫色"] },
      food: { en: ["rice", "bread", "milk", "egg", "cake", "fish", "chicken", "noodles", "dumpling", "ice cream"], zh: ["米饭", "面包", "牛奶", "鸡蛋", "蛋糕", "鱼", "鸡肉", "面条", "饺子", "冰淇淋"] },
      family: { en: ["father", "mother", "brother", "sister", "grandpa", "grandma", "uncle", "aunt"], zh: ["爸爸", "妈妈", "兄弟", "姐妹", "爷爷", "奶奶", "叔叔", "阿姨"] },
      body: { en: ["head", "eye", "nose", "mouth", "ear", "face", "hand", "foot", "leg", "arm"], zh: ["头", "眼睛", "鼻子", "嘴巴", "耳朵", "脸", "手", "脚", "腿", "手臂"] },
      number: { en: ["one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten"], zh: ["一", "二", "三", "四", "五", "六", "七", "八", "九", "十"] },
      school: { en: ["book", "pencil", "ruler", "eraser", "bag", "pen", "desk", "chair"], zh: ["书", "铅笔", "尺子", "橡皮", "书包", "钢笔", "书桌", "椅子"] }
    },
    G4: {
      classroom: { en: ["classroom", "blackboard", "door", "window", "floor", "wall", "light", "picture", "computer", "fan", "teacher's desk"], zh: ["教室", "黑板", "门", "窗户", "地板", "墙壁", "灯", "图画", "电脑", "风扇", "讲台"] },
      schoolbag: { en: ["schoolbag", "book", "pencil", "pen", "ruler", "eraser", "crayon", "notebook", "dictionary", "storybook"], zh: ["书包", "书", "铅笔", "钢笔", "尺子", "橡皮", "蜡笔", "笔记本", "词典", "故事书"] },
      friend: { en: ["friend", "strong", "tall", "short", "thin", "quiet", "friendly", "cute", "cool", "smart"], zh: ["朋友", "强壮的", "高的", "矮的", "瘦的", "安静的", "友好的", "可爱的", "酷的", "聪明的"] },
      home: { en: ["bedroom", "living room", "kitchen", "bathroom", "study", "bed", "table", "sofa", "fridge", "phone"], zh: ["卧室", "客厅", "厨房", "浴室", "书房", "床", "桌子", "沙发", "冰箱", "电话"] },
      clothes: { en: ["shirt", "shoes", "hat", "coat", "dress", "skirt", "pants", "socks", "jacket", "sweater"], zh: ["衬衫", "鞋子", "帽子", "外套", "连衣裙", "裙子", "裤子", "袜子", "夹克", "毛衣"] },
      weather: { en: ["sunny", "cloudy", "windy", "rainy", "snowy", "warm", "cold", "hot", "cool"], zh: ["晴朗的", "多云的", "有风的", "下雨的", "下雪的", "温暖的", "寒冷的", "炎热的", "凉爽的"] }
    },
    G5: {
      personality: { en: ["kind", "strict", "funny", "polite", "hard-working", "helpful", "shy", "clever", "friendly", "quiet"], zh: ["和蔼的", "严格的", "有趣的", "有礼貌的", "勤奋的", "乐于助人的", "害羞的", "聪明的", "友好的", "安静的"] },
      week: { en: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday", "weekend", "today", "tomorrow"], zh: ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日", "周末", "今天", "明天"] },
      food_drink: { en: ["hamburger", "sandwich", "salad", "pizza", "noodles", "juice", "tea", "coffee", "milk", "water"], zh: ["汉堡", "三明治", "沙拉", "比萨", "面条", "果汁", "茶", "咖啡", "牛奶", "水"] },
      housework: { en: ["clean", "wash", "cook", "read", "watch", "play", "do homework", "water plants", "walk the dog", "make bed"], zh: ["打扫", "洗", "做饭", "阅读", "看", "玩", "做作业", "浇花", "遛狗", "铺床"] },
      nature: { en: ["forest", "lake", "river", "mountain", "hill", "tree", "flower", "grass", "cloud", "sky"], zh: ["森林", "湖", "河流", "山", "小山", "树", "花", "草", "云", "天空"] },
      daily: { en: ["get up", "eat breakfast", "go to school", "have class", "eat lunch", "go home", "do homework", "go to bed"], zh: ["起床", "吃早餐", "上学", "上课", "吃午餐", "回家", "做作业", "睡觉"] }
    },
    G6: {
      transport: { en: ["bus", "subway", "train", "plane", "ship", "taxi", "bike", "walk", "car", "on foot"], zh: ["公共汽车", "地铁", "火车", "飞机", "轮船", "出租车", "自行车", "步行", "小汽车", "步行"] },
      direction: { en: ["near", "next to", "behind", "between", "in front of", "nearby", "across from", "turn left", "turn right", "go straight"], zh: ["在附近", "在旁边", "在后面", "在中间", "在前面", "在附近", "对面", "左转", "右转", "直走"] },
      hobby: { en: ["sing", "dance", "draw", "read", "swim", "skate", "cook", "play sports", "listen to music", "watch TV"], zh: ["唱歌", "跳舞", "画画", "阅读", "游泳", "滑冰", "做饭", "做运动", "听音乐", "看电视"] },
      job: { en: ["teacher", "doctor", "nurse", "farmer", "driver", "singer", "writer", "scientist", "policeman", "cook"], zh: ["老师", "医生", "护士", "农民", "司机", "歌手", "作家", "科学家", "警察", "厨师"] },
      feeling: { en: ["happy", "sad", "angry", "worried", "afraid", "excited", "tired", "bored", "surprised", "proud"], zh: ["开心的", "伤心的", "生气的", "担心的", "害怕的", "兴奋的", "疲倦的", "无聊的", "惊讶的", "骄傲的"] },
      past: { en: ["was", "were", "went", "did", "had", "ate", "drank", "read", "saw", "bought"], zh: ["是(过去)", "是(过去)", "去(过去)", "做(过去)", "有(过去)", "吃(过去)", "喝(过去)", "读(过去)", "看见(过去)", "买(过去)"] }
    }
  };

  const ALL_GRADES = ["G3", "G4", "G5", "G6"];
  const GRADE_NAMES = { G3: "三年级", G4: "四年级", G5: "五年级", G6: "六年级" };

  /* ---------- 题库构建器 ---------- */
  function buildPoolForGrade(grade, builder, count) {
    const pool = [];
    for (let i = 0; i < count; i++) {
      let item = builder(grade);
      let attempts = 0;
      while (pool.some(p => p.q === item.q) && attempts < 50) {
        item = builder(grade);
        attempts++;
      }
      pool.push(item);
    }
    return pool;
  }

  /* ============================================================
   * 1. 词汇辨义（各年级 ≥100）
   * ============================================================ */
  function wordBuilder(grade) {
    const topics = Object.keys(VOCAB[grade] || VOCAB.G3);
    const topic = pick(topics);
    const words = VOCAB[grade][topic];
    const idx = rnd(0, words.en.length - 1);
    const en = words.en[idx];
    const zh = words.zh[idx];
    const type = rnd(0, 2);
    let q, ans, optGen;
    if (type === 0) {
      q = `"${en}" 的中文意思是？`;
      ans = zh;
      optGen = () => pick(words.zh);
    } else if (type === 1) {
      q = `"${zh}" 的英文单词是？`;
      ans = en;
      optGen = () => pick(words.en);
    } else {
      const others = words.en.filter((_, i) => i !== idx);
      const wrong = pick(others);
      q = `下列哪个单词与其他不同类？`;
      ans = wrong;
      optGen = () => pick(words.en);
    }
    const o = opts(ans, optGen);
    return Q(q, o, grade === "G3" ? "基础" : "进阶", `正确答案是 ${ans}`, "词汇辨义", { name: "gWord", topic, en, zh }, grade);
  }

  const WORD_POOLS = {};
  ALL_GRADES.forEach(g => {
    WORD_POOLS[g] = buildPoolForGrade(g, wordBuilder, 110);
  });

  /* ============================================================
   * 2. 单词拼写（各年级 ≥100）
   * ============================================================ */
  function spellingBuilder(grade) {
    const topics = Object.keys(VOCAB[grade] || VOCAB.G3);
    const topic = pick(topics);
    const words = VOCAB[grade][topic];
    const idx = rnd(0, words.en.length - 1);
    const en = words.en[idx];
    const zh = words.zh[idx];
    const pos = rnd(0, en.length - 1);
    const hint = en.slice(0, pos) + "_" + en.slice(pos + 1);
    const q = `根据中文 "${zh}"，补全单词：${hint}`;
    const ans = en[pos];
    const o = opts(ans, () => "abcdefghijklmnopqrstuvwxyz"[rnd(0, 25)]);
    return Q(q, o, grade === "G3" ? "基础" : "进阶", `完整单词是 ${en}，空缺字母是 ${ans}`, "拼写补全", { name: "gSpelling", en, zh, pos }, grade);
  }

  const SPELLING_POOLS = {};
  ALL_GRADES.forEach(g => {
    SPELLING_POOLS[g] = buildPoolForGrade(g, spellingBuilder, 110);
  });

  /* ============================================================
   * 3. 语法填空（各年级 ≥100）
   * ============================================================ */
  function grammarBuilder(grade) {
    const type = rnd(0, 2);
    const gLevel = grade === "G3" ? 0 : (grade === "G4" ? 1 : 2);

    if (type === 0 && gLevel >= 0) {
      const subjects = grade === "G3" ? ["I", "You", "My father", "My mother"] :
                        grade === "G4" ? ["He", "She", "It", "My friend", "The cat"] :
                        ["He", "She", "They", "We", "My teacher", "The students"];
      const verbs = grade === "G3" ? ["go", "like", "eat", "play"] :
                    grade === "G4" ? ["run", "swim", "read", "write"] :
                    ["study", "cook", "drive", "teach"];
      const objs = grade === "G3" ? ["to school", "apples", "rice", "football"] :
                   grade === "G4" ? ["in the park", "books", "noodles", "basketball"] :
                   ["every day", "at home", "English", "now"];
      const subj = pick(subjects);
      const verb = pick(verbs);
      const obj = pick(objs);
      const isThird = subj === "He" || subj === "She" || subj === "It" || subj === "My father" || subj === "My mother" || subj === "My friend" || subj === "The cat" || subj === "My teacher" || subj === "The students";
      const form = isThird ? verb + "s" : verb;
      const q = `${subj} ______ ${obj}.`;
      const ans = form;
      const o = opts(ans, () => pick([verb, verb + "s", verb + "es", verb + "ed", verb + "ing"]));
      return Q(q, o, grade === "G3" ? "基础" : "进阶", `主语是 ${subj}${isThird ? "，第三人称单数动词加 -s/-es" : "，动词用原形"}`, "主谓一致", { name: "gGrammar", subj, verb, form }, grade);
    } else if (type === 1 && gLevel >= 1) {
      const nouns = grade === "G4" ? { cat: "cats", dog: "dogs", book: "books", pen: "pens" } :
                     { child: "children", foot: "feet", mouse: "mice", man: "men", woman: "women", goose: "geese" };
      const word = pick(Object.keys(nouns));
      const plural = nouns[word];
      const q = `写出 "${word}" 的复数形式：`;
      const ans = plural;
      const o = opts(ans, () => pick([word, word + "s", word + "es", plural]));
      return Q(q, o, grade === "G4" ? "基础" : "进阶", `可数名词复数规则：${word} → ${plural}`, "名词复数", { name: "gGrammar", word, plural }, grade);
    } else {
      const preps = grade === "G3" ? ["in", "on", "at"] :
                    grade === "G4" ? ["in", "on", "at", "under", "behind"] :
                    ["in", "on", "at", "under", "behind", "next to", "in front of", "between"];
      const prep = pick(preps);
      const subjects = grade === "G3" ? ["The book", "The pen"] :
                       grade === "G4" ? ["The cat", "My bag", "The ball"] :
                       ["The pencil", "The chair", "The desk", "My friend"];
      const objects = grade === "G3" ? ["the desk", "the box"] :
                      grade === "G4" ? ["the table", "the bed", "the floor"] :
                      ["the room", "the window", "the door", "the wall"];
      const q = `${pick(subjects)} is ______ ${pick(objects)}.`;
      const ans = prep;
      const o = opts(ans, () => pick(preps));
      return Q(q, o, grade === "G3" ? "基础" : "进阶", `介词 ${prep} 表示位置关系`, "介词用法", { name: "gGrammar", prep }, grade);
    }
  }

  const GRAMMAR_POOLS = {};
  ALL_GRADES.forEach(g => {
    GRAMMAR_POOLS[g] = buildPoolForGrade(g, grammarBuilder, 110);
  });

  /* ============================================================
   * 4. 连词成句（各年级 ≥100）
   * ============================================================ */
  function sentenceBuilder(grade) {
    const templates = {
      G3: [
        { words: ["I", "like", "apples"], answer: "I like apples." },
        { words: ["She", "is", "a", "teacher"], answer: "She is a teacher." },
        { words: ["My", "father", "can", "swim"], answer: "My father can swim." },
        { words: ["We", "have", "lunch", "at", "school"], answer: "We have lunch at school." },
        { words: ["It", "is", "a", "cat"], answer: "It is a cat." },
        { words: ["I", "have", "a", "pen"], answer: "I have a pen." }
      ],
      G4: [
        { words: ["They", "are", "reading", "books"], answer: "They are reading books." },
        { words: ["He", "goes", "to", "school", "by", "bus"], answer: "He goes to school by bus." },
        { words: ["I", "want", "to", "be", "a", "doctor"], answer: "I want to be a doctor." },
        { words: ["She", "is", "good", "at", "English"], answer: "She is good at English." },
        { words: ["Where", "is", "my", "book"], answer: "Where is my book?" },
        { words: ["What", "time", "is", "it"], answer: "What time is it?" }
      ],
      G5: [
        { words: ["They", "are", "going", "to", "the", "park"], answer: "They are going to the park." },
        { words: ["My", "mother", "cooks", "dinner", "every", "day"], answer: "My mother cooks dinner every day." },
        { words: ["I", "get", "up", "at", "six", "o'clock"], answer: "I get up at six o'clock." },
        { words: ["We", "should", "brush", "our", "teeth", "twice", "a", "day"], answer: "We should brush our teeth twice a day." },
        { words: ["What", "do", "you", "have", "on", "Mondays"], answer: "What do you have on Mondays?" },
        { words: ["I", "often", "read", "books", "on", "weekends"], answer: "I often read books on weekends." }
      ],
      G6: [
        { words: ["How", "do", "you", "go", "to", "school"], answer: "How do you go to school?" },
        { words: ["I", "went", "to", "the", "park", "yesterday"], answer: "I went to the park yesterday." },
        { words: ["She", "is", "going", "to", "visit", "her", "grandma"], answer: "She is going to visit her grandma." },
        { words: ["What", "does", "your", "father", "do"], answer: "What does your father do?" },
        { words: ["I", "feel", "happy", "today"], answer: "I feel happy today." },
        { words: ["Turn", "left", "at", "the", "crossing"], answer: "Turn left at the crossing." }
      ]
    };
    const t = pick(templates[grade] || templates.G3);
    const shuffled = shuffle(t.words);
    const q = `连词成句：${shuffled.join(" ")}`;
    const ans = t.answer;
    const allAnswers = templates[grade] ? templates[grade].map(t => t.answer) : templates.G3.map(t => t.answer);
    const o = opts(ans, () => pick(allAnswers));
    return Q(q, o, grade === "G3" || grade === "G4" ? "基础" : "进阶", `正确语序是 ${ans}`, "句子结构", { name: "gSentence", shuffled, answer: ans }, grade);
  }

  const SENTENCE_POOLS = {};
  ALL_GRADES.forEach(g => {
    SENTENCE_POOLS[g] = buildPoolForGrade(g, sentenceBuilder, 110);
  });

  /* ============================================================
   * 5. 情景对话（各年级 ≥100）
   * ============================================================ */
  function dialogueBuilder(grade) {
    const dialogs = {
      G3: [
        { q: "How are you?", ans: "I'm fine, thank you." },
        { q: "What's your name?", ans: "My name is Lily." },
        { q: "How old are you?", ans: "I'm eight years old." },
        { q: "Nice to meet you!", ans: "Nice to meet you, too." },
        { q: "Thank you.", ans: "You're welcome." },
        { q: "Good morning!", ans: "Good morning!" },
        { q: "What colour is it?", ans: "It's red." }
      ],
      G4: [
        { q: "Where are you from?", ans: "I'm from China." },
        { q: "What time is it?", ans: "It's seven o'clock." },
        { q: "Can I help you?", ans: "Yes, please." },
        { q: "What day is it today?", ans: "It's Monday." },
        { q: "Is she your sister?", ans: "No, she isn't." },
        { q: "How many books do you have?", ans: "I have five books." },
        { q: "What's your favourite colour?", ans: "I like blue." }
      ],
      G5: [
        { q: "Do you like apples?", ans: "Yes, I do." },
        { q: "What does your father do?", ans: "He is a doctor." },
        { q: "Which season do you like best?", ans: "I like summer best." },
        { q: "What do you have on Fridays?", ans: "I have English and maths." },
        { q: "Can you cook?", ans: "No, I can't." },
        { q: "What's your favourite food?", ans: "I like hamburgers." }
      ],
      G6: [
        { q: "How do you go to school?", ans: "I go to school by bus." },
        { q: "Where is the post office?", ans: "It's next to the hospital." },
        { q: "What are your hobbies?", ans: "I like singing and dancing." },
        { q: "What did you do yesterday?", ans: "I visited my grandparents." },
        { q: "How does she feel?", ans: "She feels happy." },
        { q: "What does your uncle do?", ans: "He is a scientist." }
      ]
    };
    const d = pick(dialogs[grade] || dialogs.G3);
    const q = `— ${d.q} — ______`;
    const ans = d.ans;
    const allAnswers = dialogs[grade] ? dialogs[grade].map(d => d.ans) : dialogs.G3.map(d => d.ans);
    const o = opts(ans, () => pick(allAnswers));
    return Q(q, o, grade === "G3" || grade === "G4" ? "基础" : "进阶", `合适的应答是 ${ans}`, "情景交际", { name: "gDialogue", q: d.q, ans }, grade);
  }

  const DIALOGUE_POOLS = {};
  ALL_GRADES.forEach(g => {
    DIALOGUE_POOLS[g] = buildPoolForGrade(g, dialogueBuilder, 110);
  });

  /* ============================================================
   * 6. 阅读理解（各年级 ≥100）
   * ============================================================ */
  function readingBuilder(grade) {
    const passages = {
      G3: [
        { text: "I have a cat. It is white. It likes to eat fish.", q: "I have a dog.", ans: "False" },
        { text: "My name is Mike. I am 8 years old. I like apples.", q: "Mike is 8 years old.", ans: "True" },
        { text: "It is sunny today. Let's go to the park.", q: "It is rainy today.", ans: "False" },
        { text: "I have two books. They are red.", q: "I have three books.", ans: "False" },
        { text: "My mother is a teacher. She works at school.", q: "My mother is a doctor.", ans: "False" }
      ],
      G4: [
        { text: "Tom is 10 years old. He has a dog. The dog is black. Tom likes to play with his dog.", q: "Tom is 10 years old.", ans: "True" },
        { text: "Amy likes apples. She eats an apple every day. She also likes bananas.", q: "Amy likes oranges.", ans: "False" },
        { text: "My school is big and beautiful. There are 20 classrooms. I am in Class 3, Grade 4.", q: "I am in Class 3, Grade 4.", ans: "True" },
        { text: "It is sunny today. Let's go to the park. We can fly kites there.", q: "We can fly kites in the park.", ans: "True" },
        { text: "I get up at 7:00. I go to school at 8:00. I have lunch at 12:00.", q: "I get up at 8:00.", ans: "False" }
      ],
      G5: [
        { text: "My father is a doctor. He works in a hospital. He helps sick people. He is very busy.", q: "My father is a teacher.", ans: "False" },
        { text: "There are four seasons in a year. They are spring, summer, autumn and winter. I like spring best because it's warm and beautiful.", q: "I like winter best.", ans: "False" },
        { text: "I often get up at 6:30. I eat breakfast at 7:00. I go to school at 7:30. I have lunch at school.", q: "I eat breakfast at 7:00.", ans: "True" },
        { text: "We have English, maths and Chinese on Mondays. I like English best because it's interesting.", q: "I like maths best.", ans: "False" },
        { text: "There is a forest near my village. There are many trees and flowers. I can see birds in the trees.", q: "There is a forest near my village.", ans: "True" }
      ],
      G6: [
        { text: "My family went to Beijing last summer. We visited the Great Wall. It was very beautiful. We also ate Beijing duck.", q: "We visited the Great Wall.", ans: "True" },
        { text: "I like to play basketball. I play it every Sunday. I often play with my friends. It's fun.", q: "I play basketball every day.", ans: "False" },
        { text: "My uncle is a scientist. He works in a lab. He is very clever and hard-working.", q: "My uncle is a scientist.", ans: "True" },
        { text: "I went to the zoo yesterday. I saw monkeys, tigers and elephants. I liked the monkeys best.", q: "I liked the elephants best.", ans: "False" },
        { text: "She is going to visit her grandma next week. She will go there by train.", q: "She is going to visit her grandma next week.", ans: "True" }
      ]
    };
    const p = pick(passages[grade] || passages.G3);
    const q = `阅读短文：${p.text}\n判断题：${p.q}`;
    const ans = p.ans;
    const o = opts(ans, () => pick(["True", "False"]));
    return Q(q, o, grade === "G3" || grade === "G4" ? "基础" : "进阶", p.ans === "True" ? "短文提到该信息" : "短文未提到该信息", "阅读理解", { name: "gReading", text: p.text, q: p.q }, grade);
  }

  const READING_POOLS = {};
  ALL_GRADES.forEach(g => {
    READING_POOLS[g] = buildPoolForGrade(g, readingBuilder, 110);
  });

  /* ============================================================
   * 7. 时态判断（G4-G6 ≥100，G3 简单版）
   * ============================================================ */
  function tenseBuilder(grade) {
    const items = grade === "G3" ? [
      { subj: "I", base: "am", correct: "am", tense: "现在时" },
      { subj: "She", base: "is", correct: "is", tense: "现在时" },
      { subj: "They", base: "are", correct: "are", tense: "现在时" }
    ] : grade === "G4" ? [
      { subj: "He", base: "go", correct: "goes", tense: "一般现在时" },
      { subj: "She", base: "eat", correct: "eats", tense: "一般现在时" },
      { subj: "I", base: "play", correct: "played", tense: "一般过去时" },
      { subj: "We", base: "are", correct: "are", tense: "现在进行时" }
    ] : grade === "G5" ? [
      { subj: "My mother", base: "cook", correct: "cooks", tense: "一般现在时" },
      { subj: "The children", base: "play", correct: "played", tense: "一般过去时" },
      { subj: "I", base: "study", correct: "studied", tense: "一般过去时" },
      { subj: "She", base: "swim", correct: "swims", tense: "一般现在时" },
      { subj: "He", base: "read", correct: "reads", tense: "一般现在时" }
    ] : [
      { subj: "They", base: "go", correct: "went", tense: "一般过去时" },
      { subj: "She", base: "have", correct: "had", tense: "一般过去时" },
      { subj: "I", base: "see", correct: "saw", tense: "一般过去时" },
      { subj: "We", base: "eat", correct: "ate", tense: "一般过去时" },
      { subj: "He", base: "buy", correct: "bought", tense: "一般过去时" }
    ];
    const item = pick(items);
    const q = `选择正确的动词形式：${item.subj} ______ ${pick(["to school", "football", "happy", "every day", "yesterday", "now"])}.`;
    const ans = item.correct;
    const o = opts(ans, () => pick([item.base, item.base + "s", item.base + "ed", item.base + "ing"]));
    return Q(q, o, grade === "G3" ? "基础" : "进阶", `此处需用 ${item.tense}，正确形式是 ${item.correct}`, "时态判断", { name: "gTense", subj: item.subj, correct: item.correct }, grade);
  }

  const TENSE_POOLS = {};
  ALL_GRADES.forEach(g => {
    TENSE_POOLS[g] = buildPoolForGrade(g, tenseBuilder, 110);
  });

  /* ============================================================
   * 8-10. 代词/介词/句型转换（简化，各年级 ≥100）
   * ============================================================ */
  function pronounBuilder(grade) {
    const pairs = grade === "G3" ? [{ subj: "I", obj: "me", poss: "my" }, { subj: "You", obj: "you", poss: "your" }] :
                   grade === "G4" ? [{ subj: "He", obj: "him", poss: "his" }, { subj: "She", obj: "her", poss: "her" }] :
                   [{ subj: "We", obj: "us", poss: "our" }, { subj: "They", obj: "them", poss: "their" }, { subj: "I", obj: "me", poss: "my" }];
    const p = pick(pairs);
    const type = grade === "G3" ? rnd(0, 1) : rnd(0, 2);
    const map = ["主格", "宾格", "形代"];
    const val = [p.subj, p.obj, p.poss][type];
    const q = `用适当的代词填空（${map[type]}）：_____ is a student.`;
    const ans = val;
    const o = opts(ans, () => pick([p.subj, p.obj, p.poss]));
    return Q(q, o, grade === "G3" ? "基础" : "进阶", `此处应用 ${map[type]} ${val}`, "代词用法", { name: "gPronoun", p, type }, grade);
  }

  const PRONOUN_POOLS = {};
  ALL_GRADES.forEach(g => {
    PRONOUN_POOLS[g] = buildPoolForGrade(g, pronounBuilder, 110);
  });

  function prepositionBuilder(grade) {
    const preps = grade === "G3" ? ["in", "on", "at"] :
                  grade === "G4" ? ["in", "on", "at", "under", "behind"] :
                  ["in", "on", "at", "under", "behind", "next to", "in front of", "between"];
    const prep = pick(preps);
    const objects = grade === "G3" ? ["the desk", "the box", "the table"] :
                    grade === "G4" ? ["the bed", "the floor", "the chair"] :
                    ["the room", "the window", "the door", "the wall"];
    const q = `I put my bag ______ ${pick(objects)}.`;
    const ans = prep;
    const o = opts(ans, () => pick(preps));
    return Q(q, o, grade === "G3" ? "基础" : "进阶", `介词 ${prep} 表示位置`, "介词辨析", { name: "gPreposition", prep }, grade);
  }

  const PREPOSITION_POOLS = {};
  ALL_GRADES.forEach(g => {
    PREPOSITION_POOLS[g] = buildPoolForGrade(g, prepositionBuilder, 110);
  });

  function questionBuilder(grade) {
    const sentences = grade === "G3" ? [
      { orig: "I like apples.", neg: "I don't like apples.", yesno: "Do you like apples?" },
      { orig: "She is a teacher.", neg: "She isn't a teacher.", yesno: "Is she a teacher?" }
    ] : grade === "G4" ? [
      { orig: "They are playing.", neg: "They aren't playing.", yesno: "Are they playing?" },
      { orig: "He has a pen.", neg: "He doesn't have a pen.", yesno: "Does he have a pen?" },
      { orig: "I can swim.", neg: "I can't swim.", yesno: "Can you swim?" }
    ] : grade === "G5" ? [
      { orig: "We go to school every day.", neg: "We don't go to school every day.", yesno: "Do you go to school every day?" },
      { orig: "She likes apples.", neg: "She doesn't like apples.", yesno: "Does she like apples?" },
      { orig: "I am eating lunch.", neg: "I am not eating lunch.", yesno: "Are you eating lunch?" }
    ] : [
      { orig: "I went to the park.", neg: "I didn't go to the park.", yesno: "Did you go to the park?" },
      { orig: "She ate an apple.", neg: "She didn't eat an apple.", yesno: "Did she eat an apple?" },
      { orig: "They were happy.", neg: "They weren't happy.", yesno: "Were they happy?" }
    ];
    const s = pick(sentences);
    const type = rnd(0, 2);
    const qs = ["改为否定句", "改为一般疑问句", "改为特殊疑问句（对划线部分提问）"];
    const ans = [s.neg, s.yesno, s.yesno][type];
    const q = `${s.orig} ${qs[type]}`;
    const o = opts(ans, () => pick([s.neg, s.yesno, s.orig]));
    return Q(q, o, grade === "G3" || grade === "G4" ? "基础" : "进阶", `正确转换是 ${ans}`, "句型转换", { name: "gQuestion", orig: s.orig, ans }, grade);
  }

  const QUESTION_POOLS = {};
  ALL_GRADES.forEach(g => {
    QUESTION_POOLS[g] = buildPoolForGrade(g, questionBuilder, 110);
  });

  /* ============================================================
   * 配图（增加年级标识）
   * ============================================================ */
  function figWrapper(inner, grade) {
    const gradeLabel = GRADE_NAMES[grade] || grade;
    return S(320, 120, inner + `<text x="290" y="114" font-size="10" text-anchor="end" fill="${K.sub}">${gradeLabel}</text>`, 320);
  }

  window.Fig.gWord = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">📚 ${p.topic}</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.en} → ${p.zh}</text>`, p.grade);
  };
  window.Fig.gSpelling = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">✏️ 补全字母</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.en}（空缺第 ${p.pos + 1} 位）</text>`, p.grade);
  };
  window.Fig.gGrammar = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">📖 语法点</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.subj || p.word || p.prep || "..."}</text>`, p.grade);
  };
  window.Fig.gSentence = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">🧩 连词成句</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.shuffled && p.shuffled.join(" ").slice(0, 40)}</text>`, p.grade);
  };
  window.Fig.gDialogue = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">💬 情景对话</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.q}</text>`, p.grade);
  };
  window.Fig.gReading = function (p) {
    return figWrapper(`<text x="160" y="40" font-size="15" text-anchor="middle" fill="${K.ink}">📄 阅读理解</text><text x="160" y="70" font-size="12" text-anchor="middle" fill="${K.sub}">${(p.text || "").slice(0, 40)}...</text><text x="160" y="96" font-size="12" text-anchor="middle" fill="${K.pri}">${p.q}</text>`, p.grade);
  };
  window.Fig.gTense = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">⏳ 时态判断</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.subj} → ${p.correct}</text>`, p.grade);
  };
  window.Fig.gPronoun = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">🔤 代词填空</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.p && p.p.subj} / ${p.p && p.p.obj}</text>`, p.grade);
  };
  window.Fig.gPreposition = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">📍 介词选择</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.prep}</text>`, p.grade);
  };
  window.Fig.gQuestion = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">🔄 句型转换</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.orig}</text>`, p.grade);
  };

  /* ============================================================
   * 注册 + 不重复抽取器（支持年级筛选）
   * ============================================================ */
  const POOLS = {
    word: WORD_POOLS,
    spelling: SPELLING_POOLS,
    grammar: GRAMMAR_POOLS,
    sentence: SENTENCE_POOLS,
    dialogue: DIALOGUE_POOLS,
    reading: READING_POOLS,
    tense: TENSE_POOLS,
    pronoun: PRONOUN_POOLS,
    preposition: PREPOSITION_POOLS,
    question: QUESTION_POOLS
  };

  const usedMap = {};

  function getQGen(id) {
    const gradePools = POOLS[id];
    if (!gradePools) return null;

    return function (n, grade) {
      const targetGrade = grade || "G3";
      const pool = gradePools[targetGrade] || gradePools.G3;
      const key = id + "_" + targetGrade;

      if (!usedMap[key]) usedMap[key] = [];
      const used = usedMap[key];

      if (used.length >= pool.length) {
        used.length = 0;
      }

      const nCount = n || 6;
      const available = pool.filter((_, i) => !used.includes(i));

      if (available.length < nCount) {
        used.length = 0;
        const poolCopy = shuffle([...pool]);
        const result = [];
        for (let i = 0; i < nCount; i++) {
          const idx = i % poolCopy.length;
          result.push(poolCopy[idx]);
          used.push(pool.indexOf(poolCopy[idx]));
        }
        return result;
      }

      const shuffledAvail = shuffle(available);
      const picked = shuffledAvail.slice(0, nCount);
      picked.forEach(item => {
        const idx = pool.indexOf(item);
        if (idx !== -1) used.push(idx);
      });
      return picked;
    };
  }

  const GEN = {};
  Object.keys(POOLS).forEach(id => {
    GEN[id] = getQGen(id);
  });

  if (window.TECHNIQUES) {
    window.TECHNIQUES.forEach(t => {
      if (GEN[t.id]) {
        t.qgen = GEN[t.id];
      }
    });
  }
  window.QGEN_READY = true;
})();