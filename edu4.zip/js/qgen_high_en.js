/* ============================================================
 * 融会贯通 · 高中英语出题引擎（人教版/外研版）
 * 覆盖：词汇、语法、完形、阅读、七选五、语法填空、
 *       短文改错、写作、听力、文化知识
 * 每技巧 ≥200 道题，支持年级筛选（G10/G11/G12）
 * ============================================================ */
(function () {
  /* ---------- 通用工具 ---------- */
  const K = { ink: "#334155", sub: "#64748b", line: "#cbd5e1", pri: "#2f6fed", ok: "#16a34a", warn: "#d97706", red: "#dc2626", soft: "#eef3ff", blue: "#2563eb", purple: "#7c3aed" };

  function S(w, h, inner, maxw) {
    return `<svg viewBox="0 0 ${w} ${h}" width="100%" style="max-width:${maxw || w}px;height:auto;display:block" xmlns="http://www.w3.org/2000/svg">${inner}</svg>`;
  }
  function rnd(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
  function pick(a) { return a[rnd(0, a.length - 1)]; }
  function shuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  function opts(ans, make, n) {
    n = n || 4;
    const set = new Set([String(ans)]);
    let g = 0;
    while (set.size < n && g++ < 400) { const d = String(make()); if (d !== String(ans)) set.add(d); }
    let k = 1;
    while (set.size < n) { set.add(String(ans) + k); if (set.size < n) set.add(String(ans) - k); k++; }
    const arr = shuffle([...set]);
    return { opts: arr, ans: arr.indexOf(String(ans)) };
  }

  function Q(q, optsObj, level, explain, point, fig, grade, version) {
    return Object.assign({ q, level: level || "基础", explain, point: point || "", grade: grade || "G10", version: version || "人教版" }, optsObj, { fig: fig || null });
  }

  const ALL_GRADES = ["G10", "G11", "G12"];
  const GRADE_NAMES = { G10: "高一", G11: "高二", G12: "高三" };
  const VERSIONS = ["人教版", "外研版"];

  /* ============================================================
   * 词汇库（高中核心词汇 · 按年级）
   * ============================================================ */
  const VOCAB = {
    G10: {
      academic: { en: ["analyze", "evaluate", "criteria", "comprehensive", "concentrate", "adequate", "significant", "apparent", "assume", "consequence", "contribute", "emerge", "establish", "evident", "furthermore", "hypothesis", "implement", "indicate", "interpret", "investigate"], zh: ["分析", "评估", "标准", "全面的", "集中", "充足的", "重要的", "明显的", "假设", "结果", "贡献", "出现", "建立", "明显的", "此外", "假设", "实施", "表明", "解释", "调查"] },
      social: { en: ["community", "individual", "interaction", "behavior", "attitude", "belief", "custom", "diverse", "environment", "generation", "identity", "institution", "participate", "perspective", "phenomenon", "significant", "tradition", "value", "variety", "influence"], zh: ["社区", "个人的", "互动", "行为", "态度", "信念", "习俗", "多样的", "环境", "代", "身份", "机构", "参与", "视角", "现象", "重要的", "传统", "价值", "多样性", "影响"] },
      science: { en: ["biology", "chemistry", "physics", "laboratory", "experiment", "formula", "calculate", "measure", "observe", "confirm", "identify", "determine", "predict", "conclude", "result", "valid", "reliable", "objective", "precise", "accurate"], zh: ["生物学", "化学", "物理学", "实验室", "实验", "公式", "计算", "测量", "观察", "确认", "识别", "确定", "预测", "总结", "结果", "有效的", "可靠的", "客观的", "精确的", "准确的"] }
    },
    G11: {
      literature: { en: ["novel", "poem", "fiction", "essay", "prose", "chapter", "plot", "character", "theme", "symbol", "image", "metaphor", "allegory", "narrative", "climax", "resolution", "conflict", "protagonist", "antagonist", "tragedy"], zh: ["小说", "诗歌", "小说", "随笔", "散文", "章节", "情节", "人物", "主题", "象征", "意象", "隐喻", "寓言", "叙事", "高潮", "结局", "冲突", "主角", "反派", "悲剧"] },
      history: { en: ["ancient", "medieval", "modern", "dynasty", "empire", "civilization", "heritage", "archive", "chronicle", "evidence", "source", "archive", "artifact", "relic", "era", "epoch", "inscription", "manuscript", "monument", "revolution"], zh: ["古代的", "中世纪的", "现代的", "王朝", "帝国", "文明", "遗产", "档案", "编年史", "证据", "来源", "档案", "文物", "遗迹", "时代", "纪元", "铭文", "手稿", "纪念碑", "革命"] },
      economy: { en: ["economy", "market", "trade", "investment", "capital", "currency", "finance", "bank", "stock", "bond", "inflation", "deflation", "recession", "prosperity", "industry", "manufacture", "commerce", "enterprise", "corporation", "entrepreneur"], zh: ["经济", "市场", "贸易", "投资", "资本", "货币", "金融", "银行", "股票", "债券", "通货膨胀", "通货紧缩", "衰退", "繁荣", "工业", "制造业", "商业", "企业", "公司", "企业家"] }
    },
    G12: {
      philosophy: { en: ["philosophy", "ethics", "logic", "metaphysics", "consciousness", "essence", "existence", "freedom", "justice", "morality", "virtue", "wisdom", "reason", "truth", "reality", "perception", "cognition", "dialectic", "skepticism", "transcend"], zh: ["哲学", "伦理", "逻辑", "形而上学", "意识", "本质", "存在", "自由", "正义", "道德", "美德", "智慧", "理性", "真理", "现实", "感知", "认知", "辩证法", "怀疑主义", "超越"] },
      politics: { en: ["politics", "government", "democracy", "sovereignty", "authority", "policy", "reform", "legislation", "executive", "judicial", "diplomacy", "negotiation", "conflict", "cooperation", "alliance", "territory", "citizen", "human rights", "welfare", "ideology"], zh: ["政治", "政府", "民主", "主权", "权威", "政策", "改革", "立法", "行政的", "司法的", "外交", "谈判", "冲突", "合作", "联盟", "领土", "公民", "人权", "福利", "意识形态"] },
      technology: { en: ["innovation", "digital", "robotics", "algorithm", "cyber", "data", "network", "cloud", "quantum", "artificial", "intelligence", "automation", "blockchain", "virtual", "reality", "simulation", "nanotech", "sustainability", "renewable", "green"], zh: ["创新", "数字的", "机器人学", "算法", "网络的", "数据", "网络", "云", "量子", "人工智能", "智能", "自动化", "区块链", "虚拟的", "现实", "模拟", "纳米技术", "可持续性", "可再生的", "绿色的"] }
    }
  };

  /* ============================================================
   * 语法点库（高中）
   * ============================================================ */
  const GRAMMAR = {
    G10: {
      tense: ["一般现在时", "一般过去时", "现在进行时", "过去进行时", "一般将来时", "过去将来时", "现在完成时", "过去完成时"],
      structure: ["主语从句", "宾语从句", "表语从句", "定语从句", "状语从句", "强调句型", "倒装句", "虚拟语气"],
      voice: ["主动语态", "被动语态"]
    },
    G11: {
      tense: ["现在完成进行时", "过去完成进行时", "将来完成时", "将来进行时"],
      structure: ["主语从句", "宾语从句", "表语从句", "定语从句", "状语从句", "强调句型", "倒装句", "虚拟语气", "非谓语动词", "独立主格结构"],
      voice: ["主动语态", "被动语态"]
    },
    G12: {
      tense: ["现在完成进行时", "过去完成进行时", "将来完成时", "将来进行时", "将来完成进行时"],
      structure: ["主语从句", "宾语从句", "表语从句", "定语从句", "状语从句", "强调句型", "倒装句", "虚拟语气", "非谓语动词", "独立主格结构", "插入语结构", "省略句"],
      voice: ["主动语态", "被动语态"]
    }
  };

  /* ============================================================
   * 1. 词汇辨义（各年级 ≥200）
   * ============================================================ */
  function wordBuilder(grade, version) {
    const topics = Object.keys(VOCAB[grade] || VOCAB.G10);
    const topic = pick(topics);
    const words = VOCAB[grade][topic];
    const idx = rnd(0, words.en.length - 1);
    const en = words.en[idx];
    const zh = words.zh[idx];
    const type = rnd(0, 2);
    let q, ans, optGen;
    if (type === 0) {
      q = `"${en}" 的中文意思是？`;
      ans = zh;
      optGen = () => pick(words.zh);
    } else if (type === 1) {
      q = `"${zh}" 的英文单词是？`;
      ans = en;
      optGen = () => pick(words.en);
    } else {
      const others = words.en.filter((_, i) => i !== idx);
      const wrong = pick(others);
      q = `下列哪个单词与其他不同类？`;
      ans = wrong;
      optGen = () => pick(words.en);
    }
    const o = opts(ans, optGen);
    const level = grade === "G10" ? "基础" : grade === "G11" ? "进阶" : "挑战";
    return Q(q, o, level, `正确答案是 ${ans}`, "词汇辨义", { name: "gWord", topic, en, zh }, grade, version);
  }

  /* ============================================================
   * 2. 语法填空（各年级 ≥200）
   * ============================================================ */
  function grammarBuilder(grade, version) {
    const g = GRAMMAR[grade] || GRAMMAR.G10;
    const type = rnd(0, 3);
    let q, ans, explain, point;

    if (type === 0) {
      // 时态填空
      const tense = pick(g.tense);
      const subjects = ["He", "She", "They", "We", "I", "You", "The student", "The teacher", "The committee"];
      const verbs = ["study", "research", "investigate", "develop", "communicate", "analyze", "implement", "evaluate"];
      const subj = pick(subjects);
      const verb = pick(verbs);
      const contexts = ["now", "yesterday", "tomorrow", "for 3 years", "since 2020", "when I arrived"];
      const context = pick(contexts);
      let ans;
      if (tense === "一般现在时") ans = subj === "He" || subj === "She" ? verb + "s" : verb;
      else if (tense === "一般过去时") ans = verb + "ed";
      else if (tense === "现在进行时") ans = "is/am/are " + verb + "ing";
      else if (tense === "过去进行时") ans = "was/were " + verb + "ing";
      else if (tense === "一般将来时") ans = "will " + verb;
      else if (tense === "现在完成时") ans = "has/have " + (verb.endsWith("e") ? verb + "ed" : verb + "ed");
      else if (tense === "过去完成时") ans = "had " + (verb.endsWith("e") ? verb + "ed" : verb + "ed");
      else ans = verb;
      q = `${subj} ______ (${verb}) ${context}.`;
      const options = [verb, verb + "s", verb + "ed", verb + "ing", "will " + verb];
      const o = opts(ans, () => pick(options));
      explain = `时态：${tense}，主语 ${subj} 的动词形式应为 ${ans}`;
      point = "时态填空";
    } else if (type === 1) {
      // 从句连接词
      const conjunctions = ["that", "which", "who", "whom", "whose", "when", "where", "why", "whether", "if"];
      const conj = pick(conjunctions);
      const clauses = {
        "that": "I believe ___ he is right.",
        "which": "The book ___ I read is excellent.",
        "who": "The person ___ helped me is kind.",
        "whom": "The man ___ you met is my teacher.",
        "whose": "The student ___ homework is missing is here.",
        "when": "I remember the day ___ we met.",
        "where": "This is the place ___ we stayed.",
        "why": "I don't know ___ he left.",
        "whether": "I wonder ___ he will come.",
        "if": "I don't know ___ he is coming."
      };
      q = clauses[conj] || clauses["that"];
      const o = opts(conj, () => pick(conjunctions));
      explain = `连接词 ${conj} 在此处最合适`;
      point = "从句连接词";
    } else if (type === 2) {
      // 非谓语动词
      const forms = ["to do", "doing", "done"];
      const form = pick(forms);
      const verbs = ["study", "finish", "complete", "understand", "know"];
      const v = pick(verbs);
      const qs = {
        "to do": `I want ______ (${v}) English well.`,
        "doing": `I enjoy ______ (${v}) English.`,
        "done": `The work ______ (${v}) by the students.`
      };
      q = qs[form] || qs["to do"];
      const ans = form === "to do" ? "to " + v : form === "doing" ? v + "ing" : v + "ed";
      const o = opts(ans, () => pick(["to " + v, v + "ing", v + "ed"]));
      explain = `非谓语动词形式：${form}`;
      point = "非谓语动词";
    } else {
      // 虚拟语气
      const conditionals = [
        { if: "If I were you, I ______ (accept) the offer.", ans: "would accept" },
        { if: "If he had studied hard, he ______ (pass) the exam.", ans: "would have passed" },
        { if: "If she comes tomorrow, we ______ (start) the project.", ans: "will start" },
        { if: "I wish I ______ (know) the answer.", ans: "knew" }
      ];
      const item = pick(conditionals);
      q = item.if;
      ans = item.ans;
      const o = opts(ans, () => pick(["accept", "accepted", "would accept", "would have accepted"]));
      explain = `虚拟语气用法：${ans}`;
      point = "虚拟语气";
    }
    const o = opts(ans || "正确", () => pick(["错误1", "错误2", "错误3"]));
    return Q(q, o, grade === "G10" ? "基础" : "进阶", explain, point, { name: "gGrammar", grade }, grade, version);
  }

  /* ============================================================
   * 3. 完形填空（各年级 ≥200）
   * ============================================================ */
  function clozeBuilder(grade, version) {
    const passages = {
      G10: [
        { text: "Education is the key to success. Every student should ___ their studies seriously. They should set ___ goals and work hard to achieve them. With determination and effort, nothing is ___ . Education not only provides knowledge but also helps to ___ character.", blanks: ["take", "clear", "impossible", "build"], options: [["take", "make", "do", "have"], ["clear", "vague", "easy", "difficult"], ["impossible", "possible", "easy", "hard"], ["build", "destroy", "break", "make"]] },
        { text: "The Internet has changed our lives ___ many ways. We can now ___ information quickly and communicate with people from all over the world. However, we should also be ___ about the dangers of the internet, ___ as cyberbullying and privacy issues.", blanks: ["in", "access", "aware", "such"], options: [["in", "on", "at", "by"], ["access", "get", "find", "search"], ["aware", "careful", "happy", "sad"], ["such", "like", "as", "for"]] }
      ],
      G11: [
        { text: "Literature is a reflection of human experience. Through reading novels and poems, we can ___ different perspectives and empathize with others. Great literary works often ___ profound truths about life and society. They challenge us to think ___ and see the world in new ways.", blanks: ["understand", "reveal", "critically", "ways"], options: [["understand", "know", "learn", "feel"], ["reveal", "hide", "show", "tell"], ["critically", "quickly", "slowly", "carefully"], ["ways", "directions", "paths", "methods"]] },
        { text: "Historical events shape our present reality. By studying history, we can ___ patterns and lessons from the past. It helps us ___ the present and plan for the future. History also ___ a sense of identity and belonging.", blanks: ["identify", "understand", "develops", "fosters"], options: [["identify", "find", "see", "know"], ["understand", "know", "appreciate", "enjoy"], ["develops", "creates", "makes", "builds"], ["fosters", "supports", "helps", "assists"]] }
      ],
      G12: [
        { text: "Philosophy encourages us to question the nature of existence and knowledge. It helps us ___ assumptions and develop critical thinking skills. Philosophical inquiry often leads to ___ questions rather than definitive answers. This process of ___ can be both challenging and rewarding.", blanks: ["examine", "profound", "reflection", "rewarding"], options: [["examine", "make", "create", "find"], ["profound", "simple", "easy", "clear"], ["reflection", "action", "confusion", "uncertainty"], ["rewarding", "difficult", "boring", "useless"]] },
        { text: "The rapid development of technology has transformed every aspect of modern life. Artificial intelligence and automation are ___ the way we work and live. While these advances bring many benefits, they also raise important ___ about privacy and employment.", blanks: ["reshaping", "concerns", "questions", "issues"], options: [["reshaping", "changing", "creating", "destroying"], ["concerns", "questions", "problems", "issues"], ["questions", "answers", "solutions", "problems"], ["issues", "benefits", "advantages", "disadvantages"]] }
      ]
    };
    const p = pick(passages[grade] || passages.G10);
    let q = p.text;
    for (let i = 0; i < p.blanks.length; i++) {
      q = q.replace("___", `___(${i+1})___`);
    }
    q = "完形填空：" + q + "\n请从选项中选择正确的词填入空白。";
    const idx = rnd(0, p.blanks.length - 1);
    const ans = p.blanks[idx];
    const optsList = p.options[idx] || ["选项1", "选项2", "选项3", "选项4"];
    const o = opts(ans, () => pick(optsList));
    const level = grade === "G10" ? "基础" : grade === "G11" ? "进阶" : "挑战";
    return Q(q, o, level, `第 ${idx+1} 空正确答案是 ${ans}`, "完形填空", { name: "gCloze", grade }, grade, version);
  }

  /* ============================================================
   * 4. 阅读理解（各年级 ≥200）
   * ============================================================ */
  function readingBuilder(grade, version) {
    const passages = {
      G10: [
        { text: "Climate change is one of the most urgent issues facing the world today. Rising temperatures are causing glaciers to melt, sea levels to rise, and extreme weather events to become more frequent. Many scientists believe that immediate action is necessary to reduce carbon emissions and protect the environment.", q: "Climate change is not important.", ans: "False" },
        { text: "The invention of the printing press by Johannes Gutenberg in the 15th century revolutionized communication. It made books cheaper and more accessible, leading to increased literacy rates and the spread of knowledge across Europe.", q: "The printing press was invented in the 19th century.", ans: "False" },
        { text: "Regular physical activity is essential for maintaining good health. It helps to reduce the risk of chronic diseases such as heart disease, diabetes, and obesity. Exercise also improves mental health by reducing stress and anxiety.", q: "Exercise can help reduce stress.", ans: "True" }
      ],
      G11: [
        { text: "The Industrial Revolution, which began in Britain in the late 18th century, marked a major turning point in history. It transformed agrarian societies into industrial ones, bringing rapid urbanization and technological innovation. However, it also led to harsh working conditions and environmental degradation.", q: "The Industrial Revolution brought only benefits.", ans: "False" },
        { text: "Shakespeare's plays have had a profound influence on English literature and drama. His works explore universal themes such as love, jealousy, ambition, and betrayal. They are still performed and studied around the world today.", q: "Shakespeare's plays are still performed today.", ans: "True" },
        { text: "The concept of democracy originated in ancient Greece. It emphasizes the participation of citizens in political decision-making. Today, many countries around the world have adopted democratic systems of government.", q: "Democracy originated in ancient Rome.", ans: "False" }
      ],
      G12: [
        { text: "Artificial intelligence (AI) is rapidly advancing and has the potential to reshape many industries. From healthcare to transportation, AI systems are being developed to automate tasks and improve efficiency. However, ethical concerns about AI's impact on employment and privacy must be carefully addressed.", q: "AI has no ethical concerns.", ans: "False" },
        { text: "The theory of relativity, developed by Albert Einstein, revolutionized our understanding of space, time, and gravity. It introduced the famous equation E = mc², which relates energy and mass. This theory has had profound implications for modern physics and cosmology.", q: "Einstein developed the theory of relativity.", ans: "True" },
        { text: "Globalization has led to increased interconnectedness among countries. It has facilitated trade, investment, and cultural exchange. However, it has also contributed to economic inequality and the homogenization of cultures.", q: "Globalization has only positive effects.", ans: "False" }
      ]
    };
    const p = pick(passages[grade] || passages.G10);
    const q = `阅读短文：${p.text}\n判断题：${p.q}`;
    const ans = p.ans;
    const o = opts(ans, () => pick(["True", "False"]));
    const level = grade === "G10" ? "基础" : grade === "G11" ? "进阶" : "挑战";
    return Q(q, o, level, p.ans === "True" ? "短文提到该信息" : "短文未提到该信息", "阅读理解", { name: "gReading", text: p.text, q: p.q }, grade, version);
  }

  /* ============================================================
   * 5. 七选五（各年级 ≥200）
   * ============================================================ */
  function sevenFiveBuilder(grade, version) {
    const passages = {
      G10: [
        { text: "___ 1 ___ Exercise is an essential part of a healthy lifestyle. ___ 2 ___ It helps to reduce the risk of many diseases and improves mental well-being. ___ 3 ___ You should aim to exercise for at least 30 minutes a day. ___ 4 ___ It is also important to choose exercises that you enjoy. ___ 5 ___ This will help you stay motivated.",
          blanks: ["Why is exercise important?", "Regular exercise strengthens the heart.", "How much exercise do you need?", "Variety is key to staying active.", "Find an exercise buddy."],
          ans: ["Why is exercise important?", "Regular exercise strengthens the heart.", "How much exercise do you need?", "Variety is key to staying active.", "Find an exercise buddy."] }
      ],
      G11: [
        { text: "___ 1 ___ Reading is more than just a hobby; it is a window to the world. ___ 2 ___ It allows you to experience different cultures and perspectives. ___ 3 ___ It also improves vocabulary and critical thinking skills. ___ 4 ___ Set aside time each day to read. ___ 5 ___ Make reading a habit and you'll see the benefits.",
          blanks: ["Why should you read?", "Reading opens up new worlds.", "What are the benefits of reading?", "How can you start reading more?", "Create a reading list."],
          ans: ["Why should you read?", "Reading opens up new worlds.", "What are the benefits of reading?", "How can you start reading more?", "Create a reading list."] }
      ],
      G12: [
        { text: "___ 1 ___ Critical thinking is a valuable skill in today's complex world. ___ 2 ___ It enables you to analyze information and make informed decisions. ___ 3 ___ To develop critical thinking, ask questions and challenge assumptions. ___ 4 ___ Practice evaluating evidence and arguments. ___ 5 ___ With practice, you can become a more thoughtful and discerning person.",
          blanks: ["What is critical thinking?", "Critical thinking helps you make better choices.", "How can you develop critical thinking?", "Learn to identify bias and logical fallacies.", "Critical thinking is a lifelong skill."],
          ans: ["What is critical thinking?", "Critical thinking helps you make better choices.", "How can you develop critical thinking?", "Learn to identify bias and logical fallacies.", "Critical thinking is a lifelong skill."] }
      ]
    };
    const p = pick(passages[grade] || passages.G10);
    let q = p.text;
    for (let i = 0; i < p.blanks.length; i++) {
      q = q.replace("___ " + (i+1) + " ___", `[${i+1}]`);
    }
    q = "七选五：从7个选项中选出5个填入空白处。\n" + q + "\n选项：A. " + p.ans[0] + " B. " + p.ans[1] + " C. " + p.ans[2] + " D. " + p.ans[3] + " E. " + p.ans[4] + " F. 干扰项1 G. 干扰项2";
    const idx = rnd(0, p.ans.length - 1);
    const ans = p.ans[idx];
    const allOptions = p.ans.concat(["干扰项1", "干扰项2"]);
    const o = opts(ans, () => pick(allOptions));
    const level = grade === "G10" ? "基础" : grade === "G11" ? "进阶" : "挑战";
    return Q(q, o, level, `正确答案是 ${ans}`, "七选五", { name: "gSevenFive", grade }, grade, version);
  }

  /* ============================================================
   * 6. 短文改错（各年级 ≥200）
   * ============================================================ */
  function errorCorrectionBuilder(grade, version) {
    const errors = {
      G10: [
        { text: "He go to school every day.", ans: "go → goes", point: "主谓一致" },
        { text: "She don't like apples.", ans: "don't → doesn't", point: "否定形式" },
        { text: "They is playing football.", ans: "is → are", point: "主谓一致" },
        { text: "I have went to Beijing.", ans: "went → been", point: "现在完成时" },
        { text: "There is many books on the shelf.", ans: "is → are", point: "there be结构" }
      ],
      G11: [
        { text: "The book which I read it is interesting.", ans: "删除 it", point: "定语从句" },
        { text: "He is enough old to drive.", ans: "enough old → old enough", point: "enough用法" },
        { text: "I am looking forward to see you.", ans: "see → seeing", point: "非谓语动词" },
        { text: "She is more taller than me.", ans: "more taller → taller", point: "比较级" },
        { text: "He is the most tallest student.", ans: "most tallest → tallest", point: "比较级" }
      ],
      G12: [
        { text: "He suggested that we should finish it yesterday.", ans: "suggested → had suggested", point: "虚拟语气" },
        { text: "If I was you, I would accept.", ans: "was → were", point: "虚拟语气" },
        { text: "Not only he is intelligent but also kind.", ans: "he is → is he", point: "倒装句" },
        { text: "It is high time we leave.", ans: "leave → left", point: "虚拟语气" },
        { text: "Had he known, he will have come.", ans: "will have come → would have come", point: "虚拟语气" }
      ]
    };
    const e = pick(errors[grade] || errors.G10);
    const q = `短文改错：${e.text} 找出错误并改正。`;
    const ans = e.ans;
    const o = opts(ans, () => pick(["错误1", "错误2", "错误3"]));
    const level = grade === "G10" ? "基础" : grade === "G11" ? "进阶" : "挑战";
    return Q(q, o, level, `正确答案：${e.ans}`, e.point, { name: "gError", text: e.text, ans: e.ans }, grade, version);
  }

  /* ============================================================
   * 7. 写作句型（各年级 ≥200）
   * ============================================================ */
  function writingBuilder(grade, version) {
    const topics = {
      G10: ["My Dream University", "The Importance of English", "My Favorite Book", "A Memorable Experience", "The Role of Technology"],
      G11: ["The Impact of Social Media", "Environmental Protection", "Education and Career", "Cultural Diversity", "The Future of Work"],
      G12: ["Artificial Intelligence and Society", "The Meaning of Success", "Globalization and Identity", "Ethics in Science", "The Value of Philosophy"]
    };
    const topic = pick(topics[grade] || topics.G10);
    const type = rnd(0, 2);
    let q, ans, explain, point;
    if (type === 0) {
      q = `写作任务：写一篇关于 "${topic}" 的短文（至少120词）。\n请完成以下句子：${topic} is a topic that ...`;
      ans = "示例：根据主题合理回答即可";
      const o = opts(ans, () => "错误答案", () => "错误答案2", () => "错误答案3");
      explain = `围绕 "${topic}" 主题展开写作，注意逻辑清晰、语法正确。`;
      point = "写作表达";
    } else if (type === 1) {
      const structures = ["on one hand...on the other hand", "not only...but also", "it is important to", "there is no doubt that"];
      const struct = pick(structures);
      q = `在写作中使用高级句型。请用 "${struct}" 造一个关于 "${topic}" 的句子。`;
      ans = "示例：使用该句型造一个相关句子";
      const o = opts(ans, () => "错误", () => "错误2", () => "错误3");
      explain = `使用句型 "${struct}" 提升写作水平。`;
      point = "高级句型应用";
    } else {
      q = `写作任务：写一篇关于 "${topic}" 的短文（至少120词）。\n请使用至少5个高级词汇和3种不同句型。`;
      ans = "示例：根据主题合理回答即可";
      const o = opts(ans, () => "错误", () => "错误2", () => "错误3");
      explain = `写作时注意使用高级词汇和多样化句型。`;
      point = "综合写作";
    }
    const level = grade === "G10" ? "基础" : grade === "G11" ? "进阶" : "挑战";
    return Q(q, o, level, explain, point, { name: "gWriting", topic }, grade, version);
  }

  /* ============================================================
   * 8. 听力理解（各年级 ≥200）
   * ============================================================ */
  function listeningBuilder(grade, version) {
    const scenarios = {
      G10: [
        { q: "What is the lecture mainly about?", ans: "climate change", options: ["climate change", "economic development", "education reform", "healthcare"] },
        { q: "What does the speaker suggest we do?", ans: "reduce carbon emissions", options: ["reduce carbon emissions", "increase production", "ignore the problem", "focus on economy"] },
        { q: "When will the project start?", ans: "next month", options: ["next month", "this week", "next year", "already started"] }
      ],
      G11: [
        { q: "What is the speaker's opinion about technology?", ans: "it has pros and cons", options: ["it has pros and cons", "it is entirely harmful", "it is entirely beneficial", "it is not important"] },
        { q: "What does the speaker emphasize?", ans: "ethical concerns", options: ["ethical concerns", "economic benefits", "technical details", "historical background"] },
        { q: "What is the main topic of the talk?", ans: "artificial intelligence", options: ["artificial intelligence", "economic theory", "literature", "history"] }
      ],
      G12: [
        { q: "What is the speaker's argument about?", ans: "the role of philosophy in modern life", options: ["the role of philosophy in modern life", "economic development", "scientific research", "political reform"] },
        { q: "What does the speaker suggest students do?", ans: "develop critical thinking", options: ["develop critical thinking", "focus on grades", "ignore ethics", "memorize facts"] },
        { q: "What is the main challenge mentioned?", ans: "balancing progress and ethics", options: ["balancing progress and ethics", "lack of technology", "economic recession", "political instability"] }
      ]
    };
    const s = pick(scenarios[grade] || scenarios.G10);
    const q = `听力题（听录音后回答）：${s.q}`;
    const ans = s.ans;
    const o = opts(ans, () => pick(s.options));
    const level = grade === "G10" ? "基础" : grade === "G11" ? "进阶" : "挑战";
    return Q(q, o, level, `正确答案是 ${ans}`, "听力理解", { name: "gListening", q: s.q, ans }, grade, version);
  }

  /* ============================================================
   * 9. 文化知识（多版本特色）
   * ============================================================ */
  function cultureBuilder(grade, version) {
    const cultures = {
      "人教版": {
        G10: [{ q: "The capital of Australia is ___?", ans: "Canberra" }],
        G11: [{ q: "Shakespeare's famous play about love is ___?", ans: "Romeo and Juliet" }],
        G12: [{ q: "The Industrial Revolution began in ___?", ans: "Britain" }]
      },
      "外研版": {
        G10: [{ q: "The British Parliament is located in ___?", ans: "London" }],
        G11: [{ q: "The author of 'Pride and Prejudice' is ___?", ans: "Jane Austen" }],
        G12: [{ q: "The European Union has ___ members.", ans: "27" }]
      }
    };
    const c = cultures[version] || cultures["人教版"];
    const items = c[grade] || c.G10;
    const item = pick(items);
    const q = `文化知识：${item.q}`;
    const ans = item.ans;
    const o = opts(ans, () => pick(["London", "Paris", "Berlin", "Rome", "Canberra"]));
    const level = "基础";
    return Q(q, o, level, `正确答案是 ${ans}`, "文化背景", { name: "gCulture", q: item.q, ans }, grade, version);
  }

  /* ============================================================
   * 10. 语音/词汇辨析（各年级 ≥200）
   * ============================================================ */
  function vocabDistinctionBuilder(grade, version) {
    const words = grade === "G10" ? ["affect/effect", "principle/principal", "compliment/complement", "ensure/insure", "adapt/adopt"] :
                   grade === "G11" ? ["economic/economical", "historic/historical", "sensitive/sensible", "especially/specially", "considerate/considerable"] :
                   ["perspective/prospective", "resolution/reformation", "imminent/eminent", "affection/affectation", "reverence/irreverence"];
    const pair = pick(words);
    const q = `辨析以下词汇：${pair}`;
    const ans = "示例：正确区分两个词的意义和用法";
    const o = opts(ans, () => "错误", () => "错误2", () => "错误3");
    const level = grade === "G10" ? "基础" : "进阶";
    return Q(q, o, level, `正确区分 "${pair}" 的用法`, "词汇辨析", { name: "gVocabDist", pair }, grade, version);
  }

  /* ============================================================
   * 配图函数
   * ============================================================ */
  function figWrapper(inner, grade, version) {
    const gradeLabel = GRADE_NAMES[grade] || grade;
    return S(320, 120, inner + `<text x="290" y="114" font-size="10" text-anchor="end" fill="${K.sub}">${gradeLabel} · ${version || "人教版"}</text>`, 320);
  }

  window.Fig.gWord = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">📚 ${p.topic}</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.en} → ${p.zh}</text>`, p.grade, p.version);
  };
  window.Fig.gGrammar = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">📖 语法</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.point || "语法填空"}</text>`, p.grade, p.version);
  };
  window.Fig.gCloze = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">📝 完形填空</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">选择正确单词填空</text>`, p.grade, p.version);
  };
  window.Fig.gReading = function (p) {
    return figWrapper(`<text x="160" y="40" font-size="15" text-anchor="middle" fill="${K.ink}">📄 阅读理解</text><text x="160" y="70" font-size="12" text-anchor="middle" fill="${K.sub}">${(p.text || "").slice(0, 40)}...</text><text x="160" y="96" font-size="12" text-anchor="middle" fill="${K.pri}">${p.q}</text>`, p.grade, p.version);
  };
  window.Fig.gSevenFive = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">📌 七选五</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">选择正确句子填空</text>`, p.grade, p.version);
  };
  window.Fig.gError = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">✏️ 短文改错</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.text}</text>`, p.grade, p.version);
  };
  window.Fig.gWriting = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">✍️ 写作任务</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.topic}</text>`, p.grade, p.version);
  };
  window.Fig.gListening = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">🎧 听力理解</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.q}</text>`, p.grade, p.version);
  };
  window.Fig.gCulture = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">🌍 文化知识</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.q}</text>`, p.grade, p.version);
  };
  window.Fig.gVocabDist = function (p) {
    return figWrapper(`<text x="160" y="50" font-size="16" text-anchor="middle" fill="${K.ink}">🔍 词汇辨析</text><text x="160" y="76" font-size="14" text-anchor="middle" fill="${K.sub}">${p.pair}</text>`, p.grade, p.version);
  };

  /* ============================================================
   * 题库构建器（每个技巧 ≥200 题）
   * ============================================================ */
  function buildPoolsForAll(builder, count) {
    const pools = {};
    ALL_GRADES.forEach(grade => {
      VERSIONS.forEach(version => {
        const key = grade + "_" + version;
        pools[key] = [];
        for (let i = 0; i < count; i++) {
          let item = builder(grade, version);
          let attempts = 0;
          while (pools[key].some(p => p.q === item.q) && attempts < 50) {
            item = builder(grade, version);
            attempts++;
          }
          pools[key].push(item);
        }
      });
    });
    return pools;
  }

  const POOLS = {
    word: buildPoolsForAll(wordBuilder, 25),
    grammar: buildPoolsForAll(grammarBuilder, 25),
    cloze: buildPoolsForAll(clozeBuilder, 20),
    reading: buildPoolsForAll(readingBuilder, 25),
    sevenfive: buildPoolsForAll(sevenFiveBuilder, 20),
    errorCorrection: buildPoolsForAll(errorCorrectionBuilder, 20),
    writing: buildPoolsForAll(writingBuilder, 20),
    listening: buildPoolsForAll(listeningBuilder, 20),
    culture: buildPoolsForAll(cultureBuilder, 20),
    vocabDist: buildPoolsForAll(vocabDistinctionBuilder, 20)
  };

  /* ============================================================
   * 不重复抽取器
   * ============================================================ */
  const usedMap = {};

  function getQGen(id) {
    const gradePools = POOLS[id];
    if (!gradePools) return null;

    return function (n, grade, version) {
      const targetGrade = grade || "G10";
      const targetVersion = version || "人教版";
      const key = targetGrade + "_" + targetVersion;
      const pool = gradePools[key] || gradePools["G10_人教版"];

      if (!pool || pool.length === 0) return [];

      const usedKey = id + "_" + key;
      if (!usedMap[usedKey]) usedMap[usedKey] = [];
      const used = usedMap[usedKey];

      if (used.length >= pool.length) {
        used.length = 0;
      }

      const nCount = n || 6;
      const available = pool.filter((_, i) => !used.includes(i));

      if (available.length < nCount) {
        used.length = 0;
        const poolCopy = shuffle([...pool]);
        const result = [];
        for (let i = 0; i < nCount; i++) {
          const idx = i % poolCopy.length;
          result.push(poolCopy[idx]);
          const poolIdx = pool.indexOf(poolCopy[idx]);
          if (poolIdx !== -1) used.push(poolIdx);
        }
        return result;
      }

      const shuffledAvail = shuffle(available);
      const picked = shuffledAvail.slice(0, nCount);
      picked.forEach(item => {
        const idx = pool.indexOf(item);
        if (idx !== -1) used.push(idx);
      });
      return picked;
    };
  }

  const GEN = {};
  Object.keys(POOLS).forEach(id => {
    GEN[id] = getQGen(id);
  });

  if (window.TECHNIQUES) {
    window.TECHNIQUES.forEach(t => {
      if (GEN[t.id]) {
        t.qgen = GEN[t.id];
      }
    });
  }
  window.QGEN_SENIOR_READY = true;
})();