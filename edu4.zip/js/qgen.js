/* ============================================================
 * 融会贯通 · 参数化出题引擎（小学全部技巧）- 超强版
 * 每个技巧每次生成 8 道题，题库组合超过 100+ 种
 * 覆盖：数数与数位、100以内加减法、乘法口诀、除法与余数、
 *       四则混合运算、植树问题、和差倍、盈亏、平均数、
 *       周期、归一、工程、相遇、追及、分数、小数、百分数、
 *       比和比例、鸡兔同笼、行程、圆、圆柱圆锥、方程等
 * ============================================================ */
(function () {
    'use strict';

    /* ---------- 通用工具 ---------- */
    var K = { ink: "#334155", sub: "#64748b", line: "#cbd5e1", pri: "#2f6fed", ok: "#16a34a", warn: "#d97706", red: "#dc2626", soft: "#eef3ff", blue: "#2563eb", purple: "#7c3aed" };
    
    function rnd(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
    function pick(a) { return a[rnd(0, a.length - 1)]; }
    function shuffle(a) { 
        a = a.slice(); 
        for (var i = a.length - 1; i > 0; i--) { 
            var j = Math.floor(Math.random() * (i + 1)); 
            var t = a[i]; 
            a[i] = a[j]; 
            a[j] = t; 
        } 
        return a; 
    }

    function opts(ans, make, n) {
        n = n || 4;
        var set = new Set([ans]);
        var g = 0;
        while (set.size < n && g++ < 400) { 
            var d = make(); 
            if (d !== ans) set.add(d); 
        }
        var k = 1;
        while (set.size < n) { 
            set.add(ans + k); 
            if (set.size < n) set.add(ans - k); 
            k++; 
        }
        var arr = shuffle([].slice.call(set)).map(String);
        return { opts: arr, ans: arr.indexOf(String(ans)) };
    }

    function Q(q, optsObj, level, explain, point, fig) {
        return Object.assign({ q: q, level: level || "基础", explain: explain, point: point || "" }, optsObj, { fig: fig || null });
    }

    /* ============================================================
     * 0. 数数与数位（一年级）- 100+ 种组合
     * ============================================================ */
    function qCount() {
        var type = rnd(0, 5);
        var q, ans, o, exp, point;
        
        if (type === 0) {
    // 【修复】数位识别 - 只选唯一数字，避免指代不明
    var num, digits, uniqueDigits, pos, posNames, ansVal, digitVal;
    var maxAttempts = 0;
    
    do {
        num = rnd(100, 999);
        digits = String(num).split('').map(Number);
        // 找出只出现一次的数字
        uniqueDigits = [];
        for (var i = 0; i < digits.length; i++) {
            var count = 0;
            for (var j = 0; j < digits.length; j++) {
                if (digits[j] === digits[i]) count++;
            }
            if (count === 1) uniqueDigits.push(i);
        }
        maxAttempts++;
    } while (uniqueDigits.length === 0 && maxAttempts < 50);
    
    if (uniqueDigits.length === 0) {
        pos = 2;
    } else {
        pos = uniqueDigits[rnd(0, uniqueDigits.length - 1)];
    }
    
    posNames = ['百位', '十位', '个位'];
    ansVal = posNames[pos];
    digitVal = digits[pos];
    
    var allPosNames = ['百位', '十位', '个位'];
    var optsArr = [];
    for (var i = 0; i < allPosNames.length; i++) {
        if (allPosNames[i] !== ansVal) {
            optsArr.push(allPosNames[i]);
        }
    }
    var allOpts = shuffle([ansVal].concat(optsArr));
    o = { opts: allOpts, ans: allOpts.indexOf(ansVal) };
    q = num + ' 中的 "' + digitVal + '" 在（ ）位。';
    exp = '从右数：个位、十位、百位，' + digitVal + ' 在 ' + ansVal + '。';
    point = '数位顺序';
} else if (type === 1) {
            var units = [10, 100, 1000];
            var u = pick(units);
            var ansVal = u;
            var optsArr = [];
            var used = new Set([ansVal]);
            while (optsArr.length < 3) {
                var d = pick([1, 10, 100, 1000]);
                if (!used.has(d)) { used.add(d); optsArr.push(d); }
            }
            var allOpts = shuffle([ansVal].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ansVal) };
            q = u + ' 个一是多少？';
            exp = u + ' 个一是 ' + u + '。';
            point = '计数单位';
        } else if (type === 2) {
            var a = rnd(10, 99);
            var b = rnd(10, 99);
            while (a === b) b = rnd(10, 99);
            var bigger = a > b ? a : b;
            var smaller = a < b ? a : b;
            var askBigger = Math.random() < 0.5;
            var ansVal = askBigger ? bigger : smaller;
            var optsArr = [];
            var used = new Set([ansVal]);
            while (optsArr.length < 3) {
                var d = rnd(10, 99);
                if (!used.has(d)) { used.add(d); optsArr.push(d); }
            }
            var allOpts = shuffle([ansVal].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ansVal) };
            q = '比较 ' + a + ' 与 ' + b + '，' + (askBigger ? '较大' : '较小') + '的是？';
            exp = (askBigger ? '较大' : '较小') + '的是 ' + ansVal + '。';
            point = '数的大小比较';
        } else if (type === 3) {
            var a1 = rnd(10, 80);
            var b1 = rnd(1, 20);
            var isAdd = Math.random() < 0.5;
            var ansVal = isAdd ? a1 + b1 : a1 - b1;
            if (ansVal < 0) { ansVal = a1 + b1; isAdd = true; }
            var optsArr = [];
            var used = new Set([ansVal]);
            while (optsArr.length < 3) {
                var d = ansVal + rnd(-10, 10);
                if (d >= 0 && !used.has(d)) { used.add(d); optsArr.push(d); }
            }
            var allOpts = shuffle([ansVal].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ansVal) };
            q = a1 + (isAdd ? ' + ' : ' − ') + b1 + ' = ？';
            exp = a1 + (isAdd ? ' + ' : ' − ') + b1 + ' = ' + ansVal + '。';
            point = isAdd ? '加法' : '减法';
        } else if (type === 4) {
            var num2 = rnd(100, 999);
            var digitPos = rnd(0, 2);
            var posNames2 = ['百', '十', '个'];
            var digitVal2 = String(num2)[digitPos];
            var ansVal2 = parseInt(digitVal2) * (digitPos === 0 ? 100 : digitPos === 1 ? 10 : 1);
            var optsArr2 = [];
            var used2 = new Set([ansVal2]);
            while (optsArr2.length < 3) {
                var d2 = rnd(0, 900);
                if (!used2.has(d2) && d2 % 10 === 0) { used2.add(d2); optsArr2.push(d2); }
            }
            var allOpts2 = shuffle([ansVal2].concat(optsArr2));
            o = { opts: allOpts2.map(String), ans: allOpts2.indexOf(ansVal2) };
            q = num2 + ' 中 ' + posNames2[digitPos] + ' 位上的数表示？';
            exp = posNames2[digitPos] + '位上的 ' + digitVal2 + ' 表示 ' + ansVal2 + '。';
            point = '数位值';
        } else {
            var q1 = rnd(10, 50);
            var q2 = rnd(1, 20);
            var q3 = rnd(1, 20);
            var ansVal3 = q1 + q2 - q3;
            if (ansVal3 < 0) { ansVal3 = q1 + q2 + q3; }
            var optsArr3 = [];
            var used3 = new Set([ansVal3]);
            while (optsArr3.length < 3) {
                var d3 = ansVal3 + rnd(-15, 15);
                if (d3 >= 0 && !used3.has(d3)) { used3.add(d3); optsArr3.push(d3); }
            }
            var allOpts3 = shuffle([ansVal3].concat(optsArr3));
            o = { opts: allOpts3.map(String), ans: allOpts3.indexOf(ansVal3) };
            q = q1 + ' + ' + q2 + ' − ' + q3 + ' = ？';
            exp = q1 + ' + ' + q2 + ' − ' + q3 + ' = ' + ansVal3 + '。';
            point = '加减混合';
        }
        return Q(q, o, '基础', exp, point);
    }

    /* ============================================================
     * 1. 100以内加减法（一年级）- 100+ 种组合
     * ============================================================ */
    function qAddSub() {
        var type = rnd(0, 5);
        var q, ans, o, exp, point;
        
        if (type === 0) {
            var a = rnd(10, 89);
            var b = rnd(1, 99 - a);
            while ((a % 10) + (b % 10) < 10) {
                a = rnd(10, 89);
                b = rnd(1, 99 - a);
            }
            ans = a + b;
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-10, 10);
                if (d !== ans && d > 0 && d <= 100 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = a + ' + ' + b + ' = ？';
            exp = a + ' + ' + b + ' = ' + ans + '（个位相加满十，向十位进1）';
            point = '进位加法';
        } else if (type === 1) {
            var a = rnd(20, 99);
            var b = rnd(1, a - 1);
            while ((a % 10) >= (b % 10)) {
                a = rnd(20, 99);
                b = rnd(1, a - 1);
            }
            ans = a - b;
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-10, 10);
                if (d !== ans && d >= 0 && d <= 100 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = a + ' − ' + b + ' = ？';
            exp = a + ' − ' + b + ' = ' + ans + '（个位不够减，从十位借1当10）';
            point = '退位减法';
        } else if (type === 2) {
            var type2 = rnd(0, 1);
            if (type2 === 0) {
                var a = rnd(10, 80);
                var b = rnd(1, 99 - a);
                var c = a + b;
                ans = b;
                var optsArr = [];
                var used = new Set([ans]);
                while (optsArr.length < 3) {
                    var d = rnd(1, 50);
                    if (d !== ans && !used.has(d)) {
                        used.add(d);
                        optsArr.push(d);
                    }
                }
                var allOpts = shuffle([ans].concat(optsArr));
                o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
                q = a + ' + □ = ' + c + '，□ = ？';
                exp = '□ = ' + c + ' − ' + a + ' = ' + ans;
                point = '求加数';
            } else {
                var a = rnd(30, 99);
                var b = rnd(1, a - 1);
                var c = a - b;
                ans = b;
                var optsArr = [];
                var used = new Set([ans]);
                while (optsArr.length < 3) {
                    var d = rnd(1, 50);
                    if (d !== ans && !used.has(d)) {
                        used.add(d);
                        optsArr.push(d);
                    }
                }
                var allOpts = shuffle([ans].concat(optsArr));
                o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
                q = a + ' − □ = ' + c + '，□ = ？';
                exp = '□ = ' + a + ' − ' + c + ' = ' + ans;
                point = '求减数';
            }
        } else if (type === 3) {
            var a = rnd(10, 60);
            var b = rnd(1, 30);
            var c = rnd(1, 20);
            var isMixed = Math.random() < 0.5;
            if (isMixed) {
                ans = a + b - c;
                if (ans < 0) { ans = a - b + c; }
                q = a + ' + ' + b + ' − ' + c + ' = ？';
                exp = a + ' + ' + b + ' − ' + c + ' = ' + ans;
                point = '加减混合';
            } else {
                ans = a + b + c;
                if (ans > 100) { ans = a + b - c; }
                q = a + ' + ' + b + ' + ' + c + ' = ？';
                exp = a + ' + ' + b + ' + ' + c + ' = ' + ans;
                point = '连加';
            }
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-10, 10);
                if (d !== ans && d >= 0 && d <= 100 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
        } else if (type === 4) {
            var a = rnd(10, 90);
            var b = rnd(10, 90);
            while (a === b) b = rnd(10, 90);
            var bigger = a > b ? a : b;
            var smaller = a < b ? a : b;
            var askBigger = Math.random() < 0.5;
            ans = askBigger ? bigger : smaller;
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = rnd(10, 95);
                if (d !== ans && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = '比较 ' + a + ' 与 ' + b + '，' + (askBigger ? '较大' : '较小') + '的是？';
            exp = (askBigger ? '较大' : '较小') + '的是 ' + ans;
            point = '数的大小比较';
        } else {
            var a = rnd(20, 80);
            var b = rnd(5, 30);
            var c = rnd(5, 30);
            ans = a - b + c;
            if (ans < 0) { ans = a + b - c; }
            if (ans > 100) { ans = a - b - c; }
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-15, 15);
                if (d !== ans && d >= 0 && d <= 100 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = a + ' − ' + b + ' + ' + c + ' = ？';
            exp = a + ' − ' + b + ' + ' + c + ' = ' + ans;
            point = '加减混合';
        }
        return Q(q, o, '基础', exp, point);
    }

    /* ============================================================
     * 2. 乘法口诀（二年级）- 100+ 种组合
     * ============================================================ */
    function qMulti() {
        var type = rnd(0, 4);
        var q, ans, o, exp, point;
        
        if (type === 0) {
            var a = rnd(2, 9);
            var b = rnd(2, 9);
            ans = a * b;
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-8, 8);
                if (d !== ans && d > 0 && d <= 81 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = a + ' × ' + b + ' = ？';
            var koujue = ['一一得一','一二得二','一三得三','一四得四','一五得五','一六得六','一七得七','一八得八','一九得九',
                '二二得四','二三得六','二四得八','二五一十','二六十二','二七十四','二八十六','二九十八',
                '三三得九','三四十二','三五十五','三六十八','三七二十一','三八二十四','三九二十七',
                '四四十六','四五二十','四六二十四','四七二十八','四八三十二','四九三十六',
                '五五二十五','五六三十','五七三十五','五八四十','五九四十五',
                '六六三十六','六七四十二','六八四十八','六九五十四',
                '七七四十九','七八五十六','七九六十三',
                '八八六十四','八九七十二',
                '九九八十一'];
            var kj = '';
            for (var i = 0; i < koujue.length; i++) {
                if (koujue[i].indexOf(a + '') > -1 && koujue[i].indexOf(b + '') > -1) {
                    kj = koujue[i];
                    break;
                }
            }
            exp = a + ' × ' + b + ' = ' + ans + '（' + (kj || '乘法口诀') + '）';
            point = '乘法口诀';
        } else if (type === 1) {
    var a = rnd(2, 9);
    var b = rnd(2, 9);
    var product = a * b;
    var ans = a;
    var optsArr = [];
    var used = new Set([ans]);
    while (optsArr.length < 3) {
        var d = rnd(2, 12);
        if (!used.has(d)) {
            used.add(d);
            optsArr.push(d);
        }
    }
    var allOpts = shuffle([ans].concat(optsArr));
    o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
    q = '□ × ' + b + ' = ' + product + '，□ = ？';
    exp = '□ = ' + product + ' ÷ ' + b + ' = ' + a;
    point = '求因数';
} else if (type === 2) {
    var a = rnd(2, 9);
    var b = rnd(2, 9);
    var product = a * b;
    var ans = b;
    var optsArr = [];
    var used = new Set([ans]);
    while (optsArr.length < 3) {
        var d = rnd(2, 12);
        if (!used.has(d)) {
            used.add(d);
            optsArr.push(d);
        }
    }
    var allOpts = shuffle([ans].concat(optsArr));
    o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
    q = a + ' × □ = ' + product + '，□ = ？';
    exp = '□ = ' + product + ' ÷ ' + a + ' = ' + b;
    point = '求因数';
} else if (type === 3) {
            var a = rnd(2, 9);
            var b = rnd(2, 9);
            ans = a * b;
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-8, 8);
                if (d !== ans && d > 0 && d <= 81 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = '计算：' + a + ' 个 ' + b + ' 相加是多少？';
            exp = a + ' × ' + b + ' = ' + ans;
            point = '乘法意义';
        } else {
            var a = rnd(2, 9);
            var b = rnd(2, 9);
            var c = rnd(1, 8);
            var d = rnd(1, 8);
            var ans1 = a * b;
            var ans2 = c * d;
            ans = ans1 + ans2;
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var dd = ans + rnd(-10, 10);
                if (dd !== ans && dd > 0 && dd <= 162 && !used.has(dd)) {
                    used.add(dd);
                    optsArr.push(dd);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = a + ' × ' + b + ' + ' + c + ' × ' + d + ' = ？';
            exp = a + ' × ' + b + ' + ' + c + ' × ' + d + ' = ' + ans1 + ' + ' + ans2 + ' = ' + ans;
            point = '乘法混合运算';
        }
        return Q(q, o, '基础', exp, point);
    }

    /* ============================================================
     * 3. 除法与余数（二年级）- 100+ 种组合
     * ============================================================ */
    function qDivide() {
        var type = rnd(0, 4);
        var q, ans, o, exp, point;
        
        if (type === 0) {
            var a = rnd(2, 9);
            var b = rnd(2, 9);
            ans = a * b;
            var optsArr = [];
            var used = new Set([a]);
            while (optsArr.length < 3) {
                var d = rnd(1, 9);
                if (d !== a && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([a].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(a) };
            q = ans + ' ÷ ' + b + ' = ？';
            exp = ans + ' ÷ ' + b + ' = ' + a + '（' + a + ' × ' + b + ' = ' + ans + '）';
            point = '表内除法';
        } else if (type === 1) {
            var divisor = rnd(3, 8);
            var quotient = rnd(2, 9);
            var remainder = rnd(1, divisor - 1);
            ans = quotient * divisor + remainder;
            var optsArr = [];
            var used = new Set([quotient]);
            while (optsArr.length < 3) {
                var d = rnd(1, 9);
                if (d !== quotient && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([quotient].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(quotient) };
            q = ans + ' ÷ ' + divisor + ' = ' + '□' + ' … ' + remainder + '，□ = ？';
            exp = ans + ' ÷ ' + divisor + ' = ' + quotient + ' … ' + remainder + '（余数 ' + remainder + ' < 除数 ' + divisor + '）';
            point = '有余数除法';
        } else if (type === 2) {
            var total = rnd(10, 50);
            var people = rnd(3, 8);
            var quotient = Math.floor(total / people);
            var remainder = total % people;
            ans = quotient;
            var optsArr = [];
            var used = new Set([quotient]);
            while (optsArr.length < 3) {
                var d = quotient + rnd(-3, 3);
                if (d !== quotient && d >= 0 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([quotient].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(quotient) };
            q = total + ' 个苹果平均分给 ' + people + ' 人，每人分几个？还剩几个？';
            exp = total + ' ÷ ' + people + ' = ' + quotient + ' … ' + remainder + '，每人分 ' + quotient + ' 个，还剩 ' + remainder + ' 个。';
            point = '平均分';
        } else if (type === 3) {
            var divisor = rnd(4, 9);
            var remainder = rnd(1, divisor - 1);
            var quotient = rnd(2, 9);
            ans = quotient * divisor + remainder;
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-10, 10);
                if (d !== ans && d > 0 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = '除数是 ' + divisor + '，商是 ' + quotient + '，余数是 ' + remainder + '，被除数最小是？';
            exp = '被除数 = ' + divisor + ' × ' + quotient + ' + ' + remainder + ' = ' + ans;
            point = '被除数计算';
        } else {
            var divisor = rnd(3, 8);
            var remainder = rnd(1, divisor - 1);
            var quotient = rnd(2, 9);
            ans = quotient * divisor + remainder;
            var optsArr = [];
            var used = new Set([divisor]);
            while (optsArr.length < 3) {
                var d = divisor + rnd(-3, 3);
                if (d !== divisor && d > remainder && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([divisor].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(divisor) };
            q = '被除数 ' + ans + '，商 ' + quotient + '，余数 ' + remainder + '，除数是多少？';
            exp = '除数 = (被除数 − 余数) ÷ 商 = (' + ans + ' − ' + remainder + ') ÷ ' + quotient + ' = ' + divisor;
            point = '求除数';
        }
        return Q(q, o, '基础', exp, point);
    }

    /* ============================================================
     * 4. 四则混合运算与括号（三年级）- 100+ 种组合
     * ============================================================ */
    function qFourOps() {
        var type = rnd(0, 4);
        var q, ans, o, exp, point;
        
        if (type === 0) {
            var a = rnd(5, 20);
            var b = rnd(2, 9);
            var c = rnd(1, 5);
            ans = a + b * c;
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-10, 10);
                if (d !== ans && d >= 0 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = a + ' + ' + b + ' × ' + c + ' = ？';
            exp = '先乘除后加减：' + b + ' × ' + c + ' = ' + (b * c) + '，' + a + ' + ' + (b * c) + ' = ' + ans;
            point = '先乘除后加减';
        } else if (type === 1) {
            var a = rnd(5, 20);
            var b = rnd(2, 9);
            var c = rnd(1, 5);
            ans = (a + b) * c;
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-15, 15);
                if (d !== ans && d >= 0 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = '(' + a + ' + ' + b + ') × ' + c + ' = ？';
            exp = '先算括号：' + a + ' + ' + b + ' = ' + (a + b) + '，' + (a + b) + ' × ' + c + ' = ' + ans;
            point = '括号优先';
        } else if (type === 2) {
            var a = rnd(30, 80);
            var b = rnd(2, 9);
            var c = rnd(2, 9);
            ans = a - b * c;
            if (ans < 0) { ans = a + b * c; }
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-15, 15);
                if (d !== ans && d >= 0 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = a + ' − ' + b + ' × ' + c + ' = ？';
            exp = '先乘除后加减：' + b + ' × ' + c + ' = ' + (b * c) + '，' + a + ' − ' + (b * c) + ' = ' + ans;
            point = '先乘除后加减';
        } else if (type === 3) {
            var a = rnd(30, 70);
            var b = rnd(2, 8);
            var c = rnd(2, 8);
            ans = (a - b) * c;
            if (ans < 0) { ans = (a + b) * c; }
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-15, 15);
                if (d !== ans && d >= 0 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = '(' + a + ' − ' + b + ') × ' + c + ' = ？';
            exp = '先算括号：' + a + ' − ' + b + ' = ' + (a - b) + '，' + (a - b) + ' × ' + c + ' = ' + ans;
            point = '括号优先';
        } else {
            var a = rnd(10, 30);
            var b = rnd(2, 8);
            var c = rnd(2, 8);
            var d = rnd(2, 8);
            ans = a + b * c - d;
            if (ans < 0) { ans = a + b * c + d; }
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var dd = ans + rnd(-15, 15);
                if (dd !== ans && dd >= 0 && !used.has(dd)) {
                    used.add(dd);
                    optsArr.push(dd);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = a + ' + ' + b + ' × ' + c + ' − ' + d + ' = ？';
            exp = '先算乘法：' + b + ' × ' + c + ' = ' + (b * c) + '，' + a + ' + ' + (b * c) + ' − ' + d + ' = ' + ans;
            point = '混合运算';
        }
        return Q(q, o, '基础', exp, point);
    }

    /* ============================================================
     * 5. 植树问题（三年级）- 100+ 种组合
     * ============================================================ */
    function qPlant() {
        var distances = [2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 30, 40, 50];
        var d = pick(distances);
        var seg = rnd(3, 20);
        var L = d * seg;
        var type = rnd(0, 3);
        var base = seg;
        var trees, mode, q, figMode, exp;
        if (type === 0) { 
            trees = base + 1; 
            mode = 'both'; 
            figMode = 'both'; 
            q = '一条 ' + L + ' 米长的路，每隔 ' + d + ' 米栽一棵（两端都栽），共需多少棵树？'; 
            exp = '间隔数 = ' + L + ' ÷ ' + d + ' = ' + base + '；两端都栽：棵数 = 间隔数 + 1 = ' + (base + 1) + '。'; 
        }
        else if (type === 1) { 
            trees = base; 
            mode = 'one'; 
            figMode = 'one'; 
            q = '一条 ' + L + ' 米长的路，每隔 ' + d + ' 米栽一棵（只栽一端），共需多少棵树？'; 
            exp = '间隔数 = ' + L + ' ÷ ' + d + ' = ' + base + '；只栽一端：棵数 = 间隔数 = ' + base + '。'; 
        }
        else if (type === 2) { 
            trees = base - 1; 
            mode = 'none'; 
            figMode = 'none'; 
            q = '一条 ' + L + ' 米长的路，每隔 ' + d + ' 米栽一棵（两端都不栽），共需多少棵树？'; 
            exp = '间隔数 = ' + L + ' ÷ ' + d + ' = ' + base + '；两端不栽：棵数 = 间隔数 − 1 = ' + (base - 1) + '。'; 
        }
        else { 
            trees = base; 
            mode = 'ring'; 
            figMode = 'ring'; 
            q = '一个周长 ' + L + ' 米的圆形花坛，沿边每隔 ' + d + ' 米栽一棵，共需多少棵树？'; 
            exp = '封闭图形：棵数 = 间隔数 = ' + L + ' ÷ ' + d + ' = ' + base + '。'; 
        }
        var o = opts(trees, function() { 
            return Math.max(1, base + rnd(-4, 5)); 
        });
        return Q(q, o, '基础', exp, '植树三情形', { name: 'gPlant', seg: seg, mode: figMode });
    }

    /* ============================================================
     * 6. 和差倍问题（四年级）- 100+ 种组合
     * ============================================================ */
    function qSumDiff() {
        var type = rnd(0, 2);
        if (type === 0) {
            var D = rnd(2, 50);
            var big = rnd(D + 2, D + 60);
            var small = big - D;
            var Ssum = big + small;
            var askBig = Math.random() < 0.5;
            var ans = askBig ? big : small;
            var o = opts(ans, function() { 
                return rnd(Math.max(1, small - 15), big + 15); 
            });
            var q = '两数之和是 ' + Ssum + '，差是 ' + D + '。问' + (askBig ? '较大的数' : '较小的数') + '是多少？';
            var exp = '较大 = (和 + 差) ÷ 2 = (' + Ssum + ' + ' + D + ') ÷ 2 = ' + big + '；较小 = (和 − 差) ÷ 2 = (' + Ssum + ' − ' + D + ') ÷ 2 = ' + small + '。';
            return Q(q, o, '基础', exp, '和差公式', { name: 'gSumdiff', big: big, small: small, type: 'sd' });
        } else if (type === 1) {
            var m = rnd(2, 8);
            var small = rnd(2, 25);
            var big = small * m;
            var Ssum = big + small;
            var askBig = Math.random() < 0.5;
            var ans = askBig ? big : small;
            var o = opts(ans, function() { 
                return rnd(2, big + 12); 
            });
            var q = '两数之和是 ' + Ssum + '，大数是小数的 ' + m + ' 倍。问' + (askBig ? '大数' : '小数') + '是多少？';
            var exp = '小数 = 和 ÷ (倍数 + 1) = ' + Ssum + ' ÷ (' + m + ' + 1) = ' + small + '；大数 = ' + small + ' × ' + m + ' = ' + big + '。';
            return Q(q, o, '基础', exp, '和倍公式', { name: 'gSumdiff', big: big, small: small, type: 'sb' });
        } else {
            var m = rnd(2, 8);
            var small = rnd(2, 25);
            var big = small * m;
            var D = big - small;
            var askBig = Math.random() < 0.5;
            var ans = askBig ? big : small;
            var o = opts(ans, function() { 
                return rnd(2, big + 12); 
            });
            var q = '两数之差是 ' + D + '，大数是小数的 ' + m + ' 倍。问' + (askBig ? '大数' : '小数') + '是多少？';
            var exp = '小数 = 差 ÷ (倍数 − 1) = ' + D + ' ÷ (' + m + ' − 1) = ' + small + '；大数 = ' + small + ' × ' + m + ' = ' + big + '。';
            return Q(q, o, '基础', exp, '差倍公式', { name: 'gSumdiff', big: big, small: small, type: 'db' });
        }
    }

    /* ============================================================
     * 7. 盈亏问题（四年级）- 100+ 种组合
     * ============================================================ */
    function qProfit() {
        var type = rnd(0, 2);
        var a = rnd(2, 8);
        var c = a + rnd(1, 5);
        var N = rnd(3, 15);
        var q, ans, exp, fig, o;
        if (type === 0) {
            var diff = (c - a) * N;
            var b = rnd(1, diff - 1);
            var dd = diff - b;
            ans = N;
            var thing = a * N + b;
            o = opts(ans, function() { 
                return rnd(2, N + 12); 
            });
            q = '分糖果：如果每人分 ' + a + ' 颗，多出 ' + b + ' 颗；如果每人分 ' + c + ' 颗，反而少 ' + dd + ' 颗。一共有几个小朋友？';
            exp = '人数 = (盈 + 亏) ÷ 两次每份差 = (' + b + ' + ' + dd + ') ÷ (' + c + ' − ' + a + ') = ' + diff + ' ÷ ' + (c - a) + ' = ' + N + ' 人。（糖果共 ' + thing + ' 颗）';
            fig = { name: 'gProfit', a: a, c: c, b: b, d: dd, N: N, thing: thing };
        } else if (type === 1) {
            var diff = (c - a) * N;
            var b = rnd(diff + 1, diff + 20);
            var e = b - diff;
            ans = N;
            var thing = a * N + b;
            o = opts(ans, function() { 
                return rnd(2, N + 12); 
            });
            q = '分糖果：每人分 ' + a + ' 颗多 ' + b + ' 颗；每人分 ' + c + ' 颗多 ' + e + ' 颗。一共有几个小朋友？';
            exp = '人数 = (大盈 − 小盈) ÷ 两次每份差 = (' + b + ' − ' + e + ') ÷ (' + c + ' − ' + a + ') = ' + diff + ' ÷ ' + (c - a) + ' = ' + N + ' 人。';
            fig = { name: 'gProfit', a: a, c: c, b: b, e: e, N: N, thing: thing, kind: '双盈' };
        } else {
            var diff = (c - a) * N;
            var f = rnd(diff + 1, diff + 20);
            var g = f - diff;
            ans = N;
            var need = a * N + f;
            o = opts(ans, function() { 
                return rnd(2, N + 12); 
            });
            q = '分糖果：每人分 ' + a + ' 颗少 ' + f + ' 颗；每人分 ' + c + ' 颗少 ' + g + ' 颗。一共有几个小朋友？';
            exp = '人数 = (大亏 − 小亏) ÷ 两次每份差 = (' + f + ' − ' + g + ') ÷ (' + c + ' − ' + a + ') = ' + diff + ' ÷ ' + (c - a) + ' = ' + N + ' 人。';
            fig = { name: 'gProfit', a: a, c: c, f: f, g: g, N: N, thing: need, kind: '双亏' };
        }
        return Q(q, o, '进阶', exp, '盈亏公式', fig);
    }

    /* ============================================================
     * 8. 平均数问题（三年级）- 100+ 种组合
     * ============================================================ */
    function qAvg() {
        var type = rnd(0, 1);
        if (type === 0) {
            var n = rnd(3, 10);
            var vals = [];
            var sum = 0;
            for (var i = 0; i < n; i++) {
                var v = rnd(30, 100);
                vals.push(v);
                sum += v;
            }
            var r = sum % n;
            if (r !== 0) {
                vals[n - 1] += (n - r);
                sum += (n - r);
            }
            var avg = sum / n;
            var o = opts(avg, function() { 
                return rnd(30, 100); 
            });
            var q = '某小组 ' + n + ' 次测验成绩分别为 ' + vals.join('、') + ' 分，平均成绩是多少？';
            var exp = '总数 = ' + sum + '，份数 = ' + n + '，平均数 = ' + sum + ' ÷ ' + n + ' = ' + avg + ' 分。';
            return Q(q, o, '基础', exp, '总数 ÷ 份数', { name: 'gAvg', vals: vals, avg: avg, showAvg: false });
        } else {
            var n = rnd(3, 8);
            var avg = rnd(55, 100);
            var known = [];
            for (var i = 0; i < n - 1; i++) {
                known.push(rnd(Math.max(30, avg - 30), Math.min(100, avg + 15)));
            }
            var sum = avg * n;
            var knownSum = known.reduce(function(x, y) { return x + y; }, 0);
            var miss = sum - knownSum;
            var o = opts(miss, function() { 
                return rnd(20, 140); 
            });
            var q = '前 ' + (n - 1) + ' 次成绩为 ' + known.join('、') + ' 分，要使平均分达到 ' + avg + ' 分，第 ' + n + ' 次至少要考多少分？';
            var exp = '总分需 ' + avg + ' × ' + n + ' = ' + sum + '，已得 ' + knownSum + ' 分，缺 = ' + sum + ' − ' + knownSum + ' = ' + miss + ' 分。';
            return Q(q, o, '进阶', exp, '平均数 × 份数', { name: 'gAvg', vals: known.concat([miss]), avg: avg, showAvg: true, missIndex: known.length });
        }
    }

    /* ============================================================
     * 9. 周期问题（三年级）- 100+ 种组合
     * ============================================================ */
    function qCycle() {
        var T = rnd(2, 7);
        var symbols = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
        var letters = symbols.slice(0, T);
        var n = rnd(T + 2, T + 35);
        var rem = n % T;
        var pos = rem === 0 ? T : rem;
        var ansSym = letters[pos - 1];
        var optList = shuffle(letters.slice());
        var o = { opts: optList, ans: optList.indexOf(ansSym) };
        var q = '一串珠子按 ' + letters.join('') + ' 的顺序不断重复排列。第 ' + n + ' 个珠子是什么？';
        var exp = '周期长 = ' + T + '。' + n + ' ÷ ' + T + ' = ' + Math.floor(n / T) + ' …… ' + (rem === 0 ? T : rem) + '，余数定位周期里第 ' + pos + ' 个 = ' + ansSym + '。';
        return Q(q, o, '基础', exp, '找周期余数', { name: 'gCycle', letters: letters, highlight: pos - 1, n: n });
    }

    /* ============================================================
     * 10. 归一问题（四年级）- 100+ 种组合
     * ============================================================ */
    function qGuiyi() {
        var type = rnd(0, 1);
        if (type === 0) {
            var ppl = rnd(2, 8);
            var days = rnd(2, 8);
            var unit = rnd(2, 15);
            var total = unit * ppl * days;
            var p2 = rnd(2, 8);
            var d2 = rnd(2, 8);
            var ans = unit * p2 * d2;
            var o = opts(ans, function() { 
                return unit * rnd(1, 10) * rnd(1, 10); 
            });
            var q = ppl + ' 个工人 ' + days + ' 天可生产零件 ' + total + ' 个。照这样计算，' + p2 + ' 个工人 ' + d2 + ' 天可生产多少个？';
            var exp = '单一量 = 总数 ÷ 人数 ÷ 天数 = ' + total + ' ÷ ' + ppl + ' ÷ ' + days + ' = ' + unit + ' 个/人天；' + p2 + ' 人 ' + d2 + ' 天 = ' + unit + ' × ' + p2 + ' × ' + d2 + ' = ' + ans + ' 个。';
            return Q(q, o, '基础', exp, '先求单一量', { name: 'gGuiyi', ppl: ppl, days: days, unit: unit, p2: p2, d2: d2, ans: ans });
        } else {
            var ppl = rnd(2, 7);
            var days = rnd(3, 12);
            var total = ppl * days;
            var p2;
            do { 
                p2 = rnd(2, 9); 
            } while (total % p2 !== 0);
            var ans = total / p2;
            var o = opts(ans, function() { 
                return Math.max(1, Math.round(total / rnd(1, 9))); 
            });
            var q = '一批任务，' + ppl + ' 人做需 ' + days + ' 天完成。若改为 ' + p2 + ' 人同时做（效率相同），需多少天？';
            var exp = '总工作量 = ' + ppl + ' × ' + days + ' = ' + total + ' 人·天；' + p2 + ' 人需 ' + total + ' ÷ ' + p2 + ' = ' + ans + ' 天。';
            return Q(q, o, '进阶', exp, '归总（总量不变）', { name: 'gGuiyi', ppl: ppl, days: days, p2: p2, ans: ans, total: total });
        }
    }

    /* ============================================================
     * 11. 工程问题（六年级）- 200+ 种组合
     * ============================================================ */
    var PAIRS = [];
    var PAIRS_SET = {};
    for (var a = 2; a <= 20; a++) {
        for (var b = 2; b <= 20; b++) {
            if (a !== b) {
                var key = Math.min(a, b) + ',' + Math.max(a, b);
                if (!PAIRS_SET[key]) {
                    PAIRS_SET[key] = true;
                    PAIRS.push([a, b]);
                }
            }
        }
    }
    var BIG_PAIRS = [[8,12],[10,15],[12,18],[9,15],[10,20],[12,20],[15,20],[8,16],[10,25],[12,24],[14,21],[15,30],[18,24],[20,30],[10,30],[12,30],[15,25],[18,30],[20,25],[24,30]];
    PAIRS = PAIRS.concat(BIG_PAIRS);

    function qEngineer() {
        var type = rnd(0, 2);
        var pr = pick(PAIRS);
        var a = pr[0], b = pr[1];
        var coop = Math.round(a * b / (a + b));
        if (type === 0) {
            var o = opts(coop, function() { 
                return rnd(2, Math.max(coop + 8, a, b + 4)); 
            });
            var q = '一项工程，甲单独做需 ' + a + ' 天，乙单独做需 ' + b + ' 天。两人合作需几天完成？';
            var exp = '甲效 = 1/' + a + '，乙效 = 1/' + b + '；合作效 = 1/' + a + ' + 1/' + b + ' = (' + a + ' + ' + b + ')/' + (a * b) + '；时间 = 1 ÷ (' + (a + b) + '/' + (a * b) + ') = ' + (a * b) + ' ÷ (' + (a + b) + ') = ' + coop + ' 天。';
            return Q(q, o, '基础', exp, '工程问题（设总量为1）', { name: 'gEngineer', bars: [{ l: '甲', v: a }, { l: '乙', v: b }] });
        } else if (type === 1) {
            var o = opts(b, function() { 
                return rnd(2, a + 20); 
            });
            var q = '一项工程，甲单独做需 ' + a + ' 天，甲乙合作需 ' + coop + ' 天。乙单独做需几天？';
            var exp = '1/' + a + ' + 1/乙 = 1/' + coop + ' → 1/乙 = 1/' + coop + ' − 1/' + a + ' = (' + a + ' − ' + coop + ')/(' + (a * coop) + ') → 乙 = ' + (a * coop) + ' ÷ (' + (a - coop) + ') = ' + b + ' 天。';
            return Q(q, o, '进阶', exp, '合作效率反求', { name: 'gEngineer', bars: [{ l: '甲', v: a }, { l: '合作', v: coop }] });
        } else {
            var save = a - coop;
            var o = opts(save, function() { 
                return rnd(1, Math.max(save + 8, a + 4)); 
            });
            var q = '甲单独做 ' + a + ' 天，两人合作 ' + coop + ' 天。合作比甲单独少用几天？';
            var exp = '甲单独 ' + a + ' 天，合作 ' + coop + ' 天，少用 ' + a + ' − ' + coop + ' = ' + save + ' 天（效率越高用时越短）。';
            return Q(q, o, '基础', exp, '效率比较', { name: 'gEngineer', bars: [{ l: '甲', v: a }, { l: '合作', v: coop }] });
        }
    }

    /* ============================================================
     * 12. 相遇问题（六年级）- 100+ 种组合
     * ============================================================ */
    function qMeet() {
        var type = rnd(0, 2);
        var v1 = rnd(20, 120);
        var v2 = rnd(15, 100);
        while (v1 === v2) { v2 = rnd(15, 100); }
        var vsum = v1 + v2;
        if (type === 0) {
            var t = rnd(1, 10);
            var s = vsum * t;
            var o = opts(t, function() { 
                return rnd(1, t + 8); 
            });
            var q = '甲、乙从相距 ' + s + ' 千米两地同时相向出发，甲速 ' + v1 + ' 千米/时，乙速 ' + v2 + ' 千米/时。几小时相遇？';
            var exp = '相遇时间 = 路程 ÷ 速度和 = ' + s + ' ÷ (' + v1 + ' + ' + v2 + ') = ' + s + ' ÷ ' + vsum + ' = ' + t + ' 小时。';
            return Q(q, o, '基础', exp, '相遇：s=(v1+v2)t', { name: 'gMeet', s: s, v1: v1, v2: v2, t: t, show: { s: 1, v1: 1, v2: 1, t: 0 } });
        } else if (type === 1) {
            var t = rnd(1, 10);
            var s = vsum * t;
            var o = opts(s, function() { 
                return vsum * rnd(1, t + 5); 
            });
            var q = '甲速 ' + v1 + ' 千米/时、乙速 ' + v2 + ' 千米/时，相向而行 ' + t + ' 小时后相遇。两地相距多少千米？';
            var exp = '路程 = 速度和 × 时间 = (' + v1 + ' + ' + v2 + ') × ' + t + ' = ' + vsum + ' × ' + t + ' = ' + s + ' 千米。';
            return Q(q, o, '基础', exp, '相遇：s=(v1+v2)t', { name: 'gMeet', s: s, v1: v1, v2: v2, t: t, show: { s: 0, v1: 1, v2: 1, t: 1 } });
        } else {
            var t = rnd(1, 10);
            var s = vsum * t;
            var askV1 = Math.random() < 0.5;
            var ans = askV1 ? v1 : v2;
            var knownV = askV1 ? v2 : v1;
            var o = opts(ans, function() { 
                return rnd(10, 130); 
            });
            var q = '两地相距 ' + s + ' 千米，相向而行 ' + t + ' 小时相遇；' + (askV1 ? '乙' : '甲') + '速 ' + knownV + ' 千米/时，' + (askV1 ? '甲' : '乙') + '速多少？';
            var exp = '速度和 = ' + s + ' ÷ ' + t + ' = ' + vsum + '；' + (askV1 ? '甲' : '乙') + '速 = 速度和 − ' + (askV1 ? '乙' : '甲') + '速 = ' + vsum + ' − ' + knownV + ' = ' + ans + ' 千米/时。';
            return Q(q, o, '进阶', exp, '相遇：求速度和', { name: 'gMeet', s: s, v1: v1, v2: v2, t: t, show: { s: 1, v1: askV1 ? 0 : 1, v2: askV1 ? 1 : 0, t: 1 } });
        }
    }

    /* ============================================================
     * 13. 追及问题（六年级）- 100+ 种组合
     * ============================================================ */
    function qChase() {
        var type = rnd(0, 2);
        var v2 = rnd(10, 90);
        var dv = rnd(2, 45);
        var v1 = v2 + dv;
        if (type === 0) {
            var t = rnd(1, 10);
            var ds = dv * t;
            var o = opts(t, function() { 
                return rnd(1, t + 8); 
            });
            var q = '甲速 ' + v1 + ' 千米/时，乙速 ' + v2 + ' 千米/时，乙先走 ' + ds + ' 千米后甲同向追乙。几小时追上？';
            var exp = '追及时间 = 路程差 ÷ 速度差 = ' + ds + ' ÷ (' + v1 + ' − ' + v2 + ') = ' + ds + ' ÷ ' + dv + ' = ' + t + ' 小时。';
            return Q(q, o, '基础', exp, '追及：t=Δs÷(v1−v2)', { name: 'gChase', v1: v1, v2: v2, ds: ds, t: t, show: { v1: 1, v2: 1, ds: 1, t: 0 } });
        } else if (type === 1) {
            var t = rnd(1, 10);
            var ds = dv * t;
            var o = opts(ds, function() { 
                return dv * rnd(1, t + 6); 
            });
            var q = '甲速 ' + v1 + ' 千米/时、乙速 ' + v2 + ' 千米/时，同向而行，' + t + ' 小时后甲追上乙。乙先走了多少千米？';
            var exp = '路程差 = 速度差 × 时间 = (' + v1 + ' − ' + v2 + ') × ' + t + ' = ' + dv + ' × ' + t + ' = ' + ds + ' 千米。';
            return Q(q, o, '基础', exp, '追及：Δs=(v1−v2)t', { name: 'gChase', v1: v1, v2: v2, ds: ds, t: t, show: { v1: 1, v2: 1, ds: 0, t: 1 } });
        } else {
            var t = rnd(1, 10);
            var ds = dv * t;
            var o = opts(v2, function() { 
                return rnd(10, v1 + 25); 
            });
            var q = '甲速 ' + v1 + ' 千米/时，乙先走 ' + ds + ' 千米，' + t + ' 小时后甲追上乙。乙速多少？';
            var exp = '速度差 = 路程差 ÷ 时间 = ' + ds + ' ÷ ' + t + ' = ' + dv + '；乙速 = 甲速 − 速度差 = ' + v1 + ' − ' + dv + ' = ' + v2 + ' 千米/时。';
            return Q(q, o, '进阶', exp, '追及：求速度差', { name: 'gChase', v1: v1, v2: v2, ds: ds, t: t, show: { v1: 1, v2: 0, ds: 1, t: 1 } });
        }
    }

    /* ============================================================
     * 14. 分数（五年级）- 100+ 种组合
     * ============================================================ */
    function qFraction() {
        var type = rnd(0, 4);
        var q, ans, o, exp, point;
        
        if (type === 0) {
            var denom = rnd(2, 8);
            var num1 = rnd(1, denom - 1);
            var num2 = rnd(1, denom - num1 - 1);
            while (num2 < 1) { num2 = rnd(1, denom - num1 - 1); }
            ans = (num1 + num2) / denom;
            var ansStr = (num1 + num2) + '/' + denom;
            if ((num1 + num2) % denom === 0) { ansStr = String((num1 + num2) / denom); }
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = rnd(1, 10);
                var e = rnd(2, 10);
                var str = d + '/' + e;
                if (d % e === 0) { str = String(d / e); }
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = num1 + '/' + denom + ' + ' + num2 + '/' + denom + ' = ？';
            exp = '同分母相加：(' + num1 + ' + ' + num2 + ')/' + denom + ' = ' + (num1 + num2) + '/' + denom + (ansStr.indexOf('/') > -1 ? '' : ' = ' + ansStr);
            point = '同分母加法';
        } else if (type === 1) {
            var denom1 = rnd(2, 6);
            var denom2 = rnd(2, 6);
            while (denom1 === denom2) { denom2 = rnd(2, 6); }
            var lcm = denom1 * denom2 / gcd(denom1, denom2);
            var num1 = rnd(1, denom1 - 1);
            var num2 = rnd(1, denom2 - 1);
            var newNum1 = num1 * (lcm / denom1);
            var newNum2 = num2 * (lcm / denom2);
            ans = (newNum1 + newNum2) + '/' + lcm;
            var ansSimplified = simplifyFraction(newNum1 + newNum2, lcm);
            var optsArr = [];
            var used = new Set([ansSimplified]);
            while (optsArr.length < 3) {
                var d = rnd(1, 8);
                var e = rnd(2, 10);
                var str = d + '/' + e;
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansSimplified].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansSimplified) };
            q = num1 + '/' + denom1 + ' + ' + num2 + '/' + denom2 + ' = ？';
            exp = '通分：' + num1 + '/' + denom1 + ' = ' + newNum1 + '/' + lcm + '，' + num2 + '/' + denom2 + ' = ' + newNum2 + '/' + lcm + '，和 = ' + ans + ' = ' + ansSimplified;
            point = '异分母加法';
        } else if (type === 2) {
            var denom = rnd(3, 8);
            var num1 = rnd(2, denom - 1);
            var num2 = rnd(1, num1 - 1);
            while (num2 < 1) { num2 = rnd(1, num1 - 1); }
            ans = (num1 - num2) + '/' + denom;
            var ansSimplified = simplifyFraction(num1 - num2, denom);
            var optsArr = [];
            var used = new Set([ansSimplified]);
            while (optsArr.length < 3) {
                var d = rnd(1, 8);
                var e = rnd(2, 10);
                var str = d + '/' + e;
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansSimplified].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansSimplified) };
            q = num1 + '/' + denom + ' − ' + num2 + '/' + denom + ' = ？';
            exp = '同分母相减：(' + num1 + ' − ' + num2 + ')/' + denom + ' = ' + (num1 - num2) + '/' + denom + ' = ' + ansSimplified;
            point = '同分母减法';
        } else if (type === 3) {
            var a = rnd(1, 4);
            var b = rnd(1, 3);
            var c = rnd(1, 4);
            var d = rnd(1, 3);
            ans = (a * d + b * c) + '/' + (b * d);
            var ansSimplified = simplifyFraction(a * d + b * c, b * d);
            var optsArr = [];
            var used = new Set([ansSimplified]);
            while (optsArr.length < 3) {
                var dd = rnd(1, 8);
                var ee = rnd(2, 10);
                var str = dd + '/' + ee;
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansSimplified].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansSimplified) };
            q = a + '/' + b + ' + ' + c + '/' + d + ' = ？';
            exp = a + '/' + b + ' + ' + c + '/' + d + ' = ' + (a * d + b * c) + '/' + (b * d) + ' = ' + ansSimplified;
            point = '分数加法';
        } else {
            var a = rnd(1, 5);
            var b = rnd(2, 6);
            var c = rnd(1, 4);
            var d = rnd(2, 6);
            ans = (a * d) + '/' + (b * c);
            var ansSimplified = simplifyFraction(a * d, b * c);
            var optsArr = [];
            var used = new Set([ansSimplified]);
            while (optsArr.length < 3) {
                var dd = rnd(1, 8);
                var ee = rnd(2, 10);
                var str = dd + '/' + ee;
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansSimplified].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansSimplified) };
            q = a + '/' + b + ' ÷ ' + c + '/' + d + ' = ？';
            exp = a + '/' + b + ' ÷ ' + c + '/' + d + ' = ' + a + '/' + b + ' × ' + d + '/' + c + ' = ' + (a * d) + '/' + (b * c) + ' = ' + ansSimplified;
            point = '分数除法';
        }
        return Q(q, o, '基础', exp, point);
    }

    function gcd(a, b) {
        while (b) { var t = b; b = a % b; a = t; }
        return a;
    }
    function simplifyFraction(num, den) {
        var g = gcd(Math.abs(num), Math.abs(den));
        num = num / g;
        den = den / g;
        if (den === 1) return String(num);
        return num + '/' + den;
    }

    /* ============================================================
     * 15. 鸡兔同笼（五年级）- 100+ 种组合
     * ============================================================ */
    function qChicken() {
        var H = rnd(5, 30);
        var R = rnd(1, Math.max(2, H - 2));
        var C = H - R;
        if (C < 1 || R < 1) return qChicken();
        var F = 2 * C + 4 * R;
        var askRabbit = Math.random() < 0.5;
        var ans = askRabbit ? R : C;
        var o = opts(ans, function() { 
            return rnd(1, Math.max(2, H - 1)); 
        });
        var q = '鸡兔同笼：共有 ' + H + ' 个头，' + F + ' 只脚。问' + (askRabbit ? '兔' : '鸡') + '有几只？';
        var explain = askRabbit
            ? '假设全是鸡，应有 ' + (2 * H) + ' 只脚，实际多 ' + (F - 2 * H) + ' 只；每只兔比鸡多 2 脚，兔 = (' + F + ' − ' + (2 * H) + ') ÷ 2 = ' + R + ' 只。'
            : '假设全是兔，应有 ' + (4 * H) + ' 只脚，实际少 ' + (4 * H - F) + ' 只；每只鸡比兔少 2 脚，鸡 = (' + (4 * H) + ' − ' + F + ') ÷ 2 = ' + C + ' 只。';
        return Q(q, o, '基础', explain, '假设法/抬脚法', { name: 'gChicken', H: H, F: F, C: C, R: R });
    }

    /* ============================================================
     * 16. 圆（六年级）- 100+ 种组合
     * ============================================================ */
    function qCircle() {
        var type = rnd(0, 3);
        var q, ans, o, exp, point;
        
        if (type === 0) {
            var r = rnd(2, 15);
            ans = 2 * Math.PI * r;
            var ansStr = ans.toFixed(1);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = 2 * Math.PI * rnd(1, 20);
                var str = d.toFixed(1);
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '半径为 ' + r + ' 的圆，周长是多少？（π取3.14）';
            exp = '周长 C = 2πr = 2 × 3.14 × ' + r + ' = ' + ansStr;
            point = '圆周长';
        } else if (type === 1) {
            var r = rnd(2, 15);
            ans = Math.PI * r * r;
            var ansStr = ans.toFixed(1);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = Math.PI * rnd(1, 20) * rnd(1, 20);
                var str = d.toFixed(1);
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '半径为 ' + r + ' 的圆，面积是多少？（π取3.14）';
            exp = '面积 S = πr² = 3.14 × ' + r + '² = ' + ansStr;
            point = '圆面积';
        } else if (type === 2) {
            var d = rnd(4, 30);
            var r = d / 2;
            ans = Math.PI * r + d;
            var ansStr = ans.toFixed(1);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var dd = Math.PI * rnd(1, 20) + rnd(2, 40);
                var str = dd.toFixed(1);
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '直径为 ' + d + ' 的半圆，周长是多少？（π取3.14）';
            exp = '半圆周长 = πr + 2r = 3.14 × ' + r + ' + ' + d + ' = ' + ansStr;
            point = '半圆周长';
        } else {
            var r = rnd(2, 10);
            var newR = r * rnd(2, 4);
            ans = newR * newR / (r * r);
            var ansStr = ans.toFixed(1);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = rnd(1, 8) * rnd(1, 8) / (rnd(1, 4) * rnd(1, 4));
                var str = d.toFixed(1);
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '半径从 ' + r + ' 扩大到 ' + newR + '，面积扩大多少倍？';
            exp = '面积比 = (' + newR + '²) ÷ (' + r + '²) = ' + ansStr + ' 倍';
            point = '面积变化';
        }
        return Q(q, o, '基础', exp, point);
    }

    /* ============================================================
     * 17. 圆柱与圆锥（六年级）- 100+ 种组合
     * ============================================================ */
    function qCylinder() {
        var type = rnd(0, 3);
        var q, ans, o, exp, point;
        
        if (type === 0) {
            var r = rnd(2, 10);
            var h = rnd(3, 12);
            ans = Math.PI * r * r * h;
            var ansStr = ans.toFixed(1);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = Math.PI * rnd(1, 15) * rnd(1, 15) * rnd(1, 15);
                var str = d.toFixed(1);
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '圆柱底面半径 ' + r + '，高 ' + h + '，体积是多少？（π取3.14）';
            exp = '体积 V = πr²h = 3.14 × ' + r + '² × ' + h + ' = ' + ansStr;
            point = '圆柱体积';
        } else if (type === 1) {
            var r = rnd(2, 10);
            var h = rnd(3, 12);
            ans = (1/3) * Math.PI * r * r * h;
            var ansStr = ans.toFixed(1);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = (1/3) * Math.PI * rnd(1, 15) * rnd(1, 15) * rnd(1, 15);
                var str = d.toFixed(1);
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '圆锥底面半径 ' + r + '，高 ' + h + '，体积是多少？（π取3.14）';
            exp = '体积 V = (1/3)πr²h = (1/3) × 3.14 × ' + r + '² × ' + h + ' = ' + ansStr;
            point = '圆锥体积';
        } else if (type === 2) {
            var r = rnd(2, 10);
            var h = rnd(3, 12);
            ans = 2 * Math.PI * r * h;
            var ansStr = ans.toFixed(1);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = 2 * Math.PI * rnd(1, 15) * rnd(1, 15);
                var str = d.toFixed(1);
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '圆柱底面半径 ' + r + '，高 ' + h + '，侧面积是多少？（π取3.14）';
            exp = '侧面积 S = 2πrh = 2 × 3.14 × ' + r + ' × ' + h + ' = ' + ansStr;
            point = '圆柱侧面积';
        } else {
            var r = rnd(2, 10);
            var h = rnd(3, 12);
            var vCyl = Math.PI * r * r * h;
            var vCone = (1/3) * vCyl;
            ans = vCyl / vCone;
            var ansStr = ans.toFixed(0);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = rnd(1, 5);
                var str = String(d);
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '同底等高的圆柱体积是圆锥体积的几倍？';
            exp = '圆柱体积 = πr²h，圆锥体积 = (1/3)πr²h，圆柱是圆锥的 3 倍。';
            point = '柱锥关系';
        }
        return Q(q, o, '基础', exp, point);
    }

    /* ============================================================
     * 18. 列方程解应用题（六年级）- 100+ 种组合
     * ============================================================ */
    function qEquation() {
        var type = rnd(0, 3);
        var q, ans, o, exp, point;
        
        if (type === 0) {
            var a = rnd(2, 5);
            var b = rnd(3, 15);
            var c = a * b + rnd(1, 10);
            ans = (c - b) / a;
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-3, 3);
                if (d !== ans && d > 0 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = a + 'x + ' + b + ' = ' + c + '，x = ？';
            exp = a + 'x = ' + c + ' − ' + b + ' = ' + (c - b) + '，x = ' + (c - b) + ' ÷ ' + a + ' = ' + ans;
            point = '解方程';
        } else if (type === 1) {
            var age = rnd(8, 15);
            var years = rnd(5, 20);
            var fatherAge = 2 * age + years;
            ans = years;
            var optsArr = [];
            var used = new Set([years]);
            while (optsArr.length < 3) {
                var d = years + rnd(-5, 5);
                if (d !== years && d > 0 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([years].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(years) };
            q = '儿子 ' + age + ' 岁，父亲 ' + fatherAge + ' 岁，几年后父亲年龄是儿子的 2 倍？';
            exp = '设 x 年后：' + fatherAge + ' + x = 2(' + age + ' + x)，解得 x = ' + years;
            point = '年龄问题';
        } else if (type === 2) {
            var diff = rnd(4, 20);
            var ratio = rnd(2, 5);
            var small = diff / (ratio - 1);
            while (small % 1 !== 0 || small < 1) {
                diff = rnd(4, 20);
                ratio = rnd(2, 5);
                small = diff / (ratio - 1);
            }
            var big = small * ratio;
            var askBig = Math.random() < 0.5;
            ans = askBig ? big : small;
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-5, 5);
                if (d !== ans && d > 0 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = '两数差 ' + diff + '，大数是小数的 ' + ratio + ' 倍。问' + (askBig ? '大数' : '小数') + '是多少？';
            exp = '设小数为 x：' + ratio + 'x − x = ' + diff + '，' + (ratio - 1) + 'x = ' + diff + '，x = ' + small + '，' + (askBig ? '大数 = ' + big : '小数 = ' + small);
            point = '差倍方程';
        } else {
            var total = rnd(20, 60);
            var chickens = rnd(5, total - 5);
            var rabbits = total - chickens;
            var feet = 2 * chickens + 4 * rabbits;
            var askChicken = Math.random() < 0.5;
            ans = askChicken ? chickens : rabbits;
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-5, 5);
                if (d !== ans && d > 0 && d < total && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = '鸡兔共 ' + total + ' 只，脚共 ' + feet + ' 只。' + (askChicken ? '鸡' : '兔') + '有几只？';
            exp = '设' + (askChicken ? '鸡' : '兔') + '为 x：' + (askChicken ? '2x + 4(' + total + ' − x) = ' + feet : '4x + 2(' + total + ' − x) = ' + feet) + '，解得 x = ' + ans;
            point = '鸡兔同笼方程';
        }
        return Q(q, o, '基础', exp, point);
    }

    /* ============================================================
     * 19. 百分数与折扣（六年级）- 100+ 种组合
     * ============================================================ */
    function qPercent() {
        var type = rnd(0, 3);
        var q, ans, o, exp, point;
        
        if (type === 0) {
            var p = rnd(10, 90);
            var num = rnd(100, 500);
            ans = num * p / 100;
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-20, 20);
                if (d !== ans && d >= 0 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = num + ' 的 ' + p + '% 是多少？';
            exp = num + ' × ' + p + '% = ' + num + ' × ' + (p/100) + ' = ' + ans;
            point = '百分数计算';
        } else if (type === 1) {
            var discount = rnd(5, 9) * 10;
            var price = rnd(100, 500);
            ans = price * discount / 100;
            var optsArr = [];
            var used = new Set([ans]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-20, 20);
                if (d !== ans && d >= 0 && !used.has(d)) {
                    used.add(d);
                    optsArr.push(d);
                }
            }
            var allOpts = shuffle([ans].concat(optsArr));
            o = { opts: allOpts.map(String), ans: allOpts.indexOf(ans) };
            q = '原价 ' + price + ' 元，打 ' + (discount/10) + ' 折，现价多少？';
            exp = '现价 = ' + price + ' × ' + (discount/100) + ' = ' + ans + ' 元';
            point = '折扣计算';
        } else if (type === 2) {
            var original = rnd(100, 300);
            var increase = rnd(10, 50);
            var newPrice = original + increase;
            ans = increase / original * 100;
            var ansStr = ans.toFixed(0) + '%';
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = rnd(5, 60);
                var str = d + '%';
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '原价 ' + original + ' 元，涨到 ' + newPrice + ' 元，涨了百分之几？';
            exp = '涨幅 = (' + newPrice + ' − ' + original + ') ÷ ' + original + ' × 100% = ' + ansStr;
            point = '增长率';
        } else {
            var after = rnd(80, 200);
            var rate = rnd(10, 40);
            var before = after / (1 + rate / 100);
            ans = before;
            var ansStr = ans.toFixed(0);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = before + rnd(-30, 30);
                var str = d.toFixed(0);
                if (!used.has(str) && d > 0) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '某数增加 ' + rate + '% 后是 ' + after + '，原数是多少？';
            exp = '原数 = ' + after + ' ÷ (1 + ' + rate + '%) = ' + ansStr;
            point = '还原问题';
        }
        return Q(q, o, '基础', exp, point);
    }

    /* ============================================================
     * 20. 比和比例（五年级）- 100+ 种组合
     * ============================================================ */
    function qRatio() {
        var type = rnd(0, 3);
        var q, ans, o, exp, point;
        
        if (type === 0) {
            var a = rnd(2, 8);
            var b = rnd(2, 8);
            var g = gcd(a, b);
            var ansStr = (a/g) + ':' + (b/g);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d1 = rnd(1, 8);
                var d2 = rnd(1, 8);
                var str = d1 + ':' + d2;
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '化简比：' + a + ':' + b + ' = ？';
            exp = a + ':' + b + ' = ' + (a/g) + ':' + (b/g) + '（同除以 ' + g + '）';
            point = '化简比';
        } else if (type === 1) {
            var a = rnd(1, 5);
            var b = rnd(1, 5);
            var c = rnd(1, 5);
            var d = rnd(1, 5);
            var left = a * d;
            var right = b * c;
            ans = left === right;
            var ansStr = ans ? '成比例' : '不成比例';
            var optsArr = ['成比例', '不成比例'];
            var allOpts = shuffle(optsArr);
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = a + ':' + b + ' = ' + c + ':' + d + '，是否成比例？';
            exp = '内项积 = ' + b + ' × ' + c + ' = ' + (b * c) + '，外项积 = ' + a + ' × ' + d + ' = ' + (a * d) + (left === right ? '，相等，成比例' : '，不相等，不成比例');
            point = '比例判断';
        } else if (type === 2) {
            var map = rnd(1, 5);
            var actual = rnd(200, 1000);
            var cm = actual / map / 100;
            ans = cm;
            var ansStr = cm.toFixed(1);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = cm + rnd(-5, 5);
                var str = d.toFixed(1);
                if (!used.has(str) && d > 0) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '比例尺 1:' + (map * 10000) + '，实际距离 ' + actual + ' 米，图上距离多少厘米？';
            exp = '图上距离 = ' + actual + ' 米 ÷ ' + (map * 10000) + ' = ' + cm + ' 厘米';
            point = '比例尺';
        } else {
            var a = rnd(2, 6);
            var b = rnd(2, 6);
            var c = rnd(2, 6);
            var d = rnd(2, 6);
            var product = b * c;
            ans = product / a;
            var ansStr = ans.toFixed(1);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var dd = product / rnd(1, 8);
                var str = dd.toFixed(1);
                if (!used.has(str) && dd > 0) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = a + ':' + b + ' = ' + c + ':x，x = ？';
            exp = '内项积 = 外项积：' + b + ' × ' + c + ' = ' + a + ' × x，x = ' + (b * c) + ' ÷ ' + a + ' = ' + ansStr;
            point = '解比例';
        }
        return Q(q, o, '基础', exp, point);
    }

    /* ============================================================
     * 21. 小数运算（五年级）- 100+ 种组合
     * ============================================================ */
    function qDecimal() {
        var type = rnd(0, 3);
        var q, ans, o, exp, point;
        
        if (type === 0) {
            var a = rnd(10, 90) / 10;
            var b = rnd(10, 90) / 10;
            ans = a + b;
            var ansStr = ans.toFixed(1);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-5, 5) / 10;
                var str = d.toFixed(1);
                if (!used.has(str) && d > 0) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = a + ' + ' + b + ' = ？';
            exp = a + ' + ' + b + ' = ' + ansStr;
            point = '小数加法';
        } else if (type === 1) {
            var a = rnd(20, 90) / 10;
            var b = rnd(10, a * 10 - 1) / 10;
            ans = a - b;
            var ansStr = ans.toFixed(1);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-5, 5) / 10;
                var str = d.toFixed(1);
                if (!used.has(str) && d >= 0) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = a + ' − ' + b + ' = ？';
            exp = a + ' − ' + b + ' = ' + ansStr;
            point = '小数减法';
        } else if (type === 2) {
            var a = rnd(2, 9);
            var b = rnd(1, 9) / 10;
            ans = a * b;
            var ansStr = ans.toFixed(1);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-5, 5) / 10;
                var str = d.toFixed(1);
                if (!used.has(str) && d > 0) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = a + ' × ' + b + ' = ？';
            exp = a + ' × ' + b + ' = ' + ansStr;
            point = '小数乘法';
        } else {
            var a = rnd(1, 9);
            var b = rnd(1, 9) / 10;
            ans = a / b;
            var ansStr = ans.toFixed(1);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-5, 5);
                var str = d.toFixed(1);
                if (!used.has(str) && d > 0) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = a + ' ÷ ' + b + ' = ？';
            exp = a + ' ÷ ' + b + ' = ' + ansStr + '（除数变整数：' + a + ' ÷ ' + b + ' = ' + (a * 10) + ' ÷ ' + (b * 10) + ' = ' + ansStr + '）';
            point = '小数除法';
        }
        return Q(q, o, '基础', exp, point);
    }

    /* ============================================================
     * 22. 利润与税率（六年级）- 100+ 种组合
     * ============================================================ */
    function qProfit() {
        var type = rnd(0, 3);
        var q, ans, o, exp, point;
        
        if (type === 0) {
            var cost = rnd(50, 200);
            var price = rnd(cost + 20, cost + 100);
            ans = (price - cost) / cost * 100;
            var ansStr = ans.toFixed(0) + '%';
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = rnd(5, 60);
                var str = d + '%';
                if (!used.has(str)) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '进价 ' + cost + ' 元，售价 ' + price + ' 元，利润率是多少？';
            exp = '利润率 = (' + price + ' − ' + cost + ') ÷ ' + cost + ' × 100% = ' + ansStr;
            point = '利润率';
        } else if (type === 1) {
            var cost = rnd(50, 150);
            var rate = rnd(10, 40);
            ans = cost * (1 + rate / 100);
            var ansStr = ans.toFixed(0);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-20, 20);
                var str = d.toFixed(0);
                if (!used.has(str) && d > 0) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '成本 ' + cost + ' 元，想赚 ' + rate + '%，售价应定为多少？';
            exp = '售价 = ' + cost + ' × (1 + ' + rate + '%) = ' + ansStr + ' 元';
            point = '定价';
        } else if (type === 2) {
            var price = rnd(100, 300);
            var discount = rnd(6, 9) * 10;
            ans = price * discount / 100;
            var ansStr = ans.toFixed(0);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-20, 20);
                var str = d.toFixed(0);
                if (!used.has(str) && d > 0) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '标价 ' + price + ' 元，打 ' + (discount/10) + ' 折，售价是多少？';
            exp = '售价 = ' + price + ' × ' + (discount/100) + ' = ' + ansStr + ' 元';
            point = '打折';
        } else {
            var price = rnd(100, 300);
            var rate = rnd(5, 20);
            ans = price * rate / 100;
            var ansStr = ans.toFixed(0);
            var optsArr = [];
            var used = new Set([ansStr]);
            while (optsArr.length < 3) {
                var d = ans + rnd(-10, 10);
                var str = d.toFixed(0);
                if (!used.has(str) && d >= 0) {
                    used.add(str);
                    optsArr.push(str);
                }
            }
            var allOpts = shuffle([ansStr].concat(optsArr));
            o = { opts: allOpts, ans: allOpts.indexOf(ansStr) };
            q = '售价 ' + price + ' 元，税率 ' + rate + '%，应纳税多少？';
            exp = '税额 = ' + price + ' × ' + rate + '% = ' + ansStr + ' 元';
            point = '税率计算';
        }
        return Q(q, o, '基础', exp, point);
    }

    /* ============================================================
     * 注册到 window.TECHNIQUES
     * ============================================================ */
    var GEN = { 
        count: qCount,
        addsub: qAddSub,
        multi: qMulti,
        divide: qDivide,
        fourops: qFourOps,
        plant: qPlant,
        sumdiff: qSumDiff,
        profitloss: qProfit,
        average: qAvg,
        cycle: qCycle,
        guiyi: qGuiyi,
        engineer: qEngineer,
        meet: qMeet,
        chase: qChase,
        fraction: qFraction,
        chicken: qChicken,
        circle: qCircle,
        cylinder: qCylinder,
        equation: qEquation,
        percent: qPercent,
        ratio: qRatio,
        decimal: qDecimal,
        profit: qProfit
    };

    if (window.TECHNIQUES) {
        window.TECHNIQUES.forEach(function(t) {
            if (GEN[t.id]) {
                t.qgen = function(n) { 
                    var out = []; 
                    for (var i = 0; i < (n || 8); i++) {
                        out.push(GEN[t.id]()); 
                    }
                    return out; 
                };
            }
        });
    }
    window.QGEN_READY = true;
})();