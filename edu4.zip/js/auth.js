// 前端认证模块
(function() {
    'use strict';

    let currentUser = null;

    function init() {
        // 检查登录状态
        fetch('api/auth.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'check'})
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                currentUser = data.user;
                updateUI();
            }
        })
        .catch(() => {});
    }

    function getCurrentUser() {
        return currentUser;
    }

    function isLoggedIn() {
        return currentUser !== null;
    }

    function updateUI() {
        const display = document.getElementById('usernameDisplay');
        const badge = document.getElementById('roleBadge');
        if (display && currentUser) {
            display.textContent = currentUser.username;
        }
        if (badge && currentUser) {
            badge.textContent = currentUser.role;
        }
    }

    window.Auth = {
        init: init,
        getCurrentUser: getCurrentUser,
        isLoggedIn: isLoggedIn
    };
})();