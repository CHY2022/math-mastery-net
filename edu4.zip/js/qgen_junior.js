/* ============================================================
 * 融会贯通 · 初中数学方法参数化出题引擎（超强版）
 * 每个技巧每次生成 8 道题，题库组合 200+ 种
 * 覆盖：有理数、整式、一元一次方程、不等式、方程组、
 *       线段角、三角形、全等、相似、勾股定理、
 *       四边形、圆、一次函数、反比例函数、二次函数
 * ============================================================ */
(function () {
    'use strict';

    var K = { ink: "#334155", sub: "#64748b", line: "#cbd5e1", pri: "#2f6fed", ok: "#16a34a", warn: "#d97706", red: "#dc2626", soft: "#eef3ff", blue: "#2563eb" };
    
    function rnd(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
    function pick(a) { return a[rnd(0, a.length - 1)]; }
    function shuffle(a) { 
        a = a.slice(); 
        for (var i = a.length - 1; i > 0; i--) { 
            var j = Math.floor(Math.random() * (i + 1)); 
            var t = a[i]; 
            a[i] = a[j]; 
            a[j] = t; 
        } 
        return a; 
    }

    function opts(ans, make, n) {
        n = n || 4;
        var set = new Set([ans]);
        var g = 0;
        while (set.size < n && g++ < 400) { 
            var d = make(); 
            if (d !== ans) set.add(d); 
        }
        var k = 1;
        while (set.size < n) { 
            set.add(ans + k); 
            if (set.size < n) set.add(ans - k); 
            k++; 
        }
        var arr = shuffle([].slice.call(set)).map(String);
        return { opts: arr, ans: arr.indexOf(String(ans)) };
    }

    function Q(q, optsObj, level, explain, point, fig) {
        return Object.assign({ q: q, level: level || "基础", explain: explain, point: point || "" }, optsObj, { fig: fig || null });
    }

    /* ============================================================
     * 1. 有理数与数轴（七年级）- 200+ 种组合
     * ============================================================ */
    function qRational(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var a = rnd(-99, 99);
                var absA = Math.abs(a);
                o = opts(absA, function() { return rnd(-100, 100); });
                q = '|' + a + '| = ？';
                exp = '绝对值表示数轴上点到原点的距离，|' + a + '| = ' + absA + '。';
            } else if (type === 1) {
                var a = rnd(-99, 99);
                var opp = -a;
                o = opts(opp, function() { return rnd(-100, 100); });
                q = a + ' 的相反数是？';
                exp = '相反数只变符号，' + a + ' 的相反数是 ' + opp + '。';
            } else if (type === 2) {
                var a = rnd(-50, -1);
                var b = rnd(1, 50);
                o = opts(b, function() { return rnd(-60, 60); });
                q = '比较 ' + a + ' 与 ' + b + '，较大的是？';
                exp = '正数大于负数，' + b + ' > ' + a + '，较大的是 ' + b + '。';
            } else if (type === 3) {
                var a = rnd(1, 50);
                var b = rnd(-50, -1);
                o = opts(a, function() { return rnd(-60, 60); });
                q = '比较 ' + a + ' 与 ' + b + '，较大的是？';
                exp = '正数大于负数，' + a + ' > ' + b + '，较大的是 ' + a + '。';
            } else if (type === 4) {
                var a = rnd(-99, 99);
                var b = rnd(-99, 99);
                while (a === b) b = rnd(-99, 99);
                var larger = a > b ? a : b;
                o = opts(larger, function() { return rnd(-100, 100); });
                q = '比较 ' + a + ' 与 ' + b + '，较大的是？';
                exp = larger + ' 更大。';
            } else {
                var a = rnd(-50, 50);
                var absVal = Math.abs(a);
                var recip = a !== 0 ? 1 / a : 0;
                o = opts(recip.toFixed(2), function() { return (1 / rnd(-20, 20)).toFixed(2); });
                q = a + ' 的倒数是？';
                exp = a + ' 的倒数是 ' + recip.toFixed(2) + '。';
            }
            results.push(Q(q, o, '基础', exp, '有理数基础'));
        }
        return results;
    }

    /* ============================================================
     * 2. 整式加减（七年级）- 200+ 种组合
     * ============================================================ */
    function qIntegral(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 5;
            var q, ans, o, exp;
            if (type === 0) {
                var a1 = rnd(1, 12);
                var a2 = rnd(1, 12);
                var sum = a1 + a2;
                o = opts(sum + 'x', function() { return rnd(1, 25) + 'x'; });
                q = a1 + 'x + ' + a2 + 'x = ？';
                exp = '同类项合并：系数相加 ' + a1 + ' + ' + a2 + ' = ' + sum + '，字母不变。';
            } else if (type === 1) {
                var a = rnd(1, 8);
                var b = rnd(1, 15);
                o = opts('-' + a + 'x + ' + b, function() { return '-' + rnd(1, 12) + 'x + ' + rnd(1, 20); });
                q = '−(' + a + 'x − ' + b + ') = ？';
                exp = '括号前是负号，去括号后各项变号：−' + a + 'x + ' + b + '。';
            } else if (type === 2) {
                var a = rnd(2, 10);
                o = opts('-' + a, function() { return rnd(-12, 12); });
                q = '单项式 −' + a + 'x² 的系数是？';
                exp = '单项式的系数是数字因数，−' + a + 'x² 的系数是 ' + (-a) + '。';
            } else if (type === 3) {
                var a = rnd(1, 8);
                var b = rnd(1, 8);
                var c = rnd(1, 8);
                o = opts((a + b) + 'x + ' + c, function() { return rnd(1, 20) + 'x + ' + rnd(1, 15); });
                q = '(' + a + 'x + ' + c + ') + (' + b + 'x) = ？';
                exp = '合并同类项：' + a + 'x + ' + b + 'x + ' + c + ' = ' + (a + b) + 'x + ' + c + '。';
            } else {
                var a = rnd(1, 8);
                var b = rnd(1, 8);
                var c = rnd(1, 8);
                var d = rnd(1, 8);
                o = opts((a - b) + 'x + ' + (c - d), function() { return rnd(-15, 15) + 'x + ' + rnd(-15, 15); });
                q = '(' + a + 'x + ' + c + ') − (' + b + 'x + ' + d + ') = ？';
                exp = '去括号合并：' + (a - b) + 'x + ' + (c - d) + '。';
            }
            results.push(Q(q, o, '基础', exp, '整式加减'));
        }
        return results;
    }

    /* ============================================================
     * 3. 一元一次方程（七年级）- 200+ 种组合
     * ============================================================ */
    function qLinear(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var x = rnd(1, 20);
                var a = rnd(2, 6);
                var b = rnd(1, 20);
                var c = a * x + b;
                o = opts(x, function() { return rnd(1, 25); });
                q = a + 'x + ' + b + ' = ' + c + '，x = ？';
                exp = '移项：' + a + 'x = ' + c + ' − ' + b + ' = ' + (c - b) + '，x = ' + (c - b) + ' ÷ ' + a + ' = ' + x + '。';
            } else if (type === 1) {
                var x = rnd(1, 15);
                var a = rnd(2, 5);
                var b = rnd(1, 10);
                var c = a * (x + b);
                o = opts(x, function() { return rnd(1, 20); });
                q = a + '(x + ' + b + ') = ' + c + '，x = ？';
                exp = '去括号：x + ' + b + ' = ' + c + ' ÷ ' + a + ' = ' + (c / a) + '，x = ' + (c / a) + ' − ' + b + ' = ' + x + '。';
            } else if (type === 2) {
                var age = rnd(5, 18);
                var years = rnd(3, 20);
                var fatherAge = 2 * age + years;
                o = opts(years, function() { return rnd(1, 25); });
                q = '儿子 ' + age + ' 岁，父亲 ' + fatherAge + ' 岁，几年后父亲年龄是儿子的 2 倍？';
                exp = '设 x 年后：' + fatherAge + ' + x = 2(' + age + ' + x)，解得 x = ' + years + '。';
            } else if (type === 3) {
                var x = rnd(1, 15);
                var a = rnd(2, 6);
                var b = rnd(1, 10);
                var c = a * x - b;
                o = opts(x, function() { return rnd(1, 20); });
                q = a + 'x − ' + b + ' = ' + c + '，x = ？';
                exp = '移项：' + a + 'x = ' + c + ' + ' + b + ' = ' + (c + b) + '，x = ' + (c + b) + ' ÷ ' + a + ' = ' + x + '。';
            } else if (type === 4) {
                var x = rnd(2, 20);
                var a = rnd(2, 5);
                var b = a * x;
                o = opts(x, function() { return rnd(1, 25); });
                q = b + ' ÷ x = ' + a + '，x = ？';
                exp = 'x = ' + b + ' ÷ ' + a + ' = ' + x + '。';
            } else {
                var x = rnd(1, 12);
                var a = rnd(2, 5);
                var b = rnd(1, 8);
                var c = rnd(1, 8);
                var d = a * x + b;
                o = opts(x, function() { return rnd(1, 18); });
                q = a + 'x + ' + b + ' = ' + d + ' − ' + c + '，x = ？';
                exp = a + 'x + ' + b + ' = ' + (d - c) + '，' + a + 'x = ' + (d - c - b) + '，x = ' + (d - c - b) / a + '。';
            }
            results.push(Q(q, o, type < 3 ? '基础' : '进阶', exp, '一元一次方程'));
        }
        return results;
    }

    /* ============================================================
     * 4. 一元一次不等式（七年级）- 200+ 种组合
     * ============================================================ */
    function qInequal(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 5;
            var q, ans, o, exp;
            if (type === 0) {
                var x = rnd(2, 15);
                var a = rnd(2, 5);
                var b = rnd(1, 15);
                var c = a * x + b;
                o = opts('x < ' + x, function() { return 'x > ' + rnd(1, 18); });
                q = '解不等式 ' + a + 'x + ' + b + ' < ' + c + '，解集是？';
                exp = '移项：' + a + 'x < ' + c + ' − ' + b + ' = ' + (c - b) + '，x < ' + (c - b) + ' ÷ ' + a + ' = ' + x + '。';
            } else if (type === 1) {
                var x = rnd(2, 15);
                var a = rnd(2, 5);
                var b = rnd(1, 15);
                var c = a * x + b;
                o = opts('x > ' + x, function() { return 'x < ' + rnd(1, 18); });
                q = '解不等式 ' + a + 'x + ' + b + ' > ' + c + '，解集是？';
                exp = '移项：' + a + 'x > ' + c + ' − ' + b + ' = ' + (c - b) + '，x > ' + (c - b) + ' ÷ ' + a + ' = ' + x + '。';
            } else if (type === 2) {
                var x = rnd(2, 15);
                var a = rnd(2, 5);
                var b = rnd(1, 15);
                var c = a * x + b;
                o = opts('x ≤ ' + x, function() { return 'x ≥ ' + rnd(1, 18); });
                q = '解不等式 ' + a + 'x + ' + b + ' ≤ ' + c + '，解集是？';
                exp = '移项：' + a + 'x ≤ ' + c + ' − ' + b + ' = ' + (c - b) + '，x ≤ ' + (c - b) + ' ÷ ' + a + ' = ' + x + '。';
            } else if (type === 3) {
                var x = rnd(2, 15);
                var a = rnd(2, 5);
                var b = rnd(1, 15);
                var c = a * x + b;
                o = opts('x ≥ ' + x, function() { return 'x ≤ ' + rnd(1, 18); });
                q = '解不等式 ' + a + 'x + ' + b + ' ≥ ' + c + '，解集是？';
                exp = '移项：' + a + 'x ≥ ' + c + ' − ' + b + ' = ' + (c - b) + '，x ≥ ' + (c - b) + ' ÷ ' + a + ' = ' + x + '。';
            } else {
                var a = rnd(1, 5);
                var b = rnd(1, 10);
                var c = a * rnd(1, 5) + b + 5;
                o = opts('x < ' + ((c - b) / a), function() { return 'x > ' + rnd(1, 15); });
                q = '解不等式 ' + a + 'x + ' + b + ' < ' + c + '，解集是？';
                exp = '移项：' + a + 'x < ' + (c - b) + '，x < ' + (c - b) / a + '。';
            }
            results.push(Q(q, o, '基础', exp, '一元一次不等式'));
        }
        return results;
    }

    /* ============================================================
     * 5. 二元一次方程组（七年级）- 200+ 种组合
     * ============================================================ */
    function qSystem(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 5;
            var q, ans, o, exp;
            if (type === 0) {
                var x = rnd(1, 12);
                var y = rnd(1, 12);
                var a1 = rnd(1, 4);
                var b1 = rnd(1, 4);
                var c1 = a1 * x + b1 * y;
                var a2 = rnd(1, 4);
                var b2 = rnd(1, 4);
                var c2 = a2 * x + b2 * y;
                o = opts(x + ',' + y, function() { return rnd(1, 15) + ',' + rnd(1, 15); });
                q = '方程组 ' + a1 + 'x + ' + b1 + 'y = ' + c1 + ' 与 ' + a2 + 'x + ' + b2 + 'y = ' + c2 + ' 的解是？';
                exp = '代入检验：' + a1 + '×' + x + ' + ' + b1 + '×' + y + ' = ' + c1 + '，' + a2 + '×' + x + ' + ' + b2 + '×' + y + ' = ' + c2 + '，解为 x=' + x + ', y=' + y + '。';
            } else if (type === 1) {
                var x = rnd(1, 10);
                var y = rnd(1, 10);
                var c1 = 2 * x + 3 * y;
                var c2 = 3 * x - 2 * y;
                o = opts(x + ',' + y, function() { return rnd(1, 12) + ',' + rnd(1, 12); });
                q = '方程组 2x + 3y = ' + c1 + ' 与 3x − 2y = ' + c2 + ' 的解是？';
                exp = '加减消元：×2 + ×3 消 y，得 x = ' + x + '，代入得 y = ' + y + '。';
            } else if (type === 2) {
                var a = rnd(1, 8);
                var b = rnd(1, 8);
                var total = a + b;
                var diff = Math.abs(a - b);
                o = opts(a + '个苹果', function() { return rnd(1, 15) + '个苹果'; });
                q = '买苹果和梨共 ' + total + ' 个，苹果比梨多 ' + diff + ' 个，苹果有几个？';
                exp = '设苹果 x 个：x + (x − ' + diff + ') = ' + total + '，解得 x = ' + a + '。';
            } else if (type === 3) {
                var a = rnd(2, 10);
                var b = rnd(2, 10);
                var total = a + b;
                var diff = Math.abs(a - b);
                o = opts(a + '只鸡', function() { return rnd(1, 15) + '只鸡'; });
                q = '鸡和兔共 ' + total + ' 只，鸡比兔多 ' + diff + ' 只，鸡有几只？';
                exp = '设鸡 x 只：x + (x − ' + diff + ') = ' + total + '，解得 x = ' + a + '。';
            } else {
                var a = rnd(1, 6);
                var b = rnd(1, 6);
                var total = 3 * a + 2 * b;
                o = opts(a + ',' + b, function() { return rnd(1, 8) + ',' + rnd(1, 8); });
                q = '3x + 2y = ' + total + '，x + y = ' + (a + b) + '，x 和 y 分别是？';
                exp = 'x = ' + a + ', y = ' + b + '。';
            }
            results.push(Q(q, o, type < 3 ? '基础' : '进阶', exp, '二元一次方程组'));
        }
        return results;
    }

    /* ============================================================
     * 6. 线段与角（七年级）- 200+ 种组合
     * ============================================================ */
    function qSegAngle(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 5;
            var q, ans, o, exp;
            if (type === 0) {
                var a = rnd(2, 20) * 2;
                var mid = a / 2;
                o = opts(mid, function() { return rnd(1, 25); });
                q = '线段 AB = ' + a + 'cm，M 是 AB 中点，AM = ？';
                exp = '中点分线段为两等份，AM = AB ÷ 2 = ' + a + ' ÷ 2 = ' + mid + 'cm。';
            } else if (type === 1) {
                var angle = rnd(20, 160);
                var supplement = 180 - angle;
                o = opts(supplement, function() { return rnd(10, 180); });
                q = '一个角为 ' + angle + '°，它的补角是？';
                exp = '补角 = 180° − ' + angle + '° = ' + supplement + '°。';
            } else if (type === 2) {
                var angle = rnd(20, 70);
                var complement = 90 - angle;
                o = opts(complement, function() { return rnd(10, 90); });
                q = '一个角为 ' + angle + '°，它的余角是？';
                exp = '余角 = 90° − ' + angle + '° = ' + complement + '°。';
            } else if (type === 3) {
                var angle1 = rnd(30, 80);
                var angle2 = rnd(30, 80);
                var sum = angle1 + angle2;
                var question = Math.random() < 0.5 ? '互余' : '互补';
                var target = question === '互余' ? 90 : 180;
                var remaining = target - sum;
                o = opts(remaining, function() { return rnd(10, 100); });
                q = '两角分别为 ' + angle1 + '° 和 ' + angle2 + '°，它们' + question + '吗？第三个角为多少？';
                exp = target + ' − ' + sum + ' = ' + remaining + '°，所以' + (remaining === 0 ? '正好' + question : '不' + question);
            } else {
                var angle = rnd(30, 150);
                var bisector = angle / 2;
                o = opts(bisector, function() { return rnd(10, 100); });
                q = '角平分线把 ' + angle + '° 的角分成两个相等的角，每个角是？';
                exp = '角平分线把角分成两个相等的部分：' + angle + '° ÷ 2 = ' + bisector + '°。';
            }
            results.push(Q(q, o, '基础', exp, '线段与角'));
        }
        return results;
    }

    /* ============================================================
     * 7. 三角形性质（七年级）- 200+ 种组合
     * ============================================================ */
    function qTriangle(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var a = rnd(30, 80);
                var b = rnd(30, 80);
                var c = 180 - a - b;
                o = opts(c, function() { return rnd(20, 160); });
                q = '三角形两个角分别为 ' + a + '° 和 ' + b + '°，第三个角是？';
                exp = '三角形内角和 = 180°，第三角 = 180° − ' + a + '° − ' + b + '° = ' + c + '°。';
            } else if (type === 1) {
                var a = rnd(30, 80);
                var b = rnd(30, 80);
                var exterior = a + b;
                o = opts(exterior, function() { return rnd(20, 160); });
                q = '三角形两个内角为 ' + a + '° 和 ' + b + '°，不相邻外角是？';
                exp = '外角 = 两内角和 = ' + a + '° + ' + b + '° = ' + exterior + '°。';
            } else if (type === 2) {
                var a = rnd(3, 10);
                var b = rnd(3, 10);
                var c = rnd(Math.abs(a - b) + 1, a + b - 1);
                o = opts('能构成', function() { return '不能构成'; });
                q = '三边长 ' + a + ', ' + b + ', ' + c + '，能否构成三角形？';
                exp = a + ' + ' + b + ' > ' + c + '，' + a + ' + ' + c + ' > ' + b + '，' + b + ' + ' + c + ' > ' + a + '，能构成三角形。';
            } else if (type === 3) {
                var a = rnd(3, 10);
                var b = rnd(3, 10);
                var c = a + b;
                o = opts('不能构成', function() { return '能构成'; });
                q = '三边长 ' + a + ', ' + b + ', ' + c + '，能否构成三角形？';
                exp = a + ' + ' + b + ' = ' + c + '，两边之和等于第三边，不能构成三角形。';
            } else if (type === 4) {
                var top = rnd(30, 70);
                var base = (180 - top) / 2;
                o = opts(base, function() { return rnd(20, 100); });
                q = '等腰三角形顶角 ' + top + '°，底角是？';
                exp = '底角 = (180° − ' + top + '°) ÷ 2 = ' + base + '°。';
            } else {
                var a = rnd(30, 60);
                var b = 90 - a;
                o = opts(b, function() { return rnd(10, 80); });
                q = '直角三角形一个锐角为 ' + a + '°，另一个锐角是？';
                exp = '直角三角形两锐角和 = 90°，另一个锐角 = 90° − ' + a + '° = ' + b + '°。';
            }
            results.push(Q(q, o, '基础', exp, '三角形性质'));
        }
        return results;
    }

    /* ============================================================
     * 8. 全等三角形（八年级）- 200+ 种组合
     * ============================================================ */
    function qCongruent(n) {
        var results = [];
        var methods = ['SAS', 'ASA', 'SSS', 'AAS', 'HL'];
        var methodDesc = {
            'SAS': '两边及其夹角对应相等',
            'ASA': '两角及其夹边对应相等',
            'SSS': '三边对应相等',
            'AAS': '两角及其中一角的对边对应相等',
            'HL': '斜边和一条直角边对应相等（直角三角形）'
        };
        for (var i = 0; i < n; i++) {
            var idx = i % methods.length;
            var method = methods[idx];
            var wrongMethods = methods.filter(function(m) { return m !== method; });
            var wrong = wrongMethods[i % wrongMethods.length];
            o = opts(method, function() { return wrongMethods[rnd(0, wrongMethods.length - 1)]; });
            var q = '已知' + methodDesc[method] + '，判定三角形全等的依据是？';
            var exp = methodDesc[method] + ' → ' + method + '（' + method + '）全等判定。';
            results.push(Q(q, o, '基础', exp, '全等三角形判定'));
        }
        return results;
    }

    /* ============================================================
     * 9. 相似三角形（八年级）- 200+ 种组合
     * ============================================================ */
    function qSimilar(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 5;
            var q, ans, o, exp;
            if (type === 0) {
                var ratio = rnd(2, 6);
                var side1 = ratio * rnd(2, 6);
                var side2 = rnd(2, 6);
                o = opts(ratio + ':1', function() { return rnd(1, 8) + ':1'; });
                q = '两个相似三角形对应边分别为 ' + side1 + 'cm 和 ' + side2 + 'cm，相似比是？';
                exp = '相似比 = ' + side1 + ' : ' + side2 + ' = ' + ratio + ' : 1。';
            } else if (type === 1) {
                var ratio = rnd(2, 5);
                var areaRatio = ratio * ratio;
                o = opts(areaRatio + ':1', function() { return rnd(1, 10) + ':1'; });
                q = '相似比为 ' + ratio + ':1 的两个三角形，面积比是？';
                exp = '面积比 = 相似比的平方 = ' + ratio + '² : 1² = ' + areaRatio + ' : 1。';
            } else if (type === 2) {
                var ratio = rnd(2, 5);
                var perimRatio = ratio;
                o = opts(perimRatio + ':1', function() { return rnd(1, 8) + ':1'; });
                q = '相似比为 ' + ratio + ':1 的两个三角形，周长比是？';
                exp = '周长比 = 相似比 = ' + ratio + ' : 1。';
            } else if (type === 3) {
                var a = rnd(2, 6);
                var b = rnd(2, 6);
                var c = rnd(2, 6);
                o = opts('相似', function() { return '全等'; });
                q = '两个三角形三边对应成比例 ' + a + ':' + b + ':' + c + '，它们的关系是？';
                exp = '三边对应成比例 → 两三角形相似。';
            } else {
                o = opts('平行线分线段成比例', function() { return '全等三角形'; });
                q = '证明两个三角形相似，最常用的方法是？';
                exp = '平行线截得的三角形与原三角形相似，利用平行线分线段成比例定理。';
            }
            results.push(Q(q, o, '基础', exp, '相似三角形'));
        }
        return results;
    }

    /* ============================================================
     * 10. 勾股定理（八年级）- 200+ 种组合
     * ============================================================ */
    function qPyth(n) {
        var results = [];
        var triples = [];
        for (var a = 3; a <= 30; a++) {
            for (var b = a + 1; b <= 40; b++) {
                var c = Math.sqrt(a * a + b * b);
                if (c % 1 === 0 && c <= 50) {
                    triples.push([a, b, c]);
                }
            }
        }
        for (var i = 0; i < n; i++) {
            var type = i % 5;
            var q, ans, o, exp;
            if (type === 0 || type === 1) {
                var idx = i % triples.length;
                var triple = triples[idx] || [3, 4, 5];
                var a = triple[0], b = triple[1], c = triple[2];
                if (type === 0) {
                    o = opts(c, function() { return rnd(1, 50); });
                    q = '直角三角形两直角边为 ' + a + ' 和 ' + b + '，斜边为？';
                    exp = 'c² = ' + a + '² + ' + b + '² = ' + (a*a) + ' + ' + (b*b) + ' = ' + (a*a + b*b) + '，c = ' + c + '。';
                } else {
                    o = opts(b, function() { return rnd(1, 40); });
                    q = '直角三角形斜边 ' + c + '，一直角边 ' + a + '，另一直角边为？';
                    exp = 'b² = ' + c + '² − ' + a + '² = ' + (c*c) + ' − ' + (a*a) + ' = ' + (c*c - a*a) + '，b = ' + b + '。';
                }
            } else if (type === 2) {
                var idx = i % triples.length;
                var triple = triples[idx] || [3, 4, 5];
                var a = triple[0], b = triple[1], c = triple[2];
                o = opts('是直角三角形', function() { return '不是直角三角形'; });
                q = '三边长为 ' + a + ', ' + b + ', ' + c + '，这个三角形是？';
                exp = a + '² + ' + b + '² = ' + (a*a) + ' + ' + (b*b) + ' = ' + (a*a + b*b) + ' = ' + c + '²，满足勾股定理，是直角三角形。';
            } else if (type === 3) {
                var a = rnd(2, 8);
                var b = rnd(2, 8);
                var c = Math.sqrt(a * a + b * b);
                o = opts(c.toFixed(1), function() { return rnd(1, 15).toFixed(1); });
                q = '直角三角形两直角边为 ' + a + ' 和 ' + b + '，斜边约为？';
                exp = 'c = √(' + a + '² + ' + b + '²) = √' + (a*a + b*b) + ' ≈ ' + c.toFixed(1) + '。';
            } else {
                var a = rnd(2, 8);
                var b = rnd(2, 8);
                var c = Math.sqrt(a * a + b * b);
                o = opts(c.toFixed(1), function() { return rnd(1, 15).toFixed(1); });
                q = '一个直角三角形的斜边为 ' + c.toFixed(1) + '，一直角边为 ' + a + '，另一直角边约为？';
                exp = 'b = √(' + c.toFixed(1) + '² − ' + a + '²) ≈ ' + b + '。';
            }
            results.push(Q(q, o, '基础', exp, '勾股定理'));
        }
        return results;
    }

    /* ============================================================
     * 11. 四边形与平行四边形（八年级）- 200+ 种组合
     * ============================================================ */
    function qQuad(n) {
        var results = [];
        var props = [
            { name: '平行四边形', prop: '对边平行且相等', wrong: '对边不相等' },
            { name: '矩形', prop: '对角线相等', wrong: '对角线不相等' },
            { name: '菱形', prop: '对角线互相垂直', wrong: '对角线不垂直' },
            { name: '正方形', prop: '对角线相等且垂直', wrong: '对角线不相等' },
            { name: '梯形', prop: '一组对边平行', wrong: '两组对边平行' }
        ];
        for (var i = 0; i < n; i++) {
            var idx = i % props.length;
            var p = props[idx];
            var qText = p.name + '的性质是？';
            o = opts(p.prop, function() { return p.wrong; });
            var exp = p.name + '：' + p.prop + '。';
            results.push(Q(qText, o, '基础', exp, '四边形性质'));
        }
        return results;
    }

    /* ============================================================
     * 12. 圆的性质（九年级）- 200+ 种组合
     * ============================================================ */
    function qCircle(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var central = rnd(30, 160);
                var inscribed = central / 2;
                o = opts(inscribed + '°', function() { return rnd(10, 180) + '°'; });
                q = '圆心角为 ' + central + '°，同弧所对的圆周角是？';
                exp = '圆周角 = 圆心角 ÷ 2 = ' + central + '° ÷ 2 = ' + inscribed + '°。';
            } else if (type === 1) {
                var r = rnd(2, 15);
                var circumference = 2 * r;
                o = opts('2' + r + 'π', function() { return r + 'π'; });
                q = '半径为 ' + r + ' 的圆，周长为？';
                exp = '周长 C = 2πr = 2 × π × ' + r + ' = 2' + r + 'π。';
            } else if (type === 2) {
                var r = rnd(2, 15);
                var area = r * r;
                o = opts(r * r + 'π', function() { return r + 'π'; });
                q = '半径为 ' + r + ' 的圆，面积为？';
                exp = '面积 S = πr² = π × ' + r + '² = ' + (r * r) + 'π。';
            } else if (type === 3) {
                o = opts('直径', function() { return '弦'; });
                q = '圆中最长的弦是？';
                exp = '直径是经过圆心的弦，是圆中最长的弦。';
            } else if (type === 4) {
                var r = rnd(2, 10);
                o = opts('2' + r + 'π', function() { return r + 'π'; });
                q = '半径为 ' + r + ' 的圆，直径是？';
                exp = '直径 d = 2r = 2 × ' + r + ' = ' + (2 * r) + '。';
            } else {
                var angle = rnd(30, 150);
                o = opts('同弧所对圆周角相等', function() { return '同弧所对圆心角相等'; });
                q = '同弧所对的圆周角有什么关系？';
                exp = '同弧所对的圆周角相等。';
            }
            results.push(Q(q, o, '基础', exp, '圆的性质'));
        }
        return results;
    }

    /* ============================================================
     * 13. 一次函数（八年级）- 200+ 种组合
     * ============================================================ */
    function qFunc1(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 6;
            var q, ans, o, exp;
            if (type === 0) {
                var x1 = rnd(0, 8);
                var y1 = rnd(0, 8);
                var x2 = x1 + rnd(1, 8);
                var y2 = y1 + rnd(1, 8);
                var slope = (y2 - y1) / (x2 - x1);
                o = opts(slope, function() { return rnd(1, 10); });
                q = '点 (' + x1 + ',' + y1 + ') 和 (' + x2 + ',' + y2 + ') 连线的斜率是？';
                exp = '斜率 k = (y₂−y₁)/(x₂−x₁) = (' + y2 + '−' + y1 + ')/(' + x2 + '−' + x1 + ') = ' + slope + '。';
            } else if (type === 1) {
                var k = rnd(1, 5);
                var b = rnd(-8, 8);
                o = opts(b, function() { return rnd(-10, 10); });
                q = '一次函数 y = ' + k + 'x + ' + b + '，y 轴截距是？';
                exp = 'y 轴截距是 x=0 时的 y 值，即 b = ' + b + '。';
            } else if (type === 2) {
                var k = rnd(1, 5);
                var b = rnd(1, 10);
                var x = rnd(1, 8);
                var y = k * x + b;
                o = opts(y, function() { return rnd(1, 50); });
                q = '一次函数 y = ' + k + 'x + ' + b + '，当 x = ' + x + ' 时，y = ？';
                exp = 'y = ' + k + '×' + x + ' + ' + b + ' = ' + y + '。';
            } else if (type === 3) {
                var k = rnd(1, 4);
                o = opts('上升', function() { return '下降'; });
                q = '一次函数 y = ' + k + 'x + 1，图像从左到右？';
                exp = 'k = ' + k + ' > 0，图像从左向右上升。';
            } else if (type === 4) {
                var k = rnd(-4, -1);
                o = opts('下降', function() { return '上升'; });
                q = '一次函数 y = ' + k + 'x + 1，图像从左到右？';
                exp = 'k = ' + k + ' < 0，图像从左向右下降。';
            } else {
                var k1 = rnd(1, 5);
                var k2 = rnd(1, 5);
                while (k1 === k2) k2 = rnd(1, 5);
                var b1 = rnd(1, 8);
                var b2 = rnd(1, 8);
                o = opts('相交', function() { return '平行'; });
                q = '两条直线 y = ' + k1 + 'x + ' + b1 + ' 和 y = ' + k2 + 'x + ' + b2 + ' 的位置关系是？';
                exp = 'k1 ≠ k2，两直线相交。';
            }
            results.push(Q(q, o, type < 4 ? '基础' : '进阶', exp, '一次函数'));
        }
        return results;
    }

    /* ============================================================
     * 14. 反比例函数（八年级）- 200+ 种组合
     * ============================================================ */
    function qInverse(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 5;
            var q, ans, o, exp;
            if (type === 0) {
                var k = rnd(2, 20);
                var x = rnd(1, 8);
                var y = k / x;
                o = opts(k, function() { return rnd(1, 30); });
                q = '反比例函数 y = k/x 经过点 (' + x + ',' + y + ')，k 的值为？';
                exp = 'k = x × y = ' + x + ' × ' + y + ' = ' + k + '。';
            } else if (type === 1) {
                var k = rnd(1, 8);
                o = opts('一、三象限', function() { return '二、四象限'; });
                q = '反比例函数 y = ' + k + '/x，图像在？';
                exp = 'k = ' + k + ' > 0，图像在第一、三象限。';
            } else if (type === 2) {
                var k = rnd(-8, -1);
                o = opts('二、四象限', function() { return '一、三象限'; });
                q = '反比例函数 y = ' + k + '/x，图像在？';
                exp = 'k = ' + k + ' < 0，图像在第二、四象限。';
            } else if (type === 3) {
                var k = rnd(2, 15);
                var x = rnd(1, 8);
                var y = k / x;
                o = opts(y, function() { return rnd(1, 20); });
                q = '反比例函数 y = ' + k + '/x，当 x = ' + x + ' 时，y = ？';
                exp = 'y = ' + k + ' ÷ ' + x + ' = ' + y + '。';
            } else {
                var k = rnd(2, 15);
                var x1 = rnd(1, 5);
                var x2 = rnd(1, 5);
                while (x1 === x2) x2 = rnd(1, 5);
                var y1 = k / x1;
                var y2 = k / x2;
                o = opts((y1 * x1).toFixed(1), function() { return rnd(1, 30).toFixed(1); });
                q = '反比例函数上两点 (' + x1 + ',' + y1 + ') 和 (' + x2 + ',' + y2 + ')，xy = ？';
                exp = 'xy = ' + (y1 * x1).toFixed(1) + '（常数 k）。';
            }
            results.push(Q(q, o, '基础', exp, '反比例函数'));
        }
        return results;
    }

    /* ============================================================
     * 15. 二次函数（九年级）- 200+ 种组合
     * ============================================================ */
    function qQuadfunc(n) {
        var results = [];
        for (var i = 0; i < n; i++) {
            var type = i % 8;
            var q, ans, o, exp;
            if (type === 0) {
                var h = rnd(-5, 5);
                var k = rnd(-5, 5);
                o = opts('(' + h + ',' + k + ')', function() { return '(' + rnd(-6, 6) + ',' + rnd(-6, 6) + ')'; });
                q = '二次函数 y = (x ' + (h >= 0 ? '− ' + h : '+ ' + Math.abs(h)) + ')² ' + (k >= 0 ? '+ ' + k : '− ' + Math.abs(k)) + ' 的顶点坐标是？';
                exp = '顶点式为 y = a(x−h)² + k，顶点为 (' + h + ',' + k + ')。';
            } else if (type === 1) {
                var a = rnd(1, 5) * (Math.random() < 0.5 ? 1 : -1);
                o = opts(a > 0 ? '开口向上' : '开口向下', function() { return a > 0 ? '开口向下' : '开口向上'; });
                q = '二次函数 y = ' + a + 'x² + 2x + 1，开口方向？';
                exp = 'a = ' + a + ' ' + (a > 0 ? '>' : '<') + ' 0，开口' + (a > 0 ? '向上' : '向下') + '。';
            } else if (type === 2) {
                var h = rnd(-5, 5);
                o = opts('x = ' + h, function() { return 'x = ' + rnd(-6, 6); });
                q = '二次函数 y = (x ' + (h >= 0 ? '− ' + h : '+ ' + Math.abs(h)) + ')² 的对称轴是？';
                exp = '对称轴为 x = ' + h + '。';
            } else if (type === 3) {
                var c = rnd(-8, 8);
                o = opts('(0,' + c + ')', function() { return '(' + rnd(-5, 5) + ',0)'; });
                q = '二次函数 y = x² + 2x + ' + c + '，与 y 轴交点是？';
                exp = '令 x = 0，y = ' + c + '，交点为 (0, ' + c + ')。';
            } else if (type === 4) {
                var a = -Math.abs(rnd(1, 4));
                var k = rnd(1, 8);
                o = opts('最大值 ' + k, function() { return '最小值 ' + k; });
                q = '二次函数 y = ' + a + 'x² + 2x + ' + (k + 1) + '，有最值吗？';
                exp = 'a = ' + a + ' < 0，开口向下，有最大值 ' + k + '。';
            } else if (type === 5) {
                var a = Math.abs(rnd(1, 4));
                var k = rnd(1, 8);
                o = opts('最小值 ' + k, function() { return '最大值 ' + k; });
                q = '二次函数 y = ' + a + 'x² + 2x + ' + (k + 1) + '，有最值吗？';
                exp = 'a = ' + a + ' > 0，开口向上，有最小值 ' + k + '。';
            } else if (type === 6) {
                var a = rnd(1, 4);
                var b = rnd(2, 6);
                var c = rnd(1, 8);
                var disc = b * b - 4 * a * c;
                o = opts(disc > 0 ? '两个交点' : disc === 0 ? '一个交点' : '无交点', function() { return disc > 0 ? '无交点' : '两个交点'; });
                q = '二次函数 y = ' + a + 'x² + ' + b + 'x + ' + c + ' 与 x 轴有几个交点？';
                exp = 'Δ = ' + b + '² − 4×' + a + '×' + c + ' = ' + disc + '，' + (disc > 0 ? 'Δ>0，有两个交点' : disc === 0 ? 'Δ=0，有一个交点' : 'Δ<0，无交点');
            } else {
                var a = rnd(1, 4);
                var h = rnd(-4, 4);
                var k = rnd(-4, 4);
                o = opts('y = ' + a + '(x' + (h >= 0 ? '−' + h : '+' + Math.abs(h)) + ')²' + (k >= 0 ? '+' + k : '−' + Math.abs(k)), function() { return 'y = ' + rnd(1, 5) + 'x² + ' + rnd(-5, 5) + 'x + ' + rnd(-5, 5); });
                q = '顶点为 (' + h + ',' + k + ')，a=' + a + ' 的二次函数是？';
                exp = '顶点式：y = ' + a + '(x−' + h + ')² + ' + k + '。';
            }
            results.push(Q(q, o, type < 5 ? '基础' : '进阶', exp, '二次函数'));
        }
        return results;
    }

    /* ============================================================
     * 注册到 window.TECHNIQUES
     * ============================================================ */
    var GEN = {
        rational: qRational,
        integral: qIntegral,
        linear1: qLinear,
        inequal: qInequal,
        system: qSystem,
        segangle: qSegAngle,
        triangle: qTriangle,
        congruent: qCongruent,
        similar: qSimilar,
        pyth: qPyth,
        quad: qQuad,
        circ: qCircle,
        func1: qFunc1,
        inverse: qInverse,
        quadfunc: qQuadfunc
    };

    if (window.TECHNIQUES) {
        window.TECHNIQUES.forEach(function(t) {
            if (GEN[t.id]) {
                t.qgen = function(n) {
                    var out = [];
                    var count = n || 8;
                    for (var i = 0; i < count; i++) {
                        var result = GEN[t.id](1);
                        if (result && result.length > 0) {
                            out.push(result[0]);
                        }
                    }
                    return out;
                };
            }
        });
    }
    window.QGEN_JUNIOR_READY = true;
})();