/* ============================================================
 * js/admin.js - 完整修复版（含学生选择器）
 * 修复：侧边栏折叠、主题切换、用户管理、家长绑定、机构层级
 * 新增：家长多孩子切换、学校/培训机构学生筛选弹窗
 * 修改：学生选择器增加筛选确认、双击查看、分页、滚动条
 * ============================================================ */
(function() {
    'use strict';

    // ============================================================
    // 1. 侧边栏控制
    // ============================================================
    var sidebar = document.getElementById('sidebar');
    var sidebarToggle = document.getElementById('sidebarToggle');
    var menuBtn = document.getElementById('menuBtn');

    function isMobile() {
        return window.innerWidth <= 768;
    }

    function updateToggleIcon() {
        if (!sidebarToggle) return;
        var isCollapsed = sidebar.classList.contains('collapsed');
        sidebarToggle.textContent = isCollapsed ? '▶' : '◀';
    }

    function initSidebar() {
        if (!sidebar) return;
        
        sidebar.style.transform = '';
        sidebar.style.width = '';
        sidebar.style.display = '';
        
        if (isMobile()) {
            sidebar.classList.remove('collapsed');
            var isOpen = localStorage.getItem('sidebar_mobile_open') === 'true';
            if (isOpen) {
                sidebar.classList.add('open');
            } else {
                sidebar.classList.remove('open');
            }
        } else {
            sidebar.classList.remove('open');
            var collapsed = localStorage.getItem('sidebar_collapsed') === 'true';
            if (collapsed) {
                sidebar.classList.add('collapsed');
            } else {
                sidebar.classList.remove('collapsed');
            }
            updateToggleIcon();
        }
    }

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            if (isMobile()) {
                sidebar.classList.toggle('open');
                localStorage.setItem('sidebar_mobile_open', sidebar.classList.contains('open'));
            } else {
                sidebar.classList.toggle('collapsed');
                localStorage.setItem('sidebar_collapsed', sidebar.classList.contains('collapsed'));
                updateToggleIcon();
            }
        });
    }

    if (menuBtn) {
        menuBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            if (isMobile()) {
                sidebar.classList.toggle('open');
                localStorage.setItem('sidebar_mobile_open', sidebar.classList.contains('open'));
            }
        });
    }

    document.addEventListener('click', function(e) {
        if (isMobile() && sidebar && sidebar.classList.contains('open')) {
            var target = e.target;
            var isClickInside = sidebar.contains(target) || 
                               (menuBtn && menuBtn.contains(target)) ||
                               (sidebarToggle && sidebarToggle.contains(target));
            if (!isClickInside) {
                sidebar.classList.remove('open');
                localStorage.setItem('sidebar_mobile_open', 'false');
            }
        }
    });

    var resizeTimer;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(initSidebar, 300);
    });

    initSidebar();

    // ============================================================
    // 2. 主题切换
    // ============================================================
    var themeSelect = document.getElementById('themeSelect');

    function applyTheme(theme) {
        var body = document.body;
        var classList = body.classList;
        
        var toRemove = [];
        classList.forEach(function(cls) {
            if (cls.startsWith('theme-') || cls === 'dark-mode') {
                toRemove.push(cls);
            }
        });
        toRemove.forEach(function(cls) {
            classList.remove(cls);
        });
        
        if (theme === 'auto') {
            if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                classList.add('dark-mode');
            }
            if (window.matchMedia) {
                var mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
                var handler = function(e) {
                    if (localStorage.getItem('math_theme') === 'auto') {
                        if (e.matches) {
                            document.body.classList.add('dark-mode');
                        } else {
                            document.body.classList.remove('dark-mode');
                        }
                    }
                };
                try {
                    mediaQuery.removeEventListener('change', handler);
                } catch(e) {}
                mediaQuery.addEventListener('change', handler);
                window._darkModeHandler = handler;
            }
        } else if (theme !== 'default') {
            classList.add('theme-' + theme);
        }
        
        localStorage.setItem('math_theme', theme);
    }

    if (themeSelect) {
        var savedTheme = localStorage.getItem('math_theme') || 'default';
        themeSelect.value = savedTheme;
        applyTheme(savedTheme);

        themeSelect.addEventListener('change', function() {
            var theme = this.value;
            applyTheme(theme);
            if (typeof showToast === 'function') {
                showToast('✅ 主题已切换', 'success');
            }
        });
    }

    // ============================================================
    // 3. Toast 提示
    // ============================================================
    window.showToast = function(message, type) {
        var toast = document.getElementById('toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'toast';
            toast.className = 'toast';
            document.body.appendChild(toast);
        }
        toast.textContent = message;
        toast.className = 'toast show';
        
        var colors = {
            success: '#16a34a',
            error: '#dc2626',
            warning: '#d97706',
            info: '#1f2937'
        };
        toast.style.background = colors[type] || colors.info;
        
        clearTimeout(toast._timer);
        toast._timer = setTimeout(function() {
            toast.classList.remove('show');
            setTimeout(function() {
                toast.style.background = colors.info;
            }, 300);
        }, 3000);
    };

    // ============================================================
    // 4. 模态框
    // ============================================================
    window.showModal = function(html) {
        var modal = document.getElementById('modal');
        var body = document.getElementById('modalBody');
        
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'modal';
            modal.className = 'modal';
            modal.style.display = 'none';
            modal.innerHTML = `
                <div class="modal-content">
                    <button class="modal-close" id="modalClose">&times;</button>
                    <div id="modalBody"></div>
                </div>
            `;
            document.body.appendChild(modal);
            body = document.getElementById('modalBody');
            
            document.getElementById('modalClose').addEventListener('click', closeModal);
            modal.addEventListener('click', function(e) {
                if (e.target === this) closeModal();
            });
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') closeModal();
            });
        }
        
        if (body) {
            body.innerHTML = html;
            modal.style.display = 'flex';
        }
    };

    window.closeModal = function() {
        var modal = document.getElementById('modal');
        if (modal) modal.style.display = 'none';
    };

    // ============================================================
    // 5. 工具函数
    // ============================================================
    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/"/g, '&quot;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    // ============================================================
    // 6. 用户管理（管理员）
    // ============================================================
    window.showAddUser = function() {
        showModal(`
            <h3 style="margin-top:0;">➕ 添加用户</h3>
            <form id="addUserForm" onsubmit="addUser(event)">
                <div class="form-row">
                    <div class="form-group">
                        <label>用户名 *</label>
                        <input type="text" name="username" required placeholder="至少3个字符">
                    </div>
                    <div class="form-group">
                        <label>姓名 *</label>
                        <input type="text" name="name" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>邮箱 *</label>
                        <input type="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label>角色 *</label>
                        <select name="role" required>
                            <option value="student">学生</option>
                            <option value="parent">家长</option>
                            <option value="school">学校</option>
                            <option value="training">培训机构</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label>性别</label>
                    <select name="gender">
                        <option value="保密">保密</option>
                        <option value="男">男</option>
                        <option value="女">女</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>密码 *</label>
                    <input type="password" name="password" required placeholder="至少6个字符">
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn">✅ 添加</button>
                    <button type="button" class="btn ghost" onclick="closeModal()">取消</button>
                </div>
            </form>
        `);
    };

    window.addUser = function(e) {
        e.preventDefault();
        var form = document.getElementById('addUserForm');
        var formData = new FormData(form);
        var userData = {};
        for (var pair of formData.entries()) {
            userData[pair[0]] = pair[1];
        }
        
        var submitBtn = form.querySelector('button[type="submit"]');
        var originalText = submitBtn.textContent;
        submitBtn.textContent = '提交中...';
        submitBtn.disabled = true;
        
        fetch('api/users.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'add', ...userData})
        })
        .then(function(res) { return res.json(); })
        .then(function(result) {
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            if (result.success) {
                closeModal();
                showToast('✅ 用户添加成功', 'success');
                setTimeout(function() { location.reload(); }, 1000);
            } else {
                showToast('❌ ' + (result.error || '添加失败'), 'error');
            }
        })
        .catch(function(err) {
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            showToast('❌ 网络错误: ' + err.message, 'error');
        });
    };

    window.deleteUser = function(userId) {
        if (!confirm('⚠️ 确定要删除该用户吗？此操作不可恢复！')) return;
        fetch('api/users.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'delete', userId: userId})
        })
        .then(function(res) { return res.json(); })
        .then(function(result) {
            if (result.success) {
                showToast('✅ 删除成功', 'success');
                setTimeout(function() { location.reload(); }, 1000);
            } else {
                showToast('❌ ' + (result.error || '删除失败'), 'error');
            }
        })
        .catch(function() { showToast('❌ 网络错误', 'error'); });
    };

    window.toggleUser = function(userId) {
        fetch('api/users.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'toggle', userId: userId})
        })
        .then(function(res) { return res.json(); })
        .then(function(result) {
            if (result.success) {
                showToast('✅ 状态已更新', 'success');
                setTimeout(function() { location.reload(); }, 1000);
            } else {
                showToast('❌ ' + (result.error || '操作失败'), 'error');
            }
        })
        .catch(function() { showToast('❌ 网络错误', 'error'); });
    };

    window.editUser = function(userId) {
        showModal(`
            <div style="text-align:center;padding:40px;">
                <div style="font-size:24px;color:#6b7280;">加载中...</div>
            </div>
        `);
        
        fetch('api/users.php?action=get&id=' + userId)
            .then(function(res) { return res.json(); })
            .then(function(result) {
                if (!result.success) {
                    showToast('❌ ' + (result.error || '获取用户信息失败'), 'error');
                    closeModal();
                    return;
                }
                var u = result.data;
                var currentUserId = parseInt(document.querySelector('meta[name="user-id"]')?.content || '0');
                var isSelf = (userId == currentUserId);
                
                var roleOptions = '';
                var roles = [
                    {value: 'admin', label: '管理员'},
                    {value: 'parent', label: '家长'},
                    {value: 'student', label: '学生'},
                    {value: 'school', label: '学校'},
                    {value: 'training', label: '培训机构'}
                ];
                
                roles.forEach(function(r) {
                    var selected = (u.role === r.value) ? 'selected' : '';
                    var disabled = isSelf ? 'disabled' : '';
                    roleOptions += '<option value="' + r.value + '" ' + selected + ' ' + disabled + '>' + r.label + '</option>';
                });
                
                var extraFields = '';
                if (u.role === 'student') {
                    extraFields = `
                        <div class="form-row">
                            <div class="form-group">
                                <label>学校名称</label>
                                <input type="text" name="school" value="${escapeHtml(u.school || '')}" placeholder="学校名称">
                            </div>
                            <div class="form-group">
                                <label>培训机构</label>
                                <input type="text" name="training" value="${escapeHtml(u.training || '')}" placeholder="培训机构名称">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>年级</label>
                                <input type="text" name="grade" value="${escapeHtml(u.grade || '')}" placeholder="年级">
                            </div>
                            <div class="form-group">
                                <label>家长手机号</label>
                                <input type="text" name="parent_phone" value="${escapeHtml(u.parent_phone || '')}" placeholder="家长手机号">
                            </div>
                        </div>
                    `;
                } else if (u.role === 'parent') {
                    extraFields = `
                        <div class="form-row">
                            <div class="form-group">
                                <label>孩子学校</label>
                                <input type="text" name="child_school" value="${escapeHtml(u.child_school || '')}" placeholder="孩子学校">
                            </div>
                            <div class="form-group">
                                <label>孩子培训机构</label>
                                <input type="text" name="child_training" value="${escapeHtml(u.child_training || '')}" placeholder="孩子培训机构">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>孩子年级</label>
                                <input type="text" name="child_grade" value="${escapeHtml(u.child_grade || '')}" placeholder="孩子年级">
                            </div>
                            <div class="form-group">
                                <label>手机号</label>
                                <input type="text" name="phone" value="${escapeHtml(u.phone || '')}" placeholder="手机号">
                            </div>
                        </div>
                    `;
                } else if (u.role === 'school' || u.role === 'training') {
                    var orgLevels = [];
                    try { orgLevels = JSON.parse(u.org_levels || '[]'); } catch(e) { orgLevels = []; }
                    var levelLabels = ['小学', '初级中学', '高级中学'];
                    var levelCheckboxes = levelLabels.map(function(l) {
                        var checked = orgLevels.indexOf(l) > -1 ? 'checked' : '';
                        return '<label><input type="checkbox" name="org_levels[]" value="' + l + '" ' + checked + '> ' + l + '</label>';
                    }).join('');
                    extraFields = `
                        <div class="form-group">
                            <label>机构名称</label>
                            <input type="text" name="org_name" value="${escapeHtml(u.org_name || '')}" placeholder="机构名称">
                        </div>
                        <div class="form-group">
                            <label>机构层级（可多选，至少选一个）</label>
                            <div style="display:flex;gap:12px;flex-wrap:wrap;padding:6px 0;">
                                ${levelCheckboxes}
                            </div>
                        </div>
                        <div class="form-group">
                            <label>管理员手机号</label>
                            <input type="text" name="admin_phone" value="${escapeHtml(u.admin_phone || '')}" placeholder="管理员手机号">
                        </div>
                    `;
                }
                
                showModal(`
                    <h3 style="margin-top:0;">✏️ 编辑用户</h3>
                    <form id="editUserForm" onsubmit="saveUser(event, ${userId})">
                        <div class="form-row">
                            <div class="form-group">
                                <label>用户名</label>
                                <input type="text" value="${escapeHtml(u.username)}" disabled style="background:#f3f4f6;">
                            </div>
                            <div class="form-group">
                                <label>姓名</label>
                                <input type="text" name="name" value="${escapeHtml(u.name || '')}" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>性别</label>
                                <select name="gender">
                                    <option value="保密" ${(u.gender || '保密') === '保密' ? 'selected' : ''}>保密</option>
                                    <option value="男" ${u.gender === '男' ? 'selected' : ''}>男</option>
                                    <option value="女" ${u.gender === '女' ? 'selected' : ''}>女</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>邮箱</label>
                                <input type="email" name="email" value="${escapeHtml(u.email)}" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>角色</label>
                            <select name="role" ${isSelf ? 'disabled style="background:#f3f4f6;"' : ''}>
                                ${roleOptions}
                            </select>
                            ${isSelf ? '<div style="font-size:11px;color:#6b7280;margin-top:2px;">不能修改自己的角色</div>' : ''}
                        </div>
                        ${extraFields}
                        <div class="form-group">
                            <label>新密码（留空则不修改）</label>
                            <input type="password" name="password" placeholder="输入新密码" autocomplete="off">
                        </div>
                        <div class="form-actions">
                            <button type="submit" class="btn">💾 保存</button>
                            <button type="button" class="btn ghost" onclick="closeModal()">取消</button>
                        </div>
                    </form>
                `);
            })
            .catch(function() {
                closeModal();
                showToast('❌ 网络错误', 'error');
            });
    };

    window.saveUser = function(e, userId) {
        e.preventDefault();
        var form = document.getElementById('editUserForm');
        var formData = new FormData(form);
        var userData = {};
        for (var pair of formData.entries()) {
            userData[pair[0]] = pair[1];
        }
        
        var roleSelect = form.querySelector('select[name="role"]');
        if (roleSelect && !roleSelect.disabled) {
            userData.role = roleSelect.value;
        }
        
        var orgLevels = [];
        var checkboxes = form.querySelectorAll('input[name="org_levels[]"]:checked');
        checkboxes.forEach(function(cb) {
            orgLevels.push(cb.value);
        });
        if (orgLevels.length > 0) {
            userData.org_levels = orgLevels;
        }
        
        var submitBtn = form.querySelector('button[type="submit"]');
        var originalText = submitBtn.textContent;
        submitBtn.textContent = '保存中...';
        submitBtn.disabled = true;
        
        fetch('api/users.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({action: 'update', userId: userId, ...userData})
        })
        .then(function(res) { return res.json(); })
        .then(function(result) {
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            if (result.success) {
                closeModal();
                showToast('✅ 保存成功', 'success');
                setTimeout(function() { location.reload(); }, 1000);
            } else {
                showToast('❌ ' + (result.error || '保存失败'), 'error');
            }
        })
        .catch(function() {
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            showToast('❌ 网络错误', 'error');
        });
    };

    // ============================================================
    // 7. 家长绑定孩子
    // ============================================================
    window.showBindChild = function() {
        showModal(`
            <h3 style="margin-top:0;">👶 绑定孩子</h3>
            <p style="color:#6b7280;font-size:13px;">输入孩子的用户名，绑定后即可查看孩子的学习情况。</p>
            <form id="bindChildForm" onsubmit="bindChild(event)">
                <div class="form-group">
                    <label>孩子用户名 *</label>
                    <input type="text" name="child_username" required placeholder="请输入孩子的用户名">
                </div>
                <div style="color:#6b7280;font-size:12px;margin-bottom:12px;">
                    💡 提示：孩子的用户名可以在孩子的个人资料中查看，或询问孩子本人。
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn">🔗 绑定</button>
                    <button type="button" class="btn ghost" onclick="closeModal()">取消</button>
                </div>
            </form>
        `);
    };

    window.bindChild = function(e) {
        e.preventDefault();
        var form = document.getElementById('bindChildForm');
        var formData = new FormData(form);
        var childUsername = formData.get('child_username');
        
        if (!childUsername || childUsername.trim() === '') {
            showToast('❌ 请输入孩子用户名', 'error');
            return;
        }
        
        var submitBtn = form.querySelector('button[type="submit"]');
        var originalText = submitBtn.textContent;
        submitBtn.textContent = '绑定中...';
        submitBtn.disabled = true;
        
        fetch('api/bind.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                action: 'bind_child',
                child_username: childUsername.trim()
            })
        })
        .then(function(res) { return res.json(); })
        .then(function(result) {
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            if (result.success) {
                closeModal();
                showToast('✅ 孩子绑定成功！', 'success');
                setTimeout(function() { location.reload(); }, 1000);
            } else {
                showToast('❌ ' + (result.error || '绑定失败'), 'error');
            }
        })
        .catch(function(err) {
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            showToast('❌ 网络错误: ' + err.message, 'error');
        });
    };

    // ============================================================
    // 8. 家长切换孩子
    // ============================================================
    window.showChildSelector = function(targetRoute) {
        var userRole = document.querySelector('meta[name="user-role"]')?.content || '';
        if (userRole !== 'parent') {
            showToast('❌ 只有家长可以切换孩子', 'error');
            return;
        }
        
        fetch('api/bind.php?action=get_children')
            .then(function(res) { return res.json(); })
            .then(function(result) {
                if (!result.success || !result.children || result.children.length === 0) {
                    showToast('❌ 还没有绑定孩子，请先绑定', 'warning');
                    return;
                }
                
                var children = result.children;
                var html = `
                    <h3 style="margin-top:0;">👶 选择孩子</h3>
                    <p style="color:#6b7280;font-size:13px;">选择要查看哪个孩子的学习数据：</p>
                    <div style="display:flex;flex-direction:column;gap:8px;margin:12px 0;">
                `;
                
                children.forEach(function(child) {
                    var displayName = child.name || child.username;
                    html += `
                        <button class="btn ghost" onclick="switchToChild(${child.id}, '${targetRoute}')" style="justify-content:center;padding:12px;">
                            <span style="font-size:16px;">👤</span>
                            <span style="font-weight:600;">${escapeHtml(displayName)}</span>
                            <span style="color:#6b7280;font-size:12px;">@${escapeHtml(child.username)}</span>
                            <span style="color:#6b7280;font-size:12px;">${escapeHtml(child.grade || '未设置年级')}</span>
                        </button>
                    `;
                });
                
                html += `
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn ghost" onclick="closeModal()">取消</button>
                        <button type="button" class="btn" onclick="showBindChild()">➕ 绑定新孩子</button>
                    </div>
                `;
                
                showModal(html);
            })
            .catch(function() {
                showToast('❌ 获取孩子列表失败', 'error');
            });
    };

    window.switchToChild = function(childId, targetRoute) {
        closeModal();
        window.location.href = '?route=' + targetRoute + '&child_id=' + childId;
    };

// ============================================================
// 9. 【核心修改】学校/培训机构 - 学生选择弹窗
// ============================================================
var currentTargetRoute = 'learning';
var filterTimer = null;
var allStudentsData = [];
var currentPage = 1;
var perPage = 10;
var totalPages = 1;
var filteredStudents = [];

// 将所有函数挂载到 window
window.showStudentSelector = function(targetRoute) {
    currentTargetRoute = targetRoute;
    currentPage = 1;
    allStudentsData = [];
    filteredStudents = [];
    
    showModal(`
        <h3 style="margin-top:0;">
            📚 选择学生
            <span style="font-size:13px;color:#6b7280;font-weight:400;"> - 查看${targetRoute === 'learning' ? '学习路径' : targetRoute === 'review' ? '薄弱点' : '进度'}</span>
        </h3>
        <div style="text-align:center;padding:20px;color:#6b7280;">
            <div style="font-size:24px;margin-bottom:8px;">⏳</div>
            加载学生列表中...
        </div>
    `);
    
    window.loadStudentList();
};

window.loadStudentList = function() {
    var role = document.querySelector('meta[name="user-role"]')?.content || '';
    var grade = document.getElementById('studentFilterGrade')?.value || '';
    var school = document.getElementById('studentFilterSchool')?.value || '';
    var keyword = document.getElementById('studentFilterKeyword')?.value || '';
    
    var url = 'pages/student_selector.php?action=get_students&role=' + encodeURIComponent(role);
    if (grade) url += '&grade=' + encodeURIComponent(grade);
    if (school) url += '&school=' + encodeURIComponent(school);
    if (keyword) url += '&keyword=' + encodeURIComponent(keyword);
    
    fetch(url)
        .then(function(res) { 
            if (!res.ok) {
                throw new Error('HTTP ' + res.status);
            }
            return res.json(); 
        })
        .then(function(result) {
            if (!result.success) {
                showModal(`
                    <h3 style="margin-top:0;">📚 选择学生</h3>
                    <div style="text-align:center;padding:20px;color:#dc2626;">
                        ❌ ${result.error || '加载失败'}
                    </div>
                    <div class="form-actions">
                        <button class="btn ghost" onclick="closeModal()">关闭</button>
                    </div>
                `);
                return;
            }
            allStudentsData = result.students || [];
            filteredStudents = allStudentsData.slice();
            currentPage = 1;
            window.renderStudentSelector(result);
        })
        .catch(function(err) {
            showModal(`
                <h3 style="margin-top:0;">📚 选择学生</h3>
                <div style="text-align:center;padding:20px;color:#dc2626;">
                    ❌ 网络错误: ${err.message}
                </div>
                <div class="form-actions">
                    <button class="btn ghost" onclick="closeModal()">关闭</button>
                </div>
            `);
        });
};

window.renderStudentSelector = function(data) {
    var students = data.students || [];
    if (students.length > 0) {
        allStudentsData = students;
        filteredStudents = students.slice();
    }
    
    var grades = data.grades || [];
    var schools = data.schools || [];
    var role = data.role || '';
    
    var routeLabel = currentTargetRoute === 'learning' ? '学习路径' : 
                     currentTargetRoute === 'review' ? '薄弱点' : '进度';
    
    var filterHtml = '';
    
    if (role === 'training') {
        filterHtml += `
            <div style="flex:1;min-width:120px;">
                <label style="font-size:12px;color:#6b7280;">学校</label>
                <select id="studentFilterSchool" onchange="window.applyStudentFilters()" style="width:100%;padding:6px 8px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;">
                    <option value="">全部学校</option>
                    ${schools.map(function(s) {
                        return '<option value="' + escapeHtml(s) + '">' + escapeHtml(s) + '</option>';
                    }).join('')}
                </select>
            </div>
        `;
    }
    
    filterHtml += `
        <div style="flex:1;min-width:100px;">
            <label style="font-size:12px;color:#6b7280;">年级</label>
            <select id="studentFilterGrade" onchange="window.applyStudentFilters()" style="width:100%;padding:6px 8px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;">
                <option value="">全部年级</option>
                ${grades.map(function(g) {
                    return '<option value="' + escapeHtml(g) + '">' + escapeHtml(g) + '</option>';
                }).join('')}
            </select>
        </div>
        <div style="flex:2;min-width:150px;">
            <label style="font-size:12px;color:#6b7280;">搜索</label>
            <input type="text" id="studentFilterKeyword" placeholder="输入姓名或用户名..." style="width:100%;padding:6px 8px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;" oninput="window.onStudentFilterInput()">
        </div>
        <div style="display:flex;align-items:flex-end;gap:8px;">
            <button class="btn" onclick="window.applyStudentFilters()" style="padding:6px 20px;">🔍 筛选</button>
            <button class="btn ghost" onclick="window.resetStudentFilters()" style="padding:6px 14px;">重置</button>
        </div>
    `;
    
    totalPages = Math.ceil(filteredStudents.length / perPage);
    if (totalPages < 1) totalPages = 1;
    if (currentPage > totalPages) currentPage = totalPages;
    if (currentPage < 1) currentPage = 1;
    
    var start = (currentPage - 1) * perPage;
    var end = Math.min(start + perPage, filteredStudents.length);
    var pageStudents = filteredStudents.slice(start, end);
    
    var studentHtml = '';
    if (filteredStudents.length === 0) {
        studentHtml = `
            <div style="text-align:center;padding:20px;color:#6b7280;">
                <div style="font-size:32px;margin-bottom:8px;">📚</div>
                <p>没有找到匹配的学生</p>
                <p style="font-size:12px;">请调整筛选条件</p>
            </div>
        `;
    } else {
        studentHtml = `
            <div style="max-height:280px;overflow-y:auto;margin-top:8px;border:1px solid #e5e7eb;border-radius:8px;">
                ${pageStudents.map(function(s) {
                    var displayName = s.name || s.username;
                    var weakCount = s.weak_count || 0;
                    var weakBadge = weakCount > 0 ? 
                        '<span style="background:#fdeaea;color:#dc2626;padding:2px 10px;border-radius:12px;font-size:11px;">' + weakCount + '个薄弱点</span>' : 
                        '<span style="color:#16a34a;font-size:11px;">✓ 无薄弱点</span>';
                    return `
                        <div class="student-item" data-student-id="${s.id}" data-student-name="${escapeHtml(displayName)}" style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid #f1f3f5;cursor:pointer;transition:background 0.15s;" onmouseover="this.style.background='#f0f4ff'" onmouseout="this.style.background=''" ondblclick="window.selectStudent(${s.id}, '${currentTargetRoute}')">
                            <div style="display:flex;align-items:center;gap:10px;">
                                <span style="font-size:16px;">👤</span>
                                <span style="font-weight:600;">${escapeHtml(displayName)}</span>
                                <span style="color:#6b7280;font-size:12px;">@${escapeHtml(s.username)}</span>
                                <span style="color:#6b7280;font-size:12px;background:#f1f3f5;padding:0 8px;border-radius:4px;">${escapeHtml(s.grade || '未设置')}</span>
                            </div>
                            <div>${weakBadge}</div>
                        </div>
                    `;
                }).join('')}
            </div>
            <div style="display:flex;flex-wrap:wrap;gap:6px;justify-content:center;align-items:center;margin-top:12px;padding-top:10px;border-top:1px solid #e5e7eb;">
                <button class="btn sm ghost" onclick="window.goToStudentPage(1)" ${currentPage <= 1 ? 'disabled' : ''}>⏮</button>
                <button class="btn sm ghost" onclick="window.goToStudentPage(currentPage - 1)" ${currentPage <= 1 ? 'disabled' : ''}>◀</button>
                <span style="font-size:13px;color:#6b7280;">第 ${currentPage} / ${totalPages} 页</span>
                <button class="btn sm ghost" onclick="window.goToStudentPage(currentPage + 1)" ${currentPage >= totalPages ? 'disabled' : ''}>▶</button>
                <button class="btn sm ghost" onclick="window.goToStudentPage(totalPages)" ${currentPage >= totalPages ? 'disabled' : ''}>⏭</button>
                <span style="font-size:13px;color:#6b7280;">共 ${filteredStudents.length} 名学生</span>
            </div>
        `;
    }
    
    var modalHtml = `
        <h3 style="margin-top:0;">
            📚 选择学生
            <span style="font-size:13px;color:#6b7280;font-weight:400;"> - 查看${routeLabel}</span>
            <span style="font-size:12px;color:#6b7280;font-weight:400;margin-left:8px;">（双击学生姓名查看）</span>
        </h3>
        
        <div style="display:flex;flex-wrap:wrap;gap:10px;margin:10px 0;padding:12px 14px;background:#f8fafc;border-radius:8px;align-items:flex-end;">
            ${filterHtml}
        </div>
        
        ${studentHtml}
        
        <div class="form-actions" style="margin-top:12px;">
            <button class="btn ghost" onclick="closeModal()">关闭</button>
        </div>
    `;
    
    showModal(modalHtml);
};

window.applyStudentFilters = function() {
    var grade = document.getElementById('studentFilterGrade')?.value || '';
    var school = document.getElementById('studentFilterSchool')?.value || '';
    var keyword = document.getElementById('studentFilterKeyword')?.value || '';
    
    if (!allStudentsData || allStudentsData.length === 0) {
        window.loadStudentList();
        return;
    }
    
    filteredStudents = allStudentsData.filter(function(s) {
        if (grade && s.grade !== grade) return false;
        if (school && s.school !== school) return false;
        if (keyword) {
            var name = (s.name || '').toLowerCase();
            var username = (s.username || '').toLowerCase();
            var kw = keyword.toLowerCase();
            if (name.indexOf(kw) === -1 && username.indexOf(kw) === -1) return false;
        }
        return true;
    });
    
    currentPage = 1;
    window.renderStudentPage();
};

window.resetStudentFilters = function() {
    var gradeSelect = document.getElementById('studentFilterGrade');
    if (gradeSelect) gradeSelect.value = '';
    var schoolSelect = document.getElementById('studentFilterSchool');
    if (schoolSelect) schoolSelect.value = '';
    var keywordInput = document.getElementById('studentFilterKeyword');
    if (keywordInput) keywordInput.value = '';
    
    filteredStudents = allStudentsData.slice();
    currentPage = 1;
    window.renderStudentPage();
};

window.onStudentFilterInput = function() {
    clearTimeout(filterTimer);
    filterTimer = setTimeout(function() {
        window.applyStudentFilters();
    }, 400);
};

window.goToStudentPage = function(page) {
    if (page < 1) page = 1;
    if (page > totalPages) page = totalPages;
    currentPage = page;
    window.renderStudentPage();
};

window.renderStudentPage = function() {
    totalPages = Math.ceil(filteredStudents.length / perPage);
    if (totalPages < 1) totalPages = 1;
    if (currentPage > totalPages) currentPage = totalPages;
    if (currentPage < 1) currentPage = 1;
    
    var start = (currentPage - 1) * perPage;
    var end = Math.min(start + perPage, filteredStudents.length);
    var pageStudents = filteredStudents.slice(start, end);
    
    var container = document.querySelector('.modal-content');
    if (!container) return;
    
    var listContainer = container.querySelector('div[style*="max-height:280px"]');
    if (!listContainer) {
        return;
    }
    
    if (pageStudents.length === 0) {
        listContainer.innerHTML = `
            <div style="text-align:center;padding:20px;color:#6b7280;">
                <div style="font-size:32px;margin-bottom:8px;">📚</div>
                <p>没有找到匹配的学生</p>
                <p style="font-size:12px;">请调整筛选条件</p>
            </div>
        `;
    } else {
        listContainer.innerHTML = pageStudents.map(function(s) {
            var displayName = s.name || s.username;
            var weakCount = s.weak_count || 0;
            var weakBadge = weakCount > 0 ? 
                '<span style="background:#fdeaea;color:#dc2626;padding:2px 10px;border-radius:12px;font-size:11px;">' + weakCount + '个薄弱点</span>' : 
                '<span style="color:#16a34a;font-size:11px;">✓ 无薄弱点</span>';
            return `
                <div class="student-item" data-student-id="${s.id}" data-student-name="${escapeHtml(displayName)}" style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid #f1f3f5;cursor:pointer;transition:background 0.15s;" onmouseover="this.style.background='#f0f4ff'" onmouseout="this.style.background=''" ondblclick="window.selectStudent(${s.id}, '${currentTargetRoute}')">
                    <div style="display:flex;align-items:center;gap:10px;">
                        <span style="font-size:16px;">👤</span>
                        <span style="font-weight:600;">${escapeHtml(displayName)}</span>
                        <span style="color:#6b7280;font-size:12px;">@${escapeHtml(s.username)}</span>
                        <span style="color:#6b7280;font-size:12px;background:#f1f3f5;padding:0 8px;border-radius:4px;">${escapeHtml(s.grade || '未设置')}</span>
                    </div>
                    <div>${weakBadge}</div>
                </div>
            `;
        }).join('');
    }
    
    var paginationContainer = container.querySelector('div[style*="border-top:1px solid #e5e7eb;"]');
    if (paginationContainer) {
        paginationContainer.innerHTML = `
            <div style="display:flex;flex-wrap:wrap;gap:6px;justify-content:center;align-items:center;margin-top:12px;padding-top:10px;border-top:1px solid #e5e7eb;">
                <button class="btn sm ghost" onclick="window.goToStudentPage(1)" ${currentPage <= 1 ? 'disabled' : ''}>⏮</button>
                <button class="btn sm ghost" onclick="window.goToStudentPage(currentPage - 1)" ${currentPage <= 1 ? 'disabled' : ''}>◀</button>
                <span style="font-size:13px;color:#6b7280;">第 ${currentPage} / ${totalPages} 页</span>
                <button class="btn sm ghost" onclick="window.goToStudentPage(currentPage + 1)" ${currentPage >= totalPages ? 'disabled' : ''}>▶</button>
                <button class="btn sm ghost" onclick="window.goToStudentPage(totalPages)" ${currentPage >= totalPages ? 'disabled' : ''}>⏭</button>
                <span style="font-size:13px;color:#6b7280;">共 ${filteredStudents.length} 名学生</span>
            </div>
        `;
    }
};

window.selectStudent = function(studentId, targetRoute) {
    closeModal();
    window.location.href = '?route=' + targetRoute + '&student_id=' + studentId;
};

    // 从控制台表格点击查看学生（兼容旧方式）
    window.viewStudent = function(studentId, targetRoute) {
        window.location.href = '?route=' + targetRoute + '&student_id=' + studentId;
    };

    // 家长查看孩子（兼容旧方式）
    window.viewChild = function(childId, targetRoute) {
        window.location.href = '?route=' + targetRoute + '&child_id=' + childId;
    };

    // ============================================================
    // 10. 侧边栏菜单点击处理 - 家长/学校切换逻辑
    // ============================================================
    document.addEventListener('DOMContentLoaded', function() {
        var userRole = document.querySelector('meta[name="user-role"]')?.content || '';
        
        // 家长侧边栏菜单点击
        if (userRole === 'parent') {
            var parentMenuItems = document.querySelectorAll('.sidebar-nav .nav-item');
            parentMenuItems.forEach(function(item) {
                var href = item.getAttribute('href');
                if (href && (href.includes('route=learning') || href.includes('route=review') || href.includes('route=progress'))) {
                    if (!href.includes('child_id=')) {
                        var originalHref = href;
                        item.setAttribute('data-original-href', originalHref);
                        item.removeAttribute('href');
                        item.style.cursor = 'pointer';
                        item.addEventListener('click', function(e) {
                            e.preventDefault();
                            var route = this.getAttribute('data-original-href').match(/route=([^&]+)/);
                            if (route && route[1]) {
                                showChildSelector(route[1]);
                            } else {
                                showChildSelector('learning');
                            }
                        });
                    }
                }
            });
        }
        
        // 学校/培训机构侧边栏菜单点击 - 弹出学生选择器
        if (userRole === 'school' || userRole === 'training') {
            var orgMenuItems = document.querySelectorAll('.sidebar-nav .nav-item');
            orgMenuItems.forEach(function(item) {
                var href = item.getAttribute('href');
                if (href && (href.includes('route=learning') || href.includes('route=review') || href.includes('route=progress'))) {
                    var originalHref = href;
                    item.setAttribute('data-original-href', originalHref);
                    item.removeAttribute('href');
                    item.style.cursor = 'pointer';
                    item.addEventListener('click', function(e) {
                        e.preventDefault();
                        var route = this.getAttribute('data-original-href').match(/route=([^&]+)/);
                        if (route && route[1]) {
                            showStudentSelector(route[1]);
                        } else {
                            showStudentSelector('learning');
                        }
                    });
                }
            });
        }
    });

    // ============================================================
    // 11. 登出
    // ============================================================
    window.logout = function() {
        showModal(`
            <div style="text-align:center;padding:16px 8px;">
                <div style="font-size:48px;margin-bottom:8px;">👋</div>
                <h3 style="margin:0 0 6px 0;">确认退出</h3>
                <p style="color:#6b7280;margin:0;">确定要退出登录吗？</p>
                <div style="display:flex;gap:10px;justify-content:center;margin-top:16px;flex-wrap:wrap;">
                    <button class="btn" onclick="confirmLogout()">确定退出</button>
                    <button class="btn ghost" onclick="closeModal()">取消</button>
                </div>
            </div>
        `);
    };

    window.confirmLogout = function() {
        closeModal();
        window.location.href = '?route=logout';
    };

    // ============================================================
    // 12. 初始化
    // ============================================================
    document.addEventListener('DOMContentLoaded', function() {
        // 薄弱点徽章
        var weakBadge = document.getElementById('weakBadge');
        if (weakBadge) {
            fetch('api/progress.php')
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.success) {
                        var count = 0;
                        for (var id in data.data) {
                            var weak = data.data[id].weak || {};
                            for (var k in weak) {
                                if (!weak[k].cleared) count++;
                            }
                        }
                        if (count > 0) {
                            weakBadge.textContent = count;
                            weakBadge.classList.add('show');
                        } else {
                            weakBadge.classList.remove('show');
                        }
                    }
                })
                .catch(function() {});
        }
        
        // 确保主题选择器显示当前主题
        var themeSelect = document.getElementById('themeSelect');
        if (themeSelect) {
            var savedTheme = localStorage.getItem('math_theme') || 'default';
            themeSelect.value = savedTheme;
        }
    });
})();