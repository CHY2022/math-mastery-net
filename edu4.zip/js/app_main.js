/* ============================================================
 * 融会贯通 · 核心逻辑（PHP版）
 * 保留原有功能，适配后端API
 * 文件名: app_main.js（避免与原有app.js冲突）
 * ============================================================ */
(function () {
    'use strict';

    // ============================================================
    // 1. 工具函数
    // ============================================================
    var $ = function(sel) { return document.querySelector(sel); };
    var view = function() { return document.getElementById('view'); };

    function shuffle(a) {
        a = a.slice();
        for (var i = a.length - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * (i + 1));
            var t = a[i];
            a[i] = a[j];
            a[j] = t;
        }
        return a;
    }

    function toast(msg) {
        if (typeof showToast === 'function') {
            showToast(msg);
            return;
        }
        var t = $("#toast");
        if (!t) return;
        t.textContent = msg;
        t.classList.add("show");
        clearTimeout(t._t);
        t._t = setTimeout(function() { t.classList.remove("show"); }, 2200);
    }

    function updateBadge() {
        var b = $("#weakBadge");
        if (!b) return;
        var count = AppMain.weakCount();
        if (count > 0) {
            b.textContent = count;
            b.classList.add("show");
        } else {
            b.classList.remove("show");
        }
    }

    // ============================================================
    // 2. 数据与状态
    // ============================================================
    var progress = {};
    var techniques = [];

    function getTechniques() {
        if (typeof TECHNIQUES !== 'undefined') {
            techniques = TECHNIQUES;
        }
        return techniques;
    }

    function tech(id) {
        getTechniques();
        for (var i = 0; i < techniques.length; i++) {
            if (techniques[i].id === id) return techniques[i];
        }
        return null;
    }

    function tstate(id) {
        if (!progress[id]) {
            progress[id] = { mastered: false, weak: {} };
        }
        return progress[id];
    }

    function unlocked(id) {
        var t = tech(id);
        if (!t) return false;
        if (!t.prereq) return true;
        
        // 检查前置技巧是否已掌握
        var prereqProgress = progress[t.prereq];
        if (!prereqProgress) {
            if (window.__PROGRESS_DATA && window.__PROGRESS_DATA[t.prereq]) {
                return window.__PROGRESS_DATA[t.prereq].mastered === true;
            }
            return false;
        }
        return prereqProgress.mastered === true;
    }

    function weakCount() {
        var n = 0;
        for (var id in progress) {
            var w = progress[id].weak || {};
            for (var k in w) {
                if (!w[k].cleared) n++;
            }
        }
        return n;
    }

    // ============================================================
    // 3. 加载进度（从数据库）
    // ============================================================
    function loadProgress() {
        if (window.__PROGRESS_DATA) {
            var data = window.__PROGRESS_DATA;
            console.log('📌 从 __PROGRESS_DATA 加载进度:', data);
            for (var id in data) {
                if (!progress[id]) progress[id] = {};
                progress[id].mastered = data[id].mastered || false;
                progress[id].weak = data[id].weak || {};
                progress[id].learn_count = data[id].learn_count || 0;
                progress[id].practice_count = data[id].practice_count || 0;
                progress[id].gate_count = data[id].gate_count || 0;
                progress[id].weak_count = data[id].weak_count || 0;
            }
            
            if (data['count']) {
                console.log('📌 count mastered:', data['count'].mastered);
            }
            
            if (document.getElementById('learningPath')) {
                setTimeout(function() {
                    renderPath();
                }, 100);
            }
            return Promise.resolve(progress);
        }
        
        return fetch('api/progress.php')
            .then(function(res) { return res.json(); })
            .then(function(data) {
                if (data.success) {
                    var dbProgress = data.data || {};
                    for (var id in dbProgress) {
                        if (!progress[id]) progress[id] = {};
                        progress[id].mastered = dbProgress[id].mastered || false;
                        progress[id].weak = dbProgress[id].weak || {};
                    }
                }
                return progress;
            })
            .catch(function() { return {}; });
    }

    // ============================================================
    // 4. 保存进度到数据库
    // ============================================================
    function saveProgress(data) {
        return fetch('api/progress.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        })
        .then(function(res) { return res.json(); })
        .catch(function() { return { success: false }; });
    }

    // ============================================================
    // 5. 渲染学习路径
    // ============================================================
    function renderPath() {
    // 【修复】如果 learning.php 设置了跳过标志，则不执行渲染
    if (window.__SKIP_APP_MAIN_RENDER) {
        console.log('📌 app_main.js renderPath 被 learning.php 跳过');
        return;
    }
        var container = document.getElementById('learningPath');
        if (!container) return;
        
        var techs = getTechniques();
        if (!techs || !techs.length) {
            container.innerHTML = '<div class="empty">数据加载中...</div>';
            return;
        }

        var stages = ['小学', '中学', '高中'];
        var groups = {};
        techs.forEach(function(t) {
            var key = t.stage + '|' + t.grade;
            if (!groups[key]) groups[key] = [];
            groups[key].push(t);
        });

        var html = '';
        stages.forEach(function(stage) {
            var gradeSet = {};
            var grades = [];
            techs.forEach(function(t) {
                if (t.stage === stage && !gradeSet[t.grade]) {
                    gradeSet[t.grade] = true;
                    grades.push(t.grade);
                }
            });
            grades.sort(function(a, b) {
                var num = { '一':1,'二':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9,'十':10,'十一':11,'十二':12 };
                return (num[a[0]] || 99) - (num[b[0]] || 99);
            });
            if (!grades.length) return;
            
            html += '<div class="stage-banner"><span class="stage-name">' + stage + '</span></div>';
            
            grades.forEach(function(g) {
                var items = groups[stage + '|' + g] || [];
var totalCount = items.length;
var masteredCount = 0;
items.forEach(function(t) {
    var st = progress[t.id] || { mastered: false };
    if (st.mastered) masteredCount++;
});
var pct = totalCount > 0 ? Math.round(masteredCount / totalCount * 100) : 0;
var pctDisplay = pct + '%';
var progressBarColor = pct === 100 ? '#16a34a' : (pct >= 50 ? '#d97706' : '#2f6fed');

html += '<div class="grade-sep" style="display:flex;align-items:center;flex-wrap:wrap;gap:6px 12px;margin:18px 0 6px;font-weight:700;font-size:14px;border-left:4px solid #2f6fed;padding-left:8px;">';
html += '<span class="grade-tag" style="font-weight:700;color:#2f6fed;font-size:14px;">' + g + '</span>';
html += '<span class="grade-count" style="font-size:12px;color:#6b7280;font-weight:400;margin-left:4px;">' + items.length + ' 个技巧</span>';
html += '<span class="grade-progress" style="display:inline-flex;align-items:center;gap:8px;font-size:12px;color:#6b7280;margin-left:auto;">';
html += '<span class="grade-progress-text" style="font-weight:500;white-space:nowrap;">已掌握 ' + masteredCount + '/' + totalCount + '（' + pctDisplay + '）</span>';
html += '<span class="grade-progress-bar" style="width:80px;height:6px;background:#e5e7eb;border-radius:4px;overflow:hidden;display:inline-block;flex-shrink:0;">';
html += '<span style="display:block;height:100%;width:' + pct + '%;background:' + progressBarColor + ';border-radius:4px;transition:width 0.6s ease;"></span>';
html += '</span>';
html += '</span>';
html += '</div>';
                
                var stepNo = 0;
                items.forEach(function(t) {
                    stepNo++;
                    var st = progress[t.id] || { mastered: false, weak: {} };
                    var isLocked = t.prereq && (!progress[t.prereq] || !progress[t.prereq].mastered);
                    var status = isLocked ? 'lock' : (st.mastered ? 'done' : 'learn');
                    var weakN = 0;
                    if (st.weak) {
                        for (var k in st.weak) {
                            if (!st.weak[k].cleared) weakN++;
                        }
                    }
                    
                    var prereqTech = null;
                    if (t.prereq) {
                        for (var p = 0; p < techs.length; p++) {
                            if (techs[p].id === t.prereq) { prereqTech = techs[p]; break; }
                        }
                    }
                    
                    html += '<div class="node ' + (status === 'done' ? 'mastered' : status === 'lock' ? 'locked' : '') + '" id="node-' + t.id + '">';
                    html += '<div class="step">' + (status === 'done' ? '✓' : (status === 'lock' ? '🔒' : stepNo)) + '</div>';
                    html += '<div class="body">';
                    html += '<div class="title">' + t.name;
                    if (status === 'lock') html += '<span class="lock-ico">🔒</span>';
                    html += '<span class="status-pill ' + status + '">' + (status === 'lock' ? '未解锁' : status === 'done' ? '已掌握' : '学习中') + '</span>';
                    if (weakN) html += '<span class="tag w">薄弱点 ' + weakN + '</span>';
                    html += '</div>';
                    html += '<div class="meta">' + (t.summary || '') + '</div>';
                    html += '<div class="acts">';
                    if (status !== 'lock') html += '<a class="btn sm" href="#/learn/' + t.id + '" data-tech-id="' + t.id + '" data-action="learn">去学习</a>';
                    if (status !== 'lock') html += '<a class="btn sm ghost" href="#/practice/' + t.id + '" data-tech-id="' + t.id + '" data-action="practice">练习</a>';
                    if (status !== 'lock' && !st.mastered) html += '<a class="btn sm soft" href="#/gate/' + t.id + '" data-tech-id="' + t.id + '" data-action="gate">通关测试</a>';
                    html += '</div>';
                    if (status === 'lock' && t.prereq) {
                        html += '<div class="meta" style="color:var(--lock)">需先掌握：' + (prereqTech ? prereqTech.name : t.prereq) + '</div>';
                    }
                    html += '</div></div>';
                });
            });
        });
        
        container.innerHTML = html;
        updateBadge();
        
        container.querySelectorAll('.acts a[data-tech-id]').forEach(function(link) {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                var href = this.getAttribute('href');
                var techId = this.getAttribute('data-tech-id');
                var action = this.getAttribute('data-action');
                AppMain.handleHashRoute(href, techId, action);
            });
        });
    }

    // ============================================================
    // 6. 统一的路由处理函数
    // ============================================================
    function handleHashRoute(hash, techId, action) {
        var parts = hash.replace(/^#\/?/, "").split("/");
        var route = parts[0];
        var id = parts[1] || techId;
        
        var isLearningPage = window.location.search && window.location.search.indexOf('route=learning') > -1;
        var isReviewPage = window.location.search && window.location.search.indexOf('route=review') > -1;
        var isProgressPage = window.location.search && window.location.search.indexOf('route=progress') > -1;
        
        if (isLearningPage || isReviewPage || isProgressPage) {
            loadTechniqueContent(route, id);
            return;
        }
        
        window.location.hash = hash;
    }

    // ============================================================
    // 7. AJAX 加载技巧内容（在 PHP 页面中）
    // ============================================================
    function loadTechniqueContent(action, techId) {
        var viewContainer = document.getElementById('view');
        if (!viewContainer) return;
        
        var t = tech(techId);
        if (!t) {
            viewContainer.innerHTML = '<div class="empty">技巧不存在</div>';
            return;
        }
        
        if (!unlocked(techId)) {
            toast("先融会贯通上一技巧才能解锁");
            return;
        }
        
        if (action === 'learn') {
            renderLearnInline(viewContainer, t);
        } else if (action === 'practice' || action === 'gate') {
            renderQuizInline(viewContainer, t, action);
        }
    }

    // ============================================================
    // 8. 内联渲染学习内容
    // ============================================================
    function renderLearnInline(container, t) {
        var st = tstate(t.id);
        
        var html = '<div style="margin-bottom:12px;"><a href="?route=learning" class="btn ghost sm" style="margin-bottom:12px;">← 返回学习路径</a></div>';
        html += '<div class="card"><div class="tech-head"><h2 class="section" style="margin:0">' + t.name + '</h2><span class="tag">' + (t.grade || '') + '</span></div>';
        html += '<div class="muted">' + (t.summary || '') + '</div>';
        html += '<div class="kou"><b>名师口诀：</b>' + (t.kou || '') + '</div>';
        html += '<h3>解题步骤</h3><ol class="steps">';
        if (t.steps) {
            for (var i = 0; i < t.steps.length; i++) {
                html += '<li>' + t.steps[i] + '</li>';
            }
        }
        html += '</ol></div>';
        
        if (t.anim && window.Anim && window.Anim[t.anim]) {
            html += '<div class="card"><h3>动图演示</h3><div class="anim-wrap" id="animBox"></div></div>';
        }
        
        html += '<div class="row" style="margin:4px 0 18px;">';
        html += '<a class="btn" href="#/practice/' + t.id + '" data-tech-id="' + t.id + '" data-action="practice" onclick="event.preventDefault(); AppMain.handleHashRoute(\'#/practice/' + t.id + '\', \'' + t.id + '\', \'practice\');">开始练习</a>';
        if (!st.mastered) {
            html += '<a class="btn soft" href="#/gate/' + t.id + '" data-tech-id="' + t.id + '" data-action="gate" onclick="event.preventDefault(); AppMain.handleHashRoute(\'#/gate/' + t.id + '\', \'' + t.id + '\', \'gate\');">通关测试</a>';
        } else {
            html += '<span class="status-pill done">已掌握 ✓</span>';
        }
        html += '<a class="btn ghost" href="?route=learning">返回路径</a>';
        html += '</div>';
        
        container.innerHTML = html;
        
        var userId = window.VIEWING_USER_ID || 0;
        fetch('api/progress.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                action: 'record_learn',
                technique_id: t.id,
                user_id: userId
            })
        }).catch(function() {});
        
        if (t.anim && window.Anim && window.Anim[t.anim]) {
            var box = document.getElementById('animBox');
            if (box) window.Anim[t.anim](box);
        }
        
        container.querySelectorAll('a[data-tech-id]').forEach(function(link) {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                var href = this.getAttribute('href');
                var techId = this.getAttribute('data-tech-id');
                var action = this.getAttribute('data-action');
                AppMain.handleHashRoute(href, techId, action);
            });
        });
    }

    // ============================================================
    // 9. 内联渲染练习/通关内容
    // ============================================================
    function renderQuizInline(container, t, mode) {
        if (!unlocked(t.id)) {
            toast("先融会贯通上一技巧才能解锁");
            container.innerHTML = '<div class="empty"><a href="?route=learning" class="btn">返回学习路径</a></div>';
            return;
        }
        
        var items = [];
        if (typeof t.qgen === 'function') {
            var qData = t.qgen(8);
            for (var i = 0; i < qData.length; i++) {
                items.push({ q: qData[i], qidx: i, gen: true });
            }
        } else if (t.questions && t.questions.length > 0) {
            var pool = shuffle(t.questions.map(function(_, idx) { return idx; }));
            var count = Math.min(pool.length, 8);
            for (var i = 0; i < count; i++) {
                items.push({ q: t.questions[pool[i]], qidx: pool[i], gen: false });
            }
        }
        
        if (!items || items.length === 0) {
            container.innerHTML = '<div class="empty">暂无题目，请稍后再试</div>';
            return;
        }
        
        var html = '<div style="margin-bottom:12px;"><a href="?route=learning" class="btn ghost sm">← 返回学习路径</a></div>';
        html += '<div class="card"><div class="tech-head"><h2 class="section" style="margin:0">' + t.name + ' · ' + (mode === 'gate' ? '通关测试' : '自由练习') + '</h2>';
        html += '<span class="tag">' + (mode === 'gate' ? '需 ≥80% 且薄弱点清零' : '不限量') + '</span></div>';
        html += '<div class="muted">' + (mode === 'gate' ? '通关测试会优先把你之前的薄弱点放进题里；全部答对并清零薄弱点，才算融会贯通。' : '随手练，做错自动记入薄弱点，可去「薄弱点复习」集中攻克。') + '</div></div>';
        html += '<div id="quizContainer"></div>';
        html += '<div class="row" style="margin-top:12px;"><a class="btn ghost" href="?route=learning">返回路径</a></div>';
        
        container.innerHTML = html;
        
        var quizContainer = document.getElementById('quizContainer');
        if (!quizContainer) return;
        
        var st = tstate(t.id);
        var answered = 0;
        var correct = 0;
        var total = items.length;
        
        items.forEach(function(it, qi) {
            var q = it.q;
            if (!q) return;
            
            var isJudge = q.opts && q.opts.length === 2 && 
                         ((q.opts[0] === '对' && q.opts[1] === '错') || 
                          (q.opts[0] === '正确' && q.opts[1] === '错误'));
            
            var shuffled = shuffleOptions(q);
            var disp = shuffled;
            
            var card = document.createElement('div');
            card.className = 'q';
            card.dataset.done = '0';
            
            var tag = q.level === '易错' ? '<span class="tag w">易错</span>' : 
                      (q.level === '进阶' ? '<span class="tag g">进阶</span>' : '<span class="tag">基础</span>');
            
            var figHtml = '';
            if (q.fig && window.Fig) {
                try {
                    if (typeof q.fig === 'string' && window.Fig[q.fig]) {
                        figHtml = '<div class="qfig">' + window.Fig[q.fig]() + '</div>';
                    } else if (typeof q.fig === 'object' && window.Fig[q.fig.name]) {
                        figHtml = '<div class="qfig">' + window.Fig[q.fig.name](q.fig) + '</div>';
                    }
                } catch(e) {}
            }
            
            var optsHtml = '';
            for (var j = 0; j < disp.opts.length; j++) {
                var mark = isJudge ? (disp.opts[j] === '对' || disp.opts[j] === '正确' || disp.opts[j] === '✓' ? '✓' : '✗') : String.fromCharCode(65 + j);
                optsHtml += '<div class="opt' + (isJudge ? ' judge' : '') + '" data-i="' + j + '">';
                optsHtml += '<span class="mark' + (isJudge ? ' judge' : '') + '">' + mark + '</span>';
                optsHtml += '<span>' + (disp.opts[j] || '') + '</span>';
                optsHtml += '</div>';
            }
            
            card.innerHTML = '<div class="qtext">' + (qi + 1) + '. ' + (q.q || '') + ' ' + tag + '</div>' + figHtml + '<div class="opts' + (isJudge ? ' judge' : '') + '">' + optsHtml + '</div>';
            
            quizContainer.appendChild(card);
            
            var opts = card.querySelectorAll('.opt');
            opts.forEach(function(op) {
                op.addEventListener('click', function() {
                    if (card.dataset.done === '1') return;
                    card.dataset.done = '1';
                    
                    var chosen = parseInt(this.dataset.i);
                    var ans = disp.ans;
                    var isCorrect = (chosen === ans);
                    
                    opts.forEach(function(o, i) {
                        o.style.pointerEvents = 'none';
                        if (i === ans) o.classList.add('correct');
                    });
                    
                    if (isCorrect) {
                        this.classList.add('correct');
                        correct++;
                        if (it.gen) {
                            st.weak[t.id] = { fails: 0, cleared: true };
                        } else if (st.weak["" + it.qidx]) {
                            st.weak["" + it.qidx].cleared = true;
                        }
                    } else {
                        this.classList.add('wrong');
                        if (it.gen) {
                            st.weak[t.id] = st.weak[t.id] || { fails: 0, cleared: false };
                            st.weak[t.id].fails++;
                            st.weak[t.id].cleared = false;
                        } else {
                            if (!st.weak["" + it.qidx]) {
                                st.weak["" + it.qidx] = { fails: 0, cleared: false };
                            }
                            st.weak["" + it.qidx].fails++;
                            st.weak["" + it.qidx].cleared = false;
                        }
                    }
                    
                    saveProgress({ action: 'update', data: st });
                    
                    var userId = window.VIEWING_USER_ID || 0;
                    var currentScore = Math.round((correct / total) * 100);
                    
                    fetch('api/progress.php', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({
                            action: 'record_answer',
                            technique_id: t.id,
                            action_type: mode === 'gate' ? 'gate' : 'practice',
                            score: currentScore,
                            is_correct: isCorrect,
                            question_idx: it.qidx,
                            user_id: userId
                        })
                    }).catch(function() {});
                    
                    var explain = document.createElement('div');
                    explain.className = 'explain';
                    explain.innerHTML = '解析：' + (q.explain || '无解析');
                    card.appendChild(explain);
                    
                    answered++;
                    if (answered === total) {
                        finishQuiz(t, mode, correct, total);
                    }
                });
            });
        });
    }

    function shuffleOptions(q) {
        if (!q || !q.opts) return { opts: [], ans: 0 };
        var idx = [];
        for (var i = 0; i < q.opts.length; i++) idx.push(i);
        var sh = shuffle(idx);
        var result = { opts: [], ans: 0 };
        for (var i = 0; i < sh.length; i++) {
            result.opts.push(q.opts[sh[i]]);
        }
        result.ans = sh.indexOf(q.ans);
        return result;
    }

    // ============================================================
    // 10. 完成练习/通关
    // ============================================================
    function finishQuiz(t, mode, correct, total) {
        var st = tstate(t.id);
        var weakRemain = 0;
        if (st.weak) {
            for (var k in st.weak) {
                if (!st.weak[k].cleared) weakRemain++;
            }
        }
        
        var container = document.getElementById('quizContainer');
        if (!container) return;
        
        var banner = document.createElement('div');
        banner.className = 'card center';
        
        if (mode === 'gate') {
            var pass = correct >= Math.ceil(total * 0.8) && weakRemain === 0;
            if (pass) {
                st.mastered = true;
                
                saveProgress({ action: 'update', data: st });
                
                var userId = window.VIEWING_USER_ID || 0;
                var score = Math.round((correct / total) * 100);
                
                // 【关键】调用 mastered API
                fetch('api/progress.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        action: 'mastered',
                        technique_id: t.id,
                        score: score,
                        user_id: userId
                    })
                })
                .then(function(res) { return res.json(); })
                .then(function(result) {
                    console.log('📌 mastered API 响应:', result);
                    if (result.success) {
                        if (window.__PROGRESS_DATA && window.__PROGRESS_DATA[t.id]) {
                            window.__PROGRESS_DATA[t.id].mastered = true;
                        }
                        if (window.AppMain && window.AppMain._progress && window.AppMain._progress[t.id]) {
                            window.AppMain._progress[t.id].mastered = true;
                        }
                        // 🎉 显示庆祝特效
                        showCelebration(t.name);
                        setTimeout(function() { 
                            window.location.reload(); 
                        }, 4000);
                    } else {
                        console.error('❌ mastered API 失败:', result.error);
                        // 即使失败也显示庆祝（因为本地已通过）
                        showCelebration(t.name);
                        setTimeout(function() { 
                            window.location.reload(); 
                        }, 4000);
                    }
                })
                .catch(function(err) {
                    console.error('❌ mastered API 错误:', err);
                    // 即使失败也显示庆祝
                    showCelebration(t.name);
                    setTimeout(function() { 
                        window.location.reload(); 
                    }, 4000);
                });
                
                var techs = getTechniques();
                var nxt = null;
                for (var i = 0; i < techs.length; i++) {
                    if (techs[i].prereq === t.id) { nxt = techs[i]; break; }
                }
                
                banner.innerHTML = '<div class="qres" style="color:var(--ok)">🎉 融会贯通！' + t.name + ' 已掌握</div>';
                if (nxt) {
                    banner.innerHTML += '<div class="muted">下一技巧已解锁：<b>' + nxt.name + '</b></div>';
                    banner.innerHTML += '<a class="btn" href="?route=learning" style="margin-top:10px;">返回学习路径</a>';
                } else {
                    banner.innerHTML += '<div class="muted">恭喜！你已掌握本年级所有技巧！</div>';
                    banner.innerHTML += '<a class="btn" href="?route=learning" style="margin-top:10px;">返回学习路径</a>';
                }
            } else {
                banner.innerHTML = '<div class="qres" style="color:var(--warn)">还差一点：本次正确 ' + correct + '/' + total + 
                    (weakRemain ? '，还有 ' + weakRemain + ' 个薄弱点没清零' : '') + '</div>' +
                    '<div class="muted">继续练习，清零薄弱点后再来通关！</div>' +
                    '<a class="btn soft" href="?route=review" style="margin-top:8px;">去复习薄弱点</a>' +
                    '<a class="btn ghost" href="?route=learning" style="margin-top:8px;">返回路径</a>';
            }
        } else {
            banner.innerHTML = '<div class="qres">本轮完成 ' + total + ' 题，正确 ' + correct + ' 题。</div>' +
                '<a class="btn ghost" href="?route=learning">返回路径</a>' +
                '<a class="btn" href="#/practice/' + t.id + '" style="margin-left:8px;" onclick="event.preventDefault(); AppMain.handleHashRoute(\'#/practice/' + t.id + '\', \'' + t.id + '\', \'practice\');">🔄 再练一组</a>';
        }
        
        container.appendChild(banner);
        updateBadge();
    }

    // ============================================================
    // 11. 路由
    // ============================================================
    function route() {
        var h = location.hash.replace(/^#\/?/, "");
        var parts = h.split("/");
        
        document.querySelectorAll(".nav-link").forEach(function(a) {
            a.classList.toggle("active", a.dataset.route === parts[0]);
        });
        updateBadge();
        
        if (window.location.search && window.location.search.indexOf('route=learning') > -1) {
            var container = document.getElementById('learningPath');
            if (container) {
                if (parts[0] === "" || parts[0] === "path") {
                    renderPath();
                    return;
                }
                if (parts[0] === "learn" || parts[0] === "practice" || parts[0] === "gate") {
                    var techId = parts[1];
                    if (techId) {
                        loadTechniqueContent(parts[0], techId);
                        return;
                    }
                }
            }
            return;
        }
        
        if (window.location.search && (window.location.search.indexOf('route=review') > -1 || window.location.search.indexOf('route=progress') > -1)) {
            return;
        }
        
        if (parts[0] === "" || parts[0] === "path") {
            if (document.getElementById('learningPath')) {
                renderPath();
            }
            return;
        }
        if (parts[0] === "learn") {
            var t = tech(parts[1]);
            if (t) renderLearnInline(document.getElementById('view'), t);
            return;
        }
        if (parts[0] === "practice") {
            var t = tech(parts[1]);
            if (t) renderQuizInline(document.getElementById('view'), t, "practice");
            return;
        }
        if (parts[0] === "gate") {
            var t = tech(parts[1]);
            if (t) renderQuizInline(document.getElementById('view'), t, "gate");
            return;
        }
        if (parts[0] === "review") return renderReview();
        if (parts[0] === "progress") return renderProgress();
        
        renderPath();
    }

    // ============================================================
    // 12. Review 和 Progress
    // ============================================================
    function renderReview() {
        var v = document.getElementById('view');
        if (!v) return;
        v.innerHTML = '<h2 class="section">薄弱点复习</h2><div class="empty"><div style="font-size:48px;margin-bottom:12px;">🔍</div><p style="color:#6b7280;">请从侧边栏进入「薄弱点复习」页面</p><a href="?route=review" class="btn">前往薄弱点复习</a></div>';
    }

    function renderProgress() {
        var v = document.getElementById('view');
        if (!v) return;
        v.innerHTML = '<h2 class="section">我的进度</h2><div class="empty"><div style="font-size:48px;margin-bottom:12px;">📈</div><p style="color:#6b7280;">请从侧边栏进入「我的进度」页面</p><a href="?route=progress" class="btn">前往我的进度</a></div>';
    }

    // ============================================================
    // 13. 初始化
    // ============================================================
    function init() {
        window.AppMain = window.AppMain || {};
        window.AppMain.handleHashRoute = handleHashRoute;
        window.AppMain.tech = tech;
        window.AppMain.tstate = tstate;
        window.AppMain.unlocked = unlocked;
        window.AppMain.weakCount = weakCount;
        window.AppMain.updateBadge = updateBadge;
        window.AppMain.toast = toast;
        window.AppMain.loadTechniqueContent = loadTechniqueContent;
        window.AppMain.renderLearnInline = renderLearnInline;
        window.AppMain.renderQuizInline = renderQuizInline;
        window.AppMain.renderPath = renderPath;
        window.AppMain.route = route;
        window.AppMain.loadProgress = loadProgress;
        window.AppMain.saveProgress = saveProgress;
        window.AppMain.getTechniques = getTechniques;
        window.AppMain.init = init;
        window.AppMain.finishQuiz = finishQuiz;
        window.AppMain._progress = progress;
        
        loadProgress().then(function() {
            if (document.getElementById('learningPath')) {
                renderPath();
            }
            updateBadge();
        });
        
        window.addEventListener('hashchange', function() { route(); });
        window.addEventListener('popstate', function() { route(); });
        
        document.addEventListener('click', function(e) {
            var target = e.target.closest('a[href^="#/"]');
            if (target) {
                var href = target.getAttribute('href');
                if (href && href.indexOf('#/') === 0) {
                    e.preventDefault();
                    var parts = href.replace(/^#\/?/, "").split("/");
                    var action = parts[0];
                    var techId = parts[1];
                    if (techId) {
                        handleHashRoute(href, techId, action);
                    }
                }
            }
        });
    }

    if (document.readyState === 'complete') {
        init();
    } else {
        document.addEventListener('DOMContentLoaded', init);
    }

    // ============================================================
    // 14. 通关庆祝特效
    // ============================================================
    function showCelebration(techName) {
        // 创建全屏容器
        var overlay = document.createElement('div');
        overlay.id = 'celebrationOverlay';
        overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;z-index:9999;pointer-events:none;overflow:hidden;';
        document.body.appendChild(overlay);
        
        // 创建庆祝文字
        var text = document.createElement('div');
        text.id = 'celebrationText';
        text.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:10001;text-align:center;pointer-events:none;';
        text.innerHTML = `
            <div style="font-size:42px;font-weight:900;color:#ffd700;text-shadow:0 0 20px rgba(255,215,0,0.8),0 0 40px rgba(255,215,0,0.4),0 4px 20px rgba(0,0,0,0.3);animation:textPop 0.8s cubic-bezier(0.175,0.885,0.32,1.275);font-family:'PingFang SC','Microsoft YaHei',sans-serif;line-height:1.4;">
                🎉 恭喜你过关！<br>
                <span style="font-size:32px;color:#fff;text-shadow:0 0 20px rgba(255,255,255,0.5),0 0 40px rgba(255,255,255,0.2);display:block;margin-top:6px;">
                    "「${techName}」" 你真棒！ 🌟
                </span>
            </div>
        `;
        document.body.appendChild(text);
        
        // 添加CSS动画
        var style = document.createElement('style');
        style.id = 'celebrationStyle';
        style.textContent = `
            @keyframes textPop {
                0% { transform: scale(0.1) rotate(-10deg); opacity: 0; }
                50% { transform: scale(1.2) rotate(2deg); opacity: 1; }
                100% { transform: scale(1) rotate(0deg); opacity: 1; }
            }
            @keyframes confettiFall {
                0% { transform: translateY(-100vh) rotate(0deg); opacity: 1; }
                100% { transform: translateY(110vh) rotate(720deg); opacity: 0; }
            }
            @keyframes flowerFloat {
                0% { transform: translateY(-100vh) rotate(0deg) scale(0.5); opacity: 1; }
                50% { transform: translateY(30vh) rotate(180deg) scale(1.2); opacity: 1; }
                100% { transform: translateY(110vh) rotate(360deg) scale(0.5); opacity: 0; }
            }
            @keyframes sparkle {
                0% { transform: scale(0) rotate(0deg); opacity: 0; }
                50% { transform: scale(1.5) rotate(180deg); opacity: 1; }
                100% { transform: scale(0) rotate(360deg); opacity: 0; }
            }
            @keyframes ribbonWave {
                0% { transform: translateX(-100vw) rotate(0deg) scale(1); opacity: 1; }
                50% { transform: translateX(0vw) rotate(180deg) scale(1.2); opacity: 1; }
                100% { transform: translateX(100vw) rotate(360deg) scale(0.8); opacity: 0; }
            }
            @keyframes starTwinkle {
                0%, 100% { transform: scale(0) rotate(0deg); opacity: 0; }
                30% { transform: scale(1.3) rotate(30deg); opacity: 1; }
                70% { transform: scale(1.1) rotate(-20deg); opacity: 1; }
                100% { transform: scale(0) rotate(60deg); opacity: 0; }
            }
            @keyframes balloonRise {
                0% { transform: translateY(100vh) scale(0.3); opacity: 0; }
                20% { transform: translateY(60vh) scale(1.1); opacity: 1; }
                80% { transform: translateY(-20vh) scale(1); opacity: 1; }
                100% { transform: translateY(-80vh) scale(0.8); opacity: 0; }
            }
            .confetti-piece {
                position:absolute;
                width:12px;height:12px;
                border-radius:2px;
                animation:confettiFall linear forwards;
            }
            .flower-piece {
                position:absolute;
                font-size:30px;
                animation:flowerFloat ease-in-out forwards;
            }
            .sparkle-piece {
                position:absolute;
                font-size:22px;
                animation:sparkle ease-in-out forwards;
            }
            .ribbon-piece {
                position:absolute;
                font-size:34px;
                animation:ribbonWave ease-in-out forwards;
            }
            .star-piece {
                position:absolute;
                font-size:24px;
                animation:starTwinkle ease-in-out forwards;
            }
            .balloon-piece {
                position:absolute;
                font-size:36px;
                animation:balloonRise ease-in-out forwards;
            }
        `;
        document.head.appendChild(style);
        
        // 颜色方案
        var colors = ['#ff6b6b', '#ffd93d', '#6bcb77', '#4d96ff', '#ff6bb5', '#ff9f43', '#a29bfe', '#fd79a8', '#00cec9', '#fdcb6e'];
        
        // 1. 生成彩纸 (70片)
        var confettiEmojis = ['⬛', '⬜', '🔴', '🟠', '🟡', '🟢', '🔵', '🟣'];
        for (var i = 0; i < 70; i++) {
            var piece = document.createElement('div');
            piece.className = 'confetti-piece';
            var size = 8 + Math.random() * 10;
            var x = Math.random() * 100;
            var delay = Math.random() * 3;
            var duration = 2 + Math.random() * 3;
            var color = colors[Math.floor(Math.random() * colors.length)];
            var isEmoji = Math.random() > 0.6;
            piece.style.cssText = `
                left:${x}%;
                width:${size}px;height:${size * (0.6 + Math.random() * 0.8)}px;
                background:${isEmoji ? 'transparent' : color};
                ${isEmoji ? 'font-size:' + (size + 4) + 'px;text-align:center;line-height:1;' : ''}
                border-radius:${Math.random() > 0.5 ? '50%' : '2px'};
                animation-delay:${delay}s;
                animation-duration:${duration}s;
            `;
            if (isEmoji) {
                piece.textContent = confettiEmojis[Math.floor(Math.random() * confettiEmojis.length)];
            }
            overlay.appendChild(piece);
        }
        
        // 2. 生成鲜花 (25朵)
        var flowerEmojis = ['🌸', '🌺', '🌻', '🌹', '🌷', '🌼', '💐', '🌸', '🌺', '🌻'];
        for (var i = 0; i < 25; i++) {
            var piece = document.createElement('div');
            piece.className = 'flower-piece';
            var x = 5 + Math.random() * 90;
            var delay = 0.5 + Math.random() * 3;
            var duration = 4 + Math.random() * 3;
            var emoji = flowerEmojis[Math.floor(Math.random() * flowerEmojis.length)];
            var size = 24 + Math.random() * 20;
            piece.style.cssText = `
                left:${x}%;
                font-size:${size}px;
                animation-delay:${delay}s;
                animation-duration:${duration}s;
            `;
            piece.textContent = emoji;
            overlay.appendChild(piece);
        }
        
        // 3. 生成星星闪烁 (35颗)
        var starEmojis = ['⭐', '🌟', '✨', '💫'];
        for (var i = 0; i < 35; i++) {
            var piece = document.createElement('div');
            piece.className = 'star-piece';
            var x = 3 + Math.random() * 94;
            var y = 5 + Math.random() * 40;
            var delay = Math.random() * 4;
            var duration = 1.5 + Math.random() * 2.5;
            var emoji = starEmojis[Math.floor(Math.random() * starEmojis.length)];
            var size = 16 + Math.random() * 18;
            piece.style.cssText = `
                left:${x}%;
                top:${y}%;
                font-size:${size}px;
                animation-delay:${delay}s;
                animation-duration:${duration}s;
            `;
            piece.textContent = emoji;
            overlay.appendChild(piece);
        }
        
        // 4. 生成飘带 (18条)
        var ribbonEmojis = ['🎀', '🎗️', '🌈', '🎊', '🎉'];
        for (var i = 0; i < 18; i++) {
            var piece = document.createElement('div');
            piece.className = 'ribbon-piece';
            var y = 10 + Math.random() * 80;
            var delay = Math.random() * 3;
            var duration = 5 + Math.random() * 4;
            var emoji = ribbonEmojis[Math.floor(Math.random() * ribbonEmojis.length)];
            var size = 26 + Math.random() * 20;
            piece.style.cssText = `
                top:${y}%;
                font-size:${size}px;
                animation-delay:${delay}s;
                animation-duration:${duration}s;
            `;
            piece.textContent = emoji;
            overlay.appendChild(piece);
        }
        
        // 5. 生成气球 (14个)
        var balloonEmojis = ['🎈', '🎈', '🎈', '🎈', '🎈', '🎈'];
        for (var i = 0; i < 14; i++) {
            var piece = document.createElement('div');
            piece.className = 'balloon-piece';
            var x = 4 + Math.random() * 92;
            var delay = 1 + Math.random() * 4;
            var duration = 6 + Math.random() * 4;
            var emoji = balloonEmojis[Math.floor(Math.random() * balloonEmojis.length)];
            var size = 28 + Math.random() * 20;
            piece.style.cssText = `
                left:${x}%;
                font-size:${size}px;
                animation-delay:${delay}s;
                animation-duration:${duration}s;
            `;
            piece.textContent = emoji;
            overlay.appendChild(piece);
        }
        
        // 6. 特效自动清理 (7秒后自动移除)
        setTimeout(function() {
            var overlayEl = document.getElementById('celebrationOverlay');
            if (overlayEl) overlayEl.remove();
            var textEl = document.getElementById('celebrationText');
            if (textEl) textEl.remove();
            var styleEl = document.getElementById('celebrationStyle');
            if (styleEl) styleEl.remove();
        }, 7000);
        
        // 返回清理函数（供手动调用）
        return function() {
            var overlayEl = document.getElementById('celebrationOverlay');
            if (overlayEl) overlayEl.remove();
            var textEl = document.getElementById('celebrationText');
            if (textEl) textEl.remove();
            var styleEl = document.getElementById('celebrationStyle');
            if (styleEl) styleEl.remove();
        };
    }
})();