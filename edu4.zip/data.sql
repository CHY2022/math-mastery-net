-- 创建数据库
CREATE DATABASE IF NOT EXISTS math_mastery DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE math_mastery;

-- 用户表
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    role ENUM('admin','parent','student','school','training') NOT NULL,
    name VARCHAR(50),
    gender ENUM('男','女','保密') DEFAULT '保密',
    status ENUM('active','inactive','pending') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    settings JSON,
    -- 家长字段
    child_school VARCHAR(100),
    child_training VARCHAR(100),
    child_grade VARCHAR(20),
    phone VARCHAR(20),
    -- 学生字段
    school VARCHAR(100),
    training VARCHAR(100),
    grade VARCHAR(20),
    parent_phone VARCHAR(20),
    -- 学校/培训机构字段
    org_name VARCHAR(100),
    org_levels JSON,
    admin_phone VARCHAR(20),
    -- 绑定关系
    children TEXT,
    school_id INT,
    training_id INT
);

-- 学习记录表
CREATE TABLE IF NOT EXISTS learning_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    technique_id VARCHAR(50) NOT NULL,
    action ENUM('learn','practice','gate') NOT NULL,
    score INT DEFAULT 0,
    duration INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX(user_id),
    INDEX(technique_id)
);

-- 薄弱点表
CREATE TABLE IF NOT EXISTS weak_points (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    technique_id VARCHAR(50) NOT NULL,
    question_idx VARCHAR(20),
    fail_count INT DEFAULT 0,
    cleared BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX(user_id),
    INDEX(technique_id)
);

-- 网站设置表
CREATE TABLE IF NOT EXISTS site_settings (
    key_name VARCHAR(50) PRIMARY KEY,
    value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 邮箱日志表
CREATE TABLE IF NOT EXISTS email_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    to_email VARCHAR(100) NOT NULL,
    subject VARCHAR(200),
    content TEXT,
    type ENUM('verify','reset','notice') DEFAULT 'notice',
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('sent','failed') DEFAULT 'sent'
);

-- 验证码表
CREATE TABLE IF NOT EXISTS verification_codes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    code VARCHAR(10) NOT NULL,
    type ENUM('register','reset','login') DEFAULT 'register',
    used BOOLEAN DEFAULT FALSE,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX(email)
);