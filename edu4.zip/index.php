<?php
// index.php - 在文件最顶部添加以下代码

// ============================================================
// 【关键】提前拦截 AJAX 验证码请求
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'send_code') {
    require_once 'config/database.php';
    require_once 'includes/functions.php';
    require_once 'includes/auth.php';
    
    $email = $_POST['email'] ?? '';
    if (empty($email)) {
        echo json_encode(['success' => false, 'error' => '请输入邮箱']);
        exit;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'error' => '请输入有效的邮箱地址']);
        exit;
    }
    
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'error' => '该邮箱已被注册']);
        exit;
    }
    
    $code = generateCode();
    sendVerificationEmail($email, $code, 'register');
    echo json_encode(['success' => true, 'message' => '验证码已发送']);
    exit;
}

// ============================================================
// 以下是原来 index.php 的代码
// ============================================================
require_once 'config/database.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';

// 初始化数据库
initDatabase();

// 获取路由
$route = isset($_GET['route']) ? $_GET['route'] : 'dashboard';
$currentUser = getCurrentUser();
$isLoggedIn = $currentUser !== null;

// 公开路由（不需要登录）
$publicRoutes = ['login', 'register', 'forgot', 'reset', 'verify', 'logout'];

// 如果未登录且不是公开路由，跳转到登录
if (!$isLoggedIn && !in_array($route, $publicRoutes)) {
    header('Location: ?route=login');
    exit;
}

// 处理登出
if ($route === 'logout') {
    session_destroy();
    header('Location: ?route=login');
    exit;
}

// 检查是否为公开路由（使用独立布局）
$isAuthPage = in_array($route, $publicRoutes);

// 加载页面
$pageFile = 'pages/' . $route . '.php';

// 如果页面文件不存在，显示404
if (!file_exists($pageFile) && !$isAuthPage) {
    $route = '404';
    $pageFile = 'pages/404.php';
}

// 如果是登录相关页面或页面存在，正常显示
if ($isAuthPage || file_exists($pageFile)) {
    include 'includes/header.php';
    if (!$isAuthPage && file_exists($pageFile)) {
        include $pageFile;
    }
    include 'includes/footer.php';
} else {
    include 'includes/header.php';
    echo '<div class="empty"><h2>页面未找到</h2><p>您访问的页面不存在。</p><a href="?route=dashboard" class="btn">返回首页</a></div>';
    include 'includes/footer.php';
}
?>