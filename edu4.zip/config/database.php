<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_NAME', '');
define('DB_USER', '');
define('DB_PASS', '');

// 站点配置
define('SITE_NAME', '融会贯通');
define('SITE_URL', 'http://edu.2li.xyz/');
define('ADMIN_EMAIL', 'admin@example.com');
define('ICP_NUMBER', '京ICP备2023000000号');

// 会话配置
session_start();

// 数据库连接
function getDB() {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        return $pdo;
    } catch(PDOException $e) {
        die('数据库连接失败: ' . $e->getMessage());
    }
}

// 初始化数据库表
function initDatabase() {
    $pdo = getDB();
    $sql = "
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        role ENUM('admin','parent','student','school','training') NOT NULL,
        name VARCHAR(50),
        gender ENUM('男','女','保密') DEFAULT '保密',
        status ENUM('active','inactive','pending') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        settings JSON,
        -- 家长字段
        child_school VARCHAR(100),
        child_training VARCHAR(100),
        child_grade VARCHAR(20),
        phone VARCHAR(20),
        -- 学生字段
        school VARCHAR(100),
        training VARCHAR(100),
        grade VARCHAR(20),
        parent_phone VARCHAR(20),
        -- 学校/培训机构字段
        org_name VARCHAR(100),
        org_levels JSON,
        admin_phone VARCHAR(20),
        -- 绑定关系
        children TEXT,
        school_id INT,
        training_id INT
    );

    CREATE TABLE IF NOT EXISTS learning_records (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        technique_id VARCHAR(50) NOT NULL,
        action ENUM('learn','practice','gate','mastered') NOT NULL,
        score INT DEFAULT 0,
        duration INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX(user_id),
        INDEX(technique_id)
    );

    CREATE TABLE IF NOT EXISTS weak_points (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        technique_id VARCHAR(50) NOT NULL,
        question_idx VARCHAR(20),
        fail_count INT DEFAULT 0,
        cleared BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX(user_id),
        INDEX(technique_id)
    );

    CREATE TABLE IF NOT EXISTS site_settings (
        key_name VARCHAR(50) PRIMARY KEY,
        value TEXT,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS email_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        to_email VARCHAR(100) NOT NULL,
        subject VARCHAR(200),
        content TEXT,
        type ENUM('verify','reset','notice') DEFAULT 'notice',
        sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status ENUM('sent','failed') DEFAULT 'sent'
    );

    CREATE TABLE IF NOT EXISTS verification_codes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(100) NOT NULL,
        code VARCHAR(10) NOT NULL,
        type ENUM('register','reset','login') DEFAULT 'register',
        used BOOLEAN DEFAULT FALSE,
        expires_at TIMESTAMP NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX(email)
    );

    -- ============================================================
    -- AI 模型设置表（新增）
    -- ============================================================
    CREATE TABLE IF NOT EXISTS user_ai_models (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL COMMENT '用户ID',
        name VARCHAR(100) NOT NULL COMMENT '模型显示名称',
        api_url VARCHAR(255) NOT NULL COMMENT 'API地址',
        model VARCHAR(100) NOT NULL COMMENT '模型名称',
        api_key VARCHAR(255) NOT NULL DEFAULT '' COMMENT 'API密钥',
        is_default TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否默认 1=是 0=否',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
        INDEX idx_user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户AI模型配置表';
    ";
    $pdo->exec($sql);
    
    // 检查是否有管理员账号
    $stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'");
    if ($stmt->fetchColumn() == 0) {
        $password = password_hash('admin123', PASSWORD_DEFAULT);
        $pdo->prepare("INSERT INTO users (username, password, email, role, name, status) VALUES (?, ?, ?, ?, ?, ?)")
            ->execute(['admin', $password, 'admin@example.com', 'admin', '系统管理员', 'active']);
    }
    
    // 为现有用户初始化默认AI模型配置
    initDefaultAIModels($pdo);
}

/**
 * 为现有用户初始化默认AI模型配置
 */
function initDefaultAIModels($pdo) {
    // 检查表是否存在
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE 'user_ai_models'");
        if ($stmt->rowCount() == 0) {
            return;
        }
    } catch (PDOException $e) {
        return;
    }
    
    // 获取所有活跃用户
    try {
        $stmt = $pdo->query("SELECT id FROM users WHERE status = 'active'");
        $users = $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        return;
    }
    
    if (empty($users)) {
        return;
    }
    
    $defaultModels = [
        ['name' => 'Agnes 2.5 Flash', 'api_url' => 'https://api.agnes-ai.cn/v1/chat/completions', 'model' => 'agnes-2.5-flash'],
        ['name' => 'Qwen 3.5 4B', 'api_url' => 'https://api.siliconflow.cn/v1/chat/completions', 'model' => 'Qwen/Qwen3.5-4B'],
        ['name' => 'DeepSeek OCR', 'api_url' => 'https://api.siliconflow.cn/v1/chat/completions', 'model' => 'deepseek-ai/DeepSeek-OCR'],
        ['name' => '腾讯混元 MT-7B', 'api_url' => 'https://api.siliconflow.cn/v1/chat/completions', 'model' => 'tencent/Hunyuan-MT-7B'],
        ['name' => 'DeepSeek R1 0528 Qwen3 8B', 'api_url' => 'https://api.siliconflow.cn/v1/chat/completions', 'model' => 'deepseek-ai/DeepSeek-R1-0528-Qwen3-8B'],
        ['name' => 'GLM Z1 9B 0414', 'api_url' => 'https://api.siliconflow.cn/v1/chat/completions', 'model' => 'THUDM/GLM-Z1-9B-0414'],
        ['name' => 'GLM 4 9B 0414', 'api_url' => 'https://api.siliconflow.cn/v1/chat/completions', 'model' => 'THUDM/GLM-4-9B-0414'],
        ['name' => 'Qwen 2.5 7B Instruct', 'api_url' => 'https://api.siliconflow.cn/v1/chat/completions', 'model' => 'Qwen/Qwen2.5-7B-Instruct'],
        ['name' => 'DeepSeek V4 Flash 0731', 'api_url' => 'https://developer.amd.com.cn/radeon/api/v1', 'model' => 'DeepSeek-V4-Flash-0731'],
        ['name' => 'MiniCPM5 1B', 'api_url' => 'https://developer.amd.com.cn/radeon/api/v1', 'model' => 'MiniCPM5-1B']
    ];
    
    $insertSql = "INSERT INTO user_ai_models (user_id, name, api_url, model, api_key, is_default) VALUES (?, ?, ?, ?, '', ?)";
    $insertStmt = $pdo->prepare($insertSql);
    
    foreach ($users as $userId) {
        // 检查该用户是否已有模型配置
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM user_ai_models WHERE user_id = ?");
            $stmt->execute([$userId]);
            $count = $stmt->fetchColumn();
        } catch (PDOException $e) {
            $count = 0;
        }
        
        if ($count == 0) {
            foreach ($defaultModels as $idx => $dm) {
                $isDefault = ($idx === 0) ? 1 : 0;
                try {
                    $insertStmt->execute([$userId, $dm['name'], $dm['api_url'], $dm['model'], $isDefault]);
                } catch (PDOException $e) {
                    // 忽略插入错误
                }
            }
        }
    }
}