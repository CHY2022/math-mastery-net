<?php
$currentUser = getCurrentUser();
if ($currentUser['role'] !== 'admin') {
    header('Location: ?route=dashboard');
    exit;
}

$pdo = getDB();
$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

// 角色标签映射
$roleLabels = [
    'admin' => '管理员',
    'parent' => '家长',
    'student' => '学生',
    'school' => '学校',
    'training' => '培训机构'
];
?>
<div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
        <h2 class="section" style="margin:0;">👥 用户管理</h2>
        <button class="btn" onclick="showAddUser()">+ 添加用户</button>
    </div>

    <div class="user-table-wrap" style="overflow-x:auto;background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:0;box-shadow:0 1px 3px rgba(0,0,0,.08);">
        <table class="user-table" style="width:100%;border-collapse:collapse;font-size:13px;">
            <thead>
                <tr style="background:#f8fafc;border-bottom:2px solid #e5e7eb;">
                    <th style="text-align:left;padding:12px 16px;font-weight:600;">ID</th>
                    <th style="text-align:left;padding:12px 16px;font-weight:600;">用户名</th>
                    <th style="text-align:left;padding:12px 16px;font-weight:600;">姓名</th>
                    <th style="text-align:left;padding:12px 16px;font-weight:600;">性别</th>
                    <th style="text-align:left;padding:12px 16px;font-weight:600;">邮箱</th>
                    <th style="text-align:left;padding:12px 16px;font-weight:600;">角色</th>
                    <th style="text-align:left;padding:12px 16px;font-weight:600;">状态</th>
                    <th style="text-align:left;padding:12px 16px;font-weight:600;">注册时间</th>
                    <th style="text-align:left;padding:12px 16px;font-weight:600;">操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr style="border-bottom:1px solid #f1f3f5;">
                    <td style="padding:10px 16px;"><?= $user['id'] ?></td>
                    <td style="padding:10px 16px;"><?= h($user['username']) ?></td>
                    <td style="padding:10px 16px;"><?= h($user['name'] ?? '') ?></td>
                    <td style="padding:10px 16px;"><?= h($user['gender'] ?? '保密') ?></td>
                    <td style="padding:10px 16px;"><?= h($user['email']) ?></td>
                    <td style="padding:10px 16px;">
                        <?= $roleLabels[$user['role']] ?? $user['role'] ?>
                    </td>
                    <td style="padding:10px 16px;"><?= getStatusBadge($user['status']) ?></td>
                    <td style="padding:10px 16px;"><?= date('Y-m-d H:i', strtotime($user['created_at'])) ?></td>
                    <td style="padding:10px 16px;white-space:nowrap;">
                        <button class="btn sm" onclick="editUser(<?= $user['id'] ?>)">编辑</button>
                        <?php if ($user['id'] != $currentUser['id']): ?>
                        <button class="btn sm ghost" onclick="toggleUser(<?= $user['id'] ?>)"><?= $user['status'] === 'active' ? '停用' : '启用' ?></button>
                        <button class="btn sm" style="background:#dc2626;" onclick="deleteUser(<?= $user['id'] ?>)">删除</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>