<?php
// 退出登录页面
// 清除所有会话数据
session_start();
session_unset();
session_destroy();

// 清除记住我 Cookie（如果有）
if (isset($_COOKIE['remember_token'])) {
    setcookie('remember_token', '', time() - 3600, '/');
}

// 显示退出成功页面
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
    <title>退出登录 · <?= h(SITE_NAME) ?></title>
    <link rel="stylesheet" href="css/styles.css" />
    <style>
        body {
            background: var(--bg);
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
        }
        .logout-container {
            max-width: 420px;
            width: 95%;
            margin: 20px auto;
            text-align: center;
        }
        .logout-container .card {
            padding: 40px 30px;
        }
        .logout-container .icon {
            font-size: 64px;
            display: block;
            margin-bottom: 16px;
        }
        .logout-container h2 {
            margin: 0 0 8px 0;
            color: var(--ink);
        }
        .logout-container p {
            color: var(--muted);
            font-size: 14px;
            margin-bottom: 24px;
        }
        .logout-container .btn-group {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
        }
        .logout-container .btn {
            min-width: 120px;
            justify-content: center;
        }
        .countdown {
            color: var(--muted);
            font-size: 13px;
            margin-top: 16px;
        }
        .countdown strong {
            color: var(--primary);
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="logout-container">
        <div class="card">
            <span class="icon">👋</span>
            <h2>已安全退出</h2>
            <p>您已成功退出登录，感谢使用 <?= h(SITE_NAME) ?></p>
            
            <div class="btn-group">
                <a href="?route=login" class="btn">重新登录</a>
                <a href="?route=dashboard" class="btn ghost">返回首页</a>
            </div>
            
            <div class="countdown">
                <span id="countdownText">将在 <strong id="countdownNum">5</strong> 秒后跳转到登录页</span>
            </div>
        </div>
    </div>

    <script>
    // 自动跳转倒计时
    let seconds = 5;
    const countdownNum = document.getElementById('countdownNum');
    const countdownText = document.getElementById('countdownText');
    
    const timer = setInterval(function() {
        seconds--;
        if (seconds <= 0) {
            clearInterval(timer);
            window.location.href = '?route=login';
        } else {
            countdownNum.textContent = seconds;
        }
    }, 1000);
    
    // 点击按钮时取消倒计时跳转
    document.querySelectorAll('.btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            clearInterval(timer);
        });
    });
    </script>
</body>
</html>