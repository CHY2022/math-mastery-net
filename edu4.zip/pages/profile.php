<?php
// 个人信息管理页面
$user = getCurrentUser();
if (!$user) {
    header('Location: ?route=login');
    exit;
}

$pdo = getDB();
$userId = $user['id'];
$error = '';
$success = '';

// 获取用户完整信息
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$userInfo = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_profile') {
        $name = trim($_POST['name'] ?? '');
        $gender = $_POST['gender'] ?? '保密';
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['confirm'] ?? '';
        
        // 根据角色获取特定字段
        $role = $user['role'];
        $extraUpdates = [];
        
        switch ($role) {
            case 'student':
                $extraUpdates['school'] = trim($_POST['school'] ?? '');
                $extraUpdates['training'] = trim($_POST['training'] ?? '');
                $extraUpdates['grade'] = trim($_POST['grade'] ?? '');
                $extraUpdates['parent_phone'] = trim($_POST['parent_phone'] ?? '');
                break;
            case 'parent':
                $extraUpdates['child_school'] = trim($_POST['child_school'] ?? '');
                $extraUpdates['child_training'] = trim($_POST['child_training'] ?? '');
                $extraUpdates['child_grade'] = trim($_POST['child_grade'] ?? '');
                $extraUpdates['phone'] = trim($_POST['phone'] ?? '');
                break;
            case 'school':
                $extraUpdates['org_name'] = trim($_POST['org_name'] ?? '');
                $orgLevels = isset($_POST['org_levels']) ? $_POST['org_levels'] : ['小学'];
                if (!is_array($orgLevels)) $orgLevels = ['小学'];
                $extraUpdates['org_levels'] = json_encode($orgLevels);
                $extraUpdates['admin_phone'] = trim($_POST['admin_phone'] ?? '');
                break;
            case 'training':
                $extraUpdates['org_name'] = trim($_POST['org_name'] ?? '');
                $orgLevels = isset($_POST['org_levels']) ? $_POST['org_levels'] : ['小学'];
                if (!is_array($orgLevels)) $orgLevels = ['小学'];
                $extraUpdates['org_levels'] = json_encode($orgLevels);
                $extraUpdates['admin_phone'] = trim($_POST['admin_phone'] ?? '');
                break;
            case 'admin':
                // 管理员没有额外字段
                break;
        }
        
        // 验证邮箱
        if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = '请输入有效的邮箱地址';
        } elseif (!empty($password) && strlen($password) < 6) {
            $error = '密码至少6个字符';
        } elseif (!empty($password) && $password !== $confirm) {
            $error = '两次密码输入不一致';
        } else {
            // 构建更新SQL
            $updates = [];
            $params = [];
            
            if ($name) {
                $updates[] = "name = ?";
                $params[] = $name;
            }
            if ($gender) {
                $updates[] = "gender = ?";
                $params[] = $gender;
            }
            if ($email) {
                $updates[] = "email = ?";
                $params[] = $email;
            }
            if (!empty($password)) {
                $updates[] = "password = ?";
                $params[] = password_hash($password, PASSWORD_DEFAULT);
            }
            
            // 角色特定字段
            foreach ($extraUpdates as $key => $value) {
                $updates[] = "$key = ?";
                $params[] = $value;
            }
            
            if (!empty($updates)) {
                $params[] = $userId;
                $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?";
                try {
                    $pdo->prepare($sql)->execute($params);
                    $success = '✅ 个人信息更新成功！';
                    // 刷新用户信息
                    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
                    $stmt->execute([$userId]);
                    $userInfo = $stmt->fetch(PDO::FETCH_ASSOC);
                    // 更新session中的用户信息
                    $_SESSION['user_id'] = $userId;
                } catch (PDOException $e) {
                    if (strpos($e->getMessage(), 'Duplicate') !== false) {
                        $error = '邮箱已被其他用户使用';
                    } else {
                        $error = '更新失败：' . $e->getMessage();
                    }
                }
            } else {
                $error = '没有要更新的信息';
            }
        }
    }
}

// 解析机构层级
$orgLevels = [];
if (isset($userInfo['org_levels'])) {
    $orgLevels = json_decode($userInfo['org_levels'], true);
    if (!is_array($orgLevels)) $orgLevels = [];
}
?>
<div>
    <h2 class="section">👤 个人信息</h2>
    
    <?php if ($success): ?>
    <div style="color:#16a34a;padding:10px 14px;background:#e7f6ee;border-radius:8px;margin-bottom:14px;border:1px solid #bfe6cc;"><?= h($success) ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
    <div style="color:#dc2626;padding:10px 14px;background:#fdeaea;border-radius:8px;margin-bottom:14px;border:1px solid #fcd4d4;"><?= h($error) ?></div>
    <?php endif; ?>

    <div class="card">
        <form method="POST">
            <input type="hidden" name="action" value="update_profile">
            
            <!-- 基本信息 -->
            <div class="form-row">
                <div class="form-group">
                    <label>用户名</label>
                    <input type="text" value="<?= h($userInfo['username']) ?>" disabled style="background:#f3f4f6;">
                </div>
                <div class="form-group">
                    <label>角色</label>
                    <input type="text" value="<?= getRoleLabel($userInfo['role']) ?>" disabled style="background:#f3f4f6;">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>姓名</label>
                    <input type="text" name="name" value="<?= h($userInfo['name'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label>性别</label>
                    <select name="gender">
                        <option value="保密" <?= ($userInfo['gender'] ?? '保密') === '保密' ? 'selected' : '' ?>>保密</option>
                        <option value="男" <?= ($userInfo['gender'] ?? '') === '男' ? 'selected' : '' ?>>男</option>
                        <option value="女" <?= ($userInfo['gender'] ?? '') === '女' ? 'selected' : '' ?>>女</option>
                    </select>
                </div>
            </div>
            
            <div class="form-group">
                <label>电子邮箱</label>
                <input type="email" name="email" value="<?= h($userInfo['email']) ?>" required>
            </div>
            
            <!-- 根据角色显示不同字段 -->
            <?php if ($userInfo['role'] === 'student'): ?>
            <!-- 学生字段 -->
            <div class="form-row">
                <div class="form-group">
                    <label>学校名称</label>
                    <input type="text" name="school" value="<?= h($userInfo['school'] ?? '') ?>" placeholder="请输入学校名称">
                </div>
                <div class="form-group">
                    <label>培训机构名称</label>
                    <input type="text" name="training" value="<?= h($userInfo['training'] ?? '') ?>" placeholder="请输入培训机构名称">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>年级</label>
                    <select name="grade">
                        <option value="">请选择</option>
                        <option value="一年级" <?= ($userInfo['grade'] ?? '') === '一年级' ? 'selected' : '' ?>>一年级</option>
                        <option value="二年级" <?= ($userInfo['grade'] ?? '') === '二年级' ? 'selected' : '' ?>>二年级</option>
                        <option value="三年级" <?= ($userInfo['grade'] ?? '') === '三年级' ? 'selected' : '' ?>>三年级</option>
                        <option value="四年级" <?= ($userInfo['grade'] ?? '') === '四年级' ? 'selected' : '' ?>>四年级</option>
                        <option value="五年级" <?= ($userInfo['grade'] ?? '') === '五年级' ? 'selected' : '' ?>>五年级</option>
                        <option value="六年级" <?= ($userInfo['grade'] ?? '') === '六年级' ? 'selected' : '' ?>>六年级</option>
                        <option value="七年级" <?= ($userInfo['grade'] ?? '') === '七年级' ? 'selected' : '' ?>>七年级</option>
                        <option value="八年级" <?= ($userInfo['grade'] ?? '') === '八年级' ? 'selected' : '' ?>>八年级</option>
                        <option value="九年级" <?= ($userInfo['grade'] ?? '') === '九年级' ? 'selected' : '' ?>>九年级</option>
                        <option value="十年级" <?= ($userInfo['grade'] ?? '') === '十年级' ? 'selected' : '' ?>>十年级</option>
                        <option value="十一年级" <?= ($userInfo['grade'] ?? '') === '十一年级' ? 'selected' : '' ?>>十一年级</option>
                        <option value="十二年级" <?= ($userInfo['grade'] ?? '') === '十二年级' ? 'selected' : '' ?>>十二年级</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>家长手机号</label>
                    <input type="text" name="parent_phone" value="<?= h($userInfo['parent_phone'] ?? '') ?>" placeholder="请输入家长手机号">
                </div>
            </div>
            <?php elseif ($userInfo['role'] === 'parent'): ?>
            <!-- 家长字段 -->
            <div class="form-row">
                <div class="form-group">
                    <label>孩子学校</label>
                    <input type="text" name="child_school" value="<?= h($userInfo['child_school'] ?? '') ?>" placeholder="请输入孩子学校">
                </div>
                <div class="form-group">
                    <label>孩子培训机构</label>
                    <input type="text" name="child_training" value="<?= h($userInfo['child_training'] ?? '') ?>" placeholder="请输入孩子培训机构">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>孩子年级</label>
                    <select name="child_grade">
                        <option value="">请选择</option>
                        <option value="一年级" <?= ($userInfo['child_grade'] ?? '') === '一年级' ? 'selected' : '' ?>>一年级</option>
                        <option value="二年级" <?= ($userInfo['child_grade'] ?? '') === '二年级' ? 'selected' : '' ?>>二年级</option>
                        <option value="三年级" <?= ($userInfo['child_grade'] ?? '') === '三年级' ? 'selected' : '' ?>>三年级</option>
                        <option value="四年级" <?= ($userInfo['child_grade'] ?? '') === '四年级' ? 'selected' : '' ?>>四年级</option>
                        <option value="五年级" <?= ($userInfo['child_grade'] ?? '') === '五年级' ? 'selected' : '' ?>>五年级</option>
                        <option value="六年级" <?= ($userInfo['child_grade'] ?? '') === '六年级' ? 'selected' : '' ?>>六年级</option>
                        <option value="七年级" <?= ($userInfo['child_grade'] ?? '') === '七年级' ? 'selected' : '' ?>>七年级</option>
                        <option value="八年级" <?= ($userInfo['child_grade'] ?? '') === '八年级' ? 'selected' : '' ?>>八年级</option>
                        <option value="九年级" <?= ($userInfo['child_grade'] ?? '') === '九年级' ? 'selected' : '' ?>>九年级</option>
                        <option value="十年级" <?= ($userInfo['child_grade'] ?? '') === '十年级' ? 'selected' : '' ?>>十年级</option>
                        <option value="十一年级" <?= ($userInfo['child_grade'] ?? '') === '十一年级' ? 'selected' : '' ?>>十一年级</option>
                        <option value="十二年级" <?= ($userInfo['child_grade'] ?? '') === '十二年级' ? 'selected' : '' ?>>十二年级</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>手机号</label>
                    <input type="text" name="phone" value="<?= h($userInfo['phone'] ?? '') ?>" placeholder="请输入手机号">
                </div>
            </div>
            <?php elseif ($userInfo['role'] === 'school' || $userInfo['role'] === 'training'): ?>
            <!-- 学校/培训机构字段 -->
            <div class="form-group">
                <label>机构名称</label>
                <input type="text" name="org_name" value="<?= h($userInfo['org_name'] ?? '') ?>" placeholder="请输入机构名称">
            </div>
            <div class="form-group">
                <label>机构层级（可多选）</label>
                <div style="display:flex;gap:12px;flex-wrap:wrap;padding:6px 0;">
                    <label>
                        <input type="checkbox" name="org_levels[]" value="小学" <?= in_array('小学', $orgLevels) ? 'checked' : '' ?>> 小学
                    </label>
                    <label>
                        <input type="checkbox" name="org_levels[]" value="初级中学" <?= in_array('初级中学', $orgLevels) ? 'checked' : '' ?>> 初级中学
                    </label>
                    <label>
                        <input type="checkbox" name="org_levels[]" value="高级中学" <?= in_array('高级中学', $orgLevels) ? 'checked' : '' ?>> 高级中学
                    </label>
                </div>
            </div>
            <div class="form-group">
                <label>管理员手机号</label>
                <input type="text" name="admin_phone" value="<?= h($userInfo['admin_phone'] ?? '') ?>" placeholder="请输入管理员手机号">
            </div>
            <?php endif; ?>
            
            <!-- 修改密码 -->
            <hr style="border:none;border-top:1px solid #e5e7eb;margin:20px 0;">
            <h3 style="font-size:15px;margin-bottom:12px;">🔑 修改密码</h3>
            <div class="form-row">
                <div class="form-group">
                    <label>新密码（留空则不修改）</label>
                    <input type="password" name="password" placeholder="输入新密码" autocomplete="off">
                </div>
                <div class="form-group">
                    <label>确认新密码</label>
                    <input type="password" name="confirm" placeholder="再次输入新密码" autocomplete="off">
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn">💾 保存个人信息</button>
            </div>
        </form>
    </div>
</div>