<?php
// 404 错误页面
?>
<div class="empty">
    <h2>页面未找到</h2>
    <p>您访问的页面不存在。</p>
    <a href="?route=dashboard" class="btn">返回首页</a>
</div>