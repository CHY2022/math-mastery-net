<?php
// pages/progress.php - 支持查看孩子/学生的进度
$user = getCurrentUser();
if (!$user) {
    header('Location: ?route=login');
    exit;
}

$pdo = getDB();
$userId = $user['id'];
$viewingUserId = $userId;
$viewingName = $user['name'] ?? $user['username'];
$viewingGrade = '';

// 家长查看孩子
if (isset($_GET['child_id']) && $user['role'] === 'parent') {
    $childId = (int)$_GET['child_id'];
    $childrenIds = !empty($user['children']) ? explode(',', $user['children']) : [];
    if (in_array($childId, $childrenIds)) {
        $stmt = $pdo->prepare("SELECT id, username, name, grade FROM users WHERE id = ? AND role = 'student' AND status = 'active'");
        $stmt->execute([$childId]);
        $child = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($child) {
            $viewingUserId = $childId;
            $viewingName = $child['name'] ?? $child['username'];
            $viewingGrade = $child['grade'] ?? '';
        }
    }
}

// 学校/培训机构查看学生
if (isset($_GET['student_id']) && ($user['role'] === 'school' || $user['role'] === 'training')) {
    $studentId = (int)$_GET['student_id'];
    $orgName = $user['org_name'] ?? '';
    $stmt = $pdo->prepare("SELECT id, username, name, grade FROM users WHERE id = ? AND role = 'student' AND status = 'active' AND (school = ? OR training = ?)");
    $stmt->execute([$studentId, $orgName, $orgName]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($student) {
        $viewingUserId = $studentId;
        $viewingName = $student['name'] ?? $student['username'];
        $viewingGrade = $student['grade'] ?? '';
    }
}

// 如果是学生自己查看
if ($viewingUserId === $user['id'] && $user['role'] === 'student') {
    $viewingGrade = $user['grade'] ?? '';
}

// 如果还是空，补查数据库
if (empty($viewingGrade)) {
    $stmt = $pdo->prepare("SELECT grade FROM users WHERE id = ?");
    $stmt->execute([$viewingUserId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row && !empty($row['grade'])) {
        $viewingGrade = $row['grade'];
    }
}

// 如果仍然为空，使用默认
if (empty($viewingGrade)) {
    $viewingGrade = '六年级';
}

// 根据年级推断默认阶段
$defaultStage = '';
$gradeToStage = [
    '一年级' => '小学', '二年级' => '小学', '三年级' => '小学',
    '四年级' => '小学', '五年级' => '小学', '六年级' => '小学',
    '七年级' => '中学', '八年级' => '中学', '九年级' => '中学',
    '十年级' => '高中', '十一年级' => '高中', '十二年级' => '高中',
    '大学先修' => '高中'
];
$defaultStage = $gradeToStage[$viewingGrade] ?? '小学';

// 获取用户统计
$stats = getUserStats($viewingUserId);

// 获取进度数据（所有技巧）
$stmt = $pdo->prepare("
    SELECT technique_id, 
           MAX(CASE WHEN action = 'mastered' THEN 1 ELSE 0 END) as mastered,
           COUNT(CASE WHEN action = 'practice' THEN 1 END) as practice_count,
           COUNT(CASE WHEN action = 'learn' THEN 1 END) as learn_count,
           AVG(CASE WHEN action = 'gate' THEN score END) as gate_avg
    FROM learning_records 
    WHERE user_id = ? 
    GROUP BY technique_id
");
$stmt->execute([$viewingUserId]);
$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 获取薄弱点
$stmt = $pdo->prepare("SELECT technique_id, COUNT(*) as weak_count FROM weak_points WHERE user_id = ? AND cleared = FALSE GROUP BY technique_id");
$stmt->execute([$viewingUserId]);
$weakRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$weakMap = [];
foreach ($weakRows as $row) {
    $weakMap[$row['technique_id']] = $row['weak_count'];
}

$progress = [];
foreach ($records as $r) {
    $progress[$r['technique_id']] = [
        'mastered' => (bool)$r['mastered'],
        'practice_count' => (int)$r['practice_count'],
        'learn_count' => (int)$r['learn_count'],
        'gate_avg' => round($r['gate_avg'] ?: 0, 1),
        'weak_count' => isset($weakMap[$r['technique_id']]) ? (int)$weakMap[$r['technique_id']] : 0
    ];
}

$progressJson = json_encode($progress);
?>
<div>
    <input type="hidden" id="dashboard-loaded" value="true">
    
    <h2 class="section">
        📈 学习进度
        <?php if ($viewingUserId !== $user['id']): ?>
        <span style="font-size:14px;color:#6b7280;font-weight:400;"> - 查看 <strong><?= h($viewingName) ?></strong> 的进度</span>
        <?php endif; ?>
    </h2>

    <!-- 统计卡片 -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:16px;margin-bottom:20px;">
        <div class="card" style="text-align:center;padding:16px;">
            <div style="font-size:30px;font-weight:800;color:#2f6fed;"><?= $stats['learn_count'] ?? 0 ?></div>
            <div style="font-size:13px;color:#6b7280;">📖 学习次数</div>
        </div>
        <div class="card" style="text-align:center;padding:16px;">
            <div style="font-size:30px;font-weight:800;color:#16a34a;"><?= $stats['practice_count'] ?? 0 ?></div>
            <div style="font-size:13px;color:#6b7280;">✏️ 练习次数</div>
        </div>
        <div class="card" style="text-align:center;padding:16px;">
            <div style="font-size:30px;font-weight:800;color:#7c3aed;"><?= $stats['passed_gates'] ?? 0 ?></div>
            <div style="font-size:13px;color:#6b7280;">🏆 通关数</div>
        </div>
        <div class="card" style="text-align:center;padding:16px;">
            <div style="font-size:30px;font-weight:800;color:#dc2626;"><?= $stats['weak_count'] ?? 0 ?></div>
            <div style="font-size:13px;color:#6b7280;">📌 薄弱点</div>
        </div>
    </div>

    <!-- 筛选器 -->
    <div class="filter-bar" style="display:flex;flex-wrap:wrap;gap:10px;padding:10px 14px;background:#f8fafc;border-radius:8px;margin-bottom:14px;border:1px solid #e5e7eb;align-items:center;">
        <span style="font-size:13px;font-weight:600;color:#1f2937;margin-right:4px;">📌 筛选：</span>
        
        <!-- 阶段筛选 -->
        <div style="display:flex;gap:4px;flex-wrap:wrap;align-items:center;">
            <span style="font-size:12px;color:#6b7280;">阶段：</span>
            <button class="filter-btn filter-stage" data-stage="all" style="padding:4px 14px;border-radius:16px;border:1px solid #d1d5db;background:#fff;color:#1f2937;font-size:12px;cursor:pointer;transition:0.2s;">全部</button>
            <button class="filter-btn filter-stage" data-stage="小学" style="padding:4px 14px;border-radius:16px;border:1px solid #d1d5db;background:#fff;color:#1f2937;font-size:12px;cursor:pointer;transition:0.2s;">小学</button>
            <button class="filter-btn filter-stage" data-stage="中学" style="padding:4px 14px;border-radius:16px;border:1px solid #d1d5db;background:#fff;color:#1f2937;font-size:12px;cursor:pointer;transition:0.2s;">中学</button>
            <button class="filter-btn filter-stage" data-stage="高中" style="padding:4px 14px;border-radius:16px;border:1px solid #d1d5db;background:#fff;color:#1f2937;font-size:12px;cursor:pointer;transition:0.2s;">高中</button>
        </div>
        
        <!-- 年级筛选（联动） -->
        <div style="display:flex;gap:4px;flex-wrap:wrap;align-items:center;">
            <span style="font-size:12px;color:#6b7280;">年级：</span>
            <div id="gradeFilterContainer" style="display:flex;gap:4px;flex-wrap:wrap;">
                <!-- 由 JavaScript 动态生成 -->
            </div>
        </div>
        
        <button class="filter-btn" id="resetToGradeBtn" style="padding:4px 14px;border-radius:16px;border:1px solid #d97706;background:#fef3c7;color:#d97706;font-size:12px;cursor:pointer;transition:0.2s;">↩ 回到我的年级</button>
    </div>

    <!-- 进度条 -->
    <div class="card" id="progressSummaryCard">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
            <span style="font-size:14px;font-weight:600;" id="progressTitle">总通关进度</span>
            <span style="font-size:16px;font-weight:700;color:#2f6fed;" id="progressPercent">0%</span>
        </div>
        <div style="height:10px;background:#e5e7eb;border-radius:5px;overflow:hidden;">
            <div id="progressBar" style="height:100%;width:0%;background:linear-gradient(90deg,#2f6fed,#16a34a);border-radius:5px;transition:width 0.6s;"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:12px;color:#6b7280;margin-top:4px;">
            <span id="progressMastered">已掌握: 0 个</span>
            <span id="progressTotal">总计: 0 个技巧</span>
        </div>
    </div>

    <!-- 技巧详情列表 -->
    <div class="card">
        <h3 id="progressTableTitle">📚 各技巧状态</h3>
        <div style="overflow-x:auto;">
            <table style="width:100%;border-collapse:collapse;font-size:13px;">
                <thead>
                    <tr style="border-bottom:2px solid #e5e7eb;">
                        <?php
                        // 判断是否显示年级列：当未选择具体年级时显示
                        $showGradeColumn = true; // 默认显示，由JS控制
                        ?>
                        <th id="gradeColHeader" style="text-align:left;padding:8px 10px;display:table-cell;">年级</th>
                        <th style="text-align:left;padding:8px 10px;">技巧</th>
                        <th style="text-align:center;padding:8px 10px;">状态</th>
                        <th style="text-align:center;padding:8px 10px;">学习</th>
                        <th style="text-align:center;padding:8px 10px;">练习</th>
                        <th style="text-align:center;padding:8px 10px;">平均分</th>
                        <th style="text-align:center;padding:8px 10px;">薄弱点</th>
                    </tr>
                </thead>
                <tbody id="progressTableBody">
                    <tr>
                        <td colspan="7" style="text-align:center;padding:20px;color:#6b7280;">加载中...</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
// 阻止 app_main.js 自动渲染
window.__SKIP_APP_MAIN_RENDER = true;

// ============================================================
// 1. 数据定义
// ============================================================
var progressData = <?= $progressJson ?>;
var VIEWING_USER_ID = <?= (int)$viewingUserId ?>;
var IS_VIEWING_OTHER = <?= $viewingUserId !== $user['id'] ? 'true' : 'false' ?>;

window.DEFAULT_GRADE = '<?= addslashes($viewingGrade) ?>';
window.DEFAULT_STAGE = '<?= addslashes($defaultStage) ?>';

console.log('📌 DEFAULT_GRADE:', window.DEFAULT_GRADE);
console.log('📌 DEFAULT_STAGE:', window.DEFAULT_STAGE);

// ============================================================
// 2. 工具函数
// ============================================================
function getTechniques() {
    if (typeof TECHNIQUES !== 'undefined') {
        return TECHNIQUES;
    }
    return [];
}

function gradeNum(g) {
    var m = { "一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10, "十一": 11, "十二": 12 };
    var x = /([一二三四五六七八九十]+)年级/.exec(g || "");
    var num = x ? (m[x[1]] || 99) : 99;
    if (g && g.indexOf('+') > -1) num += 0.5;
    // 兼容 '大学先锋' 和 '大学先修' 两种写法
    if (g && (g.indexOf('大学先锋') > -1 || g.indexOf('大学先修') > -1)) num = 12.5;
    return num;
}

function sortGrades(grades) {
    return grades.slice().sort(function(a, b) {
        return gradeNum(a) - gradeNum(b);
    });
}

// ============================================================
// 3. 从 TECHNIQUES 构建完整的阶段-年级映射
// ============================================================
function buildStageGradesFromTechs() {
    var techs = getTechniques();
    var result = { '小学': [], '中学': [], '高中': [] };
    
    var allGradeNames = ['一年级','二年级','三年级','四年级','五年级','六年级','七年级','八年级','九年级','十年级','十一年级','十二年级','大学先修'];
    var gradeStageMap = {
        '一年级': '小学', '二年级': '小学', '三年级': '小学',
        '四年级': '小学', '五年级': '小学', '六年级': '小学',
        '七年级': '中学', '八年级': '中学', '九年级': '中学',
        '十年级': '高中', '十一年级': '高中', '十二年级': '高中',
        '大学先修': '高中'
    };
    
    if (techs && techs.length) {
        techs.forEach(function(t) {
            if (t.stage && t.grade) {
                var gradeKey = t.grade;
                // 如果 grade 是 '大学先锋'，映射到 '大学先修'
                if (gradeKey.indexOf('大学先锋') > -1) {
                    gradeKey = '大学先修';
                }
                if (!result[t.stage]) result[t.stage] = [];
                if (result[t.stage].indexOf(gradeKey) === -1) {
                    result[t.stage].push(gradeKey);
                }
            }
        });
    }
    
    for (var stage in result) {
        var stageGrades = result[stage];
        var expectedGrades = [];
        for (var i = 0; i < allGradeNames.length; i++) {
            if (gradeStageMap[allGradeNames[i]] === stage) {
                expectedGrades.push(allGradeNames[i]);
            }
        }
        expectedGrades.forEach(function(g) {
            if (stageGrades.indexOf(g) === -1) {
                stageGrades.push(g);
            }
        });
        stageGrades.sort(function(a, b) {
            return gradeNum(a) - gradeNum(b);
        });
    }
    
    return result;
}

// ============================================================
// 4. 初始化 STAGE_GRADES 和 ALL_GRADES
// ============================================================
var STAGE_GRADES = buildStageGradesFromTechs();
var ALL_GRADES = [];
for (var stage in STAGE_GRADES) {
    STAGE_GRADES[stage].forEach(function(g) {
        if (ALL_GRADES.indexOf(g) === -1) {
            ALL_GRADES.push(g);
        }
    });
}
ALL_GRADES.sort(function(a, b) {
    return gradeNum(a) - gradeNum(b);
});

console.log('📌 STAGE_GRADES:', STAGE_GRADES);
console.log('📌 ALL_GRADES:', ALL_GRADES);

// ============================================================
// 5. 筛选状态
// ============================================================
var filterStage = window.DEFAULT_STAGE || 'all';
var filterGrade = window.DEFAULT_GRADE || 'all';

console.log('📌 初始 filterStage:', filterStage);
console.log('📌 初始 filterGrade:', filterGrade);

// ============================================================
// 6. 更新年级按钮
// ============================================================
function updateGradeButtons(selectedStage) {
    var container = document.getElementById('gradeFilterContainer');
    if (!container) return;
    
    var grades = [];
    if (selectedStage === 'all') {
        grades = ALL_GRADES.slice();
    } else {
        grades = (STAGE_GRADES[selectedStage] || []).slice();
    }
    grades = sortGrades(grades);
    
    var html = '';
    html += '<button class="filter-btn filter-grade" data-grade="all" style="padding:4px 14px;border-radius:16px;border:1px solid #d1d5db;background:#fff;color:#1f2937;font-size:12px;cursor:pointer;transition:0.2s;">全部</button>';
    grades.forEach(function(g) {
        var isDefault = (g === window.DEFAULT_GRADE && selectedStage === window.DEFAULT_STAGE);
        var bgColor = isDefault ? '#2f6fed' : '#fff';
        var textColor = isDefault ? '#fff' : '#1f2937';
        html += '<button class="filter-btn filter-grade" data-grade="' + g + '" style="padding:4px 14px;border-radius:16px;border:1px solid #d1d5db;background:' + bgColor + ';color:' + textColor + ';font-size:12px;cursor:pointer;transition:0.2s;">' + g + '</button>';
    });
    container.innerHTML = html;
    
    // 绑定年级按钮事件
    var gradeBtns = container.querySelectorAll('.filter-grade');
    gradeBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var value = this.dataset.grade;
            gradeBtns.forEach(function(b) {
                b.style.background = '#fff';
                b.style.color = '#1f2937';
                b.classList.remove('active');
            });
            this.style.background = '#2f6fed';
            this.style.color = '#fff';
            this.classList.add('active');
            filterGrade = value;
            console.log('📌 年级筛选变为:', filterGrade);
            renderProgressTable();
            updateProgressSummary();
        });
    });
}

// ============================================================
// 7. 更新进度摘要
// ============================================================
function updateProgressSummary() {
    var techs = getTechniques();
    var filteredTechs = techs.filter(function(t) {
        if (filterStage !== 'all' && t.stage !== filterStage) return false;
        if (filterGrade !== 'all' && t.grade !== filterGrade) return false;
        return true;
    });
    
    var total = filteredTechs.length;
    var mastered = 0;
    filteredTechs.forEach(function(t) {
        var p = progressData[t.id] || { mastered: false };
        if (p.mastered) mastered++;
    });
    var pct = total > 0 ? Math.round(mastered / total * 100) : 0;
    
    // 更新标题
    var titleEl = document.getElementById('progressTitle');
    if (titleEl) {
        if (filterStage !== 'all' && filterGrade !== 'all') {
            titleEl.textContent = filterGrade + '通关进度';
        } else if (filterStage !== 'all' && filterGrade === 'all') {
            titleEl.textContent = filterStage + '总通关进度';
        } else {
            titleEl.textContent = '总通关进度';
        }
    }
    
    document.getElementById('progressPercent').textContent = pct + '%';
    document.getElementById('progressBar').style.width = pct + '%';
    document.getElementById('progressMastered').textContent = '已掌握: ' + mastered + ' 个';
    document.getElementById('progressTotal').textContent = '总计: ' + total + ' 个技巧';
}

// ============================================================
// 8. 判断是否显示年级列
// ============================================================
function shouldShowGradeColumn() {
    // 当未选择具体年级时（即 filterGrade === 'all'），显示年级列
    return filterGrade === 'all';
}

// ============================================================
// 9. 渲染进度表格
// ============================================================
function renderProgressTable() {
    var tbody = document.getElementById('progressTableBody');
    if (!tbody) return;
    
    var techs = getTechniques();
    if (!techs || !techs.length) {
        setTimeout(renderProgressTable, 500);
        return;
    }
    
    // 应用筛选
    var filteredTechs = techs.filter(function(t) {
        if (filterStage !== 'all' && t.stage !== filterStage) return false;
        if (filterGrade !== 'all' && t.grade !== filterGrade) return false;
        return true;
    });
    
    // ============================================================
    // 排序：按学习路径的顺序（阶段 -> 年级 -> 技巧顺序）
    // ============================================================
    var stageOrder = { '小学': 0, '中学': 1, '高中': 2 };
    // 获取技巧在原始数组中的索引作为排序依据
    var techIndexMap = {};
    techs.forEach(function(t, idx) {
        techIndexMap[t.id] = idx;
    });
    
    filteredTechs.sort(function(a, b) {
        // 先按阶段排序
        if (a.stage !== b.stage) {
            return (stageOrder[a.stage] || 99) - (stageOrder[b.stage] || 99);
        }
        // 再按年级排序
        var gradeDiff = gradeNum(a.grade) - gradeNum(b.grade);
        if (gradeDiff !== 0) {
            return gradeDiff;
        }
        // 最后按技巧在原始数组中的顺序
        return (techIndexMap[a.id] || 0) - (techIndexMap[b.id] || 0);
    });
    
    console.log('📌 筛选后技巧数:', filteredTechs.length, 'filterStage:', filterStage, 'filterGrade:', filterGrade);
    
    // 判断是否显示年级列
    var showGrade = shouldShowGradeColumn();
    var gradeColHeader = document.getElementById('gradeColHeader');
    if (gradeColHeader) {
        gradeColHeader.style.display = showGrade ? 'table-cell' : 'none';
    }
    
    if (!filteredTechs.length) {
        var colSpan = showGrade ? 7 : 6;
        tbody.innerHTML = '<tr><td colspan="' + colSpan + '" style="text-align:center;padding:20px;color:#6b7280;">没有匹配的技巧</td></tr>';
        updateProgressSummary();
        return;
    }
    
    var html = '';
    filteredTechs.forEach(function(t) {
        var p = progressData[t.id] || { mastered: false, practice_count: 0, learn_count: 0, gate_avg: 0, weak_count: 0 };
        var status = p.mastered ? '✅ 已掌握' : '📖 学习中';
        var statusColor = p.mastered ? '#16a34a' : '#d97706';
        
        html += '<tr style="border-bottom:1px solid #f1f3f5;">';
        if (showGrade) {
            html += '<td style="padding:8px 10px;color:#6b7280;font-size:12px;">' + (t.grade || '-') + '</td>';
        }
        html += '<td style="padding:8px 10px;">' + t.name + '</td>';
        html += '<td style="text-align:center;padding:8px 10px;color:' + statusColor + ';">' + status + '</td>';
        html += '<td style="text-align:center;padding:8px 10px;">' + (p.learn_count || 0) + '</td>';
        html += '<td style="text-align:center;padding:8px 10px;">' + (p.practice_count || 0) + '</td>';
        html += '<td style="text-align:center;padding:8px 10px;">' + (p.gate_avg > 0 ? p.gate_avg + '分' : '-') + '</td>';
        html += '<td style="text-align:center;padding:8px 10px;">' + (p.weak_count > 0 ? '<span style="background:#fdeaea;color:#dc2626;padding:2px 10px;border-radius:12px;font-size:12px;">' + p.weak_count + '</span>' : '<span style="color:#16a34a;">✓</span>') + '</td>';
        html += '</tr>';
    });
    
    tbody.innerHTML = html;
    updateProgressSummary();
}

// ============================================================
// 10. 初始化筛选器
// ============================================================
function initFilters() {
    var stageBtns = document.querySelectorAll('.filter-stage');
    stageBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var value = this.dataset.stage;
            
            stageBtns.forEach(function(b) {
                b.style.background = '#fff';
                b.style.color = '#1f2937';
                b.classList.remove('active');
            });
            this.style.background = '#2f6fed';
            this.style.color = '#fff';
            this.classList.add('active');
            
            filterStage = value;
            console.log('📌 阶段筛选变为:', filterStage);
            
            updateGradeButtons(value);
            
            filterGrade = 'all';
            console.log('📌 切换阶段，年级重置为: all');
            
            var gradeBtns = document.querySelectorAll('.filter-grade');
            gradeBtns.forEach(function(b) {
                b.style.background = '#fff';
                b.style.color = '#1f2937';
                b.classList.remove('active');
                if (b.dataset.grade === 'all') {
                    b.style.background = '#2f6fed';
                    b.style.color = '#fff';
                    b.classList.add('active');
                }
            });
            
            renderProgressTable();
        });
    });
    
    var resetBtn = document.getElementById('resetToGradeBtn');
    if (resetBtn) {
        resetBtn.addEventListener('click', function() {
            if (window.DEFAULT_GRADE && window.DEFAULT_GRADE !== 'all') {
                var targetStage = window.DEFAULT_STAGE || 'all';
                
                var stageBtns = document.querySelectorAll('.filter-stage');
                stageBtns.forEach(function(b) {
                    b.style.background = '#fff';
                    b.style.color = '#1f2937';
                    b.classList.remove('active');
                    if (b.dataset.stage === targetStage) {
                        b.style.background = '#2f6fed';
                        b.style.color = '#fff';
                        b.classList.add('active');
                    }
                });
                filterStage = targetStage;
                
                updateGradeButtons(targetStage);
                
                var gradeBtns = document.querySelectorAll('.filter-grade');
                gradeBtns.forEach(function(b) {
                    b.style.background = '#fff';
                    b.style.color = '#1f2937';
                    b.classList.remove('active');
                    if (b.dataset.grade === window.DEFAULT_GRADE) {
                        b.style.background = '#2f6fed';
                        b.style.color = '#fff';
                        b.classList.add('active');
                    }
                });
                filterGrade = window.DEFAULT_GRADE;
                
                console.log('📌 回到我的年级:', filterGrade);
                renderProgressTable();
            }
        });
    }
}

// ============================================================
// 11. 初始化
// ============================================================
function init() {
    console.log('🔥 progress.php 初始化开始');
    console.log('📌 DEFAULT_GRADE:', window.DEFAULT_GRADE);
    console.log('📌 DEFAULT_STAGE:', window.DEFAULT_STAGE);
    
    var initialStage = window.DEFAULT_STAGE || 'all';
    var initialGrade = window.DEFAULT_GRADE || 'all';
    
    // 如果阶段为 all 但年级有值，从 STAGE_GRADES 推断
    if (initialStage === 'all' && initialGrade !== 'all') {
        for (var stage in STAGE_GRADES) {
            if (STAGE_GRADES[stage].indexOf(initialGrade) > -1) {
                initialStage = stage;
                console.log('📌 推断阶段:', initialStage);
                break;
            }
        }
    }
    
    filterStage = initialStage;
    filterGrade = initialGrade;
    
    console.log('📌 最终 filterStage:', filterStage);
    console.log('📌 最终 filterGrade:', filterGrade);
    
    updateGradeButtons(initialStage);
    
    var stageBtns = document.querySelectorAll('.filter-stage');
    stageBtns.forEach(function(b) {
        b.style.background = '#fff';
        b.style.color = '#1f2937';
        b.classList.remove('active');
        if (b.dataset.stage === initialStage) {
            b.style.background = '#2f6fed';
            b.style.color = '#fff';
            b.classList.add('active');
        }
    });
    
    if (initialGrade !== 'all') {
        setTimeout(function() {
            var gradeBtns = document.querySelectorAll('.filter-grade');
            gradeBtns.forEach(function(b) {
                b.style.background = '#fff';
                b.style.color = '#1f2937';
                b.classList.remove('active');
                if (b.dataset.grade === initialGrade) {
                    b.style.background = '#2f6fed';
                    b.style.color = '#fff';
                    b.classList.add('active');
                }
            });
        }, 50);
    }
    
    renderProgressTable();
    initFilters();
}

// ============================================================
// 12. 页面加载
// ============================================================
if (document.readyState === 'complete') {
    init();
} else {
    document.addEventListener('DOMContentLoaded', init);
}

// 暴露函数供调试
window.renderProgressTable = renderProgressTable;
window.updateGradeButtons = updateGradeButtons;
window.updateProgressSummary = updateProgressSummary;
</script>