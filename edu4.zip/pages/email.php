<?php
$currentUser = getCurrentUser();
if ($currentUser['role'] !== 'admin') {
    header('Location: ?route=dashboard');
    exit;
}

$pdo = getDB();
$settings = [];
$stmt = $pdo->query("SELECT * FROM site_settings");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $settings[$row['key_name']] = $row['value'];
}

$testResult = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'save') {
        $updates = [
            'smtp_host' => $_POST['smtp_host'] ?? '',
            'smtp_port' => $_POST['smtp_port'] ?? '587',
            'smtp_username' => $_POST['smtp_username'] ?? '',
            'smtp_password' => $_POST['smtp_password'] ?? '',
            'smtp_from' => $_POST['smtp_from'] ?? '',
            'smtp_secure' => $_POST['smtp_secure'] ?? 'tls'
        ];
        
        if (empty($updates['smtp_password']) && isset($settings['smtp_password'])) {
            $updates['smtp_password'] = $settings['smtp_password'];
        }
        
        foreach ($updates as $key => $value) {
            $stmt = $pdo->prepare("INSERT INTO site_settings (key_name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = ?");
            $stmt->execute([$key, $value, $value]);
        }
        
        $success = '邮箱设置已保存';
    }
    
    if ($action === 'test') {
        $to = $_POST['test_email'] ?? '';
        if (empty($to)) {
            $testResult = '❌ 请输入测试邮箱';
        } else {
            $code = generateCode();
            $result = sendVerificationEmail($to, $code, 'test');
            $testResult = $result ? '✅ 测试邮件已发送，请检查收件箱' : '❌ 测试邮件发送失败，请检查SMTP配置';
        }
    }
}

$stmt = $pdo->query("SELECT * FROM site_settings");
$settings = [];
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $settings[$row['key_name']] = $row['value'];
}
?>
<div>
    <h2 class="section">📧 邮箱设置</h2>
    
    <?php if (isset($success)): ?>
    <div style="color:var(--ok);padding:10px 14px;background:#e7f6ee;border-radius:8px;margin-bottom:14px;border:1px solid #bfe6cc;"><?= h($success) ?></div>
    <?php endif; ?>
    
    <div class="card">
        <form method="POST">
            <input type="hidden" name="action" value="save">
            
            <div class="form-group">
                <label>SMTP 服务器</label>
                <input type="text" name="smtp_host" value="<?= h($settings['smtp_host'] ?? 'smtp.gmail.com') ?>" placeholder="smtp.example.com">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>SMTP 端口</label>
                    <input type="number" name="smtp_port" value="<?= h($settings['smtp_port'] ?? '587') ?>" placeholder="587">
                </div>
                <div class="form-group">
                    <label>加密方式</label>
                    <select name="smtp_secure">
                        <option value="tls" <?= ($settings['smtp_secure'] ?? 'tls') === 'tls' ? 'selected' : '' ?>>TLS</option>
                        <option value="ssl" <?= ($settings['smtp_secure'] ?? '') === 'ssl' ? 'selected' : '' ?>>SSL</option>
                        <option value="none" <?= ($settings['smtp_secure'] ?? '') === 'none' ? 'selected' : '' ?>>无</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>SMTP 用户名</label>
                <input type="text" name="smtp_username" value="<?= h($settings['smtp_username'] ?? '') ?>" placeholder="邮箱地址或用户名">
            </div>
            <div class="form-group">
                <label>SMTP 密码</label>
                <input type="password" name="smtp_password" placeholder="输入新密码（留空则不修改）" autocomplete="off">
                <?php if (!empty($settings['smtp_password'])): ?>
                <div style="font-size:12px;color:#6b7280;margin-top:4px;">🔒 当前已设置密码</div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label>发件人邮箱</label>
                <input type="email" name="smtp_from" value="<?= h($settings['smtp_from'] ?? '') ?>" placeholder="发件人显示邮箱">
            </div>
            <div class="form-actions">
                <button type="submit" class="btn">💾 保存设置</button>
            </div>
        </form>
    </div>
    
    <!-- 测试发送 -->
    <div class="card">
        <h3>📨 测试邮件发送</h3>
        <form method="POST">
            <input type="hidden" name="action" value="test">
            <div style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;">
                <div class="form-group" style="flex:1;min-width:200px;margin-bottom:0;">
                    <label>测试邮箱</label>
                    <input type="email" name="test_email" placeholder="请输入测试邮箱">
                </div>
                <button type="submit" class="btn">📤 发送测试邮件</button>
            </div>
            <?php if ($testResult): ?>
            <div style="margin-top:12px;padding:10px 14px;background:<?= strpos($testResult, '✅') !== false ? '#e7f6ee' : '#fdeaea' ?>;border-radius:8px;border:1px solid <?= strpos($testResult, '✅') !== false ? '#bfe6cc' : '#fcd4d4' ?>;">
                <?= h($testResult) ?>
            </div>
            <?php endif; ?>
        </form>
    </div>
</div>