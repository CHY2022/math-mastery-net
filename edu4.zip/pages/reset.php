<?php
$error = '';
$success = '';

if (!isset($_SESSION['reset_email'])) {
    header('Location: ?route=forgot');
    exit;
}

$email = $_SESSION['reset_email'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = $_POST['code'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';
    
    if (empty($code) || empty($password)) {
        $error = '请填写完整信息';
    } elseif (strlen($password) < 6) {
        $error = '密码至少6个字符';
    } elseif ($password !== $confirm) {
        $error = '两次密码输入不一致';
    } elseif (!verifyCode($email, $code, 'reset')) {
        $error = '验证码无效或已过期';
    } else {
        $pdo = getDB();
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        $pdo->prepare("UPDATE users SET password = ? WHERE email = ?")->execute([$passwordHash, $email]);
        unset($_SESSION['reset_email']);
        $success = '密码重置成功！请登录。';
        header('Refresh:2;url=?route=login');
    }
}
?>
<div class="card">
    <h2 style="text-align:center;margin-bottom:20px;">重置密码</h2>
    <p style="color:var(--muted);font-size:14px;text-align:center;margin-bottom:16px;">
        已向 <strong><?= h($email) ?></strong> 发送验证码
    </p>
    <?php if ($error): ?>
    <div style="color:var(--danger);padding:10px;background:#fdeaea;border-radius:8px;margin-bottom:14px;"><?= h($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
    <div style="color:var(--ok);padding:10px;background:#e7f6ee;border-radius:8px;margin-bottom:14px;"><?= h($success) ?></div>
    <?php endif; ?>
    <form method="POST">
        <div class="form-group">
            <label>验证码 *</label>
            <input type="text" name="code" required placeholder="请输入邮箱收到的验证码">
        </div>
        <div class="form-group">
            <label>新密码 *</label>
            <input type="password" name="password" required placeholder="至少6个字符">
        </div>
        <div class="form-group">
            <label>确认新密码 *</label>
            <input type="password" name="confirm" required>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn" style="width:100%;">重置密码</button>
        </div>
        <div style="text-align:center;margin-top:12px;font-size:13px;color:var(--muted);">
            <a href="?route=login">返回登录</a>
        </div>
    </form>
</div>