<?php
// pages/review.php - 支持查看孩子/学生的薄弱点
// 【修复】首先获取当前用户
$user = getCurrentUser();
if (!$user) {
    header('Location: ?route=login');
    exit;
}

$pdo = getDB();
$userId = $user['id'];
$viewingUserId = $userId;
$viewingName = $user['name'] ?? $user['username'];
$viewingGrade = '';

// 家长查看孩子
if (isset($_GET['child_id']) && $user['role'] === 'parent') {
    $childId = (int)$_GET['child_id'];
    $childrenIds = !empty($user['children']) ? explode(',', $user['children']) : [];
    if (in_array($childId, $childrenIds)) {
        $stmt = $pdo->prepare("SELECT id, username, name, grade FROM users WHERE id = ? AND role = 'student' AND status = 'active'");
        $stmt->execute([$childId]);
        $child = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($child) {
            $viewingUserId = $childId;
            $viewingName = $child['name'] ?? $child['username'];
            $viewingGrade = $child['grade'] ?? '';
        }
    }
}

// 学校/培训机构查看学生
if (isset($_GET['student_id']) && ($user['role'] === 'school' || $user['role'] === 'training')) {
    $studentId = (int)$_GET['student_id'];
    $orgName = $user['org_name'] ?? '';
    $stmt = $pdo->prepare("SELECT id, username, name, grade FROM users WHERE id = ? AND role = 'student' AND status = 'active' AND (school = ? OR training = ?)");
    $stmt->execute([$studentId, $orgName, $orgName]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($student) {
        $viewingUserId = $studentId;
        $viewingName = $student['name'] ?? $student['username'];
        $viewingGrade = $student['grade'] ?? '';
    }
}

// 如果是学生自己查看
if ($viewingUserId === $user['id'] && $user['role'] === 'student') {
    $viewingGrade = $user['grade'] ?? '';
}

// 如果还是空，补查数据库
if (empty($viewingGrade)) {
    $stmt = $pdo->prepare("SELECT grade FROM users WHERE id = ?");
    $stmt->execute([$viewingUserId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row && !empty($row['grade'])) {
        $viewingGrade = $row['grade'];
    }
}

// 获取用户的薄弱点
$stmt = $pdo->prepare("
    SELECT id, technique_id, question_idx, fail_count, cleared, created_at 
    FROM weak_points 
    WHERE user_id = ? AND cleared = FALSE
    ORDER BY created_at DESC
");
$stmt->execute([$viewingUserId]);
$weakPoints = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 获取已清除的薄弱点数量
$stmt = $pdo->prepare("SELECT COUNT(*) FROM weak_points WHERE user_id = ? AND cleared = TRUE");
$stmt->execute([$viewingUserId]);
$clearedCount = $stmt->fetchColumn();

$totalWeak = count($weakPoints);
?>
<div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
        <h2 class="section" style="margin:0;">
            🔍 薄弱点复习
            <?php if ($viewingUserId !== $user['id']): ?>
            <span style="font-size:14px;color:#6b7280;font-weight:400;"> - 查看 <strong><?= h($viewingName) ?></strong> 的薄弱点</span>
            <?php endif; ?>
        </h2>
        <span style="font-size:14px;color:#6b7280;">
            共 <strong style="color:#dc2626;"><?= $totalWeak ?></strong> 个待复习
            <?php if ($clearedCount > 0): ?>
            · 已清除 <strong style="color:#16a34a;"><?= $clearedCount ?></strong> 个
            <?php endif; ?>
        </span>
    </div>

    <div class="hint">
        💡 在这里集中攻克做错的题目。每道题做对后会自动从薄弱点中清除，做错则继续保留。
        <?php if ($viewingUserId !== $user['id']): ?>
        <br>👤 当前查看的是 <strong><?= h($viewingName) ?></strong> 的薄弱点
        <?php endif; ?>
    </div>

    <?php if (empty($weakPoints)): ?>
    <div class="empty">
        <div style="font-size:48px;margin-bottom:12px;">🎉</div>
        <h2>没有薄弱点</h2>
        <p style="color:#6b7280;">继续保持，已经掌握了所有技巧！</p>
        <?php if ($viewingUserId !== $user['id']): ?>
        <p style="color:#6b7280;font-size:13px;"><?= h($viewingName) ?> 目前没有薄弱点，太棒了！</p>
        <?php endif; ?>
        <a href="?route=dashboard" class="btn" style="margin-top:12px;">返回控制台</a>
    </div>
    <?php else: ?>
    <div id="reviewContainer">
        <?php foreach ($weakPoints as $index => $wp): ?>
        <div class="card" id="review-item-<?= $index ?>" style="margin-bottom:16px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
                <span style="font-size:13px;color:#6b7280;">
                    <strong id="tech-name-<?= $index ?>"><?= h($wp['technique_id']) ?></strong>
                    <span style="margin:0 8px;">|</span>
                    第 <?= $index + 1 ?> 题
                    <?php if (isset($wp['fail_count']) && $wp['fail_count'] > 1): ?>
                    <span class="tag w">已错 <?= $wp['fail_count'] ?> 次</span>
                    <?php endif; ?>
                </span>
                <span style="font-size:12px;color:#6b7280;"><?= date('Y-m-d', strtotime($wp['created_at'])) ?></span>
            </div>
            <div id="question-<?= $index ?>" style="font-size:15px;font-weight:600;margin-bottom:12px;">加载题目...</div>
            
            <div id="options-<?= $index ?>" class="opts" style="display:flex;flex-direction:column;gap:8px;">
                <div style="color:#6b7280;padding:10px;">加载中...</div>
            </div>
            <div id="review-explain-<?= $index ?>" style="display:none;margin-top:10px;padding:10px 14px;background:#f8fafc;border-left:3px solid #2f6fed;border-radius:0 8px 8px 0;font-size:13px;"></div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<script>
// 阻止 app_main.js 自动渲染
window.__SKIP_APP_MAIN_RENDER = true;

// 传递查看的用户ID
var weakPoints = <?= json_encode($weakPoints) ?>;
var VIEWING_USER_ID = <?= (int)$viewingUserId ?>;
var IS_VIEWING_OTHER = <?= $viewingUserId !== $user['id'] ? 'true' : 'false' ?>;

var questionCache = {};

function getTechniqueName(techId) {
    if (typeof TECHNIQUES === 'undefined') return techId;
    var tech = TECHNIQUES.find(function(t) { return t.id === techId; });
    return tech ? tech.name : techId;
}

function loadQuestions() {
    if (typeof TECHNIQUES === 'undefined') {
        setTimeout(loadQuestions, 500);
        return;
    }
    
    weakPoints.forEach(function(wp, index) {
        var tech = TECHNIQUES.find(function(t) { return t.id === wp.technique_id; });
        
        var nameEl = document.getElementById('tech-name-' + index);
        if (nameEl && tech) {
            nameEl.textContent = tech.name;
        }
        
        if (!tech) {
            document.getElementById('question-' + index).textContent = '技巧数据未加载: ' + wp.technique_id;
            return;
        }
        
        var qData = null;
        if (typeof tech.qgen === 'function') {
            var genQuestions = tech.qgen(1);
            if (genQuestions && genQuestions.length > 0) {
                qData = genQuestions[0];
            }
        } else if (tech.questions && tech.questions.length > 0) {
            var qIdx = parseInt(wp.question_idx) || 0;
            if (tech.questions[qIdx]) {
                qData = tech.questions[qIdx];
            } else if (tech.questions[0]) {
                qData = tech.questions[0];
            }
        }
        
        if (!qData) {
            document.getElementById('question-' + index).textContent = '题目数据不可用';
            return;
        }
        
        questionCache[index] = qData;
        document.getElementById('question-' + index).textContent = qData.q || '题目加载失败';
        
        var optsHtml = '';
        var isJudge = qData.opts && qData.opts.length === 2 && 
                     ((qData.opts[0] === '对' && qData.opts[1] === '错') || 
                      (qData.opts[0] === '正确' && qData.opts[1] === '错误'));
        
        if (qData.opts) {
            qData.opts.forEach(function(opt, i) {
                var mark = isJudge ? (opt === '对' || opt === '正确' || opt === '✓' ? '✓' : '✗') : String.fromCharCode(65 + i);
                optsHtml += '<div class="opt' + (isJudge ? ' judge' : '') + '" data-index="' + index + '" data-opt="' + i + '" data-ans="' + qData.ans + '" onclick="checkReviewAnswer(this, ' + index + ', ' + wp.id + ', \'' + wp.technique_id + '\', \'' + (wp.question_idx || '') + '\')" style="cursor:pointer;padding:10px 14px;border:1px solid #e5e7eb;border-radius:8px;display:flex;align-items:center;gap:10px;transition:0.2s;">';
                optsHtml += '<span class="mark' + (isJudge ? ' judge' : '') + '" style="width:24px;height:24px;border-radius:50%;border:1px solid #d1d5db;display:flex;align-items:center;justify-content:center;font-size:12px;color:#6b7280;flex-shrink:0;">' + mark + '</span>';
                optsHtml += '<span>' + opt + '</span>';
                optsHtml += '</div>';
            });
        }
        document.getElementById('options-' + index).innerHTML = optsHtml;
    });
}

window.checkReviewAnswer = function(el, index, weakId, techniqueId, questionIdx) {
    if (el.dataset.checked === 'true') return;
    
    var parent = el.closest('.card');
    var opts = parent.querySelectorAll('.opt');
    var selected = parseInt(el.dataset.opt);
    var answer = parseInt(el.dataset.ans);
    var explainDiv = document.getElementById('review-explain-' + index);
    var qData = questionCache[index];
    
    opts.forEach(function(o) { o.dataset.checked = 'true'; });
    
    var isCorrect = selected === answer;
    opts.forEach(function(o, i) {
        o.style.pointerEvents = 'none';
        if (i === answer) {
            o.style.borderColor = '#16a34a';
            o.style.background = '#e7f6ee';
        }
        if (i === selected && selected !== answer) {
            o.style.borderColor = '#dc2626';
            o.style.background = '#fdeaea';
        }
    });
    
    explainDiv.style.display = 'block';
    explainDiv.innerHTML = '<div style="font-weight:600;color:' + (isCorrect ? '#16a34a' : '#dc2626') + ';">' + (isCorrect ? '✅ 回答正确！' : '❌ 回答错误') + '</div><div style="margin-top:4px;">' + (qData && qData.explain ? qData.explain : '解析：无') + '</div>';
    
    fetch('api/progress.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            action: 'review',
            weak_id: weakId,
            technique_id: techniqueId,
            question_idx: questionIdx,
            is_correct: isCorrect,
            user_id: VIEWING_USER_ID
        })
    })
    .then(function(res) { return res.json(); })
    .then(function(result) {
        if (isCorrect) {
            setTimeout(function() {
                var item = document.getElementById('review-item-' + index);
                if (item) {
                    item.style.transition = 'all 0.5s';
                    item.style.opacity = '0';
                    item.style.transform = 'translateX(20px)';
                    setTimeout(function() {
                        item.style.display = 'none';
                    }, 500);
                }
            }, 1500);
        }
    })
    .catch(function() {});
};

if (document.readyState === 'complete') {
    loadQuestions();
} else {
    document.addEventListener('DOMContentLoaded', loadQuestions);
}
</script>