<?php
// pages/register.php - 完整修复版（使用绝对URL）
$error = '';
$success = '';
$fieldErrors = [];

// 获取网站设置
$siteName = getSetting('site_name') ?: '融会贯通';
$logo = getSetting('logo');

// 获取当前时段、天气、月相
$currentSlot = getCurrentTimeSlot();
$weather = getUserWeather();
$lunar = getLunarDate();

$bgClass = $currentSlot['bgClass'];
$timeLabel = $currentSlot['label'];
$weatherIcon = $weather['icon'] ?? '🌤';
$weatherTemp = $weather['temp'] ?? '--';
$weatherCondition = $weather['condition'] ?? '--';
$weatherLocation = $weather['location'] ?? '--';
$moonPhase = $lunar['phase'];
$moonEmoji = $lunar['phase_emoji'];
$moonIcon = $lunar['phase_icon'];
$moonDesc = $lunar['phase_desc'];
$moonSVG = getMoonPhaseSVG($moonIcon);

// ============================================================
// 【关键】send_code 必须在任何 HTML 输出之前处理
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'send_code') {
    $email = $_POST['email'] ?? '';
    if (empty($email)) {
        echo json_encode(['success' => false, 'error' => '请输入邮箱']);
        exit;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'error' => '请输入有效的邮箱地址']);
        exit;
    }
    
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'error' => '该邮箱已被注册']);
        exit;
    }
    
    $code = generateCode();
    sendVerificationEmail($email, $code, 'register');
    echo json_encode(['success' => true, 'message' => '验证码已发送']);
    exit;
}

// ============================================================
// 注册表单提交处理
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'register') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm'] ?? '';
    $name = trim($_POST['name'] ?? '');
    $gender = $_POST['gender'] ?? '保密';
    $role = $_POST['role'] ?? 'student';
    $code = $_POST['code'] ?? '';
    $hasError = false;
    
    // 1. 验证用户名
    if (empty($username)) {
        $fieldErrors['username'] = '用户名不能为空';
        $hasError = true;
    } elseif (strlen($username) < 3) {
        $fieldErrors['username'] = '用户名至少3个字符';
        $hasError = true;
    } elseif (strlen($username) > 20) {
        $fieldErrors['username'] = '用户名不能超过20个字符';
        $hasError = true;
    }
    
    // 2. 验证真实姓名
    if (empty($name)) {
        $fieldErrors['name'] = '真实姓名不能为空';
        $hasError = true;
    } elseif (strlen($name) < 2) {
        $fieldErrors['name'] = '真实姓名至少2个字符';
        $hasError = true;
    }
    
    // 3. 验证邮箱
    if (empty($email)) {
        $fieldErrors['email'] = '邮箱地址不能为空';
        $hasError = true;
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $fieldErrors['email'] = '请输入有效的邮箱地址';
        $hasError = true;
    }
    
    // 4. 验证密码
    if (empty($password)) {
        $fieldErrors['password'] = '密码不能为空';
        $hasError = true;
    } elseif (strlen($password) < 6) {
        $fieldErrors['password'] = '密码至少6个字符';
        $hasError = true;
    } elseif (strlen($password) > 30) {
        $fieldErrors['password'] = '密码不能超过30个字符';
        $hasError = true;
    }
    
    // 5. 验证确认密码
    if (empty($confirm)) {
        $fieldErrors['confirm'] = '请再次输入密码';
        $hasError = true;
    } elseif ($password !== $confirm) {
        $fieldErrors['confirm'] = '两次密码输入不一致';
        $hasError = true;
    }
    
    // 6. 验证验证码
    if (empty($code)) {
        $fieldErrors['code'] = '请输入验证码';
        $hasError = true;
    } elseif (!verifyCode($email, $code, 'register')) {
        $fieldErrors['code'] = '验证码无效或已过期，请重新获取';
        $hasError = true;
    }
    
    // 7. 验证角色特定字段
    if ($role === 'school' || $role === 'training') {
        $orgName = trim($_POST['org_name'] ?? '');
        if (empty($orgName)) {
            $fieldErrors['org_name'] = '机构名称不能为空';
            $hasError = true;
        }
        
        $orgLevels = isset($_POST['org_levels']) ? $_POST['org_levels'] : [];
        if (!is_array($orgLevels) || empty($orgLevels)) {
            $fieldErrors['org_levels'] = '请至少选择一个机构层级';
            $hasError = true;
        }
    }
    
    // 8. 检查邮箱是否已被注册
    if (empty($fieldErrors['email']) && !empty($email)) {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetchColumn() > 0) {
            $fieldErrors['email'] = '该邮箱已被注册，请直接登录';
            $hasError = true;
        }
    }
    
    // 9. 检查用户名是否已被注册
    if (empty($fieldErrors['username']) && !empty($username)) {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetchColumn() > 0) {
            $fieldErrors['username'] = '该用户名已被使用，请换一个';
            $hasError = true;
        }
    }
    
    // ============================================================
    // 如果有错误，显示错误信息
    // ============================================================
    if ($hasError) {
        $error = '请修正以下问题：';
    } else {
        // 角色特定字段
        $extraFields = [];
        switch ($role) {
            case 'parent':
                $extraFields = [
                    'child_school' => $_POST['child_school'] ?? '',
                    'child_training' => $_POST['child_training'] ?? '',
                    'child_grade' => $_POST['child_grade'] ?? '',
                    'phone' => $_POST['phone'] ?? ''
                ];
                break;
            case 'student':
                $extraFields = [
                    'school' => $_POST['school'] ?? '',
                    'training' => $_POST['training'] ?? '',
                    'grade' => $_POST['grade'] ?? '',
                    'parent_phone' => $_POST['parent_phone'] ?? ''
                ];
                break;
            case 'school':
            case 'training':
                $orgLevels = isset($_POST['org_levels']) ? $_POST['org_levels'] : [];
                $extraFields = [
                    'org_name' => trim($_POST['org_name'] ?? ''),
                    'org_levels' => json_encode($orgLevels),
                    'admin_phone' => trim($_POST['admin_phone'] ?? '')
                ];
                break;
        }
        
        try {
            $pdo = getDB();
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            
            $sql = "INSERT INTO users (username, password, email, role, name, gender, status, 
                    child_school, child_training, child_grade, phone, school, training, grade, 
                    parent_phone, org_name, org_levels, admin_phone) 
                    VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $params = [
                $username, $passwordHash, $email, $role, $name, $gender,
                $extraFields['child_school'] ?? '',
                $extraFields['child_training'] ?? '',
                $extraFields['child_grade'] ?? '',
                $extraFields['phone'] ?? '',
                $extraFields['school'] ?? '',
                $extraFields['training'] ?? '',
                $extraFields['grade'] ?? '',
                $extraFields['parent_phone'] ?? '',
                $extraFields['org_name'] ?? '',
                $extraFields['org_levels'] ?? '[]',
                $extraFields['admin_phone'] ?? ''
            ];
            
            $pdo->prepare($sql)->execute($params);
            $success = '🎉 注册成功！正在跳转...';
            
            $_SESSION['user_id'] = $pdo->lastInsertId();
            echo '<script>setTimeout(function(){ window.location.href="?route=dashboard"; }, 1500);</script>';
            
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Duplicate') !== false) {
                if (strpos($e->getMessage(), 'username') !== false) {
                    $fieldErrors['username'] = '该用户名已被使用，请换一个';
                } else {
                    $fieldErrors['email'] = '该邮箱已被注册，请直接登录';
                }
                $error = '请修正以下问题：';
            } else {
                $error = '注册失败：' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
    <title>注册 · <?= h($siteName) ?></title>
    <link rel="stylesheet" href="css/styles.css" />
    <style>
    /* ============================================================
       注册页面 - 12时段昼夜自适应背景（与login.php相同）
       ============================================================ */
    .register-container {
        position: relative;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 30px 20px;
        margin: 0;
        transition: background 1.5s ease;
        overflow: hidden;
    }

    .register-bg {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 0;
        transition: opacity 2s ease;
    }

    /* 黎明背景 */
    .bg-dawn {
        background: linear-gradient(170deg, #2b1a3a 0%, #6b3a6b 20%, #c77d5a 50%, #f5c882 75%, #fce8b0 100%);
    }
    .bg-dawn .dawn-sun {
        position: absolute;
        bottom: 25%;
        left: 15%;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: radial-gradient(circle, #ffeaa7 0%, #fdcb6e 40%, #f6b026 70%, transparent 100%);
        box-shadow: 0 0 80px rgba(253, 203, 110, 0.3);
        animation: sunRise 8s ease-in-out infinite;
    }
    .bg-dawn .dawn-cloud {
        position: absolute;
        background: rgba(255, 200, 180, 0.3);
        border-radius: 50px;
        animation: cloudFloat 25s linear infinite;
    }
    .bg-dawn .dawn-cloud1 { width: 120px; height: 35px; top: 15%; left: 5%; }
    .bg-dawn .dawn-cloud2 { width: 80px; height: 28px; top: 25%; right: 15%; animation-duration: 20s; }

    /* 中午背景 */
    .bg-noon {
        background: linear-gradient(170deg, #1a8a8a 0%, #4ac0c0 30%, #ffd93d 70%, #f6b026 100%);
    }
    .bg-noon .noon-sun {
        position: absolute;
        top: 8%;
        right: 20%;
        width: 90px;
        height: 90px;
        border-radius: 50%;
        background: radial-gradient(circle, #fff7a0 0%, #ffd93d 40%, #f6b026 70%, transparent 100%);
        box-shadow: 0 0 120px rgba(255, 217, 61, 0.6), 0 0 200px rgba(255, 217, 61, 0.2);
        animation: sunPulse 3s ease-in-out infinite;
    }

    /* 午后背景 */
    .bg-afternoon {
        background: linear-gradient(170deg, #4facfe 0%, #7ec8e3 30%, #f5c882 60%, #fce8b0 85%);
    }
    .bg-afternoon .afternoon-sun {
        position: absolute;
        top: 15%;
        right: 10%;
        width: 70px;
        height: 70px;
        border-radius: 50%;
        background: radial-gradient(circle, #ffeaa7 0%, #fdcb6e 50%, #f6b026 80%, transparent 100%);
        box-shadow: 0 0 100px rgba(253, 203, 110, 0.4);
        animation: sunPulse 4s ease-in-out infinite;
    }
    .bg-afternoon .tree-afternoon {
        position: absolute;
        bottom: 5%;
        font-size: 50px;
        opacity: 0.25;
    }
    .bg-afternoon .tree-afternoon1 { left: 5%; }
    .bg-afternoon .tree-afternoon2 { right: 8%; font-size: 60px; }

    /* 黄昏背景（傍晚） */
    .bg-dusk {
        background: linear-gradient(170deg, #2d1b69 0%, #5a2d7a 20%, #c77d5a 50%, #f5c882 75%, #fce8b0 95%);
    }
    .bg-dusk .dusk-moon {
        position: absolute;
        top: 10%;
        right: 15%;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: radial-gradient(circle at 35% 35%, #f5f0d7 0%, #e8dca8 60%, #d4c48a 100%);
        box-shadow: 0 0 60px rgba(232, 220, 168, 0.2);
    }
    .bg-dusk .dusk-stars {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        pointer-events: none;
    }
    .bg-dusk .dusk-star {
        position: absolute;
        border-radius: 50%;
        background: #fff;
        animation: starTwinkle var(--duration) ease-in-out infinite;
    }
    .bg-dusk .dusk-star1 { width: 2px; height: 2px; top: 5%; left: 10%; --duration: 3s; }
    .bg-dusk .dusk-star2 { width: 2.5px; height: 2.5px; top: 8%; left: 30%; --duration: 2.5s; }
    .bg-dusk .dusk-star3 { width: 1.5px; height: 1.5px; top: 3%; left: 55%; --duration: 4s; }
    .bg-dusk .dusk-star4 { width: 2px; height: 2px; top: 12%; left: 75%; --duration: 3.5s; }
    .bg-dusk .dusk-star5 { width: 2.5px; height: 2.5px; top: 6%; left: 88%; --duration: 2.8s; }

    /* 日间背景 */
    .bg-day {
        background: linear-gradient(170deg, #4facfe 0%, #00f2fe 100%);
    }
    .bg-day::before {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 45%;
        background: linear-gradient(0deg, #2d8a4e 0%, #4caf50 30%, transparent 100%);
        border-radius: 0 0 50% 50% / 0 0 30% 30%;
    }
    .bg-day .sun {
        position: absolute;
        top: 12%;
        right: 15%;
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: radial-gradient(circle, #fff7a0 0%, #ffd93d 40%, #f6b026 70%, transparent 100%);
        box-shadow: 0 0 80px rgba(255, 217, 61, 0.6), 0 0 160px rgba(255, 217, 61, 0.3);
        animation: sunPulse 4s ease-in-out infinite;
    }
    .bg-day .cloud {
        position: absolute;
        background: rgba(255, 255, 255, 0.7);
        border-radius: 50px;
        animation: cloudFloat 20s linear infinite;
    }
    .bg-day .cloud1 { width: 120px; height: 40px; top: 8%; left: 5%; animation-duration: 25s; }
    .bg-day .cloud2 { width: 80px; height: 30px; top: 18%; left: 60%; animation-duration: 18s; animation-delay: -5s; }
    .bg-day .cloud3 { width: 100px; height: 35px; top: 5%; left: 35%; animation-duration: 22s; animation-delay: -10s; }
    .bg-day .tree {
        position: absolute;
        bottom: 8%;
        font-size: 60px;
        opacity: 0.6;
        filter: drop-shadow(0 4px 20px rgba(0,0,0,0.1));
    }
    .bg-day .tree1 { left: 5%; font-size: 50px; }
    .bg-day .tree2 { left: 18%; font-size: 70px; opacity: 0.5; }
    .bg-day .tree3 { right: 8%; font-size: 55px; }
    .bg-day .tree4 { right: 22%; font-size: 65px; opacity: 0.5; }
    .bg-day .grass {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 60px;
        background: linear-gradient(0deg, #2d8a4e 0%, #4caf50 60%, transparent 100%);
        border-radius: 0 0 50% 50% / 0 0 100% 100%;
    }

    /* 夜间背景 */
    .bg-night {
        background: linear-gradient(180deg, #0a0e27 0%, #1a1a3e 40%, #2d1b4e 70%, #1a0a2e 100%);
    }
    .bg-night .moon {
        position: absolute;
        top: 10%;
        right: 18%;
        width: 70px;
        height: 70px;
        border-radius: 50%;
        background: radial-gradient(circle at 35% 35%, #f5f0d7 0%, #e8dca8 40%, #d4c48a 70%, #b8a870 100%);
        box-shadow: 0 0 60px rgba(232, 220, 168, 0.3), 0 0 120px rgba(232, 220, 168, 0.1);
        animation: moonGlow 6s ease-in-out infinite;
    }
    .bg-night .moon::after {
        content: '';
        position: absolute;
        top: 12px;
        left: 20px;
        width: 18px;
        height: 18px;
        border-radius: 50%;
        background: rgba(180, 160, 100, 0.3);
        box-shadow: 30px 15px 0 4px rgba(180, 160, 100, 0.2), 10px 35px 0 6px rgba(180, 160, 100, 0.15);
    }
    .bg-night .stars {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        pointer-events: none;
    }
    .bg-night .star {
        position: absolute;
        border-radius: 50%;
        background: #fff;
        animation: starTwinkle var(--duration) ease-in-out infinite;
    }
    .bg-night .star1 { width: 2px; height: 2px; top: 5%; left: 10%; --duration: 3s; }
    .bg-night .star2 { width: 3px; height: 3px; top: 8%; left: 25%; --duration: 2.5s; }
    .bg-night .star3 { width: 1.5px; height: 1.5px; top: 3%; left: 45%; --duration: 4s; }
    .bg-night .star4 { width: 2.5px; height: 2.5px; top: 12%; left: 60%; --duration: 3.5s; }
    .bg-night .star5 { width: 2px; height: 2px; top: 6%; left: 78%; --duration: 2.8s; }
    .bg-night .star6 { width: 3px; height: 3px; top: 15%; left: 85%; --duration: 3.2s; }
    .bg-night .star7 { width: 1.5px; height: 1.5px; top: 20%; left: 5%; --duration: 4.5s; }
    .bg-night .star8 { width: 2px; height: 2px; top: 18%; left: 50%; --duration: 2.2s; }
    .bg-night .star9 { width: 3px; height: 3px; top: 25%; left: 70%; --duration: 3.8s; }
    .bg-night .star10 { width: 2px; height: 2px; top: 30%; left: 15%; --duration: 3s; }
    .bg-night .tree-night {
        position: absolute;
        bottom: 0;
        font-size: 50px;
        opacity: 0.2;
        filter: drop-shadow(0 0 20px rgba(100, 80, 200, 0.2));
    }
    .bg-night .tree-night1 { left: 3%; font-size: 45px; }
    .bg-night .tree-night2 { right: 5%; font-size: 55px; }
    .bg-night .ground-night {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 30px;
        background: linear-gradient(0deg, #0a0a1a 0%, transparent 100%);
    }

    /* 早晨背景 */
    .bg-morning {
        background: linear-gradient(170deg, #fddb92 0%, #d1fdff 100%);
    }
    .bg-morning .morning-sun {
        position: absolute;
        bottom: 30%;
        left: 15%;
        width: 70px;
        height: 70px;
        border-radius: 50%;
        background: radial-gradient(circle, #fff7a0 0%, #ffd93d 50%, #f6b026 80%, transparent 100%);
        box-shadow: 0 0 80px rgba(255, 217, 61, 0.4);
        animation: sunRise 8s ease-in-out infinite;
    }
    .bg-morning .morning-dew {
        position: absolute;
        bottom: 5%;
        left: 0;
        right: 0;
        height: 80px;
        background: linear-gradient(0deg, rgba(76, 175, 80, 0.3) 0%, transparent 100%);
        border-radius: 0 0 50% 50% / 0 0 40% 40%;
    }
    .bg-morning .tree-morning {
        position: absolute;
        bottom: 10%;
        font-size: 50px;
        opacity: 0.3;
        filter: drop-shadow(0 4px 20px rgba(0,0,0,0.05));
    }
    .bg-morning .tree-morning1 { left: 8%; }
    .bg-morning .tree-morning2 { right: 10%; font-size: 60px; opacity: 0.25; }

    /* 黄昏背景（日落） */
    .bg-sunset {
        background: linear-gradient(170deg, #ff6b35 0%, #f7931e 30%, #ffd93d 55%, #4facfe 85%);
    }
    .bg-sunset .sunset-sun {
        position: absolute;
        bottom: 25%;
        left: 50%;
        transform: translateX(-50%);
        width: 100px;
        height: 100px;
        border-radius: 50%;
        background: radial-gradient(circle, #ff6b35 0%, #ff4500 50%, transparent 100%);
        box-shadow: 0 0 120px rgba(255, 69, 0, 0.4), 0 0 200px rgba(255, 69, 0, 0.2);
        animation: sunsetGlow 3s ease-in-out infinite;
    }
    .bg-sunset .cloud-sunset {
        position: absolute;
        background: rgba(255, 200, 150, 0.5);
        border-radius: 50px;
        animation: cloudFloat 25s linear infinite;
    }
    .bg-sunset .cloud-sunset1 { width: 150px; height: 45px; top: 10%; left: 5%; }
    .bg-sunset .cloud-sunset2 { width: 100px; height: 35px; top: 20%; right: 10%; animation-duration: 20s; }
    .bg-sunset .cloud-sunset3 { width: 120px; height: 40px; top: 5%; left: 40%; animation-duration: 22s; animation-delay: -8s; }

    /* ---------- 动画 ---------- */
    @keyframes sunPulse {
        0%, 100% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.05); opacity: 0.9; }
    }
    @keyframes sunRise {
        0%, 100% { transform: translateY(0) scale(1); opacity: 0.7; }
        50% { transform: translateY(-20px) scale(1.08); opacity: 1; }
    }
    @keyframes moonGlow {
        0%, 100% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.03); opacity: 0.9; }
    }
    @keyframes sunsetGlow {
        0%, 100% { transform: translateX(-50%) scale(1); opacity: 1; }
        50% { transform: translateX(-50%) scale(1.05); opacity: 0.85; }
    }
    @keyframes starTwinkle {
        0%, 100% { opacity: 0.2; transform: scale(1); }
        50% { opacity: 1; transform: scale(1.3); }
    }
    @keyframes cloudFloat {
        0% { transform: translateX(-100px); opacity: 0; }
        10% { opacity: 1; }
        90% { opacity: 1; }
        100% { transform: translateX(calc(100vw + 100px)); opacity: 0; }
    }

    /* ---------- 注册卡片 ---------- */
    .register-card {
        position: relative;
        z-index: 1;
        width: 100%;
        max-width: 600px;
        max-height: 92vh;
        overflow-y: auto;
        padding: 36px 42px;
        background: rgba(255, 255, 255, 0.92);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border-radius: 24px;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15), 0 0 0 1px rgba(255, 255, 255, 0.1);
        transition: background 0.8s ease, box-shadow 0.8s ease;
    }
    .register-card::-webkit-scrollbar { width: 4px; }
    .register-card::-webkit-scrollbar-track { background: transparent; }
    .register-card::-webkit-scrollbar-thumb { background: rgba(47, 111, 237, 0.3); border-radius: 2px; }

    /* 夜间模式卡片 */
    body.night-mode .register-card {
        background: rgba(20, 20, 50, 0.88);
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.05);
    }
    body.night-mode .register-card .register-brand h1 { color: #e8e0c8; }
    body.night-mode .register-card .register-brand p { color: #9a8ab0; }
    body.night-mode .register-card .form-group label { color: #c8c0d8; }
    body.night-mode .register-card .form-group input,
    body.night-mode .register-card .form-group select {
        background: rgba(255, 255, 255, 0.08);
        border-color: rgba(255, 255, 255, 0.1);
        color: #e8e0d0;
    }
    body.night-mode .register-card .form-group input::placeholder { color: #6a6a8a; }
    body.night-mode .register-card .form-group select option { background: #1a1a3e; color: #e8e0d0; }
    body.night-mode .register-card .register-footer { color: #a8a0b8; }
    body.night-mode .register-card .register-footer a { color: #7a8af0; }
    body.night-mode .register-card .register-error {
        background: rgba(220, 38, 38, 0.2);
        color: #f87171;
        border-color: rgba(220, 38, 38, 0.2);
    }
    body.night-mode .register-card .register-success {
        background: rgba(22, 163, 74, 0.2);
        color: #4ade80;
        border-color: rgba(22, 163, 74, 0.2);
    }
    body.night-mode .register-card .input-group .btn-code {
        background: rgba(47, 111, 237, 0.2);
        color: #7a8af0;
    }
    body.night-mode .register-card .input-group .btn-code:hover {
        background: rgba(47, 111, 237, 0.3);
    }

    .register-brand { text-align: center; margin-bottom: 28px; }
    .register-logo { font-size: 48px; font-weight: 700; color: #2f6fed; margin-bottom: 4px; display: inline-block; }
    .register-logo-img { max-height: 60px; max-width: 180px; margin-bottom: 8px; display: inline-block; border-radius: 8px; }
    .register-brand h1 { font-size: 24px; margin: 0; color: #1f2937; font-weight: 700; }
    .register-brand p { font-size: 14px; color: #6b7280; margin: 4px 0 0; }

    .register-form .form-group { margin-bottom: 18px; }
    .register-form .form-group label { display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 5px; }
    .register-form .form-group input,
    .register-form .form-group select {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid #d1d5db;
        border-radius: 10px;
        font-size: 15px;
        transition: 0.25s;
        background: #fff;
        color: #1f2937;
        box-sizing: border-box;
    }
    .register-form .form-group input:focus,
    .register-form .form-group select:focus {
        border-color: #2f6fed;
        outline: none;
        box-shadow: 0 0 0 3px rgba(47, 111, 237, 0.12);
    }
    .register-form .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
    }

    .register-form .form-group.has-error input,
    .register-form .form-group.has-error select {
        border-color: #dc2626;
        background: #fef2f2;
    }
    .register-form .form-group.has-error input:focus,
    .register-form .form-group.has-error select:focus {
        border-color: #dc2626;
        box-shadow: 0 0 0 3px rgba(220, 38, 38, 0.12);
    }
    .field-error { font-size: 12px; color: #dc2626; margin-top: 4px; padding-left: 4px; }

    .input-group { display: flex; gap: 10px; }
    .input-group input { flex: 1; }
    .input-group .btn-code {
        padding: 10px 20px;
        border: none;
        border-radius: 10px;
        font-size: 14px;
        font-weight: 600;
        color: #fff;
        background: #2f6fed;
        cursor: pointer;
        transition: 0.25s;
        white-space: nowrap;
        min-width: 110px;
    }
    .input-group .btn-code:hover { background: #1e4fb0; }
    .input-group .btn-code:disabled { opacity: 0.6; cursor: not-allowed; }

    .register-form .form-group label:has(input[type="checkbox"]) {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        cursor: pointer;
        font-weight: 400;
        padding: 6px 14px;
        border: 1px solid #d1d5db;
        border-radius: 8px;
        background: #fafafa;
        transition: 0.2s;
        font-size: 14px;
    }
    .register-form .form-group label:has(input[type="checkbox"]):hover {
        border-color: #2f6fed;
        background: #eef3ff;
    }
    .register-form .form-group label:has(input[type="checkbox"]:checked) {
        border-color: #2f6fed;
        background: #eef3ff;
    }
    .register-form .form-group label input[type="checkbox"] {
        width: 18px;
        height: 18px;
        accent-color: #2f6fed;
        cursor: pointer;
    }

    .role-fields { display: none; }
    .role-fields.active { display: block; }

    .register-btn {
        width: 100%;
        padding: 14px;
        border: none;
        border-radius: 12px;
        font-size: 17px;
        font-weight: 700;
        color: #fff;
        background: linear-gradient(135deg, #2f6fed, #1e4fb0);
        cursor: pointer;
        transition: 0.25s;
        margin-top: 6px;
    }
    .register-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(47, 111, 237, 0.35);
    }
    .register-btn:active { transform: translateY(0); }
    .register-btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none !important; }

    .register-error {
        padding: 12px 16px;
        background: #fdeaea;
        color: #dc2626;
        border-radius: 10px;
        margin-bottom: 16px;
        border: 1px solid #fcd4d4;
        font-size: 14px;
    }
    .register-error ul { margin: 6px 0 0 16px !important; padding: 0 !important; }
    .register-error li { font-weight: 400 !important; margin-bottom: 2px; }

    .register-success {
        padding: 12px 16px;
        background: #e7f6ee;
        color: #16a34a;
        border-radius: 10px;
        margin-bottom: 16px;
        border: 1px solid #bfe6cc;
        font-size: 14px;
    }

    .register-footer {
        text-align: center;
        margin-top: 24px;
        font-size: 14px;
        color: #6b7280;
    }
    .register-footer a { color: #2f6fed; text-decoration: none; font-weight: 600; }
    .register-footer a:hover { text-decoration: underline; }

    /* 状态栏 - 时间 + 天气 + 月相 */
    .status-bar {
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 2;
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 8px 22px;
        border-radius: 30px;
        font-size: 13px;
        color: rgba(255, 255, 255, 0.9);
        background: rgba(0, 0, 0, 0.35);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        font-weight: 500;
        letter-spacing: 0.3px;
        pointer-events: none;
        transition: opacity 0.8s ease;
        flex-wrap: wrap;
        justify-content: center;
    }
    body.night-mode .status-bar {
        background: rgba(0, 0, 0, 0.5);
        color: rgba(255, 255, 255, 0.8);
    }
    .status-bar .separator {
        opacity: 0.25;
        font-size: 10px;
    }
    .status-bar .weather-info {
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .status-bar .weather-info .temp {
        font-weight: 600;
    }
    .status-bar .moon-display {
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .status-bar .moon-display .moon-icon {
        width: 28px;
        height: 28px;
        display: inline-block;
        flex-shrink: 0;
    }
    .status-bar .moon-display .moon-icon svg {
        width: 100%;
        height: 100%;
    }
    .status-bar .moon-display .moon-name {
        font-size: 12px;
        opacity: 0.85;
        white-space: nowrap;
    }
    .status-bar .moon-display .moon-detail {
        font-size: 10px;
        opacity: 0.55;
        display: none;
    }

    @media (max-width: 640px) {
        .register-card { padding: 20px 16px; max-height: 95vh; border-radius: 16px; }
        .register-form .form-row { grid-template-columns: 1fr; gap: 0; }
        .register-logo { font-size: 36px; }
        .register-logo-img { max-height: 45px; max-width: 140px; }
        .register-brand h1 { font-size: 20px; }
        .input-group { flex-direction: column; }
        .input-group .btn-code { padding: 8px 12px; font-size: 13px; min-width: auto; }
        .status-bar { font-size: 11px; padding: 5px 14px; bottom: 12px; gap: 8px; }
        .status-bar .moon-display .moon-icon { width: 20px; height: 20px; }
        .status-bar .moon-display .moon-name { font-size: 10px; }
        .status-bar .separator { display: none; }
        .bg-day .sun { width: 50px; height: 50px; top: 8%; right: 10%; }
        .bg-night .moon { width: 45px; height: 45px; top: 6%; right: 12%; }
        .bg-sunset .sunset-sun { width: 60px; height: 60px; bottom: 30%; }
        .bg-morning .morning-sun { width: 45px; height: 45px; bottom: 35%; left: 10%; }
        .bg-day .tree, .bg-night .tree-night, .bg-morning .tree-morning { font-size: 30px !important; }
        .bg-afternoon .tree-afternoon { font-size: 30px !important; }
    }
    @media (min-width: 641px) and (max-width: 768px) {
        .register-card { padding: 28px 24px; }
        .register-logo-img { max-height: 50px; max-width: 160px; }
        .status-bar .moon-display .moon-detail { display: none; }
    }
    @media (min-width: 769px) and (max-width: 1024px) {
        .register-card { padding: 32px 36px; }
    }
    @media (min-width: 769px) {
        .status-bar .moon-display .moon-detail { display: inline; }
    }
    </style>
</head>
<body>
    <div class="register-container">
        <!-- 动态背景层 -->
        <div class="register-bg <?= $bgClass ?>" id="registerBg">
            <?php if ($bgClass === 'bg-day'): ?>
            <div class="sun"></div>
            <div class="cloud cloud1"></div>
            <div class="cloud cloud2"></div>
            <div class="cloud cloud3"></div>
            <div class="tree tree1">🌳</div>
            <div class="tree tree2">🌲</div>
            <div class="tree tree3">🌳</div>
            <div class="tree tree4">🌲</div>
            <div class="grass"></div>
            <?php elseif ($bgClass === 'bg-night'): ?>
            <div class="moon"></div>
            <div class="stars">
                <div class="star star1"></div>
                <div class="star star2"></div>
                <div class="star star3"></div>
                <div class="star star4"></div>
                <div class="star star5"></div>
                <div class="star star6"></div>
                <div class="star star7"></div>
                <div class="star star8"></div>
                <div class="star star9"></div>
                <div class="star star10"></div>
            </div>
            <div class="tree-night tree-night1">🌲</div>
            <div class="tree-night tree-night2">🌲</div>
            <div class="ground-night"></div>
            <?php elseif ($bgClass === 'bg-sunset'): ?>
            <div class="sunset-sun"></div>
            <div class="cloud-sunset cloud-sunset1"></div>
            <div class="cloud-sunset cloud-sunset2"></div>
            <div class="cloud-sunset cloud-sunset3"></div>
            <?php elseif ($bgClass === 'bg-morning'): ?>
            <div class="morning-sun"></div>
            <div class="morning-dew"></div>
            <div class="tree-morning tree-morning1">🌳</div>
            <div class="tree-morning tree-morning2">🌲</div>
            <?php elseif ($bgClass === 'bg-dawn'): ?>
            <div class="dawn-sun"></div>
            <div class="dawn-cloud dawn-cloud1"></div>
            <div class="dawn-cloud dawn-cloud2"></div>
            <?php elseif ($bgClass === 'bg-noon'): ?>
            <div class="noon-sun"></div>
            <?php elseif ($bgClass === 'bg-afternoon'): ?>
            <div class="afternoon-sun"></div>
            <div class="tree-afternoon tree-afternoon1">🌳</div>
            <div class="tree-afternoon tree-afternoon2">🌳</div>
            <?php elseif ($bgClass === 'bg-dusk'): ?>
            <div class="dusk-moon"></div>
            <div class="dusk-stars">
                <div class="dusk-star dusk-star1"></div>
                <div class="dusk-star dusk-star2"></div>
                <div class="dusk-star dusk-star3"></div>
                <div class="dusk-star dusk-star4"></div>
                <div class="dusk-star dusk-star5"></div>
            </div>
            <?php endif; ?>
        </div>

        <div class="register-card">
            <div class="register-brand">
                <?php if ($logo): ?>
                <img src="<?= h($logo) ?>" alt="<?= h($siteName) ?>" class="register-logo-img">
                <?php else: ?>
                <div class="register-logo">∑</div>
                <?php endif; ?>
                <h1><?= h($siteName) ?></h1>
                <p>创建你的账号，开启学习之旅</p>
            </div>

            <!-- 错误信息显示 -->
            <?php if ($error): ?>
            <div class="register-error">
                <strong><?= h($error) ?></strong>
                <?php if (!empty($fieldErrors)): ?>
                <ul style="margin:6px 0 0 16px;padding:0;list-style:disc;">
                    <?php foreach ($fieldErrors as $field => $msg): ?>
                    <li style="font-weight:400;"><?= h($msg) ?></li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php if ($success): ?>
            <div class="register-success"><?= h($success) ?></div>
            <?php endif; ?>

            <form method="POST" id="registerForm" class="register-form" action="">
                <input type="hidden" name="action" value="register">

                <!-- ========== 第一行：角色选择 + 用户名 ========== -->
                <div class="form-row">
                    <div class="form-group <?= isset($fieldErrors['role']) ? 'has-error' : '' ?>">
                        <label>选择角色 *</label>
                        <select name="role" id="roleSelect" required onchange="toggleRoleFields()">
                            <option value="student" <?= ($_POST['role'] ?? 'student') === 'student' ? 'selected' : '' ?>>🎓 学生</option>
                            <option value="parent" <?= ($_POST['role'] ?? '') === 'parent' ? 'selected' : '' ?>>👨‍👩‍👦 家长</option>
                            <option value="school" <?= ($_POST['role'] ?? '') === 'school' ? 'selected' : '' ?>>🏫 学校</option>
                            <option value="training" <?= ($_POST['role'] ?? '') === 'training' ? 'selected' : '' ?>>📚 培训机构</option>
                        </select>
                    </div>
                    <div class="form-group <?= isset($fieldErrors['username']) ? 'has-error' : '' ?>">
                        <label>用户名 *</label>
                        <input type="text" name="username" required placeholder="至少3个字符" value="<?= h($_POST['username'] ?? '') ?>">
                        <?php if (isset($fieldErrors['username'])): ?>
                        <div class="field-error"><?= h($fieldErrors['username']) ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- ========== 第二行：真实姓名 + 性别 ========== -->
                <div class="form-row">
                    <div class="form-group <?= isset($fieldErrors['name']) ? 'has-error' : '' ?>">
                        <label>真实姓名 *</label>
                        <input type="text" name="name" required placeholder="请输入真实姓名" value="<?= h($_POST['name'] ?? '') ?>">
                        <?php if (isset($fieldErrors['name'])): ?>
                        <div class="field-error"><?= h($fieldErrors['name']) ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label>性别</label>
                        <select name="gender">
                            <option value="保密" <?= ($_POST['gender'] ?? '保密') === '保密' ? 'selected' : '' ?>>保密</option>
                            <option value="男" <?= ($_POST['gender'] ?? '') === '男' ? 'selected' : '' ?>>男</option>
                            <option value="女" <?= ($_POST['gender'] ?? '') === '女' ? 'selected' : '' ?>>女</option>
                        </select>
                    </div>
                </div>

                <!-- ========== 第三行：邮箱地址 ========== -->
                <div class="form-group <?= isset($fieldErrors['email']) ? 'has-error' : '' ?>">
                    <label>邮箱地址 *</label>
                    <input type="email" name="email" id="regEmail" required placeholder="请输入邮箱地址" value="<?= h($_POST['email'] ?? '') ?>">
                    <?php if (isset($fieldErrors['email'])): ?>
                    <div class="field-error"><?= h($fieldErrors['email']) ?></div>
                    <?php endif; ?>
                </div>

                <!-- ========== 第四行：验证码 + 发送按钮 ========== -->
                <div class="form-group <?= isset($fieldErrors['code']) ? 'has-error' : '' ?>">
                    <label>验证码 *</label>
                    <div class="input-group">
                        <input type="text" name="code" required placeholder="请输入收到的验证码" value="<?= h($_POST['code'] ?? '') ?>">
                        <button type="button" class="btn-code" onclick="sendVerifyCode()" id="sendCodeBtn">获取验证码</button>
                    </div>
                    <?php if (isset($fieldErrors['code'])): ?>
                    <div class="field-error"><?= h($fieldErrors['code']) ?></div>
                    <?php endif; ?>
                </div>

                <!-- ========== 第五行：密码 + 确认密码 ========== -->
                <div class="form-row">
                    <div class="form-group <?= isset($fieldErrors['password']) ? 'has-error' : '' ?>">
                        <label>密码 *</label>
                        <input type="password" name="password" required placeholder="至少6个字符">
                        <?php if (isset($fieldErrors['password'])): ?>
                        <div class="field-error"><?= h($fieldErrors['password']) ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group <?= isset($fieldErrors['confirm']) ? 'has-error' : '' ?>">
                        <label>确认密码 *</label>
                        <input type="password" name="confirm" required placeholder="再次输入密码">
                        <?php if (isset($fieldErrors['confirm'])): ?>
                        <div class="field-error"><?= h($fieldErrors['confirm']) ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- ============================================================ -->
                <!-- 角色特定字段 -->
                <!-- ============================================================ -->

                <!-- ========== 学生字段 ========== -->
                <div id="studentFields" class="role-fields" style="display:<?= ($_POST['role'] ?? 'student') === 'student' ? 'block' : 'none' ?>;">
                    <div class="form-row">
                        <div class="form-group">
                            <label>学校名称</label>
                            <input type="text" name="school" placeholder="请输入学校名称" value="<?= h($_POST['school'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>培训机构</label>
                            <input type="text" name="training" placeholder="请输入培训机构名称" value="<?= h($_POST['training'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>年级</label>
                            <select name="grade">
                                <option value="">请选择</option>
                                <?php
                                $grades = ['一年级','二年级','三年级','四年级','五年级','六年级','七年级','八年级','九年级','十年级','十一年级','十二年级'];
                                foreach ($grades as $g):
                                    $selected = ($_POST['grade'] ?? '') === $g ? 'selected' : '';
                                ?>
                                <option value="<?= $g ?>" <?= $selected ?>><?= $g ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>家长手机号</label>
                            <input type="text" name="parent_phone" placeholder="请输入家长手机号" value="<?= h($_POST['parent_phone'] ?? '') ?>">
                        </div>
                    </div>
                </div>

                <!-- ========== 家长字段 ========== -->
                <div id="parentFields" class="role-fields" style="display:<?= ($_POST['role'] ?? '') === 'parent' ? 'block' : 'none' ?>;">
                    <div class="form-row">
                        <div class="form-group">
                            <label>孩子学校</label>
                            <input type="text" name="child_school" placeholder="请输入孩子学校" value="<?= h($_POST['child_school'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>孩子培训机构</label>
                            <input type="text" name="child_training" placeholder="请输入孩子培训机构" value="<?= h($_POST['child_training'] ?? '') ?>">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>孩子年级</label>
                            <select name="child_grade">
                                <option value="">请选择</option>
                                <?php
                                $grades = ['一年级','二年级','三年级','四年级','五年级','六年级','七年级','八年级','九年级','十年级','十一年级','十二年级'];
                                foreach ($grades as $g):
                                    $selected = ($_POST['child_grade'] ?? '') === $g ? 'selected' : '';
                                ?>
                                <option value="<?= $g ?>" <?= $selected ?>><?= $g ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>手机号</label>
                            <input type="text" name="phone" placeholder="请输入手机号" value="<?= h($_POST['phone'] ?? '') ?>">
                        </div>
                    </div>
                </div>

                <!-- ========== 学校/培训机构字段 ========== -->
                <div id="orgFields" class="role-fields" style="display:<?= ($_POST['role'] ?? '') === 'school' || ($_POST['role'] ?? '') === 'training' ? 'block' : 'none' ?>;">
                    <div class="form-group <?= isset($fieldErrors['org_name']) ? 'has-error' : '' ?>">
                        <label>机构名称 *</label>
                        <input type="text" name="org_name" id="org_name" placeholder="请输入机构名称" value="<?= h($_POST['org_name'] ?? '') ?>">
                        <?php if (isset($fieldErrors['org_name'])): ?>
                        <div class="field-error"><?= h($fieldErrors['org_name']) ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group <?= isset($fieldErrors['org_levels']) ? 'has-error' : '' ?>">
                        <label>机构层级（可多选，至少选一个）*</label>
                        <div style="display:flex;gap:16px;flex-wrap:wrap;padding:6px 0;">
                            <?php
                            $selectedLevels = isset($_POST['org_levels']) ? $_POST['org_levels'] : ['小学'];
                            if (!is_array($selectedLevels)) $selectedLevels = ['小学'];
                            ?>
                            <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;font-weight:400;padding:6px 14px;border:1px solid <?= in_array('小学', $selectedLevels) ? '#2f6fed' : '#d1d5db' ?>;border-radius:8px;background:<?= in_array('小学', $selectedLevels) ? '#eef3ff' : '#fafafa' ?>;transition:0.2s;">
                                <input type="checkbox" name="org_levels[]" value="小学" <?= in_array('小学', $selectedLevels) ? 'checked' : '' ?> style="width:18px;height:18px;accent-color:#2f6fed;"> 🏫 小学
                            </label>
                            <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;font-weight:400;padding:6px 14px;border:1px solid <?= in_array('初级中学', $selectedLevels) ? '#2f6fed' : '#d1d5db' ?>;border-radius:8px;background:<?= in_array('初级中学', $selectedLevels) ? '#eef3ff' : '#fafafa' ?>;transition:0.2s;">
                                <input type="checkbox" name="org_levels[]" value="初级中学" <?= in_array('初级中学', $selectedLevels) ? 'checked' : '' ?> style="width:18px;height:18px;accent-color:#2f6fed;"> 📚 初级中学
                            </label>
                            <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;font-weight:400;padding:6px 14px;border:1px solid <?= in_array('高级中学', $selectedLevels) ? '#2f6fed' : '#d1d5db' ?>;border-radius:8px;background:<?= in_array('高级中学', $selectedLevels) ? '#eef3ff' : '#fafafa' ?>;transition:0.2s;">
                                <input type="checkbox" name="org_levels[]" value="高级中学" <?= in_array('高级中学', $selectedLevels) ? 'checked' : '' ?> style="width:18px;height:18px;accent-color:#2f6fed;"> 🎓 高级中学
                            </label>
                        </div>
                        <?php if (isset($fieldErrors['org_levels'])): ?>
                        <div class="field-error"><?= h($fieldErrors['org_levels']) ?></div>
                        <?php endif; ?>
                        <div style="font-size:12px;color:#6b7280;margin-top:2px;">💡 至少选择一个层级</div>
                    </div>
                    <div class="form-group">
                        <label>管理员手机号</label>
                        <input type="text" name="admin_phone" placeholder="请输入管理员手机号" value="<?= h($_POST['admin_phone'] ?? '') ?>">
                    </div>
                </div>

                <button type="submit" class="register-btn" id="registerSubmitBtn">创建账号</button>
            </form>

            <div class="register-footer">
                已有账号？<a href="?route=login">立即登录</a>
            </div>
        </div>

        <!-- 状态栏：时间 + 天气 + 月相 -->
        <div class="status-bar" id="statusBar">
            <span id="timeDisplay"><?= $timeLabel ?></span>
            <span class="separator">|</span>
            <span class="moon-display" id="moonDisplay">
                <span class="moon-icon"><?= $moonSVG ?></span>
                <span class="moon-name"><?= $moonEmoji ?> <?= $moonPhase ?></span>
                <span class="moon-detail"><?= $moonDesc ?></span>
            </span>
            <span class="separator">|</span>
            <span class="weather-info" id="weatherDisplay">
                <span id="weatherIcon"><?= $weatherIcon ?></span>
                <span class="temp" id="weatherTemp"><?= $weatherTemp ?></span>
                <span id="weatherCondition"><?= $weatherCondition ?></span>
                <span style="opacity:0.5;font-size:11px;" id="weatherLocation"><?= $weatherLocation ?></span>
            </span>
        </div>
    </div>

    <script>
    // ============================================================
    // 注册页面 - 12时段自适应 + 天气 + 月相
    // ============================================================
    (function() {
        'use strict';

        var TIME_SLOTS = [
            { start: 0, end: 2, label: '🌙 深夜 · 万籁俱寂', bgClass: 'bg-night' },
            { start: 2, end: 5, label: '🌃 凌晨 · 星光点点', bgClass: 'bg-night' },
            { start: 5, end: 7, label: '🌅 黎明 · 东方既白', bgClass: 'bg-dawn' },
            { start: 7, end: 9, label: '🌤 早晨 · 清新晨光', bgClass: 'bg-morning' },
            { start: 9, end: 11, label: '☀️ 上午 · 阳光明媚', bgClass: 'bg-day' },
            { start: 11, end: 13, label: '🌞 中午 · 烈日当空', bgClass: 'bg-noon' },
            { start: 13, end: 15, label: '☀️ 午后 · 暖阳和煦', bgClass: 'bg-afternoon' },
            { start: 15, end: 17, label: '🌤 下午 · 斜阳微醺', bgClass: 'bg-day' },
            { start: 17, end: 19, label: '🌇 黄昏 · 落日熔金', bgClass: 'bg-sunset' },
            { start: 19, end: 21, label: '🌆 傍晚 · 华灯初上', bgClass: 'bg-dusk' },
            { start: 21, end: 23, label: '🌙 夜晚 · 月明星稀', bgClass: 'bg-night' },
            { start: 23, end: 24, label: '🌙 深夜 · 夜深人静', bgClass: 'bg-night' }
        ];

        function getCurrentTimeSlot() {
            var now = new Date();
            var hours = now.getHours();
            var minutes = now.getMinutes();
            var totalMinutes = hours * 60 + minutes;
            
            for (var i = 0; i < TIME_SLOTS.length; i++) {
                var slot = TIME_SLOTS[i];
                var startMin = slot.start * 60;
                var endMin = slot.end * 60;
                
                if (slot.end < slot.start) {
                    if (totalMinutes >= startMin || totalMinutes < endMin) {
                        return slot;
                    }
                } else {
                    if (totalMinutes >= startMin && totalMinutes < endMin) {
                        return slot;
                    }
                }
            }
            return TIME_SLOTS[0];
        }

        function updateTimeAndBackground() {
            var slot = getCurrentTimeSlot();
            var container = document.querySelector('.register-container');
            if (!container) return;
            
            var bg = document.getElementById('registerBg');
            if (bg) {
                bg.className = 'register-bg ' + slot.bgClass;
            }
            
            var timeDisplay = document.getElementById('timeDisplay');
            if (timeDisplay) {
                var now = new Date();
                var hours = String(now.getHours()).padStart(2, '0');
                var minutes = String(now.getMinutes()).padStart(2, '0');
                timeDisplay.textContent = slot.label + '  ·  ' + hours + ':' + minutes;
            }
            
            var isNight = (slot.bgClass === 'bg-night' || slot.bgClass === 'bg-dusk' || slot.bgClass === 'bg-dawn');
            document.body.classList.toggle('night-mode', isNight);
        }

        // ============================================================
        // 天气更新
        // ============================================================
        function updateWeather() {
            fetch('api/weather.php')
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.success) {
                        var icon = document.getElementById('weatherIcon');
                        var temp = document.getElementById('weatherTemp');
                        var condition = document.getElementById('weatherCondition');
                        var location = document.getElementById('weatherLocation');
                        if (icon) icon.textContent = data.icon || '🌤';
                        if (temp) temp.textContent = data.temp || '--';
                        if (condition) condition.textContent = data.condition || '--';
                        if (location) location.textContent = data.location || '--';
                    }
                })
                .catch(function() {});
        }

        // ============================================================
        // 月相更新
        // ============================================================
        function updateMoon() {
            fetch('api/moon.php')
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.success) {
                        var moonDisplay = document.getElementById('moonDisplay');
                        if (moonDisplay) {
                            moonDisplay.innerHTML = `
                                <span class="moon-icon">${data.svg}</span>
                                <span class="moon-name">${data.phase_emoji} ${data.phase}</span>
                                <span class="moon-detail">${data.phase_desc}</span>
                            `;
                        }
                    }
                })
                .catch(function() {});
        }

        // 每分钟更新一次时间和背景
        setInterval(updateTimeAndBackground, 60000);
        // 每10分钟更新一次天气
        setInterval(updateWeather, 600000);
        // 每小时更新一次月相
        setInterval(updateMoon, 3600000);
        
        // 立即执行
        updateTimeAndBackground();
        updateWeather();
        updateMoon();
    })();

    // ============================================================
    // 注册页面 - 业务逻辑（保持不变）
    // ============================================================
    function toggleRoleFields() {
        var role = document.getElementById('roleSelect').value;
        var fields = document.querySelectorAll('.role-fields');
        for (var i = 0; i < fields.length; i++) {
            fields[i].style.display = 'none';
            fields[i].classList.remove('active');
        }
        var target = document.getElementById(role + 'Fields');
        if (target) {
            target.style.display = 'block';
            target.classList.add('active');
        }
        
        var orgNameInput = document.getElementById('org_name');
        if (orgNameInput) {
            if (role === 'school' || role === 'training') {
                orgNameInput.required = true;
                var label = orgNameInput.closest('.form-group').querySelector('label');
                if (label) label.innerHTML = '机构名称 *';
            } else {
                orgNameInput.required = false;
                var label = orgNameInput.closest('.form-group').querySelector('label');
                if (label) label.innerHTML = '机构名称';
            }
        }
    }

    function sendVerifyCode() {
        var email = document.getElementById('regEmail').value;
        if (!email || !email.includes('@')) {
            alert('请输入有效的邮箱地址');
            return;
        }
        
        var btn = document.getElementById('sendCodeBtn');
        btn.disabled = true;
        btn.textContent = '发送中...';
        
        var url = window.location.origin + '/index.php?route=register';
        
        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: 'action=send_code&email=' + encodeURIComponent(email)
        })
        .then(function(res) { return res.json(); })
        .then(function(result) {
            if (result.success) {
                alert('✅ 验证码已发送到您的邮箱，请查收');
                var countdown = 60;
                btn.textContent = countdown + 's';
                var timer = setInterval(function() {
                    countdown--;
                    btn.textContent = countdown + 's';
                    if (countdown <= 0) {
                        clearInterval(timer);
                        btn.disabled = false;
                        btn.textContent = '重新发送';
                    }
                }, 1000);
            } else {
                alert('❌ ' + (result.error || '发送失败'));
                btn.disabled = false;
                btn.textContent = '获取验证码';
            }
        })
        .catch(function(err) {
            console.error('发送验证码错误:', err);
            alert('⚠️ 邮件可能已发送，请检查邮箱。\n如果未收到，请重试。');
            btn.disabled = false;
            btn.textContent = '获取验证码';
        });
    }

    document.addEventListener('DOMContentLoaded', function() {
        toggleRoleFields();
        
        var form = document.getElementById('registerForm');
        if (form) {
            form.addEventListener('submit', function(e) {
                var role = document.getElementById('roleSelect').value;
                
                if (role === 'school' || role === 'training') {
                    var checkboxes = document.querySelectorAll('input[name="org_levels[]"]:checked');
                    if (checkboxes.length === 0) {
                        e.preventDefault();
                        alert('❌ 请至少选择一个机构层级');
                        return false;
                    }
                }
                
                if (role === 'school' || role === 'training') {
                    var orgName = document.getElementById('org_name');
                    if (orgName && orgName.value.trim() === '') {
                        e.preventDefault();
                        alert('❌ 请输入机构名称');
                        orgName.focus();
                        return false;
                    }
                }
                
                var codeInput = form.querySelector('input[name="code"]');
                if (codeInput && codeInput.value.trim() === '') {
                    e.preventDefault();
                    alert('❌ 请输入验证码');
                    codeInput.focus();
                    return false;
                }
                
                var password = form.querySelector('input[name="password"]');
                var confirm = form.querySelector('input[name="confirm"]');
                if (password && confirm && password.value !== confirm.value) {
                    e.preventDefault();
                    alert('❌ 两次密码输入不一致');
                    confirm.focus();
                    return false;
                }
                
                if (password && password.value.length < 6) {
                    e.preventDefault();
                    alert('❌ 密码至少6个字符');
                    password.focus();
                    return false;
                }
                
                return true;
            });
        }
    });
    </script>
</body>
</html>