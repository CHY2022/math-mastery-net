<?php
$currentUser = getCurrentUser();
if ($currentUser['role'] !== 'admin') {
    header('Location: ?route=dashboard');
    exit;
}

$pdo = getDB();
$settings = [];
$stmt = $pdo->query("SELECT * FROM site_settings");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $settings[$row['key_name']] = $row['value'];
}

$success = '';
$error = '';

// 创建上传目录
$uploadDir = __DIR__ . '/../uploads/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'save';
    
    if ($action === 'upload_logo') {
        // 处理Logo上传
        if (isset($_FILES['logo_file']) && $_FILES['logo_file']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['logo_file'];
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp'];
            
            if (!in_array($ext, $allowed)) {
                $error = '只支持 JPG, PNG, GIF, SVG, WEBP 格式';
            } elseif ($file['size'] > 2 * 1024 * 1024) {
                $error = '文件大小不能超过 2MB';
            } else {
                $filename = 'logo_' . time() . '.' . $ext;
                $targetPath = $uploadDir . $filename;
                
                if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                    $logoUrl = '/uploads/' . $filename;
                    
                    // 保存到数据库
                    $stmt = $pdo->prepare("INSERT INTO site_settings (key_name, value) VALUES ('logo', ?) ON DUPLICATE KEY UPDATE value = ?");
                    $stmt->execute([$logoUrl, $logoUrl]);
                    
                    $success = '✅ Logo上传成功！';
                    
                    // 重新读取设置
                    $stmt = $pdo->query("SELECT * FROM site_settings");
                    $settings = [];
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        $settings[$row['key_name']] = $row['value'];
                    }
                } else {
                    $error = '文件上传失败，请检查目录权限';
                }
            }
        } else {
            $error = '请选择要上传的文件';
        }
    } elseif ($action === 'remove_logo') {
        // 删除Logo
        $stmt = $pdo->prepare("UPDATE site_settings SET value = '' WHERE key_name = 'logo'");
        $stmt->execute();
        $success = '✅ Logo已移除';
        
        $stmt = $pdo->query("SELECT * FROM site_settings");
        $settings = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $settings[$row['key_name']] = $row['value'];
        }
    } else {
        // 保存其他设置
        $updates = [
            'site_name' => $_POST['site_name'] ?? SITE_NAME,
            'site_url' => $_POST['site_url'] ?? SITE_URL,
            'admin_email' => $_POST['admin_email'] ?? ADMIN_EMAIL,
            'icp_number' => $_POST['icp_number'] ?? ICP_NUMBER
        ];
        
        foreach ($updates as $key => $value) {
            $stmt = $pdo->prepare("INSERT INTO site_settings (key_name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = ?");
            $stmt->execute([$key, $value, $value]);
        }
        $success = '✅ 设置已保存';
        
        $stmt = $pdo->query("SELECT * FROM site_settings");
        $settings = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $settings[$row['key_name']] = $row['value'];
        }
    }
}

// 获取当前Logo
$currentLogo = $settings['logo'] ?? '';
?>
<div>
    <h2 class="section">⚙️ 网站设置</h2>
    
    <?php if ($success): ?>
    <div style="color:#16a34a;padding:10px 14px;background:#e7f6ee;border-radius:8px;margin-bottom:14px;border:1px solid #bfe6cc;"><?= h($success) ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
    <div style="color:#dc2626;padding:10px 14px;background:#fdeaea;border-radius:8px;margin-bottom:14px;border:1px solid #fcd4d4;"><?= h($error) ?></div>
    <?php endif; ?>
    
    <!-- Logo管理 -->
    <div class="card">
        <h3>🖼️ Logo管理</h3>
        <div style="display:flex;align-items:center;gap:20px;flex-wrap:wrap;padding:10px 0;">
            <div style="text-align:center;">
                <?php if ($currentLogo): ?>
                <img src="<?= h($currentLogo) ?>" style="max-height:80px;max-width:200px;border:1px solid #e5e7eb;border-radius:8px;padding:8px;background:#fff;" alt="当前Logo">
                <div style="font-size:12px;color:#6b7280;margin-top:4px;">当前Logo</div>
                <?php else: ?>
                <div style="width:80px;height:80px;border:2px dashed #d1d5db;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:36px;color:#d1d5db;margin:0 auto;">∑</div>
                <div style="font-size:12px;color:#6b7280;margin-top:4px;">暂无Logo</div>
                <?php endif; ?>
            </div>
            
            <div style="flex:1;">
                <form method="POST" enctype="multipart/form-data" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                    <input type="hidden" name="action" value="upload_logo">
                    <input type="file" name="logo_file" accept="image/*" style="padding:8px;border:1px solid #d1d5db;border-radius:6px;flex:1;min-width:200px;">
                    <button type="submit" class="btn">📤 上传Logo</button>
                </form>
                <div style="font-size:12px;color:#6b7280;margin-top:6px;">支持 JPG, PNG, GIF, SVG, WEBP 格式，最大 2MB</div>
            </div>
            
            <?php if ($currentLogo): ?>
            <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="remove_logo">
                <button type="submit" class="btn danger" style="background:#dc2626;color:#fff;" onclick="return confirm('确定要移除Logo吗？')">🗑️ 移除Logo</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- 其他设置 -->
    <div class="card">
        <h3>📋 基本设置</h3>
        <form method="POST">
            <input type="hidden" name="action" value="save">
            
            <div class="form-group">
                <label>网站名称</label>
                <input type="text" name="site_name" value="<?= h($settings['site_name'] ?? SITE_NAME) ?>" required>
            </div>
            <div class="form-group">
                <label>网站域名</label>
                <input type="url" name="site_url" value="<?= h($settings['site_url'] ?? SITE_URL) ?>" required>
            </div>
            <div class="form-group">
                <label>管理员邮箱</label>
                <input type="email" name="admin_email" value="<?= h($settings['admin_email'] ?? ADMIN_EMAIL) ?>" required>
            </div>
            <div class="form-group">
                <label>ICP备案号</label>
                <input type="text" name="icp_number" value="<?= h($settings['icp_number'] ?? ICP_NUMBER) ?>" placeholder="如：京ICP备2023000000号">
            </div>
            <div class="form-actions" style="margin-top:16px;padding-top:16px;border-top:1px solid #e5e7eb;">
                <button type="submit" class="btn">💾 保存设置</button>
            </div>
        </form>
    </div>
</div>