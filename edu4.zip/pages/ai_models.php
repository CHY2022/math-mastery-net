<?php
// pages/ai_models.php - AI 模型设置页面
$user = getCurrentUser();
if (!$user) {
    header('Location: ?route=login');
    exit;
}

$pdo = getDB();
$error = '';
$success = '';

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'save') {
        $name = trim($_POST['name'] ?? '');
        $apiUrl = trim($_POST['api_url'] ?? '');
        $model = trim($_POST['model'] ?? '');
        $apiKey = trim($_POST['api_key'] ?? '');
        $isDefault = isset($_POST['is_default']) ? 1 : 0;
        $modelId = (int)($_POST['model_id'] ?? 0);
        
        if (empty($name) || empty($apiUrl) || empty($model)) {
            $error = '请填写完整信息（名称、API地址、模型名称）';
        } else {
            try {
                if ($modelId > 0) {
                    // 更新
                    $sql = "UPDATE user_ai_models SET name = ?, api_url = ?, model = ?, api_key = ?, is_default = ? WHERE id = ? AND user_id = ?";
                    $params = [$name, $apiUrl, $model, $apiKey, $isDefault, $modelId, $user['id']];
                } else {
                    // 新增
                    $sql = "INSERT INTO user_ai_models (user_id, name, api_url, model, api_key, is_default) VALUES (?, ?, ?, ?, ?, ?)";
                    $params = [$user['id'], $name, $apiUrl, $model, $apiKey, $isDefault];
                }
                
                // 如果设置为默认，取消其他默认
                if ($isDefault) {
                    $pdo->prepare("UPDATE user_ai_models SET is_default = 0 WHERE user_id = ?")->execute([$user['id']]);
                }
                
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                $success = '✅ 模型配置已保存';
            } catch (PDOException $e) {
                $error = '保存失败: ' . $e->getMessage();
            }
        }
    }
    
    if ($action === 'delete') {
        $modelId = (int)($_POST['model_id'] ?? 0);
        if ($modelId > 0) {
            $pdo->prepare("DELETE FROM user_ai_models WHERE id = ? AND user_id = ?")->execute([$modelId, $user['id']]);
            $success = '✅ 已删除';
        }
    }
    
    if ($action === 'set_default') {
        $modelId = (int)($_POST['model_id'] ?? 0);
        if ($modelId > 0) {
            $pdo->prepare("UPDATE user_ai_models SET is_default = 0 WHERE user_id = ?")->execute([$user['id']]);
            $pdo->prepare("UPDATE user_ai_models SET is_default = 1 WHERE id = ? AND user_id = ?")->execute([$modelId, $user['id']]);
            $success = '✅ 已设为默认';
        }
    }
}

// 获取用户的所有模型配置
$stmt = $pdo->prepare("SELECT * FROM user_ai_models WHERE user_id = ? ORDER BY is_default DESC, id ASC");
$stmt->execute([$user['id']]);
$models = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 如果没有配置，创建默认模型列表
if (empty($models)) {
    $defaultModels = [
        ['name' => 'Agnes 2.5 Flash', 'api_url' => 'https://api.agnes-ai.cn/v1/chat/completions', 'model' => 'agnes-2.5-flash'],
    ['name' => 'GLM-4.7-Flash', 'api_url' => 'https://open.bigmodel.cn/api/paas/v4/chat/completions', 'model' => 'glm-4.7-flash'],
    ['name' => 'GLM-4-Flash', 'api_url' => 'https://open.bigmodel.cn/api/paas/v4/chat/completions', 'model' => 'glm-4-flash'],
    ['name' => 'DeepSeek-V4-Flash-0731', 'api_url' => 'https://developer.amd.com.cn/radeon/api/v1', 'model' => 'DeepSeek-V4-Flash-0731'],
    ['name' => 'MiniCPM5-1B', 'api_url' => 'https://developer.amd.com.cn/radeon/api/v1', 'model' => 'MiniCPM5-1B']
];
    
    foreach ($defaultModels as $idx => $dm) {
        $isDefault = ($idx === 0) ? 1 : 0;
        $stmt = $pdo->prepare("INSERT INTO user_ai_models (user_id, name, api_url, model, api_key, is_default) VALUES (?, ?, ?, ?, '', ?)");
        $stmt->execute([$user['id'], $dm['name'], $dm['api_url'], $dm['model'], $isDefault]);
    }
    
    // 重新获取
    $stmt = $pdo->prepare("SELECT * FROM user_ai_models WHERE user_id = ? ORDER BY is_default DESC, id ASC");
    $stmt->execute([$user['id']]);
    $models = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
        <h2 class="section" style="margin:0;">⚙️ 模型设置</h2>
        <button class="btn" onclick="showAddModel()">➕ 添加模型</button>
    </div>

    <?php if ($success): ?>
    <div style="color:#16a34a;padding:10px 14px;background:#e7f6ee;border-radius:8px;margin-bottom:14px;border:1px solid #bfe6cc;"><?= h($success) ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
    <div style="color:#dc2626;padding:10px 14px;background:#fdeaea;border-radius:8px;margin-bottom:14px;border:1px solid #fcd4d4;"><?= h($error) ?></div>
    <?php endif; ?>

    <div class="card">
        <h3>📋 已配置模型</h3>
        <div style="overflow-x:auto;">
            <table style="width:100%;border-collapse:collapse;font-size:13px;">
                <thead>
                    <tr style="border-bottom:2px solid #e5e7eb;">
                        <th style="text-align:left;padding:8px 10px;">名称</th>
                        <th style="text-align:left;padding:8px 10px;">API 地址</th>
                        <th style="text-align:left;padding:8px 10px;">模型</th>
                        <th style="text-align:center;padding:8px 10px;">默认</th>
                        <th style="text-align:center;padding:8px 10px;">操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($models as $m): ?>
                    <tr style="border-bottom:1px solid #f1f3f5;">
                        <td style="padding:8px 10px;font-weight:600;"><?= h($m['name']) ?></td>
                        <td style="padding:8px 10px;font-size:12px;color:#6b7280;max-width:200px;word-break:break-all;"><?= h($m['api_url']) ?></td>
                        <td style="padding:8px 10px;font-size:12px;color:#6b7280;"><?= h($m['model']) ?></td>
                        <td style="text-align:center;padding:8px 10px;">
                            <?php if ($m['is_default']): ?>
                            <span style="color:#16a34a;">⭐ 默认</span>
                            <?php else: ?>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="action" value="set_default">
                                <input type="hidden" name="model_id" value="<?= $m['id'] ?>">
                                <button type="submit" class="btn sm ghost" style="font-size:11px;">设为默认</button>
                            </form>
                            <?php endif; ?>
                        </td>
                        <td style="text-align:center;padding:8px 10px;">
                            <button class="btn sm ghost" onclick="editModel(<?= $m['id'] ?>)">✏️</button>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('确定要删除该模型吗？')">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="model_id" value="<?= $m['id'] ?>">
                                <button type="submit" class="btn sm" style="background:#dc2626;color:#fff;">🗑️</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div style="margin-top:12px;font-size:12px;color:#6b7280;">
            💡 提示：在「智慧学习」页面中，下拉菜单会显示所有已配置的模型
        </div>
    </div>

    <!-- 添加/编辑模型弹窗 -->
    <div id="modelModal" style="display:none;position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(0,0,0,0.5);z-index:2000;display:none;align-items:center;justify-content:center;padding:16px;">
        <div style="background:#fff;border-radius:12px;padding:28px 32px;max-width:520px;width:100%;max-height:90vh;overflow-y:auto;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
                <h3 style="margin:0;" id="modalTitle">➕ 添加模型</h3>
                <button onclick="closeModal()" style="background:none;border:none;font-size:24px;cursor:pointer;color:#9ca3af;">&times;</button>
            </div>
            <form method="POST" id="modelForm">
                <input type="hidden" name="action" value="save">
                <input type="hidden" name="model_id" id="editModelId" value="0">
                
                <div class="form-group">
                    <label>模型名称 *</label>
                    <input type="text" name="name" id="editName" required placeholder="如：Agnes 2.5 Flash">
                </div>
                <div class="form-group">
                    <label>API 地址 *</label>
                    <input type="url" name="api_url" id="editApiUrl" required placeholder="https://api.example.com/v1/chat/completions">
                </div>
                <div class="form-group">
                    <label>模型名称 *</label>
                    <input type="text" name="model" id="editModel" required placeholder="如：agnes-2.5-flash">
                </div>
                <div class="form-group">
                    <label>API Key</label>
                    <input type="password" name="api_key" id="editApiKey" placeholder="输入 API Key">
                    <div style="font-size:11px;color:#6b7280;margin-top:2px;">留空则保持原有值</div>
                </div>
                <div class="form-group">
                    <label>
                        <input type="checkbox" name="is_default" id="editIsDefault" value="1"> 设为默认模型
                    </label>
                </div>
                <div class="form-actions" style="margin-top:16px;padding-top:16px;border-top:1px solid #e5e7eb;">
                    <button type="submit" class="btn">💾 保存</button>
                    <button type="button" class="btn ghost" onclick="closeModal()">取消</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function showAddModel() {
    document.getElementById('modalTitle').textContent = '➕ 添加模型';
    document.getElementById('editModelId').value = '0';
    document.getElementById('editName').value = '';
    document.getElementById('editApiUrl').value = '';
    document.getElementById('editModel').value = '';
    document.getElementById('editApiKey').value = '';
    document.getElementById('editIsDefault').checked = false;
    document.getElementById('modelModal').style.display = 'flex';
}

function editModel(id) {
    // 获取模型数据
    fetch('api/ai_models.php?action=get&id=' + id)
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data.success) {
                document.getElementById('modalTitle').textContent = '✏️ 编辑模型';
                document.getElementById('editModelId').value = data.model.id;
                document.getElementById('editName').value = data.model.name;
                document.getElementById('editApiUrl').value = data.model.api_url;
                document.getElementById('editModel').value = data.model.model;
                document.getElementById('editApiKey').value = '';
                document.getElementById('editIsDefault').checked = data.model.is_default == 1;
                document.getElementById('modelModal').style.display = 'flex';
            } else {
                alert('❌ ' + (data.error || '获取模型信息失败'));
            }
        })
        .catch(function() {
            alert('❌ 网络错误');
        });
}

function closeModal() {
    document.getElementById('modelModal').style.display = 'none';
}

// 点击背景关闭弹窗
document.getElementById('modelModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});

// ESC 键关闭弹窗
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeModal();
});
</script>

<style>
body.dark-mode #modelModal > div {
    background: #1e293b;
    color: #e2e8f0;
}
body.dark-mode #modelModal .form-group label {
    color: #c8c0d8;
}
body.dark-mode #modelModal .form-group input {
    background: #0f172a;
    border-color: #334155;
    color: #e2e8f0;
}
body.dark-mode #modelModal .form-group input:focus {
    border-color: #2f6fed;
}
</style>