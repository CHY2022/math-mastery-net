<?php
// pages/help.php - 完整帮助页，整合所有核心特性
$adminEmail = getSetting('admin_email') ?: ADMIN_EMAIL;
$icpNumber = getSetting('icp_number') ?: ICP_NUMBER;
$siteName = getSetting('site_name') ?: SITE_NAME;
?>
<div>
    <h2 class="section">帮助中心</h2>

    <!-- ========== 项目简介 ========== -->
    <div class="help-section">
        <h3>📖 关于「融会贯通」互联版</h3>
        <p>「融会贯通」互联版是一个<b>基于<a href="https://github.com/kenowong/math-mastery" target="_blank">math-mastery</a>的开源项目</b>二次开发的中小学数学方法学习与练习应用。覆盖小学到高中核心解题技巧，<b>每轮练习随机出题、永不重样</b>，让每个学生都能充分掌握学习技巧。</p>
        <p style="color:#6b7280;font-size:12px;margin-top:4px;">🔄 参数化随机出题</p>
    </div>

    <!-- ========== 核心特性（完整版） ========== -->
    <div class="help-section" style="border-left:4px solid #2f6fed;">
        <h3>⚡ 核心特性</h3>

        <!-- 10个小学核心方法 -->
        <div style="margin:12px 0;">
            <h4 style="font-size:14px;color:#2f6fed;margin:6px 0 4px;">🧩 覆盖的 10 个小学核心方法</h4>
            <div style="display:flex;flex-wrap:wrap;gap:4px;font-size:13px;">
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">鸡兔同笼</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">植树问题</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">和差倍</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">盈亏</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">平均数</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">周期</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">归一</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">工程</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">相遇</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">追及</span>
            </div>
        </div>

        <!-- 15个初中核心方法 -->
        <div style="margin:12px 0;">
            <h4 style="font-size:14px;color:#16a34a;margin:6px 0 4px;">📐 覆盖的 15 个初中核心方法</h4>
            <div style="display:flex;flex-wrap:wrap;gap:4px;font-size:13px;">
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">有理数</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">整式</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">一元一次方程</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">不等式</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">方程组</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">线段角</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">三角形</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">全等</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">相似</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">勾股定理</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">四边形</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">圆</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">一次函数</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">反比例</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">二次函数</span>
            </div>
        </div>

        <!-- 24个高中核心方法 -->
        <div style="margin:12px 0;">
            <h4 style="font-size:14px;color:#7c3aed;margin:6px 0 4px;">📊 覆盖的 24 个高中核心方法</h4>
            <div style="display:flex;flex-wrap:wrap;gap:4px;font-size:13px;">
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">集合</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">函数概念</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">指数对数</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">三角函数</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">三角恒等变换</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">数列</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">数列求和</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">向量</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">立体几何</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">空间向量建系</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">空间角与距离</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">导数与单调性</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">导数与极值</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">导数与不等式</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">函数零点</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">圆锥曲线初步</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">联立与韦达定理</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">弦长与定点</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">圆锥曲线性质</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">参数方程</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">复数</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">分布列与期望</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">二项与正态分布</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">统计案例</span>
            </div>
        </div>

        <!-- 拓展专题 -->
        <div style="margin:12px 0;">
            <h4 style="font-size:14px;color:#d97706;margin:6px 0 4px;">🚀 拓展专题</h4>
            <div style="display:flex;flex-wrap:wrap;gap:4px;font-size:13px;">
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">欧拉公式</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">泰勒级数</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">数形结合</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">数学归纳法</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">均值不等式</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">二项式定理</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">容斥原理</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">递推数列</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">树状图法</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">排列组合</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">柯西不等式</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">线性规划</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">矩阵与行列式</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">洛必达法则</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">中值定理</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">贝叶斯与全概率</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">正态分布应用</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">定积分</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">微分方程</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">复数几何</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">数项级数</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">解析几何综合</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">琴生不等式</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">重要极限</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">棣莫弗定理</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">傅里叶级数</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">定积分应用</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">图像变换</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">不等式放缩</span>
                <span style="background:#f8fafc;padding:2px 10px;border-radius:4px;">数列不等式</span>
            </div>
            <p style="font-size:12px;color:#6b7280;margin-top:4px;">💡 更多专题持续扩展中</p>
        </div>

        <!-- 说明 -->
        <div style="margin:12px 0;padding:10px;background:#f8fafc;border-radius:6px;">
            <h4 style="font-size:14px;color:#1f2937;margin:0 0 4px 0;">📌 说明</h4>
            <p style="font-size:13px;color:#374151;margin:0;">
                每个方法配有 <b>名师口诀 + 解题步骤 + 分层题库（基础/进阶/易错）</b>。<br>
                支持 <b>参数化随机出题</b>，每轮练习题目不重样，做错的题自动进入薄弱点清单。<br>
                方法间按年级与依赖关系编排，形成可追踪的学习路径。
            </p>
        </div>

        <!-- 学习路径与薄弱点追踪 -->
        <div style="margin:12px 0;padding:10px;background:#eef3ff;border-radius:6px;border-left:3px solid #2f6fed;">
            <h4 style="font-size:14px;color:#2f6fed;margin:0 0 4px 0;">🗺️ 学习路径与薄弱点追踪</h4>
            <ul style="font-size:13px;color:#374151;margin:4px 0 0 16px;padding-left:0;">
                <li><strong>按阶段编排</strong>：小学 → 中学 → 高中，每个年级内的技巧按顺序解锁。</li>
                <li><strong>依赖关系</strong>：掌握前置技巧后，后续技巧自动解锁，形成递进式学习。</li>
                <li><strong>薄弱点自动记录</strong>：练习中的错题自动归入薄弱点，支持集中复习与清除。</li>
                <li><strong>通关测试</strong>：每个技巧有通关测试，需 ≥80% 正确率且薄弱点清零才算掌握。</li>
            </ul>
        </div>
    </div>

    <!-- ========== 角色说明 ========== -->
    <div class="help-section">
        <h3>👤 角色说明</h3>
        <ul>
            <li><strong>管理员</strong>：拥有全部权限，管理用户、网站设置、邮箱配置等。</li>
            <li><strong>家长</strong>：可以绑定并查看孩子的学习、练习、通关测试情况。</li>
            <li><strong>学生</strong>：可以学习、练习、通关测试，查看自己的学习进度。</li>
            <li><strong>学校/培训机构</strong>：可以查看下属学生的整体学习情况，按年级筛选。</li>
        </ul>
    </div>

    <!-- ========== 学习路径 ========== -->
    <div class="help-section">
        <h3>📚 学习路径</h3>
        <p>学习路径按 <strong>小学 → 中学 → 高中</strong> 排列，细分到年级。小学各年级、初一初二年级：年级内顺序解锁，掌握后才会解锁下一个技巧。初三及高中：所有技巧均可直接进入。</p>
    </div>

    <!-- ========== 练习与通关 ========== -->
    <div class="help-section">
        <h3>📝 练习与通关</h3>
        <ul>
            <li><strong>自由练习</strong>：随机出题，做错的题自动记入薄弱点。</li>
            <li><strong>通关测试</strong>：需 ≥80% 正确率且薄弱点清零才算通关。</li>
            <li><strong>薄弱点复习</strong>：集中攻克做错的题目，直到全部清除。</li>
        </ul>
        <p style="font-size:12px;color:#6b7280;margin-top:4px;">💡 每道题都配有分步解析和SVG配图，帮助理解解题思路 </p>
    </div>

    <!-- ========== 账号安全 ========== -->
    <div class="help-section">
        <h3>🔐 账号安全</h3>
        <ul>
            <li>注册需要通过邮箱验证码验证。</li>
            <li>可以通过邮箱找回密码。</li>
            <li>邮箱也可以作为用户名登录。</li>
        </ul>
    </div>

    <!-- ========== 主题切换 ========== -->
    <div class="help-section">
        <h3>🎨 自定义主题</h3>
        <p>在页面右上角可以切换主题颜色：默认蓝、清新绿、典雅紫、暖阳橙，或选择「自动」跟随系统主题（白天亮色/夜晚暗色）。</p>
    </div>

    <!-- ========== 技术支持 ========== -->
    <div class="help-section">
        <h3>📧 技术支持</h3>
        <p>如有问题，请联系管理员：<a href="mailto:<?= h($adminEmail) ?>"><?= h($adminEmail) ?></a></p>
        <?php if ($icpNumber): ?>
        <p>ICP备案号：<?= h($icpNumber) ?></p>
        <?php endif; ?>
        <p style="font-size:12px;color:#6b7280;">
            本程序基于<a href="mailto:kenowong@me.com" target="_blank">王维</a>开发的<a href="https://github.com/kenowong/math-mastery" target="_blank">math-mastery</a> 项目二次开发 · 
            <a href="https://gitee.com/kenowong/math-mastery" target="_blank">Gitee 镜像</a>
        </p>
        <p style="font-size:12px;color:#6b7280;margin-top:2px;">
            💡 项目扩展边界由生成器决定：新增知识点需单独实现生成逻辑，而非向题库追加题目 
        </p>
    </div>
</div>

<style>
/* 帮助页代码块和标签样式 */
.help-section pre {
    background: #1e293b;
    color: #e2e8f0;
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 12px;
    overflow-x: auto;
    margin: 4px 0;
}
.help-section code {
    background: #f1f3f5;
    padding: 1px 6px;
    border-radius: 4px;
    font-size: 12px;
    color: #d97706;
}
body.dark-mode .help-section code {
    background: #1a2332;
    color: #fbbf24;
}
.help-section .help-section {
    border-left: 4px solid #2f6fed;
}
</style>