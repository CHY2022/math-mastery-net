<?php
// pages/ai_chat.php - AI智慧学习页面
$user = getCurrentUser();
if (!$user) {
    header('Location: ?route=login');
    exit;
}

$pdo = getDB();

// 获取用户已保存的模型配置
$stmt = $pdo->prepare("SELECT * FROM user_ai_models WHERE user_id = ? ORDER BY is_default DESC, id ASC");
$stmt->execute([$user['id']]);
$userModels = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 如果没有配置，使用默认系统配置
if (empty($userModels)) {
    // 系统默认模型配置
    $defaultModels = [
        [
            'name' => 'Agnes 2.5 Flash',
            'api_url' => 'https://api.agnes-ai.cn/v1/chat/completions',
            'model' => 'agnes-2.5-flash',
            'api_key' => '',
            'is_default' => 1
        ],
        [
            'name' => 'Qwen 3.5 4B',
            'api_url' => 'https://api.siliconflow.cn/v1/chat/completions',
            'model' => 'Qwen/Qwen3.5-4B',
            'api_key' => '',
            'is_default' => 0
        ],
        [
            'name' => 'DeepSeek OCR',
            'api_url' => 'https://api.siliconflow.cn/v1/chat/completions',
            'model' => 'deepseek-ai/DeepSeek-OCR',
            'api_key' => '',
            'is_default' => 0
        ],
        [
            'name' => '腾讯混元 MT-7B',
            'api_url' => 'https://api.siliconflow.cn/v1/chat/completions',
            'model' => 'tencent/Hunyuan-MT-7B',
            'api_key' => '',
            'is_default' => 0
        ],
        [
            'name' => 'DeepSeek R1 0528 Qwen3 8B',
            'api_url' => 'https://api.siliconflow.cn/v1/chat/completions',
            'model' => 'deepseek-ai/DeepSeek-R1-0528-Qwen3-8B',
            'api_key' => '',
            'is_default' => 0
        ],
        [
            'name' => 'GLM Z1 9B 0414',
            'api_url' => 'https://api.siliconflow.cn/v1/chat/completions',
            'model' => 'THUDM/GLM-Z1-9B-0414',
            'api_key' => '',
            'is_default' => 0
        ],
        [
            'name' => 'GLM 4 9B 0414',
            'api_url' => 'https://api.siliconflow.cn/v1/chat/completions',
            'model' => 'THUDM/GLM-4-9B-0414',
            'api_key' => '',
            'is_default' => 0
        ],
        [
            'name' => 'Qwen 2.5 7B Instruct',
            'api_url' => 'https://api.siliconflow.cn/v1/chat/completions',
            'model' => 'Qwen/Qwen2.5-7B-Instruct',
            'api_key' => '',
            'is_default' => 0
        ],
        [
            'name' => 'DeepSeek V4 Flash 0731',
            'api_url' => 'https://developer.amd.com.cn/radeon/api/v1',
            'model' => 'DeepSeek-V4-Flash-0731',
            'api_key' => '',
            'is_default' => 0
        ],
        [
            'name' => 'MiniCPM5 1B',
            'api_url' => 'https://developer.amd.com.cn/radeon/api/v1',
            'model' => 'MiniCPM5-1B',
            'api_key' => '',
            'is_default' => 0
        ]
    ];
    $userModels = $defaultModels;
}
?>
<div>
    <style>
        .ai-chat-container {
            display: flex;
            flex-direction: column;
            height: calc(100vh - 180px);
            min-height: 500px;
            background: #fff;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
            overflow: hidden;
        }
        .ai-chat-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 20px;
            border-bottom: 1px solid #e5e7eb;
            background: #f8fafc;
            flex-wrap: wrap;
            gap: 8px;
        }
        .ai-chat-header .left {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .ai-chat-header .left .title {
            font-weight: 700;
            font-size: 16px;
            color: #1f2937;
        }
        .ai-chat-header .left .model-select {
            padding: 4px 10px;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            font-size: 13px;
            background: #fff;
            max-width: 200px;
        }
        .ai-chat-header .actions {
            display: flex;
            gap: 8px;
        }
        .ai-chat-header .actions button {
            padding: 4px 12px;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            cursor: pointer;
            transition: 0.2s;
        }
        .btn-new-chat { background: #2f6fed; color: #fff; }
        .btn-new-chat:hover { background: #1e4fb0; }
        .btn-clear-chat { background: #f1f3f5; color: #6b7280; }
        .btn-clear-chat:hover { background: #e5e7eb; }

        .ai-chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 16px 20px;
            background: #fafbfc;
        }
        .ai-chat-messages .message {
            display: flex;
            gap: 12px;
            margin-bottom: 16px;
            animation: fadeIn 0.3s ease;
        }
        .ai-chat-messages .message .avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            flex-shrink: 0;
        }
        .ai-chat-messages .message .avatar.user {
            background: #2f6fed;
            color: #fff;
        }
        .ai-chat-messages .message .avatar.assistant {
            background: #eef3ff;
            color: #2f6fed;
        }
        .ai-chat-messages .message .content {
            max-width: 80%;
            padding: 10px 14px;
            border-radius: 12px;
            font-size: 14px;
            line-height: 1.7;
            white-space: pre-wrap;
            word-break: break-word;
        }
        .ai-chat-messages .message.user .content {
            background: #2f6fed;
            color: #fff;
            border-bottom-right-radius: 4px;
        }
        .ai-chat-messages .message.assistant .content {
            background: #fff;
            color: #1f2937;
            border: 1px solid #e5e7eb;
            border-bottom-left-radius: 4px;
        }
        .ai-chat-messages .message .time {
            font-size: 11px;
            color: #9ca3af;
            margin-top: 4px;
        }
        .ai-chat-messages .message.assistant .time { text-align: left; }
        .ai-chat-messages .message.user .time { text-align: right; }
        .ai-chat-messages .typing {
            display: flex;
            gap: 4px;
            padding: 10px 14px;
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            border-bottom-left-radius: 4px;
            width: fit-content;
        }
        .ai-chat-messages .typing span {
            width: 8px;
            height: 8px;
            background: #9ca3af;
            border-radius: 50%;
            animation: typing 1.2s infinite ease-in-out;
        }
        .ai-chat-messages .typing span:nth-child(2) { animation-delay: 0.2s; }
        .ai-chat-messages .typing span:nth-child(3) { animation-delay: 0.4s; }
        @keyframes typing {
            0%, 60%, 100% { transform: translateY(0); opacity: 0.4; }
            30% { transform: translateY(-8px); opacity: 1; }
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .ai-chat-input {
            display: flex;
            gap: 10px;
            padding: 12px 20px;
            border-top: 1px solid #e5e7eb;
            background: #fff;
            align-items: flex-end;
        }
        .ai-chat-input textarea {
            flex: 1;
            padding: 10px 14px;
            border: 1px solid #d1d5db;
            border-radius: 10px;
            font-size: 14px;
            resize: none;
            min-height: 44px;
            max-height: 120px;
            font-family: inherit;
            transition: 0.2s;
            background: #fafbfc;
        }
        .ai-chat-input textarea:focus {
            border-color: #2f6fed;
            outline: none;
            box-shadow: 0 0 0 3px rgba(47,111,237,0.1);
            background: #fff;
        }
        .ai-chat-input .btn-send {
            padding: 10px 24px;
            border: none;
            border-radius: 10px;
            background: #2f6fed;
            color: #fff;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.2s;
            white-space: nowrap;
            height: 44px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .ai-chat-input .btn-send:hover { background: #1e4fb0; }
        .ai-chat-input .btn-send:disabled { opacity: 0.5; cursor: not-allowed; }

        .ai-chat-empty {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: #6b7280;
            text-align: center;
        }
        .ai-chat-empty .icon { font-size: 64px; margin-bottom: 12px; }
        .ai-chat-empty h3 { margin: 0 0 4px 0; color: #1f2937; }
        .ai-chat-empty p { margin: 0; font-size: 14px; }

        body.dark-mode .ai-chat-container {
            background: #1e293b;
            border-color: #334155;
        }
        body.dark-mode .ai-chat-header {
            background: #1a2332;
            border-color: #334155;
        }
        body.dark-mode .ai-chat-header .left .title { color: #e2e8f0; }
        body.dark-mode .ai-chat-header .left .model-select {
            background: #1a2332;
            border-color: #334155;
            color: #e2e8f0;
        }
        body.dark-mode .ai-chat-messages { background: #0f172a; }
        body.dark-mode .ai-chat-messages .message.assistant .content {
            background: #1e293b;
            color: #e2e8f0;
            border-color: #334155;
        }
        body.dark-mode .ai-chat-messages .message.user .content { background: #2f6fed; }
        body.dark-mode .ai-chat-messages .typing { background: #1e293b; border-color: #334155; }
        body.dark-mode .ai-chat-messages .typing span { background: #6b7280; }
        body.dark-mode .ai-chat-input {
            background: #1e293b;
            border-color: #334155;
        }
        body.dark-mode .ai-chat-input textarea {
            background: #0f172a;
            border-color: #334155;
            color: #e2e8f0;
        }
        body.dark-mode .ai-chat-input textarea:focus {
            border-color: #2f6fed;
            background: #1a2332;
        }
        body.dark-mode .btn-clear-chat {
            background: #334155;
            color: #e2e8f0;
        }
        body.dark-mode .btn-clear-chat:hover { background: #475569; }
        body.dark-mode .ai-chat-empty { color: #94a3b8; }
        body.dark-mode .ai-chat-empty h3 { color: #e2e8f0; }

        @media (max-width: 640px) {
            .ai-chat-container { height: calc(100vh - 140px); min-height: 400px; }
            .ai-chat-header { padding: 10px 14px; }
            .ai-chat-header .left .model-select { max-width: 140px; font-size: 12px; }
            .ai-chat-messages { padding: 12px 14px; }
            .ai-chat-messages .message .content { max-width: 90%; font-size: 13px; }
            .ai-chat-input { padding: 10px 14px; flex-wrap: wrap; }
            .ai-chat-input textarea { min-height: 36px; font-size: 13px; }
            .ai-chat-input .btn-send { padding: 8px 16px; height: 38px; font-size: 13px; }
        }
    </style>

    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <h2 class="section" style="margin:0;">🤖 智慧学习</h2>
        <a href="?route=ai_models" class="btn ghost sm">⚙️ 模型设置</a>
    </div>

    <div class="ai-chat-container">
        <!-- 头部 -->
        <div class="ai-chat-header">
            <div class="left">
                <span class="title">💬 连续对话</span>
                <select id="modelSelect" class="model-select">
                    <?php foreach ($userModels as $m): ?>
                    <option value="<?= h($m['id'] ?? '') ?>" <?= isset($m['is_default']) && $m['is_default'] ? 'selected' : '' ?>>
                        <?= h($m['name'] ?? $m['model'] ?? '未知模型') ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="actions">
                <button class="btn-new-chat" onclick="newChat()">➕ 新对话</button>
                <button class="btn-clear-chat" onclick="clearChat()">🗑️ 清空</button>
            </div>
        </div>

        <!-- 消息区域 -->
        <div class="ai-chat-messages" id="chatMessages">
            <div class="ai-chat-empty" id="emptyState">
                <div class="icon">🤖</div>
                <h3>开始智慧学习</h3>
                <p>选择下方模型，输入你的问题开始对话<br>支持数学题、编程、写作、知识问答等</p>
            </div>
        </div>

        <!-- 输入区域 -->
        <div class="ai-chat-input">
            <textarea id="chatInput" rows="1" placeholder="输入你的问题..." onkeydown="handleKeyDown(event)"></textarea>
            <button class="btn-send" id="sendBtn" onclick="sendMessage()">
                <span>📤</span> 发送
            </button>
        </div>
    </div>
</div>

<script>
// ============================================================
// AI 智慧学习 - 前端逻辑
// ============================================================
var chatHistory = [];
var isProcessing = false;
var currentConversationId = null;

// 从 localStorage 恢复对话
function loadChatHistory() {
    try {
        var saved = localStorage.getItem('ai_chat_history');
        if (saved) {
            var data = JSON.parse(saved);
            chatHistory = data.history || [];
            currentConversationId = data.conversationId || null;
            renderMessages();
        }
    } catch(e) {}
}

// 保存对话到 localStorage
function saveChatHistory() {
    try {
        localStorage.setItem('ai_chat_history', JSON.stringify({
            history: chatHistory,
            conversationId: currentConversationId
        }));
    } catch(e) {}
}

// 渲染消息
function renderMessages() {
    var container = document.getElementById('chatMessages');
    var emptyState = document.getElementById('emptyState');
    
    if (chatHistory.length === 0) {
        container.innerHTML = `
            <div class="ai-chat-empty" id="emptyState">
                <div class="icon">🤖</div>
                <h3>开始智慧学习</h3>
                <p>选择下方模型，输入你的问题开始对话<br>支持数学题、编程、写作、知识问答等</p>
            </div>
        `;
        return;
    }
    
    var html = '';
    chatHistory.forEach(function(msg, index) {
        var isUser = msg.role === 'user';
        var avatar = isUser ? '👤' : '🤖';
        var avatarClass = isUser ? 'user' : 'assistant';
        var time = msg.time || '';
        var content = msg.content || '';
        
        html += `
            <div class="message ${isUser ? 'user' : 'assistant'}">
                <div class="avatar ${avatarClass}">${avatar}</div>
                <div>
                    <div class="content">${escapeHtml(content)}</div>
                    ${time ? '<div class="time">' + time + '</div>' : ''}
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
    container.scrollTop = container.scrollHeight;
}

function escapeHtml(text) {
    var div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// 添加消息
function addMessage(role, content) {
    var now = new Date();
    var timeStr = now.getHours().toString().padStart(2, '0') + ':' + 
                  now.getMinutes().toString().padStart(2, '0');
    
    chatHistory.push({
        role: role,
        content: content,
        time: timeStr
    });
    
    renderMessages();
    saveChatHistory();
}

// 显示打字动画
function showTyping() {
    var container = document.getElementById('chatMessages');
    var typingEl = document.createElement('div');
    typingEl.className = 'message assistant';
    typingEl.id = 'typingIndicator';
    typingEl.innerHTML = `
        <div class="avatar assistant">🤖</div>
        <div class="typing">
            <span></span><span></span><span></span>
        </div>
    `;
    container.appendChild(typingEl);
    container.scrollTop = container.scrollHeight;
}

// 移除打字动画
function removeTyping() {
    var el = document.getElementById('typingIndicator');
    if (el) el.remove();
}

// 发送消息
function sendMessage() {
    var input = document.getElementById('chatInput');
    var text = input.value.trim();
    if (!text || isProcessing) return;
    
    // 清空输入
    input.value = '';
    input.style.height = 'auto';
    
    // 添加用户消息
    addMessage('user', text);
    
    // 获取选中的模型
    var modelSelect = document.getElementById('modelSelect');
    var modelId = modelSelect.value;
    var modelName = modelSelect.options[modelSelect.selectedIndex].text;
    
    // 显示打字动画
    showTyping();
    isProcessing = true;
    document.getElementById('sendBtn').disabled = true;
    
    // 构建消息历史（最近10轮）
    var messages = [];
    var startIdx = Math.max(0, chatHistory.length - 20);
    for (var i = startIdx; i < chatHistory.length; i++) {
        messages.push({
            role: chatHistory[i].role,
            content: chatHistory[i].content
        });
    }
    
    // 调用API
    fetch('api/ai_chat.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            action: 'chat',
            model_id: modelId,
            messages: messages
        })
    })
    .then(function(res) { return res.json(); })
    .then(function(result) {
        removeTyping();
        isProcessing = false;
        document.getElementById('sendBtn').disabled = false;
        
        if (result.success) {
            addMessage('assistant', result.response);
        } else {
            addMessage('assistant', '❌ ' + (result.error || '请求失败，请检查模型配置'));
        }
    })
    .catch(function(err) {
        removeTyping();
        isProcessing = false;
        document.getElementById('sendBtn').disabled = false;
        addMessage('assistant', '❌ 网络错误: ' + err.message);
    });
}

// 键盘事件
function handleKeyDown(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendMessage();
    }
    // 自动调整高度
    var el = event.target;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 120) + 'px';
}

// 新对话
function newChat() {
    if (chatHistory.length > 0 && !confirm('确定要开始新对话吗？当前对话将被清除。')) return;
    chatHistory = [];
    currentConversationId = null;
    renderMessages();
    saveChatHistory();
    document.getElementById('chatInput').focus();
}

// 清空对话
function clearChat() {
    if (chatHistory.length === 0) return;
    if (!confirm('确定要清空所有对话吗？')) return;
    chatHistory = [];
    currentConversationId = null;
    renderMessages();
    saveChatHistory();
    document.getElementById('chatInput').focus();
}

// 页面加载时初始化
document.addEventListener('DOMContentLoaded', function() {
    loadChatHistory();
    document.getElementById('chatInput').focus();
});

// 自动调整输入框高度
document.getElementById('chatInput').addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = Math.min(this.scrollHeight, 120) + 'px';
});
</script>