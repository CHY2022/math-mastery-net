<?php
// pages/student_selector.php - 学生选择器（供AJAX调用）
// 修复：添加必要的依赖加载

// 获取当前脚本的目录
$baseDir = dirname(__DIR__);
require_once $baseDir . '/config/database.php';
require_once $baseDir . '/includes/functions.php';
require_once $baseDir . '/includes/auth.php';

// 设置 JSON 响应头
header('Content-Type: application/json');

$user = getCurrentUser();
if (!$user) {
    echo json_encode(['success' => false, 'error' => '未登录']);
    exit;
}

// 只有学校或培训机构可以查看学生列表
if ($user['role'] !== 'school' && $user['role'] !== 'training') {
    echo json_encode(['success' => false, 'error' => '权限不足']);
    exit;
}

$pdo = getDB();
$role = $user['role'];
$orgName = $user['org_name'] ?? '';

// 获取筛选参数
$grade = isset($_GET['grade']) ? trim($_GET['grade']) : '';
$school = isset($_GET['school']) ? trim($_GET['school']) : '';
$keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';

// 构建查询
$sql = "SELECT id, username, name, grade, school, training FROM users WHERE role = 'student' AND status = 'active'";
$params = [];

if ($role === 'school') {
    $schoolName = $user['org_name'] ?? $user['school'] ?? '';
    if ($schoolName) {
        $sql .= " AND school = ?";
        $params[] = $schoolName;
    }
    if ($grade) {
        $sql .= " AND grade = ?";
        $params[] = $grade;
    }
}

if ($role === 'training') {
    $trainingName = $user['org_name'] ?? $user['training'] ?? '';
    if ($trainingName) {
        $sql .= " AND training = ?";
        $params[] = $trainingName;
    }
    if ($grade) {
        $sql .= " AND grade = ?";
        $params[] = $grade;
    }
    if ($school) {
        $sql .= " AND school = ?";
        $params[] = $school;
    }
}

if ($keyword) {
    $sql .= " AND (name LIKE ? OR username LIKE ?)";
    $params[] = '%' . $keyword . '%';
    $params[] = '%' . $keyword . '%';
}

$sql .= " ORDER BY grade, name";

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 获取年级列表
    $gradeSql = "SELECT DISTINCT grade FROM users WHERE role = 'student' AND status = 'active'";
    $gradeParams = [];
    if ($role === 'school') {
        $schoolName = $user['org_name'] ?? $user['school'] ?? '';
        if ($schoolName) {
            $gradeSql .= " AND school = ?";
            $gradeParams[] = $schoolName;
        }
    }
    if ($role === 'training') {
        $trainingName = $user['org_name'] ?? $user['training'] ?? '';
        if ($trainingName) {
            $gradeSql .= " AND training = ?";
            $gradeParams[] = $trainingName;
        }
    }
    $gradeStmt = $pdo->prepare($gradeSql);
    $gradeStmt->execute($gradeParams);
    $grades = $gradeStmt->fetchAll(PDO::FETCH_COLUMN);

    // 如果是培训机构，获取学校列表
    $schools = [];
    if ($role === 'training') {
        $trainingName = $user['org_name'] ?? $user['training'] ?? '';
        if ($trainingName) {
            $schoolSql = "SELECT DISTINCT school FROM users WHERE role = 'student' AND status = 'active' AND training = ? AND school IS NOT NULL AND school != ''";
            $schoolStmt = $pdo->prepare($schoolSql);
            $schoolStmt->execute([$trainingName]);
            $schools = $schoolStmt->fetchAll(PDO::FETCH_COLUMN);
        }
    }

    // 获取每个学生的薄弱点数量
    foreach ($students as &$s) {
        $stmt2 = $pdo->prepare("SELECT COUNT(*) FROM weak_points WHERE user_id = ? AND cleared = FALSE");
        $stmt2->execute([$s['id']]);
        $s['weak_count'] = (int)$stmt2->fetchColumn();
    }

    echo json_encode([
        'success' => true,
        'students' => $students,
        'grades' => $grades,
        'schools' => $schools,
        'role' => $role
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}