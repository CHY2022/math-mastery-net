<?php
// pages/forgot.php - 找回密码页面（美化版，12时段背景+天气+月相）
$step = $_GET['step'] ?? 'request';
$error = '';
$success = '';

// 获取当前时段、天气、月相
$currentSlot = getCurrentTimeSlot();
$weather = getUserWeather();
$lunar = getLunarDate();

$bgClass = $currentSlot['bgClass'];
$timeLabel = $currentSlot['label'];
$weatherIcon = $weather['icon'] ?? '🌤';
$weatherTemp = $weather['temp'] ?? '--';
$weatherCondition = $weather['condition'] ?? '--';
$weatherLocation = $weather['location'] ?? '--';
$moonPhase = $lunar['phase'];
$moonEmoji = $lunar['phase_emoji'];
$moonIcon = $lunar['phase_icon'];
$moonDesc = $lunar['phase_desc'];
$moonSVG = getMoonPhaseSVG($moonIcon);

$siteName = getSetting('site_name') ?: '融会贯通';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'request') {
        $email = trim($_POST['email'] ?? '');
        if (empty($email)) {
            $error = '请输入邮箱地址';
        } else {
            $pdo = getDB();
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetchColumn() == 0) {
                $error = '该邮箱未注册';
            } else {
                $code = generateCode();
                sendVerificationEmail($email, $code, 'reset');
                $_SESSION['reset_email'] = $email;
                $success = '✅ 验证码已发送，请查收邮箱';
                echo '<script>setTimeout(function(){ window.location.href="?route=reset"; }, 2000);</script>';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
    <title>找回密码 · <?= h($siteName) ?></title>
    <link rel="stylesheet" href="css/styles.css" />
    <style>
    /* ============================================================
       找回密码页面 - 12时段昼夜自适应背景
       ============================================================ */
    .forgot-container {
        position: relative;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        margin: 0;
        transition: background 1.5s ease;
        overflow: hidden;
    }

    .forgot-bg {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 0;
        transition: opacity 2s ease;
    }

    /* 黎明背景 */
    .bg-dawn {
        background: linear-gradient(170deg, #2b1a3a 0%, #6b3a6b 20%, #c77d5a 50%, #f5c882 75%, #fce8b0 100%);
    }
    .bg-dawn .dawn-sun {
        position: absolute;
        bottom: 25%;
        left: 15%;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: radial-gradient(circle, #ffeaa7 0%, #fdcb6e 40%, #f6b026 70%, transparent 100%);
        box-shadow: 0 0 80px rgba(253, 203, 110, 0.3);
        animation: sunRise 8s ease-in-out infinite;
    }
    .bg-dawn .dawn-cloud {
        position: absolute;
        background: rgba(255, 200, 180, 0.3);
        border-radius: 50px;
        animation: cloudFloat 25s linear infinite;
    }
    .bg-dawn .dawn-cloud1 { width: 120px; height: 35px; top: 15%; left: 5%; }
    .bg-dawn .dawn-cloud2 { width: 80px; height: 28px; top: 25%; right: 15%; animation-duration: 20s; }

    /* 中午背景 */
    .bg-noon {
        background: linear-gradient(170deg, #1a8a8a 0%, #4ac0c0 30%, #ffd93d 70%, #f6b026 100%);
    }
    .bg-noon .noon-sun {
        position: absolute;
        top: 8%;
        right: 20%;
        width: 90px;
        height: 90px;
        border-radius: 50%;
        background: radial-gradient(circle, #fff7a0 0%, #ffd93d 40%, #f6b026 70%, transparent 100%);
        box-shadow: 0 0 120px rgba(255, 217, 61, 0.6), 0 0 200px rgba(255, 217, 61, 0.2);
        animation: sunPulse 3s ease-in-out infinite;
    }

    /* 午后背景 */
    .bg-afternoon {
        background: linear-gradient(170deg, #4facfe 0%, #7ec8e3 30%, #f5c882 60%, #fce8b0 85%);
    }
    .bg-afternoon .afternoon-sun {
        position: absolute;
        top: 15%;
        right: 10%;
        width: 70px;
        height: 70px;
        border-radius: 50%;
        background: radial-gradient(circle, #ffeaa7 0%, #fdcb6e 50%, #f6b026 80%, transparent 100%);
        box-shadow: 0 0 100px rgba(253, 203, 110, 0.4);
        animation: sunPulse 4s ease-in-out infinite;
    }
    .bg-afternoon .tree-afternoon {
        position: absolute;
        bottom: 5%;
        font-size: 50px;
        opacity: 0.25;
    }
    .bg-afternoon .tree-afternoon1 { left: 5%; }
    .bg-afternoon .tree-afternoon2 { right: 8%; font-size: 60px; }

    /* 黄昏背景（傍晚） */
    .bg-dusk {
        background: linear-gradient(170deg, #2d1b69 0%, #5a2d7a 20%, #c77d5a 50%, #f5c882 75%, #fce8b0 95%);
    }
    .bg-dusk .dusk-moon {
        position: absolute;
        top: 10%;
        right: 15%;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: radial-gradient(circle at 35% 35%, #f5f0d7 0%, #e8dca8 60%, #d4c48a 100%);
        box-shadow: 0 0 60px rgba(232, 220, 168, 0.2);
    }
    .bg-dusk .dusk-stars {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        pointer-events: none;
    }
    .bg-dusk .dusk-star {
        position: absolute;
        border-radius: 50%;
        background: #fff;
        animation: starTwinkle var(--duration) ease-in-out infinite;
    }
    .bg-dusk .dusk-star1 { width: 2px; height: 2px; top: 5%; left: 10%; --duration: 3s; }
    .bg-dusk .dusk-star2 { width: 2.5px; height: 2.5px; top: 8%; left: 30%; --duration: 2.5s; }
    .bg-dusk .dusk-star3 { width: 1.5px; height: 1.5px; top: 3%; left: 55%; --duration: 4s; }
    .bg-dusk .dusk-star4 { width: 2px; height: 2px; top: 12%; left: 75%; --duration: 3.5s; }
    .bg-dusk .dusk-star5 { width: 2.5px; height: 2.5px; top: 6%; left: 88%; --duration: 2.8s; }

    /* 日间背景 */
    .bg-day {
        background: linear-gradient(170deg, #4facfe 0%, #00f2fe 100%);
    }
    .bg-day::before {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 45%;
        background: linear-gradient(0deg, #2d8a4e 0%, #4caf50 30%, transparent 100%);
        border-radius: 0 0 50% 50% / 0 0 30% 30%;
    }
    .bg-day .sun {
        position: absolute;
        top: 12%;
        right: 15%;
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: radial-gradient(circle, #fff7a0 0%, #ffd93d 40%, #f6b026 70%, transparent 100%);
        box-shadow: 0 0 80px rgba(255, 217, 61, 0.6), 0 0 160px rgba(255, 217, 61, 0.3);
        animation: sunPulse 4s ease-in-out infinite;
    }
    .bg-day .cloud {
        position: absolute;
        background: rgba(255, 255, 255, 0.7);
        border-radius: 50px;
        animation: cloudFloat 20s linear infinite;
    }
    .bg-day .cloud1 { width: 120px; height: 40px; top: 8%; left: 5%; animation-duration: 25s; }
    .bg-day .cloud2 { width: 80px; height: 30px; top: 18%; left: 60%; animation-duration: 18s; animation-delay: -5s; }
    .bg-day .cloud3 { width: 100px; height: 35px; top: 5%; left: 35%; animation-duration: 22s; animation-delay: -10s; }
    .bg-day .tree {
        position: absolute;
        bottom: 8%;
        font-size: 60px;
        opacity: 0.6;
        filter: drop-shadow(0 4px 20px rgba(0,0,0,0.1));
    }
    .bg-day .tree1 { left: 5%; font-size: 50px; }
    .bg-day .tree2 { left: 18%; font-size: 70px; opacity: 0.5; }
    .bg-day .tree3 { right: 8%; font-size: 55px; }
    .bg-day .tree4 { right: 22%; font-size: 65px; opacity: 0.5; }
    .bg-day .grass {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 60px;
        background: linear-gradient(0deg, #2d8a4e 0%, #4caf50 60%, transparent 100%);
        border-radius: 0 0 50% 50% / 0 0 100% 100%;
    }

    /* 夜间背景 */
    .bg-night {
        background: linear-gradient(180deg, #0a0e27 0%, #1a1a3e 40%, #2d1b4e 70%, #1a0a2e 100%);
    }
    .bg-night .moon {
        position: absolute;
        top: 10%;
        right: 18%;
        width: 70px;
        height: 70px;
        border-radius: 50%;
        background: radial-gradient(circle at 35% 35%, #f5f0d7 0%, #e8dca8 40%, #d4c48a 70%, #b8a870 100%);
        box-shadow: 0 0 60px rgba(232, 220, 168, 0.3), 0 0 120px rgba(232, 220, 168, 0.1);
        animation: moonGlow 6s ease-in-out infinite;
    }
    .bg-night .moon::after {
        content: '';
        position: absolute;
        top: 12px;
        left: 20px;
        width: 18px;
        height: 18px;
        border-radius: 50%;
        background: rgba(180, 160, 100, 0.3);
        box-shadow: 30px 15px 0 4px rgba(180, 160, 100, 0.2), 10px 35px 0 6px rgba(180, 160, 100, 0.15);
    }
    .bg-night .stars {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        pointer-events: none;
    }
    .bg-night .star {
        position: absolute;
        border-radius: 50%;
        background: #fff;
        animation: starTwinkle var(--duration) ease-in-out infinite;
    }
    .bg-night .star1 { width: 2px; height: 2px; top: 5%; left: 10%; --duration: 3s; }
    .bg-night .star2 { width: 3px; height: 3px; top: 8%; left: 25%; --duration: 2.5s; }
    .bg-night .star3 { width: 1.5px; height: 1.5px; top: 3%; left: 45%; --duration: 4s; }
    .bg-night .star4 { width: 2.5px; height: 2.5px; top: 12%; left: 60%; --duration: 3.5s; }
    .bg-night .star5 { width: 2px; height: 2px; top: 6%; left: 78%; --duration: 2.8s; }
    .bg-night .star6 { width: 3px; height: 3px; top: 15%; left: 85%; --duration: 3.2s; }
    .bg-night .star7 { width: 1.5px; height: 1.5px; top: 20%; left: 5%; --duration: 4.5s; }
    .bg-night .star8 { width: 2px; height: 2px; top: 18%; left: 50%; --duration: 2.2s; }
    .bg-night .star9 { width: 3px; height: 3px; top: 25%; left: 70%; --duration: 3.8s; }
    .bg-night .star10 { width: 2px; height: 2px; top: 30%; left: 15%; --duration: 3s; }
    .bg-night .tree-night {
        position: absolute;
        bottom: 0;
        font-size: 50px;
        opacity: 0.2;
        filter: drop-shadow(0 0 20px rgba(100, 80, 200, 0.2));
    }
    .bg-night .tree-night1 { left: 3%; font-size: 45px; }
    .bg-night .tree-night2 { right: 5%; font-size: 55px; }
    .bg-night .ground-night {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 30px;
        background: linear-gradient(0deg, #0a0a1a 0%, transparent 100%);
    }

    /* 早晨背景 */
    .bg-morning {
        background: linear-gradient(170deg, #fddb92 0%, #d1fdff 100%);
    }
    .bg-morning .morning-sun {
        position: absolute;
        bottom: 30%;
        left: 15%;
        width: 70px;
        height: 70px;
        border-radius: 50%;
        background: radial-gradient(circle, #fff7a0 0%, #ffd93d 50%, #f6b026 80%, transparent 100%);
        box-shadow: 0 0 80px rgba(255, 217, 61, 0.4);
        animation: sunRise 8s ease-in-out infinite;
    }
    .bg-morning .morning-dew {
        position: absolute;
        bottom: 5%;
        left: 0;
        right: 0;
        height: 80px;
        background: linear-gradient(0deg, rgba(76, 175, 80, 0.3) 0%, transparent 100%);
        border-radius: 0 0 50% 50% / 0 0 40% 40%;
    }
    .bg-morning .tree-morning {
        position: absolute;
        bottom: 10%;
        font-size: 50px;
        opacity: 0.3;
        filter: drop-shadow(0 4px 20px rgba(0,0,0,0.05));
    }
    .bg-morning .tree-morning1 { left: 8%; }
    .bg-morning .tree-morning2 { right: 10%; font-size: 60px; opacity: 0.25; }

    /* 黄昏背景（日落） */
    .bg-sunset {
        background: linear-gradient(170deg, #ff6b35 0%, #f7931e 30%, #ffd93d 55%, #4facfe 85%);
    }
    .bg-sunset .sunset-sun {
        position: absolute;
        bottom: 25%;
        left: 50%;
        transform: translateX(-50%);
        width: 100px;
        height: 100px;
        border-radius: 50%;
        background: radial-gradient(circle, #ff6b35 0%, #ff4500 50%, transparent 100%);
        box-shadow: 0 0 120px rgba(255, 69, 0, 0.4), 0 0 200px rgba(255, 69, 0, 0.2);
        animation: sunsetGlow 3s ease-in-out infinite;
    }
    .bg-sunset .cloud-sunset {
        position: absolute;
        background: rgba(255, 200, 150, 0.5);
        border-radius: 50px;
        animation: cloudFloat 25s linear infinite;
    }
    .bg-sunset .cloud-sunset1 { width: 150px; height: 45px; top: 10%; left: 5%; }
    .bg-sunset .cloud-sunset2 { width: 100px; height: 35px; top: 20%; right: 10%; animation-duration: 20s; }
    .bg-sunset .cloud-sunset3 { width: 120px; height: 40px; top: 5%; left: 40%; animation-duration: 22s; animation-delay: -8s; }

    /* ---------- 动画 ---------- */
    @keyframes sunPulse {
        0%, 100% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.05); opacity: 0.9; }
    }
    @keyframes sunRise {
        0%, 100% { transform: translateY(0) scale(1); opacity: 0.7; }
        50% { transform: translateY(-20px) scale(1.08); opacity: 1; }
    }
    @keyframes moonGlow {
        0%, 100% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.03); opacity: 0.9; }
    }
    @keyframes sunsetGlow {
        0%, 100% { transform: translateX(-50%) scale(1); opacity: 1; }
        50% { transform: translateX(-50%) scale(1.05); opacity: 0.85; }
    }
    @keyframes starTwinkle {
        0%, 100% { opacity: 0.2; transform: scale(1); }
        50% { opacity: 1; transform: scale(1.3); }
    }
    @keyframes cloudFloat {
        0% { transform: translateX(-100px); opacity: 0; }
        10% { opacity: 1; }
        90% { opacity: 1; }
        100% { transform: translateX(calc(100vw + 100px)); opacity: 0; }
    }

    /* ---------- 找回密码卡片 ---------- */
    .forgot-card {
        position: relative;
        z-index: 1;
        width: 100%;
        max-width: 440px;
        padding: 40px 36px;
        background: rgba(255, 255, 255, 0.92);
        backdrop-filter: blur(20px);
        -webkit-backdrop-filter: blur(20px);
        border-radius: 20px;
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15), 0 0 0 1px rgba(255, 255, 255, 0.1);
        transition: background 0.8s ease, box-shadow 0.8s ease;
        text-align: center;
    }

    body.night-mode .forgot-card {
        background: rgba(20, 20, 50, 0.88);
        box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.05);
    }
    body.night-mode .forgot-card .forgot-brand h1 { color: #e8e0c8; }
    body.night-mode .forgot-card .forgot-brand p { color: #9a8ab0; }
    body.night-mode .forgot-card .form-group label { color: #c8c0d8; }
    body.night-mode .forgot-card .form-group input {
        background: rgba(255, 255, 255, 0.08);
        border-color: rgba(255, 255, 255, 0.1);
        color: #e8e0d0;
    }
    body.night-mode .forgot-card .form-group input::placeholder { color: #6a6a8a; }
    body.night-mode .forgot-card .forgot-footer { color: #a8a0b8; }
    body.night-mode .forgot-card .forgot-footer a { color: #7a8af0; }
    body.night-mode .forgot-card .forgot-error {
        background: rgba(220, 38, 38, 0.2);
        color: #f87171;
        border-color: rgba(220, 38, 38, 0.2);
    }
    body.night-mode .forgot-card .forgot-success {
        background: rgba(22, 163, 74, 0.2);
        color: #4ade80;
        border-color: rgba(22, 163, 74, 0.2);
    }

    .forgot-brand { margin-bottom: 28px; }
    .forgot-brand .icon {
        font-size: 56px;
        display: block;
        margin-bottom: 8px;
    }
    .forgot-brand h1 {
        font-size: 22px;
        margin: 0 0 4px 0;
        color: #1f2937;
        font-weight: 700;
    }
    .forgot-brand p {
        font-size: 14px;
        color: #6b7280;
        margin: 0;
        line-height: 1.6;
    }

    .forgot-form .form-group { margin-bottom: 18px; text-align: left; }
    .forgot-form .form-group label {
        display: block;
        font-size: 13px;
        font-weight: 600;
        color: #374151;
        margin-bottom: 4px;
    }
    .forgot-form .form-group input {
        width: 100%;
        padding: 10px 14px;
        border: 1px solid #d1d5db;
        border-radius: 10px;
        font-size: 15px;
        transition: 0.25s;
        background: #fff;
        color: #1f2937;
        box-sizing: border-box;
    }
    .forgot-form .form-group input:focus {
        border-color: #2f6fed;
        outline: none;
        box-shadow: 0 0 0 3px rgba(47, 111, 237, 0.12);
    }

    .forgot-btn {
        width: 100%;
        padding: 12px;
        border: none;
        border-radius: 10px;
        font-size: 16px;
        font-weight: 700;
        color: #fff;
        background: linear-gradient(135deg, #2f6fed, #1e4fb0);
        cursor: pointer;
        transition: 0.25s;
        margin-top: 4px;
    }
    .forgot-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(47, 111, 237, 0.35);
    }
    .forgot-btn:active { transform: translateY(0); }

    .forgot-error {
        padding: 10px 14px;
        background: #fdeaea;
        color: #dc2626;
        border-radius: 10px;
        margin-bottom: 16px;
        border: 1px solid #fcd4d4;
        font-size: 14px;
        text-align: left;
    }
    .forgot-success {
        padding: 10px 14px;
        background: #e7f6ee;
        color: #16a34a;
        border-radius: 10px;
        margin-bottom: 16px;
        border: 1px solid #bfe6cc;
        font-size: 14px;
        text-align: left;
    }

    .forgot-footer {
        text-align: center;
        margin-top: 20px;
        font-size: 14px;
        color: #6b7280;
    }
    .forgot-footer a {
        color: #2f6fed;
        text-decoration: none;
        font-weight: 600;
    }
    .forgot-footer a:hover { text-decoration: underline; }

    /* 状态栏 */
    .status-bar {
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 2;
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 8px 22px;
        border-radius: 30px;
        font-size: 13px;
        color: rgba(255, 255, 255, 0.9);
        background: rgba(0, 0, 0, 0.35);
        backdrop-filter: blur(10px);
        -webkit-backdrop-filter: blur(10px);
        font-weight: 500;
        letter-spacing: 0.3px;
        pointer-events: none;
        transition: opacity 0.8s ease;
        flex-wrap: wrap;
        justify-content: center;
    }
    body.night-mode .status-bar {
        background: rgba(0, 0, 0, 0.5);
        color: rgba(255, 255, 255, 0.8);
    }
    .status-bar .separator {
        opacity: 0.25;
        font-size: 10px;
    }
    .status-bar .weather-info {
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .status-bar .weather-info .temp { font-weight: 600; }
    .status-bar .moon-display {
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .status-bar .moon-display .moon-icon {
        width: 28px;
        height: 28px;
        display: inline-block;
        flex-shrink: 0;
    }
    .status-bar .moon-display .moon-icon svg {
        width: 100%;
        height: 100%;
    }
    .status-bar .moon-display .moon-name {
        font-size: 12px;
        opacity: 0.85;
        white-space: nowrap;
    }
    .status-bar .moon-display .moon-detail {
        font-size: 10px;
        opacity: 0.55;
        display: none;
    }

    @media (max-width: 480px) {
        .forgot-card { padding: 28px 20px; margin: 10px; border-radius: 16px; }
        .forgot-brand .icon { font-size: 42px; }
        .forgot-brand h1 { font-size: 18px; }
        .status-bar { font-size: 11px; padding: 5px 14px; bottom: 12px; gap: 8px; }
        .status-bar .moon-display .moon-icon { width: 20px; height: 20px; }
        .status-bar .moon-display .moon-name { font-size: 10px; }
        .status-bar .separator { display: none; }
        .bg-day .sun { width: 50px; height: 50px; top: 8%; right: 10%; }
        .bg-night .moon { width: 45px; height: 45px; top: 6%; right: 12%; }
        .bg-sunset .sunset-sun { width: 60px; height: 60px; bottom: 30%; }
        .bg-morning .morning-sun { width: 45px; height: 45px; bottom: 35%; left: 10%; }
        .bg-day .tree, .bg-night .tree-night, .bg-morning .tree-morning { font-size: 30px !important; }
        .bg-afternoon .tree-afternoon { font-size: 30px !important; }
    }
    @media (min-width: 481px) and (max-width: 768px) {
        .forgot-card { padding: 32px 24px; }
        .status-bar .moon-display .moon-detail { display: none; }
    }
    @media (min-width: 769px) {
        .status-bar .moon-display .moon-detail { display: inline; }
    }
    </style>
</head>
<body>
    <div class="forgot-container">
        <!-- 动态背景层 -->
        <div class="forgot-bg <?= $bgClass ?>" id="forgotBg">
            <?php if ($bgClass === 'bg-day'): ?>
            <div class="sun"></div>
            <div class="cloud cloud1"></div>
            <div class="cloud cloud2"></div>
            <div class="cloud cloud3"></div>
            <div class="tree tree1">🌳</div>
            <div class="tree tree2">🌲</div>
            <div class="tree tree3">🌳</div>
            <div class="tree tree4">🌲</div>
            <div class="grass"></div>
            <?php elseif ($bgClass === 'bg-night'): ?>
            <div class="moon"></div>
            <div class="stars">
                <div class="star star1"></div>
                <div class="star star2"></div>
                <div class="star star3"></div>
                <div class="star star4"></div>
                <div class="star star5"></div>
                <div class="star star6"></div>
                <div class="star star7"></div>
                <div class="star star8"></div>
                <div class="star star9"></div>
                <div class="star star10"></div>
            </div>
            <div class="tree-night tree-night1">🌲</div>
            <div class="tree-night tree-night2">🌲</div>
            <div class="ground-night"></div>
            <?php elseif ($bgClass === 'bg-sunset'): ?>
            <div class="sunset-sun"></div>
            <div class="cloud-sunset cloud-sunset1"></div>
            <div class="cloud-sunset cloud-sunset2"></div>
            <div class="cloud-sunset cloud-sunset3"></div>
            <?php elseif ($bgClass === 'bg-morning'): ?>
            <div class="morning-sun"></div>
            <div class="morning-dew"></div>
            <div class="tree-morning tree-morning1">🌳</div>
            <div class="tree-morning tree-morning2">🌲</div>
            <?php elseif ($bgClass === 'bg-dawn'): ?>
            <div class="dawn-sun"></div>
            <div class="dawn-cloud dawn-cloud1"></div>
            <div class="dawn-cloud dawn-cloud2"></div>
            <?php elseif ($bgClass === 'bg-noon'): ?>
            <div class="noon-sun"></div>
            <?php elseif ($bgClass === 'bg-afternoon'): ?>
            <div class="afternoon-sun"></div>
            <div class="tree-afternoon tree-afternoon1">🌳</div>
            <div class="tree-afternoon tree-afternoon2">🌳</div>
            <?php elseif ($bgClass === 'bg-dusk'): ?>
            <div class="dusk-moon"></div>
            <div class="dusk-stars">
                <div class="dusk-star dusk-star1"></div>
                <div class="dusk-star dusk-star2"></div>
                <div class="dusk-star dusk-star3"></div>
                <div class="dusk-star dusk-star4"></div>
                <div class="dusk-star dusk-star5"></div>
            </div>
            <?php endif; ?>
        </div>

        <div class="forgot-card">
            <div class="forgot-brand">
                <span class="icon">🔑</span>
                <h1>找回密码</h1>
                <p>输入您注册时使用的邮箱，<br>我们将发送重置密码的验证码。</p>
            </div>

            <?php if ($error): ?>
            <div class="forgot-error"><?= h($error) ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
            <div class="forgot-success"><?= h($success) ?></div>
            <?php endif; ?>

            <form method="POST" class="forgot-form">
                <input type="hidden" name="action" value="request">
                <div class="form-group">
                    <label>📧 注册邮箱</label>
                    <input type="email" name="email" required placeholder="请输入注册邮箱" autofocus>
                </div>
                <button type="submit" class="forgot-btn">📤 发送验证码</button>
            </form>

            <div class="forgot-footer">
                <a href="?route=login">← 返回登录</a>
            </div>
        </div>

        <!-- 状态栏：时间 + 天气 + 月相 -->
        <div class="status-bar" id="statusBar">
            <span id="timeDisplay"><?= $timeLabel ?></span>
            <span class="separator">|</span>
            <span class="moon-display" id="moonDisplay">
                <span class="moon-icon"><?= $moonSVG ?></span>
                <span class="moon-name"><?= $moonEmoji ?> <?= $moonPhase ?></span>
                <span class="moon-detail"><?= $moonDesc ?></span>
            </span>
            <span class="separator">|</span>
            <span class="weather-info" id="weatherDisplay">
                <span id="weatherIcon"><?= $weatherIcon ?></span>
                <span class="temp" id="weatherTemp"><?= $weatherTemp ?></span>
                <span id="weatherCondition"><?= $weatherCondition ?></span>
                <span style="opacity:0.5;font-size:11px;" id="weatherLocation"><?= $weatherLocation ?></span>
            </span>
        </div>
    </div>

    <script>
    // ============================================================
    // 找回密码页面 - 12时段自适应 + 天气 + 月相
    // ============================================================
    (function() {
        'use strict';

        var TIME_SLOTS = [
            { start: 0, end: 2, label: '🌙 深夜 · 万籁俱寂', bgClass: 'bg-night' },
            { start: 2, end: 5, label: '🌃 凌晨 · 星光点点', bgClass: 'bg-night' },
            { start: 5, end: 7, label: '🌅 黎明 · 东方既白', bgClass: 'bg-dawn' },
            { start: 7, end: 9, label: '🌤 早晨 · 清新晨光', bgClass: 'bg-morning' },
            { start: 9, end: 11, label: '☀️ 上午 · 阳光明媚', bgClass: 'bg-day' },
            { start: 11, end: 13, label: '🌞 中午 · 烈日当空', bgClass: 'bg-noon' },
            { start: 13, end: 15, label: '☀️ 午后 · 暖阳和煦', bgClass: 'bg-afternoon' },
            { start: 15, end: 17, label: '🌤 下午 · 斜阳微醺', bgClass: 'bg-day' },
            { start: 17, end: 19, label: '🌇 黄昏 · 落日熔金', bgClass: 'bg-sunset' },
            { start: 19, end: 21, label: '🌆 傍晚 · 华灯初上', bgClass: 'bg-dusk' },
            { start: 21, end: 23, label: '🌙 夜晚 · 月明星稀', bgClass: 'bg-night' },
            { start: 23, end: 24, label: '🌙 深夜 · 夜深人静', bgClass: 'bg-night' }
        ];

        function getCurrentTimeSlot() {
            var now = new Date();
            var hours = now.getHours();
            var minutes = now.getMinutes();
            var totalMinutes = hours * 60 + minutes;
            
            for (var i = 0; i < TIME_SLOTS.length; i++) {
                var slot = TIME_SLOTS[i];
                var startMin = slot.start * 60;
                var endMin = slot.end * 60;
                
                if (slot.end < slot.start) {
                    if (totalMinutes >= startMin || totalMinutes < endMin) {
                        return slot;
                    }
                } else {
                    if (totalMinutes >= startMin && totalMinutes < endMin) {
                        return slot;
                    }
                }
            }
            return TIME_SLOTS[0];
        }

        function updateTimeAndBackground() {
            var slot = getCurrentTimeSlot();
            var container = document.querySelector('.forgot-container');
            if (!container) return;
            
            var bg = document.getElementById('forgotBg');
            if (bg) {
                bg.className = 'forgot-bg ' + slot.bgClass;
            }
            
            var timeDisplay = document.getElementById('timeDisplay');
            if (timeDisplay) {
                var now = new Date();
                var hours = String(now.getHours()).padStart(2, '0');
                var minutes = String(now.getMinutes()).padStart(2, '0');
                timeDisplay.textContent = slot.label + '  ·  ' + hours + ':' + minutes;
            }
            
            var isNight = (slot.bgClass === 'bg-night' || slot.bgClass === 'bg-dusk' || slot.bgClass === 'bg-dawn');
            document.body.classList.toggle('night-mode', isNight);
        }

        function updateWeather() {
            fetch('api/weather.php')
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.success) {
                        var icon = document.getElementById('weatherIcon');
                        var temp = document.getElementById('weatherTemp');
                        var condition = document.getElementById('weatherCondition');
                        var location = document.getElementById('weatherLocation');
                        if (icon) icon.textContent = data.icon || '🌤';
                        if (temp) temp.textContent = data.temp || '--';
                        if (condition) condition.textContent = data.condition || '--';
                        if (location) location.textContent = data.location || '--';
                    }
                })
                .catch(function() {});
        }

        function updateMoon() {
            fetch('api/moon.php')
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (data.success) {
                        var moonDisplay = document.getElementById('moonDisplay');
                        if (moonDisplay) {
                            moonDisplay.innerHTML = `
                                <span class="moon-icon">${data.svg}</span>
                                <span class="moon-name">${data.phase_emoji} ${data.phase}</span>
                                <span class="moon-detail">${data.phase_desc}</span>
                            `;
                        }
                    }
                })
                .catch(function() {});
        }

        setInterval(updateTimeAndBackground, 60000);
        setInterval(updateWeather, 600000);
        setInterval(updateMoon, 3600000);
        
        updateTimeAndBackground();
        updateWeather();
        updateMoon();
    })();
    </script>
</body>
</html>