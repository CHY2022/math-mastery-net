<?php
// pages/dashboard.php - 完整修复版控制台
$user = getCurrentUser();
if (!$user) {
    header('Location: ?route=login');
    exit;
}

$pdo = getDB();
$userId = $user['id'];
$role = $user['role'];

// 获取用户自己的统计
$myStats = getUserStats($userId);

// 根据角色获取不同的数据
$students = [];
$stats = getStats();
$trend = getLearningTrend();
$roleLabel = '';

if ($role === 'admin') {
    $roleLabel = '管理员';
} elseif ($role === 'parent') {
    $roleLabel = '家长';
    // 获取绑定的孩子
    $childrenIds = [];
    if (!empty($user['children'])) {
        $childrenIds = array_filter(explode(',', $user['children']));
    }
    if (!empty($childrenIds)) {
        $placeholders = implode(',', array_fill(0, count($childrenIds), '?'));
        $stmt = $pdo->prepare("SELECT id, username, name, grade, school, training FROM users WHERE id IN ($placeholders) AND role = 'student' AND status = 'active'");
        $stmt->execute($childrenIds);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // 修复：使用普通循环，避免引用覆盖
        $studentsWithStats = [];
        foreach ($students as $s) {
            $stats = getUserStats($s['id']);
            $studentsWithStats[] = array_merge($s, ['stats' => $stats]);
        }
        $students = $studentsWithStats;
    }
} elseif ($role === 'student') {
    $roleLabel = '学生';
} elseif ($role === 'school') {
    $roleLabel = '学校';
    $orgName = $user['org_name'] ?? $user['school'] ?? '';
    
    if (empty($orgName)) {
        $stmt = $pdo->prepare("SELECT id, username, name, grade, school FROM users WHERE school_id = ? AND role = 'student' AND status = 'active'");
        $stmt->execute([$userId]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $stmt = $pdo->prepare("SELECT id, username, name, grade, school, training FROM users WHERE school = ? AND role = 'student' AND status = 'active'");
        $stmt->execute([$orgName]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($students)) {
            $stmt = $pdo->prepare("SELECT id, username, name, grade, school, training FROM users WHERE training = ? AND role = 'student' AND status = 'active'");
            $stmt->execute([$orgName]);
            $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }
    
    // 修复：使用普通循环，避免引用覆盖
    $studentsWithStats = [];
    foreach ($students as $s) {
        $stats = getUserStats($s['id']);
        $studentsWithStats[] = array_merge($s, ['stats' => $stats]);
    }
    $students = $studentsWithStats;
    
} elseif ($role === 'training') {
    $roleLabel = '培训机构';
    $orgName = $user['org_name'] ?? $user['training'] ?? '';
    
    if (empty($orgName)) {
        $stmt = $pdo->prepare("SELECT id, username, name, grade, training FROM users WHERE training_id = ? AND role = 'student' AND status = 'active'");
        $stmt->execute([$userId]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $stmt = $pdo->prepare("SELECT id, username, name, grade, school, training FROM users WHERE training = ? AND role = 'student' AND status = 'active'");
        $stmt->execute([$orgName]);
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($students)) {
            $stmt = $pdo->prepare("SELECT id, username, name, grade, school, training FROM users WHERE school = ? AND role = 'student' AND status = 'active'");
            $stmt->execute([$orgName]);
            $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    }
    
    // 修复：使用普通循环，避免引用覆盖
    $studentsWithStats = [];
    foreach ($students as $s) {
        $stats = getUserStats($s['id']);
        $studentsWithStats[] = array_merge($s, ['stats' => $stats]);
    }
    $students = $studentsWithStats;
    
} else {
    $roleLabel = '未知角色';
}

// 按年级分组统计
$gradeStats = [];
foreach ($students as $s) {
    $grade = $s['grade'] ?? '未设置';
    if (!isset($gradeStats[$grade])) {
        $gradeStats[$grade] = 0;
    }
    $gradeStats[$grade]++;
}
?>
<div>
    <input type="hidden" id="dashboard-loaded" value="true">
    
    <h2 class="section">📊 控制台</h2>
    
    <!-- 角色欢迎信息 -->
    <div class="card" style="background:linear-gradient(135deg,#eef3ff,#fff);border-color:#dbe4ff;">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
            <div>
                <span style="font-size:14px;color:#6b7280;">欢迎回来，</span>
                <span style="font-size:18px;font-weight:700;color:#1f2937;"><?= h($user['name'] ?? $user['username']) ?></span>
                <span style="margin-left:8px;background:#2f6fed;color:#fff;padding:2px 12px;border-radius:12px;font-size:12px;"><?= $roleLabel ?></span>
            </div>
            <div style="font-size:13px;color:#6b7280;">
                角色：<?= $role ?> | ID：<?= $userId ?>
            </div>
        </div>
    </div>

    <!-- ============================================================ -->
    <!-- 学生控制台 -->
    <!-- ============================================================ -->
    <?php if ($role === 'student'): ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:16px;">
        <div class="card" style="text-align:center;padding:14px;">
            <div style="font-size:26px;font-weight:800;color:#2f6fed;"><?= $myStats['learn_count'] ?? 0 ?></div>
            <div style="font-size:12px;color:#6b7280;">📖 学习次数</div>
        </div>
        <div class="card" style="text-align:center;padding:14px;">
            <div style="font-size:26px;font-weight:800;color:#16a34a;"><?= $myStats['practice_count'] ?? 0 ?></div>
            <div style="font-size:12px;color:#6b7280;">✏️ 练习次数</div>
        </div>
        <div class="card" style="text-align:center;padding:14px;">
            <div style="font-size:26px;font-weight:800;color:#7c3aed;"><?= $myStats['passed_gates'] ?? 0 ?></div>
            <div style="font-size:12px;color:#6b7280;">🏆 通关数</div>
        </div>
        <div class="card" style="text-align:center;padding:14px;">
            <div style="font-size:26px;font-weight:800;color:#dc2626;"><?= $myStats['weak_count'] ?? 0 ?></div>
            <div style="font-size:12px;color:#6b7280;">📌 薄弱点</div>
        </div>
    </div>

    <div class="card">
        <h3>👤 我的信息</h3>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
            <div><span style="color:#6b7280;">姓名：</span><strong><?= h($user['name'] ?? '未设置') ?></strong></div>
            <div><span style="color:#6b7280;">用户名：</span><strong><?= h($user['username']) ?></strong></div>
            <div><span style="color:#6b7280;">年级：</span><strong><?= h($user['grade'] ?? '未设置') ?></strong></div>
            <div><span style="color:#6b7280;">学校：</span><strong><?= h($user['school'] ?? '未设置') ?></strong></div>
            <div><span style="color:#6b7280;">培训机构：</span><strong><?= h($user['training'] ?? '未设置') ?></strong></div>
            <div><span style="color:#6b7280;">邮箱：</span><strong><?= h($user['email']) ?></strong></div>
        </div>
    </div>

    <!-- ============================================================ -->
    <!-- 管理员控制台 -->
    <!-- ============================================================ -->
    <?php elseif ($role === 'admin'): ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:16px;">
        <div class="card" style="text-align:center;padding:14px;">
            <div style="font-size:26px;font-weight:800;color:#2f6fed;"><?= $stats['total_users'] ?? 0 ?></div>
            <div style="font-size:12px;color:#6b7280;">总用户数</div>
        </div>
        <div class="card" style="text-align:center;padding:14px;">
            <div style="font-size:26px;font-weight:800;color:#16a34a;"><?= $stats['active_users'] ?? 0 ?></div>
            <div style="font-size:12px;color:#6b7280;">活跃用户</div>
        </div>
        <div class="card" style="text-align:center;padding:14px;">
            <div style="font-size:26px;font-weight:800;color:#2f6fed;"><?= $stats['role_student'] ?? 0 ?></div>
            <div style="font-size:12px;color:#6b7280;">学生</div>
        </div>
        <div class="card" style="text-align:center;padding:14px;">
            <div style="font-size:26px;font-weight:800;color:#d97706;"><?= $stats['role_parent'] ?? 0 ?></div>
            <div style="font-size:12px;color:#6b7280;">家长</div>
        </div>
        <div class="card" style="text-align:center;padding:14px;">
            <div style="font-size:26px;font-weight:800;color:#7c3aed;"><?= ($stats['role_school'] ?? 0) + ($stats['role_training'] ?? 0) ?></div>
            <div style="font-size:12px;color:#6b7280;">学校/培训机构</div>
        </div>
        <div class="card" style="text-align:center;padding:14px;">
            <div style="font-size:26px;font-weight:800;color:#dc2626;"><?= $stats['total_weak'] ?? 0 ?></div>
            <div style="font-size:12px;color:#6b7280;">薄弱点总数</div>
        </div>
    </div>

    <div class="card">
        <h3>📈 近7天学习趋势</h3>
        <div style="display:flex;align-items:flex-end;gap:6px;height:100px;padding:8px 0;">
            <?php 
            $maxCount = 1;
            foreach ($trend as $item) {
                if ($item['count'] > $maxCount) $maxCount = $item['count'];
            }
            foreach ($trend as $item): 
            ?>
            <div style="flex:1;display:flex;flex-direction:column;align-items:center;">
                <div style="height:<?= max(4, ($item['count'] / max(1, $maxCount)) * 90) ?>px;width:100%;background:#2f6fed;border-radius:3px 3px 0 0;min-height:4px;"></div>
                <span style="font-size:10px;color:#6b7280;margin-top:3px;"><?= substr($item['date'], 5) ?></span>
                <span style="font-size:10px;font-weight:600;"><?= $item['count'] ?></span>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- ============================================================ -->
    <!-- 家长控制台 -->
    <!-- ============================================================ -->
    <?php elseif ($role === 'parent'): ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:16px;">
        <div class="card" style="text-align:center;padding:14px;">
            <div style="font-size:26px;font-weight:800;color:#2f6fed;"><?= count($students) ?></div>
            <div style="font-size:12px;color:#6b7280;">👶 已绑定孩子</div>
        </div>
        <?php 
        $totalLearn = 0;
        $totalWeak = 0;
        foreach ($students as $s) {
            $totalLearn += $s['stats']['learn_count'] ?? 0;
            $totalWeak += $s['stats']['weak_count'] ?? 0;
        }
        ?>
        <div class="card" style="text-align:center;padding:14px;">
            <div style="font-size:26px;font-weight:800;color:#16a34a;"><?= $totalLearn ?></div>
            <div style="font-size:12px;color:#6b7280;">📖 总学习次数</div>
        </div>
        <div class="card" style="text-align:center;padding:14px;">
            <div style="font-size:26px;font-weight:800;color:#dc2626;"><?= $totalWeak ?></div>
            <div style="font-size:12px;color:#6b7280;">📌 总薄弱点</div>
        </div>
    </div>

    <?php if (empty($students)): ?>
    <div class="card" style="text-align:center;padding:24px;">
        <div style="font-size:42px;margin-bottom:8px;">👶</div>
        <h3 style="margin:0 0 6px 0;">还没有绑定孩子</h3>
        <p style="color:#6b7280;">绑定孩子后，即可查看孩子的学习情况。</p>
        <button class="btn" onclick="showBindChild()" style="margin-top:10px;">➕ 绑定孩子</button>
    </div>
    <?php else: ?>
    <div class="card">
        <h3>👶 孩子的学习情况</h3>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;">
            <?php foreach ($students as $s): ?>
            <div style="border:1px solid #e5e7eb;border-radius:8px;padding:14px;">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;">
                    <div>
                        <span style="font-weight:700;font-size:15px;"><?= h($s['name'] ?? $s['username']) ?></span>
                        <span style="color:#6b7280;font-size:12px;margin-left:8px;"><?= h($s['grade'] ?? '未设置年级') ?></span>
                    </div>
                    <span style="font-size:11px;color:#6b7280;">@<?= h($s['username']) ?></span>
                </div>
                <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:10px;">
                    <div style="text-align:center;background:#f8fafc;border-radius:4px;padding:4px;">
                        <div style="font-size:16px;font-weight:700;color:#2f6fed;"><?= $s['stats']['learn_count'] ?? 0 ?></div>
                        <div style="font-size:10px;color:#6b7280;">学习</div>
                    </div>
                    <div style="text-align:center;background:#f8fafc;border-radius:4px;padding:4px;">
                        <div style="font-size:16px;font-weight:700;color:#16a34a;"><?= $s['stats']['practice_count'] ?? 0 ?></div>
                        <div style="font-size:10px;color:#6b7280;">练习</div>
                    </div>
                    <div style="text-align:center;background:#f8fafc;border-radius:4px;padding:4px;">
                        <div style="font-size:16px;font-weight:700;color:#7c3aed;"><?= $s['stats']['passed_gates'] ?? 0 ?></div>
                        <div style="font-size:10px;color:#6b7280;">通关</div>
                    </div>
                    <div style="text-align:center;background:#f8fafc;border-radius:4px;padding:4px;">
                        <div style="font-size:16px;font-weight:700;color:#dc2626;"><?= $s['stats']['weak_count'] ?? 0 ?></div>
                        <div style="font-size:10px;color:#6b7280;">薄弱点</div>
                    </div>
                </div>
                <div style="margin-top:8px;display:flex;gap:4px;flex-wrap:wrap;">
                    <button class="btn sm ghost" onclick="viewChild('<?= $s['id'] ?>', 'learning')">📚 学习路径</button>
                    <button class="btn sm ghost" onclick="viewChild('<?= $s['id'] ?>', 'review')">🔍 薄弱点</button>
                    <button class="btn sm ghost" onclick="viewChild('<?= $s['id'] ?>', 'progress')">📈 进度</button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- ============================================================ -->
    <!-- 学校/培训机构控制台（含分页、排序、搜索） -->
    <!-- ============================================================ -->
    <?php elseif ($role === 'school' || $role === 'training'): ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:16px;">
        <div class="card" style="text-align:center;padding:14px;">
            <div style="font-size:26px;font-weight:800;color:#2f6fed;"><?= count($students) ?></div>
            <div style="font-size:12px;color:#6b7280;">📚 下属学生总数</div>
        </div>
        <?php foreach ($gradeStats as $g => $count): ?>
        <div class="card" style="text-align:center;padding:14px;">
            <div style="font-size:26px;font-weight:800;color:#16a34a;"><?= $count ?></div>
            <div style="font-size:12px;color:#6b7280;"><?= h($g) ?></div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="card">
        <h3>🏢 机构信息</h3>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
            <div><span style="color:#6b7280;">机构名称：</span><strong><?= h($user['org_name'] ?? '未设置') ?></strong></div>
            <div><span style="color:#6b7280;">类型：</span><strong><?= $role === 'school' ? '学校' : '培训机构' ?></strong></div>
            <?php 
            $orgLevels = json_decode($user['org_levels'] ?? '[]', true);
            if (!empty($orgLevels)):
            ?>
            <div style="grid-column:1/-1;"><span style="color:#6b7280;">机构层级：</span>
                <?php foreach ($orgLevels as $level): ?>
                <span class="tag"><?= h($level) ?></span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if (empty($students)): ?>
    <div class="card" style="text-align:center;padding:24px;">
        <div style="font-size:42px;margin-bottom:8px;">📚</div>
        <h3 style="margin:0 0 6px 0;">还没有学生</h3>
        <p style="color:#6b7280;">目前还没有学生关联到您的<?= $role === 'school' ? '学校' : '培训机构' ?>。</p>
        <p style="color:#6b7280;font-size:13px;">请确保学生注册时填写了您的机构名称。</p>
    </div>
    <?php else: ?>
    <div class="card">
        <h3>📚 下属学生列表</h3>
        
        <!-- ========== 搜索、排序、分页控制 ========== -->
        <div style="display:flex;flex-wrap:wrap;gap:10px;margin-bottom:12px;padding:10px;background:#f8fafc;border-radius:8px;align-items:center;">
            <div style="flex:2;min-width:150px;">
                <input type="text" id="studentSearchInput" placeholder="🔍 搜索用户名或姓名..." style="width:100%;padding:6px 10px;border:1px solid #d1d5db;border-radius:6px;font-size:13px;" oninput="filterStudents()">
            </div>
            <div style="display:flex;align-items:center;gap:6px;">
                <label style="font-size:12px;color:#6b7280;">排序：</label>
                <select id="studentSortSelect" onchange="filterStudents()" style="padding:5px 8px;border:1px solid #d1d5db;border-radius:6px;font-size:13px;">
                    <option value="name_asc">姓名 ↑</option>
                    <option value="name_desc">姓名 ↓</option>
                    <option value="weak_asc">薄弱点 ↑（少→多）</option>
                    <option value="weak_desc">薄弱点 ↓（多→少）</option>
                    <option value="learn_asc">学习次数 ↑</option>
                    <option value="learn_desc">学习次数 ↓</option>
                </select>
            </div>
            <div style="display:flex;align-items:center;gap:6px;">
                <label style="font-size:12px;color:#6b7280;">显示：</label>
                <select id="studentPerPageSelect" onchange="filterStudents()" style="padding:5px 8px;border:1px solid #d1d5db;border-radius:6px;font-size:13px;">
                    <option value="5">5条</option>
                    <option value="10" selected>10条</option>
                    <option value="20">20条</option>
                    <option value="50">50条</option>
                    <option value="9999">全部</option>
                </select>
            </div>
        </div>
        
        <!-- ========== 学生表格 ========== -->
        <div style="overflow-x:auto;">
            <table style="width:100%;border-collapse:collapse;font-size:13px;">
                <thead>
                    <tr style="border-bottom:2px solid #e5e7eb;">
                        <th style="text-align:left;padding:8px 10px;">#</th>
                        <th style="text-align:left;padding:8px 10px;">姓名</th>
                        <th style="text-align:left;padding:8px 10px;">用户名</th>
                        <th style="text-align:left;padding:8px 10px;">年级</th>
                        <th style="text-align:center;padding:8px 10px;">📖学习</th>
                        <th style="text-align:center;padding:8px 10px;">✏️练习</th>
                        <th style="text-align:center;padding:8px 10px;">🏆通关</th>
                        <th style="text-align:center;padding:8px 10px;">📌薄弱点</th>
                        <th style="text-align:center;padding:8px 10px;">操作</th>
                    </tr>
                </thead>
                <tbody id="studentTableBody">
                    <?php 
                    $index = 0;
                    foreach ($students as $s): 
                        $index++;
                        $studentId = (int)($s['id'] ?? 0);
                        $studentName = htmlspecialchars($s['name'] ?? $s['username'] ?? '未知');
                        $studentUsername = htmlspecialchars($s['username'] ?? '未知');
                        $studentGrade = htmlspecialchars($s['grade'] ?? '未设置');
                        $stats = $s['stats'] ?? ['learn_count' => 0, 'practice_count' => 0, 'passed_gates' => 0, 'weak_count' => 0];
                    ?>
                    <tr class="student-row" data-student-id="<?= $studentId ?>" data-index="<?= $index ?>" data-name="<?= $studentName ?>" data-username="<?= $studentUsername ?>" data-weak="<?= (int)($stats['weak_count'] ?? 0) ?>" data-learn="<?= (int)($stats['learn_count'] ?? 0) ?>" style="border-bottom:1px solid #f1f3f5;">
                        <td style="padding:8px 10px;color:#6b7280;"><?= $index ?></td>
                        <td style="padding:8px 10px;font-weight:600;"><?= $studentName ?></td>
                        <td style="padding:8px 10px;color:#6b7280;"><?= $studentUsername ?></td>
                        <td style="padding:8px 10px;"><?= $studentGrade ?></td>
                        <td style="text-align:center;padding:8px 10px;color:#2f6fed;font-weight:600;"><?= (int)($stats['learn_count'] ?? 0) ?></td>
                        <td style="text-align:center;padding:8px 10px;color:#16a34a;font-weight:600;"><?= (int)($stats['practice_count'] ?? 0) ?></td>
                        <td style="text-align:center;padding:8px 10px;color:#7c3aed;font-weight:600;"><?= (int)($stats['passed_gates'] ?? 0) ?></td>
                        <td style="text-align:center;padding:8px 10px;color:#dc2626;font-weight:600;"><?= (int)($stats['weak_count'] ?? 0) ?></td>
                        <td style="text-align:center;padding:8px 10px;">
                            <button class="btn sm ghost" onclick="viewStudent(<?= $studentId ?>, 'learning')" title="学习路径">📚</button>
                            <button class="btn sm ghost" onclick="viewStudent(<?= $studentId ?>, 'review')" title="薄弱点">🔍</button>
                            <button class="btn sm ghost" onclick="viewStudent(<?= $studentId ?>, 'progress')" title="进度">📈</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <!-- ========== 分页控件 ========== -->
        <div id="paginationControls" style="display:flex;flex-wrap:wrap;gap:6px;justify-content:center;align-items:center;margin-top:12px;padding-top:12px;border-top:1px solid #e5e7eb;">
            <button class="btn sm ghost" onclick="goToPage(1)" id="pageFirst">⏮ 首页</button>
            <button class="btn sm ghost" onclick="goToPage(currentPage - 1)" id="pagePrev">◀ 上一页</button>
            <span id="pageInfo" style="font-size:13px;color:#6b7280;">第 1 / 1 页</span>
            <button class="btn sm ghost" onclick="goToPage(currentPage + 1)" id="pageNext">下一页 ▶</button>
            <button class="btn sm ghost" onclick="goToPage(totalPages)" id="pageLast">尾页 ⏭</button>
            <span style="font-size:13px;color:#6b7280;">跳至</span>
            <input type="number" id="pageJumpInput" min="1" style="width:50px;padding:4px 6px;border:1px solid #d1d5db;border-radius:4px;font-size:13px;text-align:center;">
            <button class="btn sm" onclick="goToPage(parseInt(document.getElementById('pageJumpInput').value))">跳转</button>
            <span id="totalRecordsInfo" style="font-size:12px;color:#6b7280;margin-left:8px;">共 0 条记录</span>
        </div>
    </div>
    <?php endif; ?>

    <?php else: ?>
    <!-- 未知角色 -->
    <div class="card" style="text-align:center;padding:24px;">
        <div style="font-size:42px;margin-bottom:8px;">⚠️</div>
        <h3 style="margin:0 0 6px 0;">未知角色</h3>
        <p style="color:#6b7280;">您的角色 (<?= h($role) ?>) 暂不支持控制台显示，请联系管理员。</p>
    </div>
    <?php endif; ?>

    <!-- 快捷入口 -->
    <div class="card">
        <h3>🚀 快捷入口</h3>
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <?php if ($role === 'student'): ?>
            <a href="?route=learning" class="btn" style="background:#2f6fed;">📚 学习路径</a>
            <a href="?route=review" class="btn" style="background:#d97706;">🔍 薄弱点复习</a>
            <a href="?route=progress" class="btn" style="background:#7c3aed;">📈 我的进度</a>
            <?php elseif ($role === 'parent' && !empty($students)): ?>
            <button class="btn" style="background:#2f6fed;" onclick="viewChild('<?= $students[0]['id'] ?>', 'learning')">📚 查看孩子学习</button>
            <button class="btn" style="background:#d97706;" onclick="viewChild('<?= $students[0]['id'] ?>', 'review')">🔍 查看薄弱点</button>
            <button class="btn" style="background:#7c3aed;" onclick="viewChild('<?= $students[0]['id'] ?>', 'progress')">📈 查看进度</button>
            <?php elseif (($role === 'school' || $role === 'training') && !empty($students)): ?>
            <button class="btn" style="background:#2f6fed;" onclick="viewStudent('<?= $students[0]['id'] ?>', 'learning')">📚 查看学生学习</button>
            <button class="btn" style="background:#d97706;" onclick="viewStudent('<?= $students[0]['id'] ?>', 'review')">🔍 查看薄弱点</button>
            <button class="btn" style="background:#7c3aed;" onclick="viewStudent('<?= $students[0]['id'] ?>', 'progress')">📈 查看进度</button>
            <?php else: ?>
            <a href="?route=profile" class="btn" style="background:#16a34a;">👤 个人信息</a>
            <?php endif; ?>
            <a href="?route=profile" class="btn ghost">👤 个人信息</a>
            <a href="?route=help" class="btn ghost">❓ 帮助</a>
        </div>
    </div>
</div>

<script>
// ============================================================
// 家长查看孩子
// ============================================================
function viewChild(childId, type) {
    window.location.href = '?route=' + type + '&child_id=' + childId;
}

// ============================================================
// 学校/培训机构查看学生
// ============================================================
function viewStudent(studentId, type) {
    if (!studentId || studentId === '0') {
        alert('❌ 错误：学生ID无效');
        return;
    }
    console.log('📚 查看学生 ID: ' + studentId + ', 类型: ' + type);
    window.location.href = '?route=' + type + '&student_id=' + studentId;
}

// ============================================================
// 学校/培训机构 - 学生列表分页、排序、搜索
// ============================================================
var allRows = [];
var currentPage = 1;
var perPage = 10;
var totalPages = 1;
var filteredRows = [];

function initStudentTable() {
    var rows = document.querySelectorAll('.student-row');
    allRows = [];
    
    console.log('🔍 找到 ' + rows.length + ' 个学生行');
    
    rows.forEach(function(row, idx) {
        var tds = row.querySelectorAll('td');
        var name = tds[1] ? tds[1].textContent.trim() : '';
        var username = tds[2] ? tds[2].textContent.trim() : '';
        var weak = tds[7] ? parseInt(tds[7].textContent.trim()) || 0 : 0;
        var learn = tds[4] ? parseInt(tds[4].textContent.trim()) || 0 : 0;
        var studentId = row.dataset.studentId || '0';
        
        console.log('  行 ' + idx + ': ID=' + studentId + ', 姓名=' + name + ', 用户名=' + username);
        
        allRows.push({
            element: row,
            name: name,
            username: username,
            weak: weak,
            learn: learn,
            studentId: studentId,
            index: parseInt(row.dataset.index) || idx + 1
        });
    });
    
    var perPageSelect = document.getElementById('studentPerPageSelect');
    if (perPageSelect) {
        perPage = parseInt(perPageSelect.value) || 10;
    }
    filterStudents();
}

function filterStudents() {
    var searchInput = document.getElementById('studentSearchInput');
    var keyword = searchInput ? searchInput.value.toLowerCase().trim() : '';
    
    filteredRows = allRows.filter(function(row) {
        if (!keyword) return true;
        var name = (row.name || '').toLowerCase();
        var username = (row.username || '').toLowerCase();
        return name.indexOf(keyword) > -1 || username.indexOf(keyword) > -1;
    });
    
    var sortSelect = document.getElementById('studentSortSelect');
    var sortBy = sortSelect ? sortSelect.value : 'name_asc';
    filteredRows.sort(function(a, b) {
        switch(sortBy) {
            case 'name_asc': return (a.name || '').localeCompare(b.name || '');
            case 'name_desc': return (b.name || '').localeCompare(a.name || '');
            case 'weak_asc': return a.weak - b.weak;
            case 'weak_desc': return b.weak - a.weak;
            case 'learn_asc': return a.learn - b.learn;
            case 'learn_desc': return b.learn - a.learn;
            default: return 0;
        }
    });
    
    var perPageSelect = document.getElementById('studentPerPageSelect');
    if (perPageSelect) {
        perPage = parseInt(perPageSelect.value) || 10;
    }
    
    totalPages = Math.ceil(filteredRows.length / perPage);
    if (totalPages < 1) totalPages = 1;
    if (currentPage > totalPages) currentPage = totalPages;
    if (currentPage < 1) currentPage = 1;
    
    renderPage();
}

function renderPage() {
    allRows.forEach(function(row) {
        row.element.style.display = 'none';
    });
    
    var start = (currentPage - 1) * perPage;
    var end = Math.min(start + perPage, filteredRows.length);
    
    console.log('📄 显示第 ' + currentPage + ' 页，行 ' + start + ' 到 ' + (end - 1));
    
    for (var i = start; i < end; i++) {
        if (filteredRows[i]) {
            filteredRows[i].element.style.display = '';
            var td = filteredRows[i].element.querySelector('td:first-child');
            if (td) td.textContent = i + 1;
        }
    }
    
    var pageInfo = document.getElementById('pageInfo');
    if (pageInfo) {
        pageInfo.textContent = '第 ' + currentPage + ' / ' + totalPages + ' 页';
    }
    
    var totalRecordsInfo = document.getElementById('totalRecordsInfo');
    if (totalRecordsInfo) {
        totalRecordsInfo.textContent = '共 ' + filteredRows.length + ' 条记录';
    }
    
    var pageFirst = document.getElementById('pageFirst');
    var pagePrev = document.getElementById('pagePrev');
    var pageNext = document.getElementById('pageNext');
    var pageLast = document.getElementById('pageLast');
    
    if (pageFirst) pageFirst.disabled = (currentPage <= 1);
    if (pagePrev) pagePrev.disabled = (currentPage <= 1);
    if (pageNext) pageNext.disabled = (currentPage >= totalPages);
    if (pageLast) pageLast.disabled = (currentPage >= totalPages);
    
    var jumpInput = document.getElementById('pageJumpInput');
    if (jumpInput) {
        jumpInput.value = currentPage;
        jumpInput.max = totalPages;
    }
}

function goToPage(page) {
    if (page < 1) page = 1;
    if (page > totalPages) page = totalPages;
    currentPage = page;
    renderPage();
}

// ============================================================
// 页面初始化
// ============================================================
document.addEventListener('DOMContentLoaded', function() {
    initStudentTable();
    
    var jumpInput = document.getElementById('pageJumpInput');
    if (jumpInput) {
        jumpInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                var page = parseInt(this.value);
                if (!isNaN(page) && page >= 1 && page <= totalPages) {
                    goToPage(page);
                } else {
                    alert('请输入有效的页码（1-' + totalPages + '）');
                }
            }
        });
    }
});

// 标记 dashboard 已加载
(function() {
    window.__IS_DASHBOARD = true;
    var view = document.getElementById('view');
    if (view) {
        var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    mutation.addedNodes.forEach(function(node) {
                        if (node.nodeType === 1) {
                            var h2 = node.querySelector('h2.section');
                            if (h2 && h2.textContent === '学习路径') {
                                window.location.reload();
                            }
                        }
                    });
                }
            });
        });
        observer.observe(view, { childList: true, subtree: true });
    }
})();
</script>