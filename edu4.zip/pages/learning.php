<?php
// pages/learning.php - 支持查看孩子/学生的学习路径（完整版）
$user = getCurrentUser();
if (!$user) {
    header('Location: ?route=login');
    exit;
}

$pdo = getDB();
$userId = $user['id'];
$viewingUserId = $userId;
$viewingRole = $user['role'];
$viewingName = $user['name'] ?? $user['username'];
$viewingGrade = '';

// 如果是学校/培训机构查看学生
if (isset($_GET['student_id']) && ($user['role'] === 'school' || $user['role'] === 'training')) {
    $studentId = (int)$_GET['student_id'];
    $orgName = $user['org_name'] ?? '';
    
    $stmt = $pdo->prepare("SELECT id, username, name, role, grade FROM users WHERE id = ? AND role = 'student' AND status = 'active' AND (school = ? OR training = ?)");
    $stmt->execute([$studentId, $orgName, $orgName]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($student) {
        $viewingUserId = $studentId;
        $viewingRole = 'student';
        $viewingName = $student['name'] ?? $student['username'];
        $viewingGrade = $student['grade'] ?? '';
    } else {
        header('Location: ?route=dashboard');
        exit;
    }
}

// 家长查看孩子
if (isset($_GET['child_id']) && $user['role'] === 'parent') {
    $childId = (int)$_GET['child_id'];
    $childrenIds = !empty($user['children']) ? explode(',', $user['children']) : [];
    if (in_array($childId, $childrenIds)) {
        $stmt = $pdo->prepare("SELECT id, username, name, role, grade FROM users WHERE id = ? AND role = 'student' AND status = 'active'");
        $stmt->execute([$childId]);
        $child = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($child) {
            $viewingUserId = $childId;
            $viewingRole = 'student';
            $viewingName = $child['name'] ?? $child['username'];
            $viewingGrade = $child['grade'] ?? '';
        }
    }
}

// 获取当前用户的年级（如果是学生自己查看）
if ($viewingUserId === $user['id'] && $user['role'] === 'student') {
    $viewingGrade = $user['grade'] ?? '';
} elseif (!isset($viewingGrade)) {
    $viewingGrade = '';
}

// ============================================================
// 【修复】如果 $viewingGrade 为空，从数据库补查
// ============================================================
if (empty($viewingGrade)) {
    $stmt = $pdo->prepare("SELECT grade FROM users WHERE id = ?");
    $stmt->execute([$viewingUserId]);
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($userData && !empty($userData['grade'])) {
        $viewingGrade = $userData['grade'];
        error_log("📌 从数据库补查年级: $viewingGrade (用户ID: $viewingUserId)");
    }
}

// 如果还是空，强制使用默认年级
if (empty($viewingGrade)) {
    $viewingGrade = '六年级';
    error_log("📌 使用默认年级: $viewingGrade");
}

// 如果是查看他人，在session中标记
if ($viewingUserId !== $user['id']) {
    $_SESSION['viewing_user_id'] = $viewingUserId;
    $_SESSION['viewing_user_name'] = $viewingName;
} else {
    unset($_SESSION['viewing_user_id']);
    unset($_SESSION['viewing_user_name']);
}

// ============================================================
// 获取用户进度数据（从数据库加载）
// ============================================================
$progress = [];

// 1. 获取已掌握的技巧
$stmt = $pdo->prepare("
    SELECT DISTINCT technique_id 
    FROM learning_records 
    WHERE user_id = ? AND action = 'mastered'
");
$stmt->execute([$viewingUserId]);
$masteredRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($masteredRows as $r) {
    $progress[$r['technique_id']] = ['mastered' => true];
}

// 2. 获取 gate 记录（如果有 gate 但没有 mastered，自动补录）
$stmt = $pdo->prepare("
    SELECT technique_id, COUNT(*) as gate_count
    FROM learning_records 
    WHERE user_id = ? AND action = 'gate' AND score >= 80
    GROUP BY technique_id
");
$stmt->execute([$viewingUserId]);
$gateRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($gateRows as $r) {
    if (!isset($progress[$r['technique_id']]) || !$progress[$r['technique_id']]['mastered']) {
        $stmt2 = $pdo->prepare("SELECT COUNT(*) FROM learning_records WHERE user_id = ? AND technique_id = ? AND action = 'mastered'");
        $stmt2->execute([$viewingUserId, $r['technique_id']]);
        if ($stmt2->fetchColumn() == 0) {
            $stmt3 = $pdo->prepare("INSERT INTO learning_records (user_id, technique_id, action, score) 
                                    VALUES (?, ?, 'mastered', 100)");
            $stmt3->execute([$viewingUserId, $r['technique_id']]);
        }
        $progress[$r['technique_id']] = ['mastered' => true];
    }
}

// 3. 获取薄弱点
$stmt = $pdo->prepare("
    SELECT technique_id, COUNT(*) as weak_count 
    FROM weak_points 
    WHERE user_id = ? AND cleared = FALSE 
    GROUP BY technique_id
");
$stmt->execute([$viewingUserId]);
$weakRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($weakRows as $r) {
    if (!isset($progress[$r['technique_id']])) {
        $progress[$r['technique_id']] = ['mastered' => false];
    }
    $progress[$r['technique_id']]['weak_count'] = (int)$r['weak_count'];
}

// 4. 获取学习统计
$stmt = $pdo->prepare("
    SELECT technique_id, 
           COUNT(CASE WHEN action = 'learn' THEN 1 END) as learn_count,
           COUNT(CASE WHEN action = 'practice' THEN 1 END) as practice_count,
           COUNT(CASE WHEN action = 'gate' THEN 1 END) as gate_count
    FROM learning_records 
    WHERE user_id = ? 
    GROUP BY technique_id
");
$stmt->execute([$viewingUserId]);
$statsRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($statsRows as $r) {
    if (!isset($progress[$r['technique_id']])) {
        $progress[$r['technique_id']] = ['mastered' => false];
    }
    $progress[$r['technique_id']]['learn_count'] = (int)$r['learn_count'];
    $progress[$r['technique_id']]['practice_count'] = (int)$r['practice_count'];
    $progress[$r['technique_id']]['gate_count'] = (int)$r['gate_count'];
}

// 5. 确保所有技巧都有记录
if (isset($GLOBALS['TECHNIQUES'])) {
    foreach ($GLOBALS['TECHNIQUES'] as $t) {
        if (!isset($progress[$t['id']])) {
            $progress[$t['id']] = ['mastered' => false];
        }
    }
}

$progressJson = json_encode($progress);
?>
<div>
    <input type="hidden" id="dashboard-loaded" value="true">
    
    <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;margin-bottom:12px;">
        <h2 class="section" style="margin:0;">
            📚 学习路径
            <?php if ($viewingUserId !== $user['id']): ?>
            <span style="font-size:14px;color:#6b7280;font-weight:400;"> - 查看 <strong><?= h($viewingName) ?></strong> 的学习路径</span>
            <?php endif; ?>
            <?php if ($viewingGrade): ?>
            <span style="font-size:14px;color:#6b7280;font-weight:400;margin-left:8px;">（当前年级：<strong><?= h($viewingGrade) ?></strong>）</span>
            <?php endif; ?>
        </h2>
    </div>
    
    <!-- ============================================================
    二级联动筛选器
    ============================================================ -->
    <div class="filter-bar" style="display:flex;flex-wrap:wrap;gap:10px;padding:10px 14px;background:#f8fafc;border-radius:8px;margin-bottom:14px;border:1px solid #e5e7eb;align-items:center;">
        <span style="font-size:13px;font-weight:600;color:#1f2937;margin-right:4px;">📌 筛选：</span>
        
        <!-- 阶段筛选 -->
        <div style="display:flex;gap:4px;flex-wrap:wrap;align-items:center;">
            <span style="font-size:12px;color:#6b7280;">阶段：</span>
            <button class="filter-btn filter-stage" data-stage="all" style="padding:4px 14px;border-radius:16px;border:1px solid #d1d5db;background:#fff;color:#1f2937;font-size:12px;cursor:pointer;transition:0.2s;">全部</button>
            <button class="filter-btn filter-stage" data-stage="小学" style="padding:4px 14px;border-radius:16px;border:1px solid #d1d5db;background:#fff;color:#1f2937;font-size:12px;cursor:pointer;transition:0.2s;">小学</button>
            <button class="filter-btn filter-stage" data-stage="中学" style="padding:4px 14px;border-radius:16px;border:1px solid #d1d5db;background:#fff;color:#1f2937;font-size:12px;cursor:pointer;transition:0.2s;">中学</button>
            <button class="filter-btn filter-stage" data-stage="高中" style="padding:4px 14px;border-radius:16px;border:1px solid #d1d5db;background:#fff;color:#1f2937;font-size:12px;cursor:pointer;transition:0.2s;">高中</button>
        </div>
        
        <!-- 年级筛选（联动） -->
        <div style="display:flex;gap:4px;flex-wrap:wrap;align-items:center;">
            <span style="font-size:12px;color:#6b7280;">年级：</span>
            <div id="gradeFilterContainer" style="display:flex;gap:4px;flex-wrap:wrap;">
                <!-- 由 JavaScript 动态生成 -->
            </div>
        </div>
        
        <?php if ($viewingGrade): ?>
        <button class="filter-btn" id="resetToGradeBtn" style="padding:4px 14px;border-radius:16px;border:1px solid #d97706;background:#fef3c7;color:#d97706;font-size:12px;cursor:pointer;transition:0.2s;">↩ 回到我的年级</button>
        <?php endif; ?>
    </div>
    
    <div class="hint">
        按 小学 → 中学 → 高中 排列，细分到年级。小学各年级、中学各年级：年级内顺序解锁。高中各年级（大学先修）：所有技巧均可直接进入。
        <?php if ($viewingUserId !== $user['id']): ?>
        <br>💡 当前正在查看 <strong><?= h($viewingName) ?></strong> 的学习进度
        <?php endif; ?>
    </div>
    
    <div id="learningPath">
        <div style="text-align:center;padding:40px;color:#6b7280;">加载中...</div>
    </div>
</div>

<script>
// 阻止 app_main.js 自动渲染（避免覆盖 learning.php 的筛选渲染）
window.__SKIP_APP_MAIN_RENDER = true;
console.log('📌 设置 __SKIP_APP_MAIN_RENDER = true，app_main.js 的 renderPath 将被跳过');
// ============================================================
// 1. 定义进度数据
// ============================================================
window.__PROGRESS_DATA = <?= $progressJson ?>;
window.VIEWING_USER_ID = <?= (int)$viewingUserId ?>;
window.VIEWING_USER_NAME = '<?= addslashes($viewingName) ?>';
window.IS_VIEWING_OTHER = <?= $viewingUserId !== $user['id'] ? 'true' : 'false' ?>;

// 【硬性】直接从 PHP 传入默认年级
window.DEFAULT_GRADE = '<?= addslashes($viewingGrade) ?>';
window.DEFAULT_STAGE = '';

// 根据默认年级确定默认阶段
var defaultStage = '';
if (window.DEFAULT_GRADE) {
    var grade = window.DEFAULT_GRADE;
    if (['一年级','二年级','三年级','四年级','五年级','六年级'].indexOf(grade) !== -1) {
        defaultStage = '小学';
    } else if (['七年级','八年级','九年级'].indexOf(grade) !== -1) {
        defaultStage = '中学';
    } else if (['十年级','十一年级','十一年级+','十二年级','十二年级+','大学先锋'].indexOf(grade) !== -1) {
        defaultStage = '高中';
    }
}
window.DEFAULT_STAGE = defaultStage;

console.log('📌 DEFAULT_GRADE:', window.DEFAULT_GRADE);
console.log('📌 DEFAULT_STAGE:', window.DEFAULT_STAGE);

// ============================================================
// 2. 筛选状态
// ============================================================
var filterStage = window.DEFAULT_STAGE || 'all';
var filterGrade = window.DEFAULT_GRADE || 'all';

console.log('📌 初始 filterStage:', filterStage);
console.log('📌 初始 filterGrade:', filterGrade);

// ============================================================
// 3. 从 TECHNIQUES 动态生成年级列表
// ============================================================
function getStageGrades() {
    var result = { '小学': [], '中学': [], '高中': [] };
    if (typeof TECHNIQUES === 'undefined' || !TECHNIQUES.length) {
        return result;
    }
    TECHNIQUES.forEach(function(t) {
        if (t.stage && t.grade) {
            if (result[t.stage].indexOf(t.grade) === -1) {
                result[t.stage].push(t.grade);
            }
        }
    });
    // 排序
    var gradeOrder = ['一','二','三','四','五','六','七','八','九','十','十一','十二'];
    for (var stage in result) {
        result[stage].sort(function(a, b) {
            var aNum = 0, bNum = 0;
            gradeOrder.forEach(function(g, i) {
                if (a.indexOf(g) !== -1) aNum = i + 1;
                if (b.indexOf(g) !== -1) bNum = i + 1;
            });
            if (a.indexOf('+') > -1) aNum += 0.5;
            if (b.indexOf('+') > -1) bNum += 0.5;
            if (a.indexOf('大学先锋') > -1) aNum = 13;
            if (b.indexOf('大学先锋') > -1) bNum = 13;
            return aNum - bNum;
        });
    }
    return result;
}

// ============================================================
// 4. 渲染学习路径
// ============================================================
function renderLearningPath() {
    var container = document.getElementById('learningPath');
    if (!container) return;
    
    if (typeof TECHNIQUES === 'undefined' || !TECHNIQUES.length) {
        setTimeout(renderLearningPath, 300);
        return;
    }
    
    var progress = window.__PROGRESS_DATA || {};
    var techs = TECHNIQUES || [];
    var stages = ['小学', '中学', '高中'];
    var groups = {};
    
    // 根据筛选条件过滤技巧
    var filteredTechs = techs.filter(function(t) {
        if (filterStage !== 'all' && t.stage !== filterStage) return false;
        if (filterGrade !== 'all' && t.grade !== filterGrade) return false;
        return true;
    });
    
    console.log('📌 筛选后技巧数:', filteredTechs.length, 'filterStage:', filterStage, 'filterGrade:', filterGrade);
    
    if (!filteredTechs.length) {
        container.innerHTML = '<div class="empty" style="padding:40px;text-align:center;color:#6b7280;">没有匹配的技巧</div>';
        return;
    }
    
    filteredTechs.forEach(function(t) {
        var key = t.stage + '|' + t.grade;
        if (!groups[key]) groups[key] = [];
        groups[key].push(t);
    });
    
    var html = '';
    stages.forEach(function(stage) {
        var gradeSet = {};
        var grades = [];
        filteredTechs.forEach(function(t) {
            if (t.stage === stage && !gradeSet[t.grade]) {
                gradeSet[t.grade] = true;
                grades.push(t.grade);
            }
        });
        grades.sort(function(a, b) {
            var num = {'一':1,'二':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9,'十':10,'十一':11,'十二':12};
            var aNum = num[a[0]] || 99;
            var bNum = num[b[0]] || 99;
            if (a.indexOf('+') > -1) aNum += 0.5;
            if (b.indexOf('+') > -1) bNum += 0.5;
            if (a.indexOf('大学先锋') > -1) aNum = 13;
            if (b.indexOf('大学先锋') > -1) bNum = 13;
            return aNum - bNum;
        });
        if (!grades.length) return;
        
        html += '<div class="stage-banner"><span class="stage-name">' + stage + '</span></div>';
        
        grades.forEach(function(g) {
            var items = groups[stage + '|' + g] || [];
            
            var totalCount = items.length;
            var masteredCount = 0;
            items.forEach(function(t) {
                var st = progress[t.id] || { mastered: false };
                if (st.mastered) masteredCount++;
            });
            var pct = totalCount > 0 ? Math.round(masteredCount / totalCount * 100) : 0;
            var pctDisplay = pct + '%';
            var progressBarColor = pct === 100 ? '#16a34a' : (pct >= 50 ? '#d97706' : '#2f6fed');
            
            html += '<div class="grade-sep" style="display:flex;align-items:center;flex-wrap:wrap;gap:6px 12px;margin:18px 0 6px;font-weight:700;font-size:14px;border-left:4px solid #2f6fed;padding-left:8px;">';
            html += '<span class="grade-tag" style="font-weight:700;color:#2f6fed;font-size:14px;">' + g + '</span>';
            html += '<span class="grade-count" style="font-size:12px;color:#6b7280;font-weight:400;margin-left:4px;">' + items.length + ' 个技巧</span>';
            html += '<span class="grade-progress" style="display:inline-flex;align-items:center;gap:8px;font-size:12px;color:#6b7280;margin-left:auto;">';
            html += '<span class="grade-progress-text" style="font-weight:500;white-space:nowrap;">已掌握 ' + masteredCount + '/' + totalCount + '（' + pctDisplay + '）</span>';
            html += '<span class="grade-progress-bar" style="width:80px;height:6px;background:#e5e7eb;border-radius:4px;overflow:hidden;display:inline-block;flex-shrink:0;">';
            html += '<span style="display:block;height:100%;width:' + pct + '%;background:' + progressBarColor + ';border-radius:4px;transition:width 0.6s ease;"></span>';
            html += '</span>';
            html += '</span>';
            html += '</div>';
            
            var stepNo = 0;
            items.forEach(function(t) {
                stepNo++;
                var st = progress[t.id] || { mastered: false, weak: {} };
                var isLocked = t.prereq && (!progress[t.prereq] || !progress[t.prereq].mastered);
                var status = isLocked ? 'lock' : (st.mastered ? 'done' : 'learn');
                var weakN = 0;
                if (st.weak) {
                    for (var k in st.weak) {
                        if (!st.weak[k].cleared) weakN++;
                    }
                }
                
                var prereqTech = null;
                if (t.prereq) {
                    for (var p = 0; p < techs.length; p++) {
                        if (techs[p].id === t.prereq) { prereqTech = techs[p]; break; }
                    }
                }
                
                html += '<div class="node ' + (status === 'done' ? 'mastered' : status === 'lock' ? 'locked' : '') + '" id="node-' + t.id + '">';
                html += '<div class="step">' + (status === 'done' ? '✓' : (status === 'lock' ? '🔒' : stepNo)) + '</div>';
                html += '<div class="body">';
                html += '<div class="title">' + t.name;
                if (status === 'lock') html += '<span class="lock-ico">🔒</span>';
                html += '<span class="status-pill ' + status + '">' + (status === 'lock' ? '未解锁' : status === 'done' ? '已掌握' : '学习中') + '</span>';
                if (weakN) html += '<span class="tag w">薄弱点 ' + weakN + '</span>';
                html += '</div>';
                html += '<div class="meta">' + (t.summary || '') + '</div>';
                html += '<div class="acts">';
                if (status !== 'lock') html += '<a class="btn sm" href="#/learn/' + t.id + '">去学习</a>';
                if (status !== 'lock') html += '<a class="btn sm ghost" href="#/practice/' + t.id + '">练习</a>';
                if (status !== 'lock' && !st.mastered) html += '<a class="btn sm soft" href="#/gate/' + t.id + '">通关测试</a>';
                html += '</div>';
                if (status === 'lock' && t.prereq) {
                    html += '<div class="meta" style="color:var(--lock)">需先掌握：' + (prereqTech ? prereqTech.name : t.prereq) + '</div>';
                }
                html += '</div></div>';
            });
        });
    });
    
    container.innerHTML = html;
    
    container.querySelectorAll('.acts a[data-tech-id]').forEach(function(link) {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            var href = this.getAttribute('href');
            var techId = this.getAttribute('data-tech-id');
            var action = this.getAttribute('data-action');
            if (window.AppMain && window.AppMain.handleHashRoute) {
                window.AppMain.handleHashRoute(href, techId, action);
            } else {
                window.location.hash = href;
            }
        });
    });
}

// ============================================================
// 5. 更新年级按钮（根据选中的阶段）
// ============================================================
function updateGradeButtons(selectedStage) {
    var container = document.getElementById('gradeFilterContainer');
    if (!container) return;
    
    console.log('📌 updateGradeButtons, selectedStage:', selectedStage);
    
    var stageGrades = getStageGrades();
    var grades = [];
    if (selectedStage === 'all') {
        var allGradesSet = {};
        for (var stage in stageGrades) {
            stageGrades[stage].forEach(function(g) {
                if (!allGradesSet[g]) {
                    allGradesSet[g] = true;
                    grades.push(g);
                }
            });
        }
        var gradeOrder = ['一','二','三','四','五','六','七','八','九','十','十一','十二'];
        grades.sort(function(a, b) {
            var aNum = 0, bNum = 0;
            gradeOrder.forEach(function(g, i) {
                if (a.indexOf(g) !== -1) aNum = i + 1;
                if (b.indexOf(g) !== -1) bNum = i + 1;
            });
            if (a.indexOf('+') > -1) aNum += 0.5;
            if (b.indexOf('+') > -1) bNum += 0.5;
            if (a.indexOf('大学先锋') > -1) aNum = 13;
            if (b.indexOf('大学先锋') > -1) bNum = 13;
            return aNum - bNum;
        });
    } else {
        grades = stageGrades[selectedStage] || [];
    }
    
    console.log('📌 生成的年级列表:', grades);
    
    var html = '';
    html += '<button class="filter-btn filter-grade" data-grade="all" style="padding:4px 14px;border-radius:16px;border:1px solid #d1d5db;background:#fff;color:#1f2937;font-size:12px;cursor:pointer;transition:0.2s;">全部</button>';
    grades.forEach(function(g) {
        var isDefault = (g === window.DEFAULT_GRADE && selectedStage === window.DEFAULT_STAGE);
        var bgColor = isDefault ? '#2f6fed' : '#fff';
        var textColor = isDefault ? '#fff' : '#1f2937';
        html += '<button class="filter-btn filter-grade" data-grade="' + g + '" style="padding:4px 14px;border-radius:16px;border:1px solid #d1d5db;background:' + bgColor + ';color:' + textColor + ';font-size:12px;cursor:pointer;transition:0.2s;">' + g + '</button>';
    });
    container.innerHTML = html;
    
    // 绑定年级按钮事件
    var gradeBtns = container.querySelectorAll('.filter-grade');
    gradeBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var value = this.dataset.grade;
            
            gradeBtns.forEach(function(b) {
                b.style.background = '#fff';
                b.style.color = '#1f2937';
                b.classList.remove('active');
            });
            this.style.background = '#2f6fed';
            this.style.color = '#fff';
            this.classList.add('active');
            
            filterGrade = value;
            console.log('📌 年级筛选变为:', filterGrade);
            renderLearningPath();
        });
    });
}

// ============================================================
// 6. 筛选器事件绑定
// ============================================================
function initFilters() {
    var stageBtns = document.querySelectorAll('.filter-stage');
    stageBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var value = this.dataset.stage;
            
            stageBtns.forEach(function(b) {
                b.style.background = '#fff';
                b.style.color = '#1f2937';
                b.classList.remove('active');
            });
            this.style.background = '#2f6fed';
            this.style.color = '#fff';
            this.classList.add('active');
            
            filterStage = value;
            console.log('📌 阶段筛选变为:', filterStage);
            
            // 更新年级按钮
            updateGradeButtons(value);
            
            // 【关键】切换阶段时，强制 filterGrade = all
            filterGrade = 'all';
            console.log('📌 切换阶段，年级强制重置为: all');
            
            // 高亮"全部"年级按钮
            var gradeBtns = document.querySelectorAll('.filter-grade');
            gradeBtns.forEach(function(b) {
                b.style.background = '#fff';
                b.style.color = '#1f2937';
                b.classList.remove('active');
                if (b.dataset.grade === 'all') {
                    b.style.background = '#2f6fed';
                    b.style.color = '#fff';
                    b.classList.add('active');
                }
            });
            
            renderLearningPath();
        });
    });
    
    var resetBtn = document.getElementById('resetToGradeBtn');
    if (resetBtn) {
        resetBtn.addEventListener('click', function() {
            if (window.DEFAULT_GRADE) {
                var targetStage = window.DEFAULT_STAGE || 'all';
                
                // 重置阶段按钮
                var stageBtns = document.querySelectorAll('.filter-stage');
                stageBtns.forEach(function(b) {
                    b.style.background = '#fff';
                    b.style.color = '#1f2937';
                    b.classList.remove('active');
                    if (b.dataset.stage === targetStage) {
                        b.style.background = '#2f6fed';
                        b.style.color = '#fff';
                        b.classList.add('active');
                    }
                });
                filterStage = targetStage;
                
                // 更新年级按钮
                updateGradeButtons(targetStage);
                
                // 高亮默认年级
                var gradeBtns = document.querySelectorAll('.filter-grade');
                gradeBtns.forEach(function(b) {
                    b.style.background = '#fff';
                    b.style.color = '#1f2937';
                    b.classList.remove('active');
                    if (b.dataset.grade === window.DEFAULT_GRADE) {
                        b.style.background = '#2f6fed';
                        b.style.color = '#fff';
                        b.classList.add('active');
                    }
                });
                filterGrade = window.DEFAULT_GRADE;
                
                console.log('📌 回到我的年级:', filterGrade);
                renderLearningPath();
            }
        });
    }
}

// ============================================================
// 7. 页面加载完成后渲染
// ============================================================
(function() {
    function init() {
        console.log('🔥 初始化开始');
        console.log('📌 DEFAULT_GRADE:', window.DEFAULT_GRADE);
        console.log('📌 DEFAULT_STAGE:', window.DEFAULT_STAGE);
        
        if (typeof TECHNIQUES !== 'undefined' && TECHNIQUES.length) {
            // 【硬性设置】强制使用默认年级作为筛选条件
            var initialStage = window.DEFAULT_STAGE || 'all';
            var initialGrade = window.DEFAULT_GRADE || 'all';
            
            filterStage = initialStage;
            filterGrade = initialGrade;
            
            console.log('📌 强制设置 filterStage:', filterStage);
            console.log('📌 强制设置 filterGrade:', filterGrade);
            
            // 初始化年级按钮
            updateGradeButtons(initialStage);
            
            // 【硬性高亮】高亮默认阶段
            var stageBtns = document.querySelectorAll('.filter-stage');
            stageBtns.forEach(function(b) {
                b.style.background = '#fff';
                b.style.color = '#1f2937';
                b.classList.remove('active');
                if (b.dataset.stage === initialStage) {
                    b.style.background = '#2f6fed';
                    b.style.color = '#fff';
                    b.classList.add('active');
                }
            });
            
            // 【硬性高亮】高亮默认年级
            if (window.DEFAULT_GRADE) {
                var gradeBtns = document.querySelectorAll('.filter-grade');
                gradeBtns.forEach(function(b) {
                    b.style.background = '#fff';
                    b.style.color = '#1f2937';
                    b.classList.remove('active');
                    if (b.dataset.grade === window.DEFAULT_GRADE) {
                        b.style.background = '#2f6fed';
                        b.style.color = '#fff';
                        b.classList.add('active');
                    }
                });
            }
            
            // 渲染
            renderLearningPath();
            initFilters();
        } else {
            console.log('⏳ TECHNIQUES 未加载，等待...');
            setTimeout(init, 300);
        }
    }
    
    if (document.readyState === 'complete') {
        init();
    } else {
        document.addEventListener('DOMContentLoaded', init);
    }
})();

window.renderLearningPath = renderLearningPath;
window.updateGradeButtons = updateGradeButtons;
</script>