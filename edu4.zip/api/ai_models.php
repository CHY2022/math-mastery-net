<?php
// api/ai_models.php - AI 模型 API
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

$user = getCurrentUser();
if (!$user) {
    echo json_encode(['success' => false, 'error' => '未登录']);
    exit;
}

$action = $_GET['action'] ?? '';

if ($action === 'get') {
    $id = (int)($_GET['id'] ?? 0);
    if (!$id) {
        echo json_encode(['success' => false, 'error' => '模型ID不能为空']);
        exit;
    }
    
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT id, name, api_url, model, api_key, is_default FROM user_ai_models WHERE id = ? AND user_id = ?");
    $stmt->execute([$id, $user['id']]);
    $model = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($model) {
        // 隐藏 api_key 的完整值（只显示部分）
        if (!empty($model['api_key'])) {
            $model['api_key'] = '********' . substr($model['api_key'], -4);
        }
        echo json_encode(['success' => true, 'model' => $model]);
    } else {
        echo json_encode(['success' => false, 'error' => '模型不存在']);
    }
    exit;
}

echo json_encode(['success' => false, 'error' => '未知操作']);