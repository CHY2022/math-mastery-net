<?php
// api/ai_chat.php - AI 聊天 API
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

$user = getCurrentUser();
if (!$user) {
    echo json_encode(['success' => false, 'error' => '未登录']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? '';

if ($action === 'chat') {
    $modelId = $data['model_id'] ?? 0;
    $messages = $data['messages'] ?? [];
    
    if (empty($messages)) {
        echo json_encode(['success' => false, 'error' => '消息不能为空']);
        exit;
    }
    
    $pdo = getDB();
    
    // 获取模型配置
    $stmt = $pdo->prepare("SELECT * FROM user_ai_models WHERE id = ? AND user_id = ?");
    $stmt->execute([$modelId, $user['id']]);
    $model = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$model) {
        // 如果用户没有保存该模型，尝试使用默认系统配置
        $stmt = $pdo->prepare("SELECT * FROM user_ai_models WHERE user_id = ? AND is_default = 1 LIMIT 1");
        $stmt->execute([$user['id']]);
        $model = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$model) {
            echo json_encode(['success' => false, 'error' => '请先在模型设置中添加并选择模型']);
            exit;
        }
    }
    
    if (empty($model['api_key'])) {
        echo json_encode(['success' => false, 'error' => '该模型未配置 API Key，请在模型设置中配置']);
        exit;
    }
    
    // 调用 AI API
    $result = callAIApi($model, $messages);
    echo json_encode($result);
    exit;
}

echo json_encode(['success' => false, 'error' => '未知操作']);

/**
 * 调用 AI API
 */
function callAIApi($model, $messages) {
    $apiUrl = $model['api_url'];
    $apiKey = $model['api_key'];
    $modelName = $model['model'];
    
    // 构建请求体
    $payload = [
        'model' => $modelName,
        'messages' => $messages,
        'stream' => false,
        'max_tokens' => 4096,
        'temperature' => 0.7
    ];
    
    $ch = curl_init($apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 120);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        return ['success' => false, 'error' => 'CURL 错误: ' . $error];
    }
    
    if ($httpCode !== 200) {
        return ['success' => false, 'error' => 'API 返回错误 (HTTP ' . $httpCode . '): ' . substr($response, 0, 200)];
    }
    
    $data = json_decode($response, true);
    if (!$data) {
        return ['success' => false, 'error' => '解析响应失败: ' . substr($response, 0, 200)];
    }
    
    if (isset($data['error'])) {
        $errMsg = $data['error']['message'] ?? json_encode($data['error']);
        return ['success' => false, 'error' => 'API 错误: ' . $errMsg];
    }
    
    $content = $data['choices'][0]['message']['content'] ?? '';
    if (empty($content)) {
        return ['success' => false, 'error' => 'AI 返回空响应'];
    }
    
    return ['success' => true, 'response' => $content];
}