<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? '';

switch ($action) {
    case 'logout':
        session_destroy();
        echo json_encode(['success' => true]);
        break;
        
    case 'check':
        $user = getCurrentUser();
        if ($user) {
            echo json_encode(['success' => true, 'user' => ['id' => $user['id'], 'username' => $user['username'], 'role' => $user['role']]]);
        } else {
            echo json_encode(['success' => false]);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => '未知操作']);
}