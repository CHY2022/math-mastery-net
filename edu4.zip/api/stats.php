<?php
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

$user = getCurrentUser();
if (!$user) {
    echo json_encode(['success' => false, 'error' => '未登录']);
    exit;
}

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'overview':
        $stats = getStats();
        echo json_encode(['success' => true, 'data' => $stats]);
        break;
        
    case 'trend':
        $trend = getLearningTrend();
        echo json_encode(['success' => true, 'data' => $trend]);
        break;
        
    case 'user':
        $userId = $_GET['user_id'] ?? $user['id'];
        $stats = getUserLearningStats($userId);
        echo json_encode(['success' => true, 'data' => $stats]);
        break;
        
    case 'students':
        if ($user['role'] === 'parent' || $user['role'] === 'school' || $user['role'] === 'training') {
            $students = getBoundStudents($user['id']);
            $result = [];
            foreach ($students as $student) {
                $result[] = array_merge($student, getUserLearningStats($student['id']));
            }
            echo json_encode(['success' => true, 'data' => $result]);
        } else {
            echo json_encode(['success' => false, 'error' => '无权限']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => '未知操作']);
}