<?php
// api/users.php - 修复用户管理API
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

// 检查登录
$user = getCurrentUser();
if (!$user || $user['role'] !== 'admin') {
    echo json_encode(['success' => false, 'error' => '无权限']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

$pdo = getDB();

// GET 请求处理
if ($method === 'GET') {
    $action = $_GET['action'] ?? '';
    
    if ($action === 'get') {
        $userId = (int)($_GET['id'] ?? 0);
        if (!$userId) {
            echo json_encode(['success' => false, 'error' => '用户ID不能为空']);
            exit;
        }
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $userData = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($userData) {
            echo json_encode(['success' => true, 'data' => $userData]);
        } else {
            echo json_encode(['success' => false, 'error' => '用户不存在']);
        }
        exit;
    }
    
    // 获取用户列表
    $users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'data' => $users]);
    exit;
}

// POST 请求处理
if ($method === 'POST') {
    switch ($action) {
        case 'add':
            $username = trim($data['username'] ?? '');
            $name = trim($data['name'] ?? '');
            $email = trim($data['email'] ?? '');
            $role = $data['role'] ?? 'student';
            $gender = $data['gender'] ?? '保密';
            $password = $data['password'] ?? '';
            
            // 验证
            if (empty($username) || strlen($username) < 3) {
                echo json_encode(['success' => false, 'error' => '用户名至少3个字符']);
                break;
            }
            if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo json_encode(['success' => false, 'error' => '请输入有效的邮箱地址']);
                break;
            }
            if (empty($password) || strlen($password) < 6) {
                echo json_encode(['success' => false, 'error' => '密码至少6个字符']);
                break;
            }
            
            // 检查用户名或邮箱是否已存在
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            if ($stmt->fetchColumn() > 0) {
                echo json_encode(['success' => false, 'error' => '用户名或邮箱已存在']);
                break;
            }
            
            // 根据角色获取额外字段
            $extraFields = getExtraFieldsForRole($role, $data);
            
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            
            $sql = "INSERT INTO users (
                username, password, email, role, name, gender, status,
                child_school, child_training, child_grade, phone,
                school, training, grade, parent_phone,
                org_name, org_levels, admin_phone
            ) VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $params = [
                $username, $passwordHash, $email, $role, $name, $gender,
                $extraFields['child_school'] ?? '',
                $extraFields['child_training'] ?? '',
                $extraFields['child_grade'] ?? '',
                $extraFields['phone'] ?? '',
                $extraFields['school'] ?? '',
                $extraFields['training'] ?? '',
                $extraFields['grade'] ?? '',
                $extraFields['parent_phone'] ?? '',
                $extraFields['org_name'] ?? '',
                $extraFields['org_levels'] ?? '[]',
                $extraFields['admin_phone'] ?? ''
            ];
            
            try {
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                echo json_encode(['success' => true, 'id' => $pdo->lastInsertId(), 'message' => '用户添加成功']);
            } catch (PDOException $e) {
                echo json_encode(['success' => false, 'error' => '添加失败：' . $e->getMessage()]);
            }
            break;
            
        case 'update':
            $userId = (int)($data['userId'] ?? 0);
            if (!$userId) {
                echo json_encode(['success' => false, 'error' => '用户ID不能为空']);
                break;
            }
            
            $name = trim($data['name'] ?? '');
            $email = trim($data['email'] ?? '');
            $gender = $data['gender'] ?? '保密';
            $password = $data['password'] ?? '';
            $role = $data['role'] ?? '';
            
            // 检查用户是否存在
            $stmt = $pdo->prepare("SELECT id, role FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $targetUser = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$targetUser) {
                echo json_encode(['success' => false, 'error' => '用户不存在']);
                break;
            }
            
            // 验证邮箱
            if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo json_encode(['success' => false, 'error' => '请输入有效的邮箱地址']);
                break;
            }
            if (!empty($password) && strlen($password) < 6) {
                echo json_encode(['success' => false, 'error' => '密码至少6个字符']);
                break;
            }
            
            $updates = [];
            $params = [];
            
            if ($name) {
                $updates[] = "name = ?";
                $params[] = $name;
            }
            if ($email) {
                $updates[] = "email = ?";
                $params[] = $email;
            }
            if ($gender) {
                $updates[] = "gender = ?";
                $params[] = $gender;
            }
            
            // 角色 - 只有管理员可以修改角色，且不能修改自己的角色
            if ($role && $userId != $user['id']) {
                $updates[] = "role = ?";
                $params[] = $role;
            }
            
            if (!empty($password)) {
                $updates[] = "password = ?";
                $params[] = password_hash($password, PASSWORD_DEFAULT);
            }
            
            // 根据角色获取额外字段
            $targetRole = $role ?: $targetUser['role'];
            $extraFields = getExtraFieldsForRole($targetRole, $data);
            
            // 更新额外字段
            $fieldMap = [
                'student' => ['school', 'training', 'grade', 'parent_phone'],
                'parent' => ['child_school', 'child_training', 'child_grade', 'phone'],
                'school' => ['org_name', 'org_levels', 'admin_phone'],
                'training' => ['org_name', 'org_levels', 'admin_phone']
            ];
            
            if (isset($fieldMap[$targetRole])) {
                foreach ($fieldMap[$targetRole] as $field) {
                    if (isset($extraFields[$field])) {
                        $updates[] = "$field = ?";
                        $params[] = $extraFields[$field];
                    }
                }
            }
            
            if (empty($updates)) {
                echo json_encode(['success' => false, 'error' => '没有要更新的字段']);
                break;
            }
            
            $params[] = $userId;
            $sql = "UPDATE users SET " . implode(', ', $updates) . " WHERE id = ?";
            try {
                $pdo->prepare($sql)->execute($params);
                echo json_encode(['success' => true]);
            } catch (PDOException $e) {
                if (strpos($e->getMessage(), 'Duplicate') !== false) {
                    echo json_encode(['success' => false, 'error' => '邮箱已被其他用户使用']);
                } else {
                    echo json_encode(['success' => false, 'error' => '更新失败：' . $e->getMessage()]);
                }
            }
            break;
            
        case 'delete':
            $userId = (int)($data['userId'] ?? 0);
            if (!$userId) {
                echo json_encode(['success' => false, 'error' => '用户ID不能为空']);
                break;
            }
            if ($userId == $user['id']) {
                echo json_encode(['success' => false, 'error' => '不能删除自己']);
                break;
            }
            $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$userId]);
            echo json_encode(['success' => true]);
            break;
            
        case 'toggle':
            $userId = (int)($data['userId'] ?? 0);
            if (!$userId) {
                echo json_encode(['success' => false, 'error' => '用户ID不能为空']);
                break;
            }
            if ($userId == $user['id']) {
                echo json_encode(['success' => false, 'error' => '不能停用自己']);
                break;
            }
            $stmt = $pdo->prepare("SELECT status FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row) {
                $newStatus = $row['status'] === 'active' ? 'inactive' : 'active';
                $pdo->prepare("UPDATE users SET status = ? WHERE id = ?")->execute([$newStatus, $userId]);
                echo json_encode(['success' => true, 'status' => $newStatus]);
            } else {
                echo json_encode(['success' => false, 'error' => '用户不存在']);
            }
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => '未知操作']);
    }
}

/**
 * 根据角色获取额外字段
 */
function getExtraFieldsForRole($role, $data) {
    $fields = [];
    
    switch ($role) {
        case 'student':
            $fields['school'] = trim($data['school'] ?? '');
            $fields['training'] = trim($data['training'] ?? '');
            $fields['grade'] = trim($data['grade'] ?? '');
            $fields['parent_phone'] = trim($data['parent_phone'] ?? '');
            break;
        case 'parent':
            $fields['child_school'] = trim($data['child_school'] ?? '');
            $fields['child_training'] = trim($data['child_training'] ?? '');
            $fields['child_grade'] = trim($data['child_grade'] ?? '');
            $fields['phone'] = trim($data['phone'] ?? '');
            break;
        case 'school':
        case 'training':
            $fields['org_name'] = trim($data['org_name'] ?? '');
            $orgLevels = isset($data['org_levels']) ? $data['org_levels'] : ['小学'];
            if (!is_array($orgLevels)) $orgLevels = ['小学'];
            $fields['org_levels'] = json_encode($orgLevels);
            $fields['admin_phone'] = trim($data['admin_phone'] ?? '');
            break;
        default:
            break;
    }
    
    return $fields;
}
?>