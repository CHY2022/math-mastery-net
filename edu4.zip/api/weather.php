<?php
// api/weather.php - 获取天气信息（供前端AJAX调用）
require_once '../config/database.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

$weather = getUserWeather();

echo json_encode([
    'success' => true,
    'icon' => $weather['icon'] ?? '🌤',
    'temp' => $weather['temp'] ?? '--',
    'condition' => $weather['condition'] ?? '--',
    'location' => $weather['location'] ?? '--',
    'wind' => $weather['wind'] ?? '--',
    'humidity' => $weather['humidity'] ?? '--'
]);