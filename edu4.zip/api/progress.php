<?php
// api/progress.php - 支持指定用户ID查看进度，完整记录学习行为
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

$user = getCurrentUser();
if (!$user) {
    echo json_encode(['success' => false, 'error' => '未登录']);
    exit;
}

$pdo = getDB();
$userId = $user['id'];

// 支持查看指定用户（家长/学校/培训机构查看孩子/学生）
$targetUserId = isset($_GET['user_id']) ? (int)$_GET['user_id'] : $userId;

// 如果请求的是其他用户，验证权限
if ($targetUserId !== $userId) {
    $targetUser = getUserFull($targetUserId);
    if (!$targetUser || $targetUser['role'] !== 'student') {
        echo json_encode(['success' => false, 'error' => '只能查看学生用户']);
        exit;
    }
    
    $hasPermission = false;
    
    if ($user['role'] === 'parent') {
        $childrenIds = !empty($user['children']) ? explode(',', $user['children']) : [];
        if (in_array($targetUserId, $childrenIds)) {
            $hasPermission = true;
        }
    }
    
    if ($user['role'] === 'school' || $user['role'] === 'training') {
        $schoolName = $user['org_name'] ?? $user['school'] ?? '';
        $trainingName = $user['org_name'] ?? $user['training'] ?? '';
        if ($targetUser['school'] === $schoolName || $targetUser['training'] === $trainingName) {
            $hasPermission = true;
        }
    }
    
    if (!$hasPermission) {
        echo json_encode(['success' => false, 'error' => '无权限查看该用户']);
        exit;
    }
}

$method = $_SERVER['REQUEST_METHOD'];

// POST 请求处理
if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $action = $data['action'] ?? '';
    
    // 记录学习行为
    if ($action === 'record_learn') {
        $techniqueId = $data['technique_id'] ?? '';
        $userId = $data['user_id'] ?? $targetUserId;
        
        if ($techniqueId) {
            logLearning($userId, $techniqueId, 'learn', 0, 0);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => '缺少技巧ID']);
        }
        exit;
    }
    
    // 记录答题
    if ($action === 'record_answer') {
        $techniqueId = $data['technique_id'] ?? '';
        $actionType = $data['action_type'] ?? '';
        $score = $data['score'] ?? 0;
        $isCorrect = $data['is_correct'] ?? false;
        $questionIdx = $data['question_idx'] ?? '';
        $userId = $data['user_id'] ?? $targetUserId;
        
        if ($techniqueId && $actionType) {
            logLearning($userId, $techniqueId, $actionType, $score, 0);
            
            if ($questionIdx !== '') {
                if ($isCorrect) {
                    $stmt = $pdo->prepare("UPDATE weak_points SET cleared = TRUE WHERE user_id = ? AND technique_id = ? AND question_idx = ?");
                    $stmt->execute([$userId, $techniqueId, $questionIdx]);
                } else {
                    $stmt = $pdo->prepare("INSERT INTO weak_points (user_id, technique_id, question_idx, fail_count, cleared) 
                                           VALUES (?, ?, ?, 1, FALSE) 
                                           ON DUPLICATE KEY UPDATE fail_count = fail_count + 1, cleared = FALSE");
                    $stmt->execute([$userId, $techniqueId, $questionIdx]);
                }
            }
            
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => '参数不完整']);
        }
        exit;
    }
    
    // 通关完成 (mastered)
    if ($action === 'mastered') {
        $techniqueId = $data['technique_id'] ?? '';
        $score = $data['score'] ?? 100;
        $userId = $data['user_id'] ?? $targetUserId;
        
        error_log("📌 mastered 操作: technique_id=$techniqueId, user_id=$userId, score=$score");
        
        if ($techniqueId) {
            // 检查是否已存在 mastered 记录
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM learning_records WHERE user_id = ? AND technique_id = ? AND action = 'mastered'");
            $stmt->execute([$userId, $techniqueId]);
            $exists = $stmt->fetchColumn();
            
            if (!$exists) {
                // 插入 mastered 记录
                $stmt = $pdo->prepare("INSERT INTO learning_records (user_id, technique_id, action, score) 
                                       VALUES (?, ?, 'mastered', ?)");
                $result = $stmt->execute([$userId, $techniqueId, $score]);
                error_log("✅ 插入 mastered 记录: " . ($result ? '成功' : '失败'));
            } else {
                error_log("⚠️ mastered 记录已存在，跳过插入");
            }
            
            // 清除该技巧的所有薄弱点
            $stmt = $pdo->prepare("UPDATE weak_points SET cleared = TRUE WHERE user_id = ? AND technique_id = ?");
            $stmt->execute([$userId, $techniqueId]);
            
            echo json_encode(['success' => true, 'message' => '通关记录已保存']);
        } else {
            echo json_encode(['success' => false, 'error' => '缺少技巧ID']);
        }
        exit;
    }
    
    // 复习操作 (review)
    if ($action === 'review') {
        $weakId = $data['weak_id'] ?? 0;
        $isCorrect = $data['is_correct'] ?? false;
        $reviewUserId = $data['user_id'] ?? $targetUserId;
        
        if ($isCorrect) {
            $stmt = $pdo->prepare("UPDATE weak_points SET cleared = TRUE WHERE id = ? AND user_id = ?");
            $stmt->execute([$weakId, $reviewUserId]);
            echo json_encode(['success' => true, 'cleared' => true]);
        } else {
            $stmt = $pdo->prepare("UPDATE weak_points SET fail_count = fail_count + 1 WHERE id = ? AND user_id = ?");
            $stmt->execute([$weakId, $reviewUserId]);
            echo json_encode(['success' => true, 'cleared' => false]);
        }
        exit;
    }
    
    // 更新进度 (update)
    if ($action === 'update') {
        echo json_encode(['success' => true]);
        exit;
    }
    
    echo json_encode(['success' => false, 'error' => '未知操作']);
    exit;
}

// GET 请求 - 获取进度
$stmt = $pdo->prepare("
    SELECT technique_id, 
           MAX(CASE WHEN action = 'mastered' THEN 1 ELSE 0 END) as mastered,
           COUNT(CASE WHEN action = 'practice' THEN 1 END) as practice_count,
           COUNT(CASE WHEN action = 'learn' THEN 1 END) as learn_count,
           AVG(CASE WHEN action = 'gate' AND score >= 80 THEN score END) as gate_avg
    FROM learning_records 
    WHERE user_id = ? 
    GROUP BY technique_id
");
$stmt->execute([$targetUserId]);
$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("SELECT technique_id, question_idx, fail_count, cleared FROM weak_points WHERE user_id = ?");
$stmt->execute([$targetUserId]);
$weak = $stmt->fetchAll(PDO::FETCH_ASSOC);

$progress = [];
foreach ($records as $r) {
    $progress[$r['technique_id']] = [
        'mastered' => (bool)$r['mastered'],
        'practice_count' => (int)$r['practice_count'],
        'learn_count' => (int)$r['learn_count'],
        'gate_avg' => round($r['gate_avg'] ?: 0, 1),
        'weak' => []
    ];
}

foreach ($weak as $w) {
    if (!isset($progress[$w['technique_id']])) {
        $progress[$w['technique_id']] = ['mastered' => false, 'weak' => []];
    }
    $progress[$w['technique_id']]['weak'][$w['question_idx']] = [
        'fails' => (int)$w['fail_count'],
        'cleared' => (bool)$w['cleared']
    ];
}

echo json_encode(['success' => true, 'data' => $progress]);