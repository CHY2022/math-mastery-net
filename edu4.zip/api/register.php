<?php
// api/register.php - 独立处理验证码发送
require_once '../config/database.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

$action = $_POST['action'] ?? '';

if ($action === 'send_code') {
    $email = $_POST['email'] ?? '';
    if (empty($email)) {
        echo json_encode(['success' => false, 'error' => '请输入邮箱']);
        exit;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'error' => '请输入有效的邮箱地址']);
        exit;
    }
    
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'error' => '该邮箱已被注册']);
        exit;
    }
    
    $code = generateCode();
    sendVerificationEmail($email, $code, 'register');
    echo json_encode(['success' => true, 'message' => '验证码已发送']);
    exit;
}

echo json_encode(['success' => false, 'error' => '未知操作']);