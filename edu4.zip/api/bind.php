<?php
// api/bind.php - 家长绑定孩子API
require_once '../config/database.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

$user = getCurrentUser();
if (!$user) {
    echo json_encode(['success' => false, 'error' => '未登录']);
    exit;
}

// 只有家长可以绑定孩子
if ($user['role'] !== 'parent') {
    echo json_encode(['success' => false, 'error' => '只有家长可以绑定孩子']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? '';

if ($action === 'bind_child') {
    $childUsername = trim($data['child_username'] ?? '');
    
    if (empty($childUsername)) {
        echo json_encode(['success' => false, 'error' => '请输入孩子用户名']);
        exit;
    }
    
    $pdo = getDB();
    
    // 查找孩子用户
    $stmt = $pdo->prepare("SELECT id, username, name FROM users WHERE username = ? AND role = 'student' AND status = 'active'");
    $stmt->execute([$childUsername]);
    $child = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$child) {
        echo json_encode(['success' => false, 'error' => '未找到该学生用户，请确认用户名正确']);
        exit;
    }
    
    // 检查是否已经绑定
    $stmt = $pdo->prepare("SELECT children FROM users WHERE id = ?");
    $stmt->execute([$user['id']]);
    $parent = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $children = [];
    if (!empty($parent['children'])) {
        $children = explode(',', $parent['children']);
    }
    
    if (in_array($child['id'], $children)) {
        echo json_encode(['success' => false, 'error' => '该孩子已经绑定过了']);
        exit;
    }
    
    // 添加绑定
    $children[] = $child['id'];
    $childrenStr = implode(',', $children);
    
    $stmt = $pdo->prepare("UPDATE users SET children = ? WHERE id = ?");
    $stmt->execute([$childrenStr, $user['id']]);
    
    echo json_encode([
        'success' => true,
        'message' => '绑定成功',
        'child' => ['id' => $child['id'], 'username' => $child['username'], 'name' => $child['name']]
    ]);
    exit;
}

echo json_encode(['success' => false, 'error' => '未知操作']);