<?php
// api/moon.php - 获取月相信息（供前端AJAX调用）
require_once '../config/database.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

$lunar = getLunarDate();

echo json_encode([
    'success' => true,
    'lunar_year' => $lunar['year'],
    'lunar_month' => $lunar['month'],
    'lunar_day' => $lunar['day'],
    'phase' => $lunar['phase'],
    'phase_emoji' => $lunar['phase_emoji'],
    'phase_icon' => $lunar['phase_icon'],
    'phase_desc' => $lunar['phase_desc'],
    'phase_detail' => $lunar['phase_detail'],
    'svg' => getMoonPhaseSVG($lunar['phase_icon'])
]);